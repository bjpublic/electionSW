﻿namespace ElecFTP
{
    partial class frmMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnExec = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkDBUP = new System.Windows.Forms.CheckBox();
            this.chkFTPUP = new System.Windows.Forms.CheckBox();
            this.chkHTTPDN = new System.Windows.Forms.CheckBox();
            this.chkFTPDN = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbLog = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.rdoManual = new System.Windows.Forms.RadioButton();
            this.rdoAuto = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgvDNFileInfo = new System.Windows.Forms.DataGridView();
            this.serverFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.localFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDNDel = new System.Windows.Forms.Button();
            this.btnDNAdd = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkPassive = new System.Windows.Forms.CheckBox();
            this.txtPasswd = new System.Windows.Forms.TextBox();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtHost = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnFTPSave = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgvHttpFileInfo = new System.Windows.Forms.DataGridView();
            this.hServerFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hLocalFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnHTTPSave = new System.Windows.Forms.Button();
            this.btnHTTPDel = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dgvUPFileInfo = new System.Windows.Forms.DataGridView();
            this.uLocalFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uServerFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnUploadDel = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.chkUPassive = new System.Windows.Forms.CheckBox();
            this.txtUPasswd = new System.Windows.Forms.TextBox();
            this.txtUUserID = new System.Windows.Forms.TextBox();
            this.txtUPort = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtUHost = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnUploadSave = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.chkSD51 = new System.Windows.Forms.CheckBox();
            this.chkSD49 = new System.Windows.Forms.CheckBox();
            this.chkSD48 = new System.Windows.Forms.CheckBox();
            this.chkSD47 = new System.Windows.Forms.CheckBox();
            this.chkSD46 = new System.Windows.Forms.CheckBox();
            this.chkSD45 = new System.Windows.Forms.CheckBox();
            this.chkSD44 = new System.Windows.Forms.CheckBox();
            this.chkSD43 = new System.Windows.Forms.CheckBox();
            this.chkSD42 = new System.Windows.Forms.CheckBox();
            this.chkSD41 = new System.Windows.Forms.CheckBox();
            this.chkSD31 = new System.Windows.Forms.CheckBox();
            this.chkSD30 = new System.Windows.Forms.CheckBox();
            this.chkSD29 = new System.Windows.Forms.CheckBox();
            this.chkSD28 = new System.Windows.Forms.CheckBox();
            this.chkSD27 = new System.Windows.Forms.CheckBox();
            this.chkSD26 = new System.Windows.Forms.CheckBox();
            this.chkSD11 = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtConnStr = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtHTTPFile3 = new System.Windows.Forms.TextBox();
            this.txtHTTPFile2 = new System.Windows.Forms.TextBox();
            this.txtHTTPFile1 = new System.Windows.Forms.TextBox();
            this.txtFTPFile = new System.Windows.Forms.TextBox();
            this.rdoHTTPFile = new System.Windows.Forms.RadioButton();
            this.rdoFTPFile = new System.Windows.Forms.RadioButton();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.lstLog = new System.Windows.Forms.ListBox();
            this.btnLogClear = new System.Windows.Forms.Button();
            this.txtMaxLine = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnExecFolder = new System.Windows.Forms.Button();
            this.btnINI = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDNFileInfo)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHttpFileInfo)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUPFileInfo)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(477, 455);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnINI);
            this.tabPage1.Controls.Add(this.btnExecFolder);
            this.tabPage1.Controls.Add(this.btnExec);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(469, 429);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Exec";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnExec
            // 
            this.btnExec.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExec.Location = new System.Drawing.Point(170, 329);
            this.btnExec.Name = "btnExec";
            this.btnExec.Size = new System.Drawing.Size(283, 79);
            this.btnExec.TabIndex = 10;
            this.btnExec.Tag = "0";
            this.btnExec.Text = "실행";
            this.btnExec.UseVisualStyleBackColor = true;
            this.btnExec.Click += new System.EventHandler(this.btnExec_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.chkDBUP);
            this.groupBox2.Controls.Add(this.chkFTPUP);
            this.groupBox2.Controls.Add(this.chkHTTPDN);
            this.groupBox2.Controls.Add(this.chkFTPDN);
            this.groupBox2.Location = new System.Drawing.Point(8, 200);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(453, 107);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Execute";
            // 
            // chkDBUP
            // 
            this.chkDBUP.AutoSize = true;
            this.chkDBUP.Location = new System.Drawing.Point(362, 50);
            this.chkDBUP.Name = "chkDBUP";
            this.chkDBUP.Size = new System.Drawing.Size(83, 16);
            this.chkDBUP.TabIndex = 3;
            this.chkDBUP.Text = "DB Update";
            this.chkDBUP.UseVisualStyleBackColor = true;
            this.chkDBUP.CheckedChanged += new System.EventHandler(this.chkDBUP_CheckedChanged);
            // 
            // chkFTPUP
            // 
            this.chkFTPUP.AutoSize = true;
            this.chkFTPUP.Location = new System.Drawing.Point(261, 50);
            this.chkFTPUP.Name = "chkFTPUP";
            this.chkFTPUP.Size = new System.Drawing.Size(90, 16);
            this.chkFTPUP.TabIndex = 2;
            this.chkFTPUP.Text = "FTP Upload";
            this.chkFTPUP.UseVisualStyleBackColor = true;
            this.chkFTPUP.CheckedChanged += new System.EventHandler(this.chkFTPUP_CheckedChanged);
            // 
            // chkHTTPDN
            // 
            this.chkHTTPDN.AutoSize = true;
            this.chkHTTPDN.Location = new System.Drawing.Point(134, 50);
            this.chkHTTPDN.Name = "chkHTTPDN";
            this.chkHTTPDN.Size = new System.Drawing.Size(116, 16);
            this.chkHTTPDN.TabIndex = 1;
            this.chkHTTPDN.Text = "HTTP Download";
            this.chkHTTPDN.UseVisualStyleBackColor = true;
            this.chkHTTPDN.CheckedChanged += new System.EventHandler(this.chkHTTPDN_CheckedChanged);
            // 
            // chkFTPDN
            // 
            this.chkFTPDN.AutoSize = true;
            this.chkFTPDN.Location = new System.Drawing.Point(16, 50);
            this.chkFTPDN.Name = "chkFTPDN";
            this.chkFTPDN.Size = new System.Drawing.Size(107, 16);
            this.chkFTPDN.TabIndex = 0;
            this.chkFTPDN.Text = "FTP Download";
            this.chkFTPDN.UseVisualStyleBackColor = true;
            this.chkFTPDN.CheckedChanged += new System.EventHandler(this.chkFTPDN_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbLog);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtTime);
            this.groupBox1.Controls.Add(this.rdoManual);
            this.groupBox1.Controls.Add(this.rdoAuto);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(8, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(453, 163);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Operation";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(193, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "(레벨 0는 로그 무출력)";
            // 
            // cbLog
            // 
            this.cbLog.FormattingEnabled = true;
            this.cbLog.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cbLog.Location = new System.Drawing.Point(140, 112);
            this.cbLog.Name = "cbLog";
            this.cbLog.Size = new System.Drawing.Size(47, 20);
            this.cbLog.TabIndex = 7;
            this.cbLog.SelectedIndexChanged += new System.EventHandler(this.cbLog_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(187, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(231, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "초 (실행종료 후 다음 실행까지 대기 시간)";
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(140, 75);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(35, 21);
            this.txtTime.TabIndex = 5;
            this.txtTime.TextChanged += new System.EventHandler(this.txtTime_TextChanged);
            // 
            // rdoManual
            // 
            this.rdoManual.AutoSize = true;
            this.rdoManual.Checked = true;
            this.rdoManual.Location = new System.Drawing.Point(201, 40);
            this.rdoManual.Name = "rdoManual";
            this.rdoManual.Size = new System.Drawing.Size(47, 16);
            this.rdoManual.TabIndex = 4;
            this.rdoManual.TabStop = true;
            this.rdoManual.Text = "수동";
            this.rdoManual.UseVisualStyleBackColor = true;
            this.rdoManual.CheckedChanged += new System.EventHandler(this.rdbManual_CheckedChanged);
            // 
            // rdoAuto
            // 
            this.rdoAuto.AutoSize = true;
            this.rdoAuto.Location = new System.Drawing.Point(140, 40);
            this.rdoAuto.Name = "rdoAuto";
            this.rdoAuto.Size = new System.Drawing.Size(47, 16);
            this.rdoAuto.TabIndex = 3;
            this.rdoAuto.Text = "자동";
            this.rdoAuto.UseVisualStyleBackColor = true;
            this.rdoAuto.CheckedChanged += new System.EventHandler(this.rdbAuto_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "로그레벨 :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "지연시간 :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "자동/수동 :";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.btnFTPSave);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(469, 429);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "FTP Info";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.dgvDNFileInfo);
            this.groupBox4.Controls.Add(this.btnDNDel);
            this.groupBox4.Controls.Add(this.btnDNAdd);
            this.groupBox4.Location = new System.Drawing.Point(8, 168);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(453, 240);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Tag = "";
            this.groupBox4.Text = "Download File Info";
            // 
            // dgvDNFileInfo
            // 
            this.dgvDNFileInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDNFileInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDNFileInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serverFile,
            this.localFile});
            this.dgvDNFileInfo.Location = new System.Drawing.Point(7, 49);
            this.dgvDNFileInfo.MultiSelect = false;
            this.dgvDNFileInfo.Name = "dgvDNFileInfo";
            this.dgvDNFileInfo.RowHeadersVisible = false;
            this.dgvDNFileInfo.RowTemplate.Height = 23;
            this.dgvDNFileInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDNFileInfo.Size = new System.Drawing.Size(440, 185);
            this.dgvDNFileInfo.TabIndex = 2;
            // 
            // serverFile
            // 
            this.serverFile.HeaderText = "Server File Name";
            this.serverFile.Name = "serverFile";
            this.serverFile.Width = 215;
            // 
            // localFile
            // 
            this.localFile.HeaderText = "Local File Name";
            this.localFile.Name = "localFile";
            this.localFile.Width = 215;
            // 
            // btnDNDel
            // 
            this.btnDNDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDNDel.Location = new System.Drawing.Point(372, 20);
            this.btnDNDel.Name = "btnDNDel";
            this.btnDNDel.Size = new System.Drawing.Size(75, 23);
            this.btnDNDel.TabIndex = 1;
            this.btnDNDel.Text = "Delete";
            this.btnDNDel.UseVisualStyleBackColor = true;
            this.btnDNDel.Click += new System.EventHandler(this.btnDNDel_Click);
            // 
            // btnDNAdd
            // 
            this.btnDNAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDNAdd.Location = new System.Drawing.Point(291, 20);
            this.btnDNAdd.Name = "btnDNAdd";
            this.btnDNAdd.Size = new System.Drawing.Size(75, 23);
            this.btnDNAdd.TabIndex = 0;
            this.btnDNAdd.Text = "Add";
            this.btnDNAdd.UseVisualStyleBackColor = true;
            this.btnDNAdd.Visible = false;
            this.btnDNAdd.Click += new System.EventHandler(this.btnDNAdd_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.chkPassive);
            this.groupBox3.Controls.Add(this.txtPasswd);
            this.groupBox3.Controls.Add(this.txtUserID);
            this.groupBox3.Controls.Add(this.txtPort);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtHost);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(8, 44);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(453, 118);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "SBS FTP Server Info";
            // 
            // chkPassive
            // 
            this.chkPassive.AutoSize = true;
            this.chkPassive.Location = new System.Drawing.Point(69, 87);
            this.chkPassive.Name = "chkPassive";
            this.chkPassive.Size = new System.Drawing.Size(69, 16);
            this.chkPassive.TabIndex = 8;
            this.chkPassive.Text = "Passive";
            this.chkPassive.UseVisualStyleBackColor = true;
            // 
            // txtPasswd
            // 
            this.txtPasswd.Location = new System.Drawing.Point(300, 55);
            this.txtPasswd.Name = "txtPasswd";
            this.txtPasswd.PasswordChar = '*';
            this.txtPasswd.Size = new System.Drawing.Size(130, 21);
            this.txtPasswd.TabIndex = 7;
            // 
            // txtUserID
            // 
            this.txtUserID.Location = new System.Drawing.Point(300, 28);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(130, 21);
            this.txtUserID.TabIndex = 6;
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(69, 55);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(130, 21);
            this.txtPort.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(226, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 12);
            this.label9.TabIndex = 4;
            this.label9.Text = "Password";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(242, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 12);
            this.label8.TabIndex = 3;
            this.label8.Text = "User ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 59);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "Port";
            // 
            // txtHost
            // 
            this.txtHost.Location = new System.Drawing.Point(69, 28);
            this.txtHost.Name = "txtHost";
            this.txtHost.Size = new System.Drawing.Size(130, 21);
            this.txtHost.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "Host";
            // 
            // btnFTPSave
            // 
            this.btnFTPSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFTPSave.Location = new System.Drawing.Point(386, 13);
            this.btnFTPSave.Name = "btnFTPSave";
            this.btnFTPSave.Size = new System.Drawing.Size(75, 23);
            this.btnFTPSave.TabIndex = 0;
            this.btnFTPSave.Text = "Save";
            this.btnFTPSave.UseVisualStyleBackColor = true;
            this.btnFTPSave.Click += new System.EventHandler(this.btnFTPSave_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgvHttpFileInfo);
            this.tabPage3.Controls.Add(this.btnHTTPSave);
            this.tabPage3.Controls.Add(this.btnHTTPDel);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(469, 427);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "HTTP Info";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgvHttpFileInfo
            // 
            this.dgvHttpFileInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHttpFileInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.hServerFile,
            this.hLocalFile});
            this.dgvHttpFileInfo.Location = new System.Drawing.Point(8, 42);
            this.dgvHttpFileInfo.Name = "dgvHttpFileInfo";
            this.dgvHttpFileInfo.RowHeadersVisible = false;
            this.dgvHttpFileInfo.RowTemplate.Height = 23;
            this.dgvHttpFileInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHttpFileInfo.Size = new System.Drawing.Size(453, 364);
            this.dgvHttpFileInfo.TabIndex = 3;
            // 
            // hServerFile
            // 
            this.hServerFile.HeaderText = "Server File Name";
            this.hServerFile.Name = "hServerFile";
            this.hServerFile.Width = 225;
            // 
            // hLocalFile
            // 
            this.hLocalFile.HeaderText = "Local File Name";
            this.hLocalFile.Name = "hLocalFile";
            this.hLocalFile.Width = 225;
            // 
            // btnHTTPSave
            // 
            this.btnHTTPSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHTTPSave.Location = new System.Drawing.Point(386, 13);
            this.btnHTTPSave.Name = "btnHTTPSave";
            this.btnHTTPSave.Size = new System.Drawing.Size(75, 23);
            this.btnHTTPSave.TabIndex = 2;
            this.btnHTTPSave.Text = "Save";
            this.btnHTTPSave.UseVisualStyleBackColor = true;
            this.btnHTTPSave.Click += new System.EventHandler(this.btnHTTPSave_Click);
            // 
            // btnHTTPDel
            // 
            this.btnHTTPDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHTTPDel.Location = new System.Drawing.Point(305, 13);
            this.btnHTTPDel.Name = "btnHTTPDel";
            this.btnHTTPDel.Size = new System.Drawing.Size(75, 23);
            this.btnHTTPDel.TabIndex = 1;
            this.btnHTTPDel.Text = "Delete";
            this.btnHTTPDel.UseVisualStyleBackColor = true;
            this.btnHTTPDel.Click += new System.EventHandler(this.btnHTTPDel_Click);
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.Location = new System.Drawing.Point(224, 13);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 0;
            this.button5.Text = "Add";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Visible = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox5);
            this.tabPage4.Controls.Add(this.groupBox6);
            this.tabPage4.Controls.Add(this.btnUploadSave);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(469, 427);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Upload";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.dgvUPFileInfo);
            this.groupBox5.Controls.Add(this.btnUploadDel);
            this.groupBox5.Controls.Add(this.button9);
            this.groupBox5.Location = new System.Drawing.Point(8, 168);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(453, 238);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Tag = "";
            this.groupBox5.Text = "Upload File Info";
            // 
            // dgvUPFileInfo
            // 
            this.dgvUPFileInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvUPFileInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUPFileInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.uLocalFile,
            this.uServerFile});
            this.dgvUPFileInfo.Location = new System.Drawing.Point(7, 49);
            this.dgvUPFileInfo.MultiSelect = false;
            this.dgvUPFileInfo.Name = "dgvUPFileInfo";
            this.dgvUPFileInfo.RowHeadersVisible = false;
            this.dgvUPFileInfo.RowTemplate.Height = 23;
            this.dgvUPFileInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUPFileInfo.Size = new System.Drawing.Size(440, 183);
            this.dgvUPFileInfo.TabIndex = 3;
            // 
            // uLocalFile
            // 
            this.uLocalFile.HeaderText = "Local File Name";
            this.uLocalFile.Name = "uLocalFile";
            this.uLocalFile.Width = 215;
            // 
            // uServerFile
            // 
            this.uServerFile.HeaderText = "Server File Name";
            this.uServerFile.Name = "uServerFile";
            this.uServerFile.Width = 215;
            // 
            // btnUploadDel
            // 
            this.btnUploadDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUploadDel.Location = new System.Drawing.Point(372, 20);
            this.btnUploadDel.Name = "btnUploadDel";
            this.btnUploadDel.Size = new System.Drawing.Size(75, 23);
            this.btnUploadDel.TabIndex = 1;
            this.btnUploadDel.Text = "Delete";
            this.btnUploadDel.UseVisualStyleBackColor = true;
            this.btnUploadDel.Click += new System.EventHandler(this.btnUploadDel_Click);
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button9.Location = new System.Drawing.Point(291, 20);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 0;
            this.button9.Text = "Add";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.chkUPassive);
            this.groupBox6.Controls.Add(this.txtUPasswd);
            this.groupBox6.Controls.Add(this.txtUUserID);
            this.groupBox6.Controls.Add(this.txtUPort);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.txtUHost);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Location = new System.Drawing.Point(8, 44);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(453, 118);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Upload FTP Server Info";
            // 
            // chkUPassive
            // 
            this.chkUPassive.AutoSize = true;
            this.chkUPassive.Location = new System.Drawing.Point(69, 87);
            this.chkUPassive.Name = "chkUPassive";
            this.chkUPassive.Size = new System.Drawing.Size(69, 16);
            this.chkUPassive.TabIndex = 8;
            this.chkUPassive.Text = "Passive";
            this.chkUPassive.UseVisualStyleBackColor = true;
            // 
            // txtUPasswd
            // 
            this.txtUPasswd.Location = new System.Drawing.Point(300, 55);
            this.txtUPasswd.Name = "txtUPasswd";
            this.txtUPasswd.PasswordChar = '*';
            this.txtUPasswd.Size = new System.Drawing.Size(130, 21);
            this.txtUPasswd.TabIndex = 7;
            // 
            // txtUUserID
            // 
            this.txtUUserID.Location = new System.Drawing.Point(300, 28);
            this.txtUUserID.Name = "txtUUserID";
            this.txtUUserID.Size = new System.Drawing.Size(130, 21);
            this.txtUUserID.TabIndex = 6;
            // 
            // txtUPort
            // 
            this.txtUPort.Location = new System.Drawing.Point(69, 55);
            this.txtUPort.Name = "txtUPort";
            this.txtUPort.Size = new System.Drawing.Size(130, 21);
            this.txtUPort.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(226, 59);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 12);
            this.label10.TabIndex = 4;
            this.label10.Text = "Password";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(242, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 12);
            this.label11.TabIndex = 3;
            this.label11.Text = "User ID";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(35, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "Port";
            // 
            // txtUHost
            // 
            this.txtUHost.Location = new System.Drawing.Point(69, 28);
            this.txtUHost.Name = "txtUHost";
            this.txtUHost.Size = new System.Drawing.Size(130, 21);
            this.txtUHost.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "Host";
            // 
            // btnUploadSave
            // 
            this.btnUploadSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUploadSave.Location = new System.Drawing.Point(386, 13);
            this.btnUploadSave.Name = "btnUploadSave";
            this.btnUploadSave.Size = new System.Drawing.Size(75, 23);
            this.btnUploadSave.TabIndex = 3;
            this.btnUploadSave.Text = "Save";
            this.btnUploadSave.UseVisualStyleBackColor = true;
            this.btnUploadSave.Click += new System.EventHandler(this.btnUploadSave_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(469, 427);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "DB Connection";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.chkAll);
            this.groupBox7.Controls.Add(this.chkSD51);
            this.groupBox7.Controls.Add(this.chkSD49);
            this.groupBox7.Controls.Add(this.chkSD48);
            this.groupBox7.Controls.Add(this.chkSD47);
            this.groupBox7.Controls.Add(this.chkSD46);
            this.groupBox7.Controls.Add(this.chkSD45);
            this.groupBox7.Controls.Add(this.chkSD44);
            this.groupBox7.Controls.Add(this.chkSD43);
            this.groupBox7.Controls.Add(this.chkSD42);
            this.groupBox7.Controls.Add(this.chkSD41);
            this.groupBox7.Controls.Add(this.chkSD31);
            this.groupBox7.Controls.Add(this.chkSD30);
            this.groupBox7.Controls.Add(this.chkSD29);
            this.groupBox7.Controls.Add(this.chkSD28);
            this.groupBox7.Controls.Add(this.chkSD27);
            this.groupBox7.Controls.Add(this.chkSD26);
            this.groupBox7.Controls.Add(this.chkSD11);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.txtConnStr);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Location = new System.Drawing.Point(8, 30);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(453, 354);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Database Info";
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Location = new System.Drawing.Point(78, 255);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(72, 16);
            this.chkAll.TabIndex = 21;
            this.chkAll.Text = "전체선택";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // chkSD51
            // 
            this.chkSD51.AutoSize = true;
            this.chkSD51.Location = new System.Drawing.Point(131, 320);
            this.chkSD51.Name = "chkSD51";
            this.chkSD51.Size = new System.Drawing.Size(48, 16);
            this.chkSD51.TabIndex = 20;
            this.chkSD51.Tag = "51";
            this.chkSD51.Text = "세종";
            this.chkSD51.UseVisualStyleBackColor = true;
            this.chkSD51.CheckedChanged += new System.EventHandler(this.chkSD51_CheckedChanged);
            // 
            // chkSD49
            // 
            this.chkSD49.AutoSize = true;
            this.chkSD49.Location = new System.Drawing.Point(78, 320);
            this.chkSD49.Name = "chkSD49";
            this.chkSD49.Size = new System.Drawing.Size(48, 16);
            this.chkSD49.TabIndex = 19;
            this.chkSD49.Tag = "49";
            this.chkSD49.Text = "제주";
            this.chkSD49.UseVisualStyleBackColor = true;
            this.chkSD49.CheckedChanged += new System.EventHandler(this.chkSD49_CheckedChanged);
            // 
            // chkSD48
            // 
            this.chkSD48.AutoSize = true;
            this.chkSD48.Location = new System.Drawing.Point(25, 320);
            this.chkSD48.Name = "chkSD48";
            this.chkSD48.Size = new System.Drawing.Size(48, 16);
            this.chkSD48.TabIndex = 18;
            this.chkSD48.Tag = "48";
            this.chkSD48.Text = "경남";
            this.chkSD48.UseVisualStyleBackColor = true;
            this.chkSD48.CheckedChanged += new System.EventHandler(this.chkSD48_CheckedChanged);
            // 
            // chkSD47
            // 
            this.chkSD47.AutoSize = true;
            this.chkSD47.Location = new System.Drawing.Point(343, 298);
            this.chkSD47.Name = "chkSD47";
            this.chkSD47.Size = new System.Drawing.Size(48, 16);
            this.chkSD47.TabIndex = 17;
            this.chkSD47.Tag = "47";
            this.chkSD47.Text = "경북";
            this.chkSD47.UseVisualStyleBackColor = true;
            this.chkSD47.CheckedChanged += new System.EventHandler(this.chkSD47_CheckedChanged);
            // 
            // chkSD46
            // 
            this.chkSD46.AutoSize = true;
            this.chkSD46.Location = new System.Drawing.Point(290, 298);
            this.chkSD46.Name = "chkSD46";
            this.chkSD46.Size = new System.Drawing.Size(48, 16);
            this.chkSD46.TabIndex = 16;
            this.chkSD46.Tag = "46";
            this.chkSD46.Text = "전남";
            this.chkSD46.UseVisualStyleBackColor = true;
            this.chkSD46.CheckedChanged += new System.EventHandler(this.chkSD46_CheckedChanged);
            // 
            // chkSD45
            // 
            this.chkSD45.AutoSize = true;
            this.chkSD45.Location = new System.Drawing.Point(237, 298);
            this.chkSD45.Name = "chkSD45";
            this.chkSD45.Size = new System.Drawing.Size(48, 16);
            this.chkSD45.TabIndex = 15;
            this.chkSD45.Tag = "45";
            this.chkSD45.Text = "전북";
            this.chkSD45.UseVisualStyleBackColor = true;
            this.chkSD45.CheckedChanged += new System.EventHandler(this.chkSD45_CheckedChanged);
            // 
            // chkSD44
            // 
            this.chkSD44.AutoSize = true;
            this.chkSD44.Location = new System.Drawing.Point(184, 298);
            this.chkSD44.Name = "chkSD44";
            this.chkSD44.Size = new System.Drawing.Size(48, 16);
            this.chkSD44.TabIndex = 14;
            this.chkSD44.Tag = "44";
            this.chkSD44.Text = "충남";
            this.chkSD44.UseVisualStyleBackColor = true;
            this.chkSD44.CheckedChanged += new System.EventHandler(this.chkSD44_CheckedChanged);
            // 
            // chkSD43
            // 
            this.chkSD43.AutoSize = true;
            this.chkSD43.Location = new System.Drawing.Point(131, 298);
            this.chkSD43.Name = "chkSD43";
            this.chkSD43.Size = new System.Drawing.Size(48, 16);
            this.chkSD43.TabIndex = 13;
            this.chkSD43.Tag = "43";
            this.chkSD43.Text = "충북";
            this.chkSD43.UseVisualStyleBackColor = true;
            this.chkSD43.CheckedChanged += new System.EventHandler(this.chkSD43_CheckedChanged);
            // 
            // chkSD42
            // 
            this.chkSD42.AutoSize = true;
            this.chkSD42.Location = new System.Drawing.Point(78, 298);
            this.chkSD42.Name = "chkSD42";
            this.chkSD42.Size = new System.Drawing.Size(48, 16);
            this.chkSD42.TabIndex = 12;
            this.chkSD42.Tag = "42";
            this.chkSD42.Text = "강원";
            this.chkSD42.UseVisualStyleBackColor = true;
            this.chkSD42.CheckedChanged += new System.EventHandler(this.chkSD42_CheckedChanged);
            // 
            // chkSD41
            // 
            this.chkSD41.AutoSize = true;
            this.chkSD41.Location = new System.Drawing.Point(25, 298);
            this.chkSD41.Name = "chkSD41";
            this.chkSD41.Size = new System.Drawing.Size(48, 16);
            this.chkSD41.TabIndex = 11;
            this.chkSD41.Tag = "41";
            this.chkSD41.Text = "경기";
            this.chkSD41.UseVisualStyleBackColor = true;
            this.chkSD41.CheckedChanged += new System.EventHandler(this.chkSD41_CheckedChanged);
            // 
            // chkSD31
            // 
            this.chkSD31.AutoSize = true;
            this.chkSD31.Location = new System.Drawing.Point(343, 276);
            this.chkSD31.Name = "chkSD31";
            this.chkSD31.Size = new System.Drawing.Size(48, 16);
            this.chkSD31.TabIndex = 10;
            this.chkSD31.Tag = "31";
            this.chkSD31.Text = "울산";
            this.chkSD31.UseVisualStyleBackColor = true;
            this.chkSD31.CheckedChanged += new System.EventHandler(this.chkSD31_CheckedChanged);
            // 
            // chkSD30
            // 
            this.chkSD30.AutoSize = true;
            this.chkSD30.Location = new System.Drawing.Point(290, 276);
            this.chkSD30.Name = "chkSD30";
            this.chkSD30.Size = new System.Drawing.Size(48, 16);
            this.chkSD30.TabIndex = 9;
            this.chkSD30.Tag = "30";
            this.chkSD30.Text = "대전";
            this.chkSD30.UseVisualStyleBackColor = true;
            this.chkSD30.CheckedChanged += new System.EventHandler(this.chkSD30_CheckedChanged);
            // 
            // chkSD29
            // 
            this.chkSD29.AutoSize = true;
            this.chkSD29.Location = new System.Drawing.Point(237, 276);
            this.chkSD29.Name = "chkSD29";
            this.chkSD29.Size = new System.Drawing.Size(48, 16);
            this.chkSD29.TabIndex = 8;
            this.chkSD29.Tag = "29";
            this.chkSD29.Text = "광주";
            this.chkSD29.UseVisualStyleBackColor = true;
            this.chkSD29.CheckedChanged += new System.EventHandler(this.chkSD29_CheckedChanged);
            // 
            // chkSD28
            // 
            this.chkSD28.AutoSize = true;
            this.chkSD28.Location = new System.Drawing.Point(184, 276);
            this.chkSD28.Name = "chkSD28";
            this.chkSD28.Size = new System.Drawing.Size(48, 16);
            this.chkSD28.TabIndex = 7;
            this.chkSD28.Tag = "28";
            this.chkSD28.Text = "인천";
            this.chkSD28.UseVisualStyleBackColor = true;
            this.chkSD28.CheckedChanged += new System.EventHandler(this.chkSD28_CheckedChanged);
            // 
            // chkSD27
            // 
            this.chkSD27.AutoSize = true;
            this.chkSD27.Location = new System.Drawing.Point(131, 276);
            this.chkSD27.Name = "chkSD27";
            this.chkSD27.Size = new System.Drawing.Size(48, 16);
            this.chkSD27.TabIndex = 6;
            this.chkSD27.Tag = "27";
            this.chkSD27.Text = "대구";
            this.chkSD27.UseVisualStyleBackColor = true;
            this.chkSD27.CheckedChanged += new System.EventHandler(this.chkSD27_CheckedChanged);
            // 
            // chkSD26
            // 
            this.chkSD26.AutoSize = true;
            this.chkSD26.Location = new System.Drawing.Point(78, 276);
            this.chkSD26.Name = "chkSD26";
            this.chkSD26.Size = new System.Drawing.Size(48, 16);
            this.chkSD26.TabIndex = 5;
            this.chkSD26.Tag = "26";
            this.chkSD26.Text = "부산";
            this.chkSD26.UseVisualStyleBackColor = true;
            this.chkSD26.CheckedChanged += new System.EventHandler(this.chkSD26_CheckedChanged);
            // 
            // chkSD11
            // 
            this.chkSD11.AutoSize = true;
            this.chkSD11.Location = new System.Drawing.Point(25, 276);
            this.chkSD11.Name = "chkSD11";
            this.chkSD11.Size = new System.Drawing.Size(48, 16);
            this.chkSD11.TabIndex = 4;
            this.chkSD11.Tag = "11";
            this.chkSD11.Text = "서울";
            this.chkSD11.UseVisualStyleBackColor = true;
            this.chkSD11.CheckedChanged += new System.EventHandler(this.chkSD11_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(23, 256);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 3;
            this.label19.Text = "시도선택";
            // 
            // txtConnStr
            // 
            this.txtConnStr.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtConnStr.Location = new System.Drawing.Point(25, 218);
            this.txtConnStr.Name = "txtConnStr";
            this.txtConnStr.Size = new System.Drawing.Size(410, 21);
            this.txtConnStr.TabIndex = 2;
            this.txtConnStr.TextChanged += new System.EventHandler(this.txtConnStr_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(23, 200);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(105, 12);
            this.label14.TabIndex = 1;
            this.label14.Text = "Connection String";
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this.label18);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.txtHTTPFile3);
            this.groupBox8.Controls.Add(this.txtHTTPFile2);
            this.groupBox8.Controls.Add(this.txtHTTPFile1);
            this.groupBox8.Controls.Add(this.txtFTPFile);
            this.groupBox8.Controls.Add(this.rdoHTTPFile);
            this.groupBox8.Controls.Add(this.rdoFTPFile);
            this.groupBox8.Location = new System.Drawing.Point(23, 29);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(412, 154);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Data Source";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(212, 120);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 8;
            this.label18.Text = "기초단체";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(211, 94);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 12);
            this.label17.TabIndex = 7;
            this.label17.Text = "교육감";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(212, 66);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 6;
            this.label16.Text = "광역단체";
            // 
            // txtHTTPFile3
            // 
            this.txtHTTPFile3.Location = new System.Drawing.Point(271, 116);
            this.txtHTTPFile3.Name = "txtHTTPFile3";
            this.txtHTTPFile3.Size = new System.Drawing.Size(121, 21);
            this.txtHTTPFile3.TabIndex = 5;
            this.txtHTTPFile3.TextChanged += new System.EventHandler(this.txtHTTPFile3_TextChanged);
            // 
            // txtHTTPFile2
            // 
            this.txtHTTPFile2.Location = new System.Drawing.Point(271, 89);
            this.txtHTTPFile2.Name = "txtHTTPFile2";
            this.txtHTTPFile2.Size = new System.Drawing.Size(121, 21);
            this.txtHTTPFile2.TabIndex = 4;
            this.txtHTTPFile2.TextChanged += new System.EventHandler(this.txtHTTPFile2_TextChanged);
            // 
            // txtHTTPFile1
            // 
            this.txtHTTPFile1.Location = new System.Drawing.Point(271, 62);
            this.txtHTTPFile1.Name = "txtHTTPFile1";
            this.txtHTTPFile1.Size = new System.Drawing.Size(121, 21);
            this.txtHTTPFile1.TabIndex = 3;
            this.txtHTTPFile1.TextChanged += new System.EventHandler(this.txtHTTPFile_TextChanged);
            // 
            // txtFTPFile
            // 
            this.txtFTPFile.Location = new System.Drawing.Point(21, 62);
            this.txtFTPFile.Name = "txtFTPFile";
            this.txtFTPFile.Size = new System.Drawing.Size(180, 21);
            this.txtFTPFile.TabIndex = 2;
            this.txtFTPFile.TextChanged += new System.EventHandler(this.txtFTPFile_TextChanged);
            // 
            // rdoHTTPFile
            // 
            this.rdoHTTPFile.AutoSize = true;
            this.rdoHTTPFile.Location = new System.Drawing.Point(212, 34);
            this.rdoHTTPFile.Name = "rdoHTTPFile";
            this.rdoHTTPFile.Size = new System.Drawing.Size(79, 16);
            this.rdoHTTPFile.TabIndex = 1;
            this.rdoHTTPFile.TabStop = true;
            this.rdoHTTPFile.Text = "HTTP File";
            this.rdoHTTPFile.UseVisualStyleBackColor = true;
            this.rdoHTTPFile.CheckedChanged += new System.EventHandler(this.rdoHTTPFile_CheckedChanged);
            // 
            // rdoFTPFile
            // 
            this.rdoFTPFile.AutoSize = true;
            this.rdoFTPFile.Location = new System.Drawing.Point(21, 34);
            this.rdoFTPFile.Name = "rdoFTPFile";
            this.rdoFTPFile.Size = new System.Drawing.Size(70, 16);
            this.rdoFTPFile.TabIndex = 0;
            this.rdoFTPFile.TabStop = true;
            this.rdoFTPFile.Text = "FTP File";
            this.rdoFTPFile.UseVisualStyleBackColor = true;
            this.rdoFTPFile.CheckedChanged += new System.EventHandler(this.rdoFTPFile_CheckedChanged);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.lstLog);
            this.tabPage6.Controls.Add(this.btnLogClear);
            this.tabPage6.Controls.Add(this.txtMaxLine);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(469, 427);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "로그";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // lstLog
            // 
            this.lstLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstLog.BackColor = System.Drawing.Color.Black;
            this.lstLog.ForeColor = System.Drawing.Color.White;
            this.lstLog.FormattingEnabled = true;
            this.lstLog.ItemHeight = 12;
            this.lstLog.Location = new System.Drawing.Point(8, 43);
            this.lstLog.Name = "lstLog";
            this.lstLog.Size = new System.Drawing.Size(453, 352);
            this.lstLog.TabIndex = 3;
            // 
            // btnLogClear
            // 
            this.btnLogClear.Location = new System.Drawing.Point(363, 13);
            this.btnLogClear.Name = "btnLogClear";
            this.btnLogClear.Size = new System.Drawing.Size(98, 23);
            this.btnLogClear.TabIndex = 2;
            this.btnLogClear.Text = "로그 지우기";
            this.btnLogClear.UseVisualStyleBackColor = true;
            this.btnLogClear.Click += new System.EventHandler(this.btnLogClear_Click);
            // 
            // txtMaxLine
            // 
            this.txtMaxLine.Location = new System.Drawing.Point(101, 16);
            this.txtMaxLine.Name = "txtMaxLine";
            this.txtMaxLine.Size = new System.Drawing.Size(100, 21);
            this.txtMaxLine.TabIndex = 1;
            this.txtMaxLine.TextChanged += new System.EventHandler(this.txtMaxLine_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "총 라인수 :";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnExecFolder
            // 
            this.btnExecFolder.Location = new System.Drawing.Point(8, 329);
            this.btnExecFolder.Name = "btnExecFolder";
            this.btnExecFolder.Size = new System.Drawing.Size(75, 79);
            this.btnExecFolder.TabIndex = 11;
            this.btnExecFolder.Text = "실행폴더";
            this.btnExecFolder.UseVisualStyleBackColor = true;
            this.btnExecFolder.Click += new System.EventHandler(this.btnExecFolder_Click);
            // 
            // btnINI
            // 
            this.btnINI.Location = new System.Drawing.Point(89, 329);
            this.btnINI.Name = "btnINI";
            this.btnINI.Size = new System.Drawing.Size(75, 79);
            this.btnINI.TabIndex = 12;
            this.btnINI.Text = "INI폴더";
            this.btnINI.UseVisualStyleBackColor = true;
            this.btnINI.Click += new System.EventHandler(this.btnINI_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 455);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(493, 491);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "2014 선거 자료수신";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDNFileInfo)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHttpFileInfo)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUPFileInfo)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdoManual;
        private System.Windows.Forms.RadioButton rdoAuto;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbLog;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkDBUP;
        private System.Windows.Forms.CheckBox chkFTPUP;
        private System.Windows.Forms.CheckBox chkHTTPDN;
        private System.Windows.Forms.CheckBox chkFTPDN;
        private System.Windows.Forms.Button btnExec;
        private System.Windows.Forms.Button btnFTPSave;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtPasswd;
        private System.Windows.Forms.TextBox txtUserID;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtHost;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox chkPassive;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnDNDel;
        private System.Windows.Forms.Button btnDNAdd;
        private System.Windows.Forms.Button btnHTTPSave;
        private System.Windows.Forms.Button btnHTTPDel;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnUploadDel;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox chkUPassive;
        private System.Windows.Forms.TextBox txtUPasswd;
        private System.Windows.Forms.TextBox txtUUserID;
        private System.Windows.Forms.TextBox txtUPort;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtUHost;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnUploadSave;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtHTTPFile1;
        private System.Windows.Forms.TextBox txtFTPFile;
        private System.Windows.Forms.RadioButton rdoHTTPFile;
        private System.Windows.Forms.RadioButton rdoFTPFile;
        private System.Windows.Forms.TextBox txtConnStr;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnLogClear;
        private System.Windows.Forms.TextBox txtMaxLine;
        private System.Windows.Forms.DataGridView dgvDNFileInfo;
        private System.Windows.Forms.DataGridView dgvHttpFileInfo;
        private System.Windows.Forms.DataGridView dgvUPFileInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn serverFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn localFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn hServerFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn hLocalFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn uLocalFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn uServerFile;
        private System.Windows.Forms.ListBox lstLog;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtHTTPFile3;
        private System.Windows.Forms.TextBox txtHTTPFile2;
        private System.Windows.Forms.CheckBox chkSD11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox chkSD31;
        private System.Windows.Forms.CheckBox chkSD30;
        private System.Windows.Forms.CheckBox chkSD29;
        private System.Windows.Forms.CheckBox chkSD28;
        private System.Windows.Forms.CheckBox chkSD27;
        private System.Windows.Forms.CheckBox chkSD26;
        private System.Windows.Forms.CheckBox chkSD51;
        private System.Windows.Forms.CheckBox chkSD49;
        private System.Windows.Forms.CheckBox chkSD48;
        private System.Windows.Forms.CheckBox chkSD47;
        private System.Windows.Forms.CheckBox chkSD46;
        private System.Windows.Forms.CheckBox chkSD45;
        private System.Windows.Forms.CheckBox chkSD44;
        private System.Windows.Forms.CheckBox chkSD43;
        private System.Windows.Forms.CheckBox chkSD42;
        private System.Windows.Forms.CheckBox chkSD41;
        private System.Windows.Forms.CheckBox chkAll;
        private System.Windows.Forms.Button btnExecFolder;
        private System.Windows.Forms.Button btnINI;
    }
}

