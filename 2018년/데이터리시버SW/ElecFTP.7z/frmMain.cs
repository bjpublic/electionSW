﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.IO;
using System.Collections;
using System.Xml;
using System.Data.SqlClient;

namespace ElecFTP
{
    public partial class frmMain : Form
    {
        
        
        delegate void SetProgressCallback(long totalSize, long saveSize);
        //int SBSNCOUNT = 62;
        int SBSNCOUNT = 108;
        int HUBOCOUNT = 30;
        int[] SBSNPOS = { 1,  1,  1,  8,  8,  8,  5,  1,  8,  5,  1,  2, 30,  2,  2,  8,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2, //
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,  
                               8,  5,  2,//
                               14,  1 };
        int SBSNLENGTH = 0;

        SqlConnection conn;

        struct THubo
        {
            public string votecnt;     //득표수
            public string voterate;    //득표율
            public string rank;        //순위
        }



        public static frmMain FMainForm;

        
 

        
        public frmMain()
        {
            InitializeComponent();

            //init 파일 설정
            init();
        }

        public void init()
        {
            //version, title
            this.Text = Global.Title + " (Version " + Global.Version + ")";
            FMainForm = this;

            setExec();
            setFtpInfo();
            setHttpInfo();
            setUpload();
            setDBConnect();
            setLog();
        }

        private void setExec()
        {
            //EXEC
            string auto = Global.IniFile.GetString("EXEC", "AUTO");
            string time = Global.IniFile.GetString("EXEC", "TIME");
            string log = Global.IniFile.GetString("EXEC", "LOG");
            string execFtp = Global.IniFile.GetString("EXEC", "ExecFtp");
            string execHttp = Global.IniFile.GetString("EXEC", "ExecHttp");
            string execUp = Global.IniFile.GetString("EXEC", "ExecUp");
            string execDb = Global.IniFile.GetString("EXEC", "ExecDb");

            if (auto.Equals("0"))
            {
                this.rdoAuto.Checked = false;
                this.rdoManual.Checked = true;
            }
            else
            {
                this.rdoAuto.Checked = true;
                this.rdoManual.Checked = false;
            }

            /*EXEC*/
            this.txtTime.Text = time;
            this.cbLog.SelectedIndex = Convert.ToInt32(log);

            if (execFtp.Equals("1")) { this.chkFTPDN.Checked = true; }
            else { this.chkFTPDN.Checked = false; }

            if (execHttp.Equals("1")) { this.chkHTTPDN.Checked = true; }
            else { this.chkHTTPDN.Checked = false; }

            if (execUp.Equals("1")) { this.chkFTPUP.Checked = true; }
            else { this.chkFTPUP.Checked = false; }

            if (execDb.Equals("1")) { this.chkDBUP.Checked = true; }
            else { this.chkDBUP.Checked = false; }
        }

        private void setFtpInfo()
        {
            //FTP Info
            string host = Global.IniFile.GetString("FTP", "IP");
            string port = Global.IniFile.GetString("FTP", "PORT");
            string userid = Global.IniFile.GetString("FTP", "USERID");
            string passwd = Global.IniFile.GetString("FTP", "PASSWD");
            string passive = Global.IniFile.GetString("FTP", "PASSIVE");
            string files = Global.IniFile.GetString("FTP", "Files");

            /*FTP Info*/
            this.txtHost.Text = host;
            this.txtPasswd.Text = passwd;
            this.txtPort.Text = port;
            this.txtUserID.Text = userid;
            if (passive.Equals("1")) { this.chkPassive.Checked = true; }
            else { this.chkPassive.Checked = false; }

            string[] itemFiles = files.TrimEnd('|').Split('|');
            foreach (string item in itemFiles)
            {
                
                string[] fn = item.Split('=');
                if (fn.Count() == 2)
                {
                    string sfn = fn[0];
                    string lfn = fn[1];
                    string[] items = { sfn, lfn };

                    dgvDNFileInfo.Rows.Add(items);
                }


            }



        }

        private void setHttpInfo()
        {
            //HTTP Info           
            string files = Global.IniFile.GetString("HTTP", "Files");
            string[] itemFiles = files.TrimEnd('|').Split('|');
            foreach (string item in itemFiles)
            {
                string[] fn = item.Split('=');
                if (fn.Count() == 2)
                {
                    string sfn = fn[0];
                    string lfn = fn[1];
                    string[] items = { sfn, lfn };

                    this.dgvHttpFileInfo.Rows.Add(items);
                }

            }
        }

        private void setUpload()
        {
            //Upload
            string host = Global.IniFile.GetString("Upload", "IP");
            string port = Global.IniFile.GetString("Upload", "PORT");
            string userid = Global.IniFile.GetString("Upload", "USERID");
            string passwd = Global.IniFile.GetString("Upload", "PASSWD");
            string passive = Global.IniFile.GetString("Upload", "PASSIVE");
            string files = Global.IniFile.GetString("Upload", "Files");

            /*Upload*/
            this.txtUHost.Text = host;
            this.txtUPasswd.Text = passwd;
            this.txtUPort.Text = port;
            this.txtUUserID.Text = userid;
            if (passive.Equals("1")) { this.chkUPassive.Checked = true; }
            else { this.chkUPassive.Checked = false; }

            string[] itemFiles = files.TrimEnd('|').Split('|');
            foreach (string item in itemFiles)
            {
                
                string[] fn = item.Split('=');
                if (fn.Count() == 2)
                {
                    string sfn = fn[0];
                    string lfn = fn[1];
                    string[] items = { sfn, lfn };

                    dgvUPFileInfo.Rows.Add(items);
                }

            }
        }

        private void setDBConnect()
        {
            //DB Connection
            string connstr = Global.IniFile.GetString("DB", "CONNSTR");
            string source = Global.IniFile.GetString("DB", "Source");
            string ftp = Global.IniFile.GetString("DB", "FTP");
            string http = Global.IniFile.GetString("DB", "HTTP");
            string http2 = Global.IniFile.GetString("DB", "HTTP2");
            string http3 = Global.IniFile.GetString("DB", "HTTP3");
            string sd = Global.IniFile.GetString("DB", "SD");

            this.txtConnStr.Text = connstr;
            this.txtFTPFile.Text = ftp;
            this.txtHTTPFile1.Text = http;
            this.txtHTTPFile2.Text = http2;
            this.txtHTTPFile3.Text = http3;


            if (sd.IndexOf("11") > -1) this.chkSD11.Checked = true;
            if (sd.IndexOf("26") > -1) this.chkSD26.Checked = true;
            if (sd.IndexOf("27") > -1) this.chkSD27.Checked = true;
            if (sd.IndexOf("28") > -1) this.chkSD28.Checked = true;
            if (sd.IndexOf("29") > -1) this.chkSD29.Checked = true;
            if (sd.IndexOf("30") > -1) this.chkSD30.Checked = true;
            if (sd.IndexOf("31") > -1) this.chkSD31.Checked = true;
            if (sd.IndexOf("41") > -1) this.chkSD41.Checked = true;
            if (sd.IndexOf("42") > -1) this.chkSD42.Checked = true;
            if (sd.IndexOf("43") > -1) this.chkSD43.Checked = true;
            if (sd.IndexOf("44") > -1) this.chkSD44.Checked = true;
            if (sd.IndexOf("45") > -1) this.chkSD45.Checked = true;
            if (sd.IndexOf("46") > -1) this.chkSD46.Checked = true;
            if (sd.IndexOf("47") > -1) this.chkSD47.Checked = true;
            if (sd.IndexOf("48") > -1) this.chkSD48.Checked = true;
            if (sd.IndexOf("49") > -1) this.chkSD49.Checked = true;
            if (sd.IndexOf("51") > -1) this.chkSD51.Checked = true;


            if (source.Equals("HTTP")) { this.rdoHTTPFile.Checked = true; }
            else { this.rdoFTPFile.Checked = true; }
        }

        private void setLog()
        {
            //LOG
            string maxlines = Global.IniFile.GetString("LOG", "MAXLINE");
            this.txtMaxLine.Text = maxlines;
        }

        private void btnDNAdd_Click(object sender, EventArgs e)
        {
           
        }

        private void btnDNDel_Click(object sender, EventArgs e)
        {
            
            for (int i = 0; i < dgvDNFileInfo.Rows.Count; i++)
            {
                if (dgvDNFileInfo.Rows[i].Selected == true)
                {
                   dgvDNFileInfo.Rows.Remove(dgvDNFileInfo.Rows[i]);
                }
            }
        }

        public void addMsg(int lvl, string head, string msg)
        {
            CheckForIllegalCrossThreadCalls = false;
            try
            {
               
                    //Console.WriteLine("=============="+cbLog.SelectedIndex + "," + lvl);
                    if (cbLog.SelectedIndex >= lvl)
                    {
                        string maxline = Global.IniFile.GetString("LOG", "MAXLINE");
                        if (lstLog.Items.Count >= Convert.ToInt32(maxline))
                        {
                            lstLog.Items.RemoveAt(0);
                        }

                        string strLog = "[" + DateTime.Now + "] " + head + msg;
                        //ListViewItem log = new ListViewItem(strLog);

                        lstLog.Items.Add(strLog);
                        lstLog.SelectedIndex = lstLog.Items.Count - 1;
                    }
                
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(ex.Message);
            }

            
        }

        public void setProgress(long totalSize, long saveSize)
        {
            try
            {
                
                SetProgressCallback d = new SetProgressCallback(setProgress);
                //this.Invoke(d, new object[] { saveSize, totalSize });
                //Console.WriteLine("==============1==" + saveSize);
                //Console.WriteLine("==============2==" + totalSize);
                double ds = (saveSize * 100) / totalSize;
                //Console.WriteLine("==============3==" + ds);

                //this.progressBar.Value = 20;
            }
            catch { }
        }

        private void rdbAuto_CheckedChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("EXEC", "AUTO", "1");
        }

        private void rdbManual_CheckedChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("EXEC", "AUTO", "0");
            if (rdoManual.Checked) timer1.Stop();
        }

        private void txtTime_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("EXEC", "TIME", this.txtTime.Text.ToString().Trim());
        }

        private void cbLog_SelectedIndexChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("EXEC", "LOG", this.cbLog.SelectedIndex.ToString());
        }

        private void chkFTPDN_CheckedChanged(object sender, EventArgs e)
        {
            if(this.chkFTPDN.Checked)
                Global.IniFile.SetString("EXEC", "ExecFtp", "1");
            else Global.IniFile.SetString("EXEC", "ExecFtp", "0");
        }

        private void chkHTTPDN_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkHTTPDN.Checked)
                Global.IniFile.SetString("EXEC", "ExecHttp", "1");
            else Global.IniFile.SetString("EXEC", "ExecHttp", "0");
        }

        private void chkFTPUP_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkFTPUP.Checked)
                Global.IniFile.SetString("EXEC", "ExecUp", "1");
            else Global.IniFile.SetString("EXEC", "ExecUp", "0");
        }

        private void chkDBUP_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkDBUP.Checked)
                Global.IniFile.SetString("EXEC", "ExecDb", "1");
            else Global.IniFile.SetString("EXEC", "ExecDb", "0");
        }

        private void btnFTPSave_Click(object sender, EventArgs e)
        {
            //FTP Info 저장
            Global.IniFile.SetString("FTP", "IP", this.txtHost.Text.ToString().Trim());
            Global.IniFile.SetString("FTP", "PORT", this.txtPort.Text.ToString().Trim());
            Global.IniFile.SetString("FTP", "USERID", this.txtUserID.Text.ToString().Trim());
            Global.IniFile.SetString("FTP", "PASSWD", this.txtPasswd.Text.ToString().Trim());
            if (this.chkPassive.Checked) Global.IniFile.SetString("FTP", "PASSIVE", "1");
            else Global.IniFile.SetString("FTP", "PASSIVE", "0");


            string files = "";
            for (int i = 0; i < dgvDNFileInfo.Rows.Count; i++)
            {
                if (dgvDNFileInfo.Rows[i].Cells["serverFile"].Value != null && dgvDNFileInfo.Rows[i].Cells["localFile"].Value != null)
                {
                    string sfn = dgvDNFileInfo.Rows[i].Cells["serverFile"].Value.ToString();
                    string lfn = dgvDNFileInfo.Rows[i].Cells["localFile"].Value.ToString();
                    files += sfn + "=" + lfn;
                    files += "|";
                }
            }
            Global.IniFile.SetString("FTP", "Files", files);
            
        }

        private void btnHTTPDel_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvHttpFileInfo.Rows.Count; i++)
            {
                if (dgvHttpFileInfo.Rows[i].Selected == true)
                {
                    dgvHttpFileInfo.Rows.Remove(dgvHttpFileInfo.Rows[i]);
                }
            }
        }

        private void btnHTTPSave_Click(object sender, EventArgs e)
        {
            string files = "";
            for (int i = 0; i < dgvHttpFileInfo.Rows.Count; i++)
            {
                if (dgvHttpFileInfo.Rows[i].Cells["hServerFile"].Value != null && dgvHttpFileInfo.Rows[i].Cells["hLocalFile"].Value != null)
                {
                    string sfn = dgvHttpFileInfo.Rows[i].Cells["hServerFile"].Value.ToString();
                    string lfn = dgvHttpFileInfo.Rows[i].Cells["hLocalFile"].Value.ToString();
                    files += sfn + "=" + lfn;
                    files += "|";
                }
            }
            Global.IniFile.SetString("HTTP", "Files", files);
        }

        private void btnUploadSave_Click(object sender, EventArgs e)
        {
            //Upload 저장
            Global.IniFile.SetString("Upload", "IP", this.txtUHost.Text.ToString().Trim());
            Global.IniFile.SetString("Upload", "PORT", this.txtUPort.Text.ToString().Trim());
            Global.IniFile.SetString("Upload", "USERID", this.txtUUserID.Text.ToString().Trim());
            Global.IniFile.SetString("Upload", "PASSWD", this.txtUPasswd.Text.ToString().Trim());
            if (this.chkUPassive.Checked) Global.IniFile.SetString("Upload", "PASSIVE", "1");
            else Global.IniFile.SetString("Upload", "PASSIVE", "0");


            string files = "";
            for (int i = 0; i < dgvUPFileInfo.Rows.Count; i++)
            {
                if (dgvUPFileInfo.Rows[i].Cells["uServerFile"].Value != null && dgvUPFileInfo.Rows[i].Cells["uLocalFile"].Value != null)
                {
                    string sfn = dgvUPFileInfo.Rows[i].Cells["uServerFile"].Value.ToString();
                    string lfn = dgvUPFileInfo.Rows[i].Cells["uLocalFile"].Value.ToString();
                    files += lfn + "=" + sfn;
                    files += "|";
                }
            }
            Global.IniFile.SetString("Upload", "Files", files);
        }

        private void btnUploadDel_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvUPFileInfo.Rows.Count; i++)
            {
                if (dgvUPFileInfo.Rows[i].Selected == true)
                {
                    dgvUPFileInfo.Rows.Remove(dgvUPFileInfo.Rows[i]);
                }
            }
        }

        private void rdoFTPFile_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdoFTPFile.Checked) Global.IniFile.SetString("DB", "Source", "FTP");
        }

        private void rdoHTTPFile_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdoHTTPFile.Checked) Global.IniFile.SetString("DB", "Source", "HTTP");
        }

        private void txtFTPFile_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("DB", "FTP", this.txtFTPFile.Text.ToString().Trim());
        }

        private void txtHTTPFile_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("DB", "HTTP", this.txtHTTPFile1.Text.ToString().Trim());
        }

        private void txtConnStr_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("DB", "CONNSTR", this.txtConnStr.Text.ToString().Trim());
        }

        private void txtMaxLine_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("LOG", "MAXLINE", this.txtMaxLine.Text.ToString().Trim());
        }

        private void btnLogClear_Click(object sender, EventArgs e)
        {
            //rtxtLog.Text = "";
            for (int i = lstLog.Items.Count-1; i >= 0; i--)
            {
                lstLog.Items.RemoveAt(i);
            }
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            //addMsg("선거 자료수신이 실행되었습니다.~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~3234345");
            addMsg(0, "Start","-------------------------------------------");
            btnExec.Enabled = false;

            dataExec(); //FTP DN/UP, HTTP DN, DB UP 실행
            if (this.rdoAuto.Checked)
            {
                int interval = int.Parse(this.txtTime.Text.ToString()) * 1000;
                //Console.WriteLine(interval + "======================");
                this.timer1.Interval = interval;
                this.timer1.Start();
            }
            addMsg(0, "End", "-------------------------------------------");
        }

        

        private void dataExec()
        {
            timer1.Stop();

            if (this.chkFTPDN.Checked && this.chkFTPUP.Checked){
                
                bool flag = download();
                if (flag)
                {
                    upload();
                }
            }else{



                //FTP DN
                if (this.chkFTPDN.Checked)
                {
                    //Thread thread = new Thread(new ThreadStart(download));
                    //thread.Start();
                    download();
                
                }



                //FTP UP
                if (this.chkFTPUP.Checked)
                {
                    //Thread thread2 = new Thread(new ThreadStart(upload));
                    //thread2.Start();
                    upload();
                }

                

            }
            //HTTP DN
            if (this.chkHTTPDN.Checked)
            {
                //Thread thread3 = new Thread(new ThreadStart(getHttp));
                //thread3.Start();
                getHttp();
            }

            //DB Update
            if (this.chkDBUP.Checked)
            {
                //Thread thread4 = new Thread(new ThreadStart(dbup));
                //thread4.Start();
                dbup();
            }

            btnExec.Enabled = true;

        }

       

        private  bool download()
        {
            
            try
            {
                FTP ftp = null;
               
                string ip = FMainForm.txtHost.Text.ToString().Trim();
                string userid = FMainForm.txtUserID.Text.ToString().Trim();
                string userpwd = FMainForm.txtPasswd.Text.ToString().Trim();
                string port = FMainForm.txtPort.Text.ToString().Trim();
                addMsg(1, "+ ", "FTP 서버 접속");
                ftp = new FTP(ip, userid, userpwd, port, FMainForm);
                
                for (int i = 0; i < FMainForm.dgvDNFileInfo.Rows.Count; i++)
                {
                    
                    if (FMainForm.dgvDNFileInfo.Rows[i].Cells["serverFile"].Value != null && FMainForm.dgvDNFileInfo.Rows[i].Cells["localFile"].Value != null)
                    {
                        string sfn = FMainForm.dgvDNFileInfo.Rows[i].Cells["serverFile"].Value.ToString();
                        string lfn = FMainForm.dgvDNFileInfo.Rows[i].Cells["localFile"].Value.ToString();

                        ftp.Download(lfn, sfn);
                        //addMsg(1, "- ", "수신완료 : " + sfn);
                    }
                }
                
                return true;
            }
            catch
            {
                return false;
            }

            
        }

        private void upload(){
            try
            {
                FTP ftp = null;
                string ip = this.txtUHost.Text.ToString().Trim();
                string userid = this.txtUUserID.Text.ToString().Trim();
                string userpwd = this.txtUPasswd.Text.ToString().Trim();
                string port = this.txtUPort.Text.ToString().Trim();
                addMsg(1, "+ ", "FTP 서버 접속");
                ftp = new FTP(ip, userid, userpwd, port, this);

                
                for (int i = 0; i < dgvUPFileInfo.Rows.Count; i++)
                {
                    if (dgvUPFileInfo.Rows[i].Cells["uServerFile"].Value != null && dgvUPFileInfo.Rows[i].Cells["uLocalFile"].Value != null)
                    {
                        string sfn = dgvUPFileInfo.Rows[i].Cells["uServerFile"].Value.ToString();
                        string lfn = dgvUPFileInfo.Rows[i].Cells["uLocalFile"].Value.ToString();

                        string upload_dir = sfn.Substring(0, sfn.LastIndexOf('/'));
                        string local_file = Application.StartupPath + "\\" + lfn;
                        string rename_file = sfn.Substring(sfn.LastIndexOf('/') + 1);
                        
                        ftp.Upload(upload_dir, local_file, rename_file);

                    }
                }
                //return true;
            }
            catch (Exception ex)
            {
               // MessageBox.Show(ex.Message);
                addMsg(1, "- ", "오류 : " + ex.Message);
                //return false;
            }
        }

        private void getHttp()
        {

            try
            {
                addMsg(1, "+ ", "HTTP 서버 접속");
                for (int i = 0; i < dgvHttpFileInfo.Rows.Count; i++)
                {
                    if (dgvHttpFileInfo.Rows[i].Cells["hServerFile"].Value != null && dgvHttpFileInfo.Rows[i].Cells["hLocalFile"].Value != null)
                    {
                        string sfn = dgvHttpFileInfo.Rows[i].Cells["hServerFile"].Value.ToString();
                        string lfn = dgvHttpFileInfo.Rows[i].Cells["hLocalFile"].Value.ToString();
                        
                        
                        string local_file = Application.StartupPath + "\\" + lfn;
                        using (WebClient client = new WebClient())
                        {
                            addMsg(2, lfn, " 다운로드가 시작되었습니다.");
                            client.Encoding = System.Text.Encoding.GetEncoding("utf-8");
                            string data = client.DownloadString(sfn);
                            //byte[] dataByte = Encoding.GetEncoding("euc-kr").GetBytes(data.Trim());
                            StreamWriter fs = new StreamWriter(local_file);
                            fs.Write(data.Trim());
                            fs.Close();
                            this.addMsg(2, lfn, " 다운로드가 완료되었습니다.");
                        }

                        

                    }
                }

                

                //return true;
            }
            catch { //return false;
            }
        }

        private void dbup()
        {
            /*
             * 국회의원선거 S사 프로토콜(201X)

              NO  내용     길이   설명
              ------------------------------------------
               0	STX      	  1   STX : *
               1	선거종류    1	  0:대선, 1:국회, 2:광역단체, 3:교육감, 4:기초단체, 5: 국회비례, 6:광역의원, 7:광역비례, 8:기초의회, 9: 기초비례
               2	선거구분    1	  G:개표소 S:선거구 ( 통상적으로 S 만 제공함 )
               3	선거구      8	  선거구 코드 ( 0 + 선거구코드 7자리 )
               4	유권자수    8	  유권자수
               5	투표자수    8	  투표자수
               6	투표율      5	  투표율 (5.1:소수점포함)
               7	투표완료    1	  투표완료여부(Y/N)
               8	개표수      8	  개표수
               9	개표율      5	  개표율 (5.1:소수점포함)
              10	개표완료    1	  개표완료여부(Y/N)
              11	후보자수    2	  후보자수
              12	출마여부   30	  후보기호별 출마 여부 (ex)YYNNY ? 1,2,5번 출마    -->2014.6.4 지선에서는 30회로 변경
              13	1위기호     2	  1위후보의 후보기호
              14	당선여부    2	  40:유력,50:확실,60:당선확정(개표중),80:무투표당선,90 당선(개표완료)
              15	무효표수    8	  무효표
               ------array 30회반복구간-------- 기호 01 - 30까지 -->2012.12.19 대선에서는 15회로 변경
              16  1번득표수   8   득표수
              17  1번득표율   5   득표율 (5.1:소수점포함)
              18  1번순위     2   순위
               --------------------------------
             103  30번득표수  8   득표수
             104  30번득표율  5   득표율 (5.1:소수점포함)
             105  30번순위    2   순위
             106  전송시간	 14	  전송시간   yyyymmddhhmmss
             107  ETX	        1	   ETX : #
               ================================
             * */

            //자료 길이 계산
            SBSNLENGTH = 0;
            for (int i = 0; i < SBSNCOUNT; i++)
            {

                
                SBSNLENGTH = SBSNLENGTH + SBSNPOS[i];
                //Console.WriteLine(SBSNPOS[i] + ">>" + SBSNLENGTH);
                
            }
            //return;
            

            if (this.rdoFTPFile.Checked)
            {
                //string text = System.IO.File.ReadAllText(Application.StartupPath + "\\"+txtFTPFile.Text.ToString().Trim());
                addMsg(3, txtFTPFile.Text.ToString().Trim(), "파일 읽는 중...");
                string[] lines = System.IO.File.ReadAllLines(Application.StartupPath + "\\" + txtFTPFile.Text.ToString().Trim());
                foreach (string line in lines)
                {
                    if (line.Length != SBSNLENGTH) continue;

                    string suncode = line.Substring(3, 8);
                    string localCode = suncode.Substring(2, 2);

                    Console.WriteLine(suncode + ">>>" + localCode);

                    //시도 체크된 데이터만 업로드
                    string chkLocal = "";
                    if (this.chkSD11.Checked) chkLocal += this.chkSD11.Tag.ToString() + ",";
                    if (this.chkSD26.Checked) chkLocal += this.chkSD26.Tag.ToString() + ",";
                    if (this.chkSD27.Checked) chkLocal += this.chkSD27.Tag.ToString() + ",";
                    if (this.chkSD28.Checked) chkLocal += this.chkSD28.Tag.ToString() + ",";
                    if (this.chkSD29.Checked) chkLocal += this.chkSD29.Tag.ToString() + ",";
                    if (this.chkSD30.Checked) chkLocal += this.chkSD30.Tag.ToString() + ",";
                    if (this.chkSD31.Checked) chkLocal += this.chkSD31.Tag.ToString() + ",";
                    if (this.chkSD41.Checked) chkLocal += this.chkSD41.Tag.ToString() + ",";
                    if (this.chkSD42.Checked) chkLocal += this.chkSD42.Tag.ToString() + ",";
                    if (this.chkSD43.Checked) chkLocal += this.chkSD43.Tag.ToString() + ",";
                    if (this.chkSD44.Checked) chkLocal += this.chkSD44.Tag.ToString() + ",";
                    if (this.chkSD45.Checked) chkLocal += this.chkSD45.Tag.ToString() + ",";
                    if (this.chkSD46.Checked) chkLocal += this.chkSD46.Tag.ToString() + ",";
                    if (this.chkSD47.Checked) chkLocal += this.chkSD47.Tag.ToString() + ",";
                    if (this.chkSD48.Checked) chkLocal += this.chkSD48.Tag.ToString() + ",";
                    if (this.chkSD49.Checked) chkLocal += this.chkSD49.Tag.ToString() + ",";
                    if (this.chkSD51.Checked) chkLocal += this.chkSD51.Tag.ToString();

                    if (chkLocal.IndexOf(localCode) > -1)
                    {
                        addMsg(3, "+ ", "DB 업데이트 중...");
                        UpdateData(line); //2014 수정
                        addMsg(3, "+ ", "DB 업데이트 완료");
                    }

                    //UpdateData(line);
                    //return;
                }
            }

            if (this.rdoHTTPFile.Checked)
            {
                for (int i = 1; i <= 3; i++)
                {
                    string uri = "";
                    string httpFile = "";
                    if(i == 1) httpFile = txtHTTPFile1.Text.ToString().Trim();
                    if (i == 2) httpFile = txtHTTPFile2.Text.ToString().Trim();
                    if(i == 3) httpFile = txtHTTPFile3.Text.ToString().Trim();

                    if ("".Equals(httpFile)) return;

                    //uri = Application.StartupPath + "\\" + txtHTTPFile.Text.ToString().Trim();
                    //Console.WriteLine(httpFile);
                    addMsg(3, "-", httpFile +"파일 읽는 중...");
                    uri = Application.StartupPath + "\\" + httpFile;
                    try
                    {
                        XmlDocument xml = new XmlDocument();
                        xml.Load(uri);
                        //XmlNodeList xnList = xml.SelectNodes("/VOTE/INFO"); //접근할 노드
                        XmlNodeList sgList = xml.SelectNodes("/VOTE/SG"); //접근할 노드(2014)
                        //Console.WriteLine(xnList.ToString());
                        addMsg(3, "-", "XML 파싱중...");
                        foreach (XmlNode sg in sgList) //선거코드
                        {
                            
                            string kind = sg.Attributes["code"].Value;
                            

                            XmlNodeList localList = sg.SelectNodes("LOCAL");
                            foreach (XmlNode local in localList) //시도코드
                            {
                                string localCode = local.Attributes["code"].Value;
                                XmlNodeList subList = local.SelectNodes("SUB");
                                foreach (XmlNode sub in subList) //구시군코드
                                {
                                    
                                    XmlNodeList sggList = sub.SelectNodes("SGG");
                                    foreach (XmlNode sgg in sggList) //선거구코드
                                    {
                                        string lines = "";
                                        string line = "*";
                                        string line2 = "";
                                        line += kind;
                                        line += "S";
                                        string[] arrHuboinfo = {"N","N","N","N","N","N","N","N","N","N","N","N","N","N","N",
                                                                "N","N","N","N","N","N","N","N","N","N","N","N","N","N","N"};
                                        string huboinfo = "";

                                        //문자열 숫자에 컴마 있는거 제거
                                        sgg.Attributes["total_cnt"].Value = sgg.Attributes["total_cnt"].Value.Replace(",", "");
                                        sgg.Attributes["voter_cnt"].Value = sgg.Attributes["voter_cnt"].Value.Replace(",", "");
                                        sgg.Attributes["open_cnt"].Value = sgg.Attributes["open_cnt"].Value.Replace(",", "");
                                        sgg.Attributes["not_num"].Value = sgg.Attributes["not_num"].Value.Replace(",", "");
                                        sgg.Attributes["hb_cnt"].Value = sgg.Attributes["hb_cnt"].Value.Replace(",", "");

                                        string suncode = String.Format("{0:D8}", int.Parse("".Equals(sgg.Attributes["code"].Value) ? "0" : sgg.Attributes["code"].Value));
                                        string yoocnt = String.Format("{0:D8}", int.Parse("".Equals(sgg.Attributes["total_cnt"].Value) ? "0" : sgg.Attributes["total_cnt"].Value));
                                        string toocnt = String.Format("{0:D8}", int.Parse("".Equals(sgg.Attributes["voter_cnt"].Value) ? "0" : sgg.Attributes["voter_cnt"].Value));
                                        string toorate = String.Format("{0:000.0}", double.Parse("".Equals(sgg.Attributes["vote_per"].Value) ? "0.0" : sgg.Attributes["vote_per"].Value));
                                        string tooend = "".Equals(sgg.Attributes["vote_yn"].Value) ? "N" : sgg.Attributes["vote_yn"].Value;
                                        string opencnt = String.Format("{0:D8}", int.Parse("".Equals(sgg.Attributes["open_cnt"].Value) ? "0" : sgg.Attributes["open_cnt"].Value));
                                        string openrate = String.Format("{0:000.0}", double.Parse("".Equals(sgg.Attributes["open_per"].Value) ? "0" : sgg.Attributes["open_per"].Value));
                                        string openend = "".Equals(sgg.Attributes["open_yn"].Value) ? "N" : sgg.Attributes["open_yn"].Value;
                                        string hubocnt = String.Format("{0:00}", int.Parse("".Equals(sgg.Attributes["hb_cnt"].Value) ? "0" : sgg.Attributes["hb_cnt"].Value));
                                        //string huboinfo = "YYYYYYYYYYYYYYYYYYYYYYYYYYYYYY";//30명
                                        string rank01 = String.Format("{0:00}", int.Parse("".Equals(sgg.Attributes["top_num"].Value) ? "0" : sgg.Attributes["top_num"].Value));
                                        string degree = String.Format("{0:00}", int.Parse("".Equals(sgg.Attributes["expec_cd"].Value) ? "0" : sgg.Attributes["expec_cd"].Value));
                                        string dukpcnt00 = String.Format("{0:D8}", int.Parse("".Equals(sgg.Attributes["not_num"].Value) ? "0" : sgg.Attributes["not_num"].Value));

                                        


                                        line += suncode;
                                        line += yoocnt;
                                        line += toocnt;
                                        line += toorate;
                                        line += tooend;
                                        line += opencnt;
                                        line += openrate;
                                        line += openend;
                                        line += hubocnt;

                                        XmlNodeList candiList = sgg.SelectNodes("CANDI");

                                        THubo[] hubo = new THubo[30];
                                        for (int j = 0; j < 30; j++ )
                                        {
                                            hubo[j].votecnt = "00000000";
                                            hubo[j].voterate = "000.0";
                                            hubo[j].rank = "99";
                                        }

                                        foreach (XmlNode candi in candiList)
                                        {
                                            int ordno;
                                            if(candi.Attributes["num"].Value.ToString().Trim() == "")
                                                ordno = 0;
                                            else
                                                ordno = int.Parse(candi.Attributes["num"].Value.ToString()) - 1;

                                            //문자열 숫자에 컴마 있는거 제거
                                            candi.Attributes["vote_cnt"].Value = candi.Attributes["vote_cnt"].Value.Replace(",", "");

                                            hubo[ordno].votecnt = String.Format("{0:D8}", int.Parse("".Equals(candi.Attributes["vote_cnt"].Value) ? "0" : candi.Attributes["vote_cnt"].Value.ToString().Replace(",", "")));
                                            hubo[ordno].voterate = String.Format("{0:000.0}", double.Parse("".Equals(candi.Attributes["vote_per"].Value) ? "0" : candi.Attributes["vote_per"].Value));
                                            hubo[ordno].rank = String.Format("{0:D2}", int.Parse("".Equals(candi.Attributes["rank"].Value) ? "0" : candi.Attributes["rank"].Value)); 
                                            arrHuboinfo[ordno] = "Y";
                                        }

                                        //후보 30만큼 채운다
                                        for (int j = 0; j < 30; j++)
                                        {
                                            line2 += hubo[j].votecnt + hubo[j].voterate + hubo[j].rank;
                                        }

                                        for (int k = 0; k < arrHuboinfo.Length; k++)
                                        {
                                            huboinfo += arrHuboinfo[k];
                                        }
                                        line += huboinfo;
                                        line += rank01;
                                        line += degree;
                                        line += dukpcnt00;

                                        XmlNode send = xml.SelectSingleNode("/VOTE/REG_DATE");
                                        string sendtime = send.InnerText;
                                        if (sendtime.Length == 12) sendtime = sendtime + "00";
                                        line2 += sendtime;
                                        line2 += "#";

                                        lines = line + line2;

                                        //시도 체크된 데이터만 업로드
                                        string chkLocal = "";
                                        if (this.chkSD11.Checked) chkLocal += this.chkSD11.Tag.ToString() + ",";
                                        if (this.chkSD26.Checked) chkLocal += this.chkSD26.Tag.ToString() + ",";
                                        if (this.chkSD27.Checked) chkLocal += this.chkSD27.Tag.ToString() + ",";
                                        if (this.chkSD28.Checked) chkLocal += this.chkSD28.Tag.ToString() + ",";
                                        if (this.chkSD29.Checked) chkLocal += this.chkSD29.Tag.ToString() + ",";
                                        if (this.chkSD30.Checked) chkLocal += this.chkSD30.Tag.ToString() + ",";
                                        if (this.chkSD31.Checked) chkLocal += this.chkSD31.Tag.ToString() + ",";
                                        if (this.chkSD41.Checked) chkLocal += this.chkSD41.Tag.ToString() + ",";
                                        if (this.chkSD42.Checked) chkLocal += this.chkSD42.Tag.ToString() + ",";
                                        if (this.chkSD43.Checked) chkLocal += this.chkSD43.Tag.ToString() + ",";
                                        if (this.chkSD44.Checked) chkLocal += this.chkSD44.Tag.ToString() + ",";
                                        if (this.chkSD45.Checked) chkLocal += this.chkSD45.Tag.ToString() + ",";
                                        if (this.chkSD46.Checked) chkLocal += this.chkSD46.Tag.ToString() + ",";
                                        if (this.chkSD47.Checked) chkLocal += this.chkSD47.Tag.ToString() + ",";
                                        if (this.chkSD48.Checked) chkLocal += this.chkSD48.Tag.ToString() + ",";
                                        if (this.chkSD49.Checked) chkLocal += this.chkSD49.Tag.ToString() + ",";
                                        if (this.chkSD51.Checked) chkLocal += this.chkSD51.Tag.ToString();

                                        //Console.WriteLine(chkLocal + ">>" + localCode);
                                        if (chkLocal.IndexOf(localCode) > -1)
                                        {
                                            addMsg(3, "+ ", "DB 업데이트 중...");
                                            UpdateData(lines); //2014 수정
                                            addMsg(3, "+ ", "DB 업데이트 완료");
                                        }


                                    }
                                }

                            }

                            //XmlNodeList sendList = xml.SelectNodes("/VOTE/REG_DATE");
                            
                        }

                    }
                    catch { }
                }
            }

            
            
        }

        private void UpdateData(string strData)
        {
            String result = "";
            Console.WriteLine(strData.Length + "," + SBSNLENGTH);
            if (strData.Length != SBSNLENGTH)
            {
                result = "데이터 길이 오류";
                
            }
            else
            {
                ArrayList col = new ArrayList();
                
                //try
                //{
                    
                    int p = 0;
                    for (int i = 0; i < SBSNCOUNT; i++)
                    {
                        //Console.WriteLine(strData.Substring(p, SBSNPOS[i]));

                        //Console.WriteLine(strData.Substring(0, 1));
                        //Console.WriteLine(strData.Substring(1, 1));
                        //Console.WriteLine(i + "==" + strData.Substring(p, SBSNPOS[i]).ToString());
                        try
                        {
                            col.Add(strData.Substring(p, SBSNPOS[i]).ToString());
                        }catch(Exception ex)
                        {
                            //
                        }
                        //col[i] = strData.Substring(p, SBSNPOS[i]).ToString();
                        p += SBSNPOS[i];
                        //Console.WriteLine(">>>>>>"+ col.Count);
                    }

                    //return;
                    //Console.WriteLine(">>>>>>"+ col.Count);
                    if (!"*".Equals(col[0])) result = "STX 오류 : " + col[0];
                    else if (!"#".Equals(col[SBSNCOUNT-1])) result = "ETX 오류 : " + col[SBSNCOUNT];
                    else if (!"2".Equals(col[1]) && !"3".Equals(col[1]) && !"4".Equals(col[1])) result = "선거종류 PASS : " + col[1];
                    else if (!"S".Equals(col[2])) result = "선거구분 PASS : " + col[2];
                    else
                    {
                        //Console.WriteLine("- " + "선거구 : " + col[1].ToString() + ", " + col[3].ToString());
                        addMsg(3, "- ", "선거구 : " + col[1].ToString() + " " + col[3].ToString()); 

                       
                        if ("".Equals(col[6].ToString().Trim())) col[6] = "0.0";
                        if ("".Equals(col[9].ToString().Trim())) col[9] = "0.0";

                        col[6] = String.Format("{0:0.0}", Convert.ToDecimal(col[6]));
                        col[9] = String.Format("{0:0.0}", Convert.ToDecimal(col[9]));

                        

                        connectDB(); //DB연결
                        try
                        {
                            conn.Open();

                            col[1] = col[1].ToString().PadLeft(2, '0');

                            string sql = "";
                            sql += "UPDATE ELE_TPRECSBS SET";
                            sql += " eleccnt = " + int.Parse(col[4].ToString());
                            sql += ", pollcnt = " + int.Parse(col[5].ToString());
                            sql += ", pollrate = '" + col[6] + "'";
                            sql += ", pollyn = '" + col[7] + "'";
                            sql += ", opencnt = " + int.Parse(col[8].ToString());
                            sql += ", openrate = '" + col[9] + "'";
                            sql += ", openyn = '" + col[10] + "'";
                            sql += ", fstno = '" + col[13] + "'";
                            sql += ", elecgbn = '" + col[14] + "'";
                            sql += ", cancnt = " + int.Parse(col[15].ToString());
                            sql += " where eleccatgr = '" + col[1] + "'";
                            sql += " and precid = '" + col[3] + "'";

                            Console.WriteLine(sql);
                            try
                            {
                                SqlCommand sqlCommand = new SqlCommand(sql, conn);
                                sqlCommand.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                addMsg(3, "@ ", "DB 선거구 오류: " + ex.Message); 
                                result = "Update 오류";
                            }

                            string hubo = col[12].ToString();
                            for (int i = 1; i <= HUBOCOUNT; i++)
                            {
                                Console.WriteLine(HUBOCOUNT + ">>>" + hubo + "<<<"+i);
                                if(hubo.Substring(i-1, 1).Equals("Y")){
                                    int pp = (i - 1) * 3 + 16;
                                    string ordno = String.Format("{0:00}", i);
                                    if ("".Equals(col[pp + 1])) col[pp + 1] = "0.0";
                                    col[pp + 1] = String.Format("{0:0.0}", double.Parse(col[pp+1].ToString()));

                                    addMsg(3, "- ", "후보자 : " + col[1].ToString() + " " + col[3].ToString() + " " + ordno);
                                    sql = "";
                                    sql += "UPDATE ELE_TCANDSBS SET";
                                    sql += " VOTESCNT = "+ int.Parse(col[pp].ToString());
                                    sql += ", VOTESRATE = '"+col[pp+1]+"'";
                                    sql += ", RANK = "+int.Parse(col[pp+2].ToString());
                                    sql += " WHERE ELECCATGR = '"+col[1]+"'";
                                    sql += " AND PRECID = '"+col[3]+"'";
                                    sql += " AND ORDNO = '"+ordno+"'";
                                    Console.WriteLine(sql);
                                    try
                                    {
                                        SqlCommand sqlCommand = new SqlCommand(sql, conn);
                                        sqlCommand.ExecuteNonQuery();
                                    }
                                    catch (Exception ex)
                                    {
                                        addMsg(1, "@ ", "DB 후보자 오류: " + ex.Message);
                                        result = "Update 오류";
                                    }
                                }
                            
                            }

                            conn.Close();
                        }catch(Exception ex){
                            MessageBox.Show(ex.Message);
                        }
                        result = "데이터 저장 성공";
                    }

                    
                   

                   
                //}
                //catch (Exception ex)
                //{
                //    result = ex.Message;
                //}
                //finally { }
            }
            addMsg(3, "- 데이터 DB업로드 : ", result);
            //Console.WriteLine(strData);
        }

        private void UpdateXMLData(string strData)
        {
            String result = "";
            Console.WriteLine(strData.Length + "," + SBSNLENGTH);
            if (strData.Length != SBSNLENGTH)
            {
                result = "데이터 길이 오류";

            }
            else
            {
                ArrayList col = new ArrayList();



                int p = 0;
                for (int i = 0; i < SBSNCOUNT; i++)
                {
                    //Console.WriteLine(strData.Substring(p, SBSNPOS[i]));

                    //Console.WriteLine(strData.Substring(0, 1));
                    //Console.WriteLine(strData.Substring(1, 1));
                    //Console.WriteLine(i + "==" + strData.Substring(p, SBSNPOS[i]).ToString());

                    col.Add(strData.Substring(p, SBSNPOS[i]).ToString());
                    //col[i] = strData.Substring(p, SBSNPOS[i]).ToString();
                    p += SBSNPOS[i];
                    //Console.WriteLine(">>>>>>"+ col.Count);
                }

                //return;
                //Console.WriteLine(">>>>>>"+ col.Count);
                if (!"*".Equals(col[0])) result = "STX 오류 : " + col[0];
                else if (!"#".Equals(col[SBSNCOUNT - 1])) result = "ETX 오류 : " + col[SBSNCOUNT];
                else if (!"2".Equals(col[1]) && !"3".Equals(col[1]) && !"4".Equals(col[1])) result = "선거종류 PASS : " + col[1];
                else if (!"S".Equals(col[2])) result = "선거구분 PASS : " + col[2];
                else
                {
                    //Console.WriteLine("- " + "선거구 : " + col[0].ToString() + ", " + col[6].ToString() + ", " + col[9].ToString() + ", " + col[SBSNCOUNT - 1]);


                    //Console.WriteLine("====6>>" + col[6]);
                    //Console.WriteLine("====9>>" + col[9]);

                    if ("".Equals(col[6].ToString().Trim())) col[6] = "0.0";
                    if ("".Equals(col[9].ToString().Trim())) col[9] = "0.0";

                    col[6] = String.Format("{0:0.0}", Convert.ToDecimal(col[6]));
                    col[9] = String.Format("{0:0.0}", Convert.ToDecimal(col[9]));



                    connectDB(); //DB연결
                    conn.Open();

                    string sql = "";
                    sql += "UPDATE ELE_TPRECSBS SET";
                    sql += " eleccnt = " + int.Parse(col[4].ToString());
                    sql += ", pollcnt = " + int.Parse(col[5].ToString());
                    sql += ", pollrate = '" + col[6] + "'";
                    sql += ", pollyn = '" + col[7] + "'";
                    sql += ", opencnt = " + int.Parse(col[8].ToString());
                    sql += ", openrate = '" + col[9] + "'";
                    sql += ", openyn = '" + col[10] + "'";
                    sql += ", fstno = '" + col[13] + "'";
                    sql += ", elecgbn = '" + col[14] + "'";
                    sql += ", cancnt = " + int.Parse(col[15].ToString());
                    sql += " where eleccatgr = '" + col[1] + "'";
                    sql += " and precid = '" + col[3] + "'";

                    Console.WriteLine(sql);
                    try
                    {
                        SqlCommand sqlCommand = new SqlCommand(sql, conn);
                        sqlCommand.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        result = "Update 오류";
                    }

                    for (int i = 1; i <= HUBOCOUNT; i++)
                    {
                        string hubo = col[12].ToString();
                        Console.WriteLine(HUBOCOUNT + ">>>" + hubo + "<<<" + i);
                        if (hubo.Substring(i - 1, 1).Equals("Y"))
                        {
                            int pp = (i - 1) * 3 + 16;
                            string ordno = String.Format("{0:00}", i);
                            if ("".Equals(col[pp + 1])) col[pp + 1] = "0.0";
                            col[pp + 1] = String.Format("{0:0.0}", double.Parse(col[pp + 1].ToString()));


                            sql = "";
                            sql += "UPDATE ELE_TCANDSBS SET";
                            sql += " VOTESCNT = " + int.Parse(col[pp].ToString());
                            sql += ", VOTESRATE = '" + col[pp + 1] + "'";
                            sql += ", RANK = " + int.Parse(col[pp + 2].ToString());
                            sql += " WHERE ELECCATGR = '" + col[1] + "'";
                            sql += " AND PRECID = '" + col[3] + "'";
                            sql += " AND ORDNO = '" + ordno + "'";
                            Console.WriteLine(sql);
                            try
                            {
                                SqlCommand sqlCommand = new SqlCommand(sql, conn);
                                sqlCommand.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                result = "Update 오류";
                            }
                        }
                    }

                    conn.Close();

                    result = "데이터 저장 성공";
                }






            }
            addMsg(2, "데이터 DB업로드 : ", result);
            //Console.WriteLine(strData);
        }

        private void connectDB()
        {
            string connectionString = this.txtConnStr.Text.ToString().Trim();
            try
            {
                conn = new SqlConnection(connectionString);
            }
            catch (Exception ex)
            {
                addMsg(1, "DB연결 : ", ex.Message);
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Console.WriteLine("===========123");
            timer1.Stop();
            btnExec_Click(btnExec, null);
        }

        private void setSDCheck()
        {
            string sd = "";

            if (this.chkSD11.Checked) sd += this.chkSD11.Tag.ToString() + ",";
            if (this.chkSD26.Checked) sd += this.chkSD26.Tag.ToString() + ",";
            if (this.chkSD27.Checked) sd += this.chkSD27.Tag.ToString() + ",";
            if (this.chkSD28.Checked) sd += this.chkSD28.Tag.ToString() + ",";
            if (this.chkSD29.Checked) sd += this.chkSD29.Tag.ToString() + ",";
            if (this.chkSD30.Checked) sd += this.chkSD30.Tag.ToString() + ",";
            if (this.chkSD31.Checked) sd += this.chkSD31.Tag.ToString() + ",";
            if (this.chkSD41.Checked) sd += this.chkSD41.Tag.ToString() + ",";
            if (this.chkSD42.Checked) sd += this.chkSD42.Tag.ToString() + ",";
            if (this.chkSD43.Checked) sd += this.chkSD43.Tag.ToString() + ",";
            if (this.chkSD44.Checked) sd += this.chkSD44.Tag.ToString() + ",";
            if (this.chkSD45.Checked) sd += this.chkSD45.Tag.ToString() + ",";
            if (this.chkSD46.Checked) sd += this.chkSD46.Tag.ToString() + ",";
            if (this.chkSD47.Checked) sd += this.chkSD47.Tag.ToString() + ",";
            if (this.chkSD48.Checked) sd += this.chkSD48.Tag.ToString() + ",";
            if (this.chkSD49.Checked) sd += this.chkSD49.Tag.ToString() + ",";
            if (this.chkSD51.Checked) sd += this.chkSD51.Tag.ToString();

            Global.IniFile.SetString("DB", "SD", sd);
        }

        private void txtHTTPFile2_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("DB", "HTTP2", this.txtHTTPFile2.Text.ToString().Trim());
        }

        private void txtHTTPFile3_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("DB", "HTTP3", this.txtHTTPFile3.Text.ToString().Trim());
        }

        private void chkSD11_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD26_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD27_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD28_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD29_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD30_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD31_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD41_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD42_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD43_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD44_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD45_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD46_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD47_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD48_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD49_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkSD51_CheckedChanged(object sender, EventArgs e)
        {
            setSDCheck();
        }

        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAll.Checked)
            {
                this.chkSD11.Checked = true; this.chkSD26.Checked = true;
                this.chkSD27.Checked = true; this.chkSD28.Checked = true;
                this.chkSD29.Checked = true; this.chkSD30.Checked = true;
                this.chkSD31.Checked = true; this.chkSD41.Checked = true;
                this.chkSD42.Checked = true; this.chkSD43.Checked = true;
                this.chkSD44.Checked = true; this.chkSD45.Checked = true;
                this.chkSD46.Checked = true; this.chkSD47.Checked = true;
                this.chkSD48.Checked = true; this.chkSD49.Checked = true;
                this.chkSD51.Checked = true; 
            }
            else
            {
                this.chkSD11.Checked = false; this.chkSD26.Checked = false;
                this.chkSD27.Checked = false; this.chkSD28.Checked = false;
                this.chkSD29.Checked = false; this.chkSD30.Checked = false;
                this.chkSD31.Checked = false; this.chkSD41.Checked = false;
                this.chkSD42.Checked = false; this.chkSD43.Checked = false;
                this.chkSD44.Checked = false; this.chkSD45.Checked = false;
                this.chkSD46.Checked = false; this.chkSD47.Checked = false;
                this.chkSD48.Checked = false; this.chkSD49.Checked = false;
                this.chkSD51.Checked = false;
            }
        }

        private void btnExecFolder_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", Global.StartupPath);
        }

        private void btnINI_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", Global.DataPath);
        }

        
    }
}
