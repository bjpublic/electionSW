﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Deployment.Application;
using System.IO;
using IniFile;

namespace ElectDB
{
    class Global
    {
        /// <summary>
        ///     버젼
        /// </summary>
        public static string Version
        {
            get
            {
                string ver = Application.ProductVersion;
                if (ApplicationDeployment.IsNetworkDeployed)
                    ver = ApplicationDeployment.CurrentDeployment.CurrentVersion.ToString();
                return ver;
            }
        }
        public static string Title = "2018 선거 개표자료 수신기";

        /// <summary>
        ///     ini 전체 파일명
        /// </summary>
        private static string IniFileName = DataPath + "\\" + ExeName + ".INI";

        public static TIniFile IniFile
        {
            get
            {
                //if it's not already there, 
                //copy the file from the deployment location to the folder
                string sourceFilePath = Path.Combine(StartupPath, ExeName + ".ini");
                string destFilePath = IniFileName;
                if (!File.Exists(destFilePath))
                {
                    File.Copy(sourceFilePath, destFilePath);
                }

                return new TIniFile(IniFileName);
            }
        }

        /// <summary>
        ///     실행파일의 full path
        /// </summary>
        public static string ExecutablePath
        {
            get { return Application.ExecutablePath; }
        }

        /// <summary>
        ///     실행파일의 folder path
        /// </summary>
        public static string StartupPath
        {
            get { return Application.StartupPath; }
        }

        public static string DataPath
        {
            get
            {
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string userFilePath = Path.Combine(localAppData, "KNN");

                if (!Directory.Exists(userFilePath))
                    Directory.CreateDirectory(userFilePath);

                return userFilePath;
            }
        }

        /// <summary>
        ///     확장자없는 실행파일명
        /// </summary>
        public static string ExeName
        {
            get
            {
                string name = ExeNameNExt;
                int n = name.LastIndexOf(".");
                return name.Substring(0, n);
            }
        }

        /// <summary>
        ///     확장자있는 실행파일명
        /// </summary>
        public static string ExeNameNExt
        {
            get
            {
                string path = ExecutablePath;
                int n = path.LastIndexOf(@"\");
                return path.Substring(n + 1);
            }
        }
    }
}
