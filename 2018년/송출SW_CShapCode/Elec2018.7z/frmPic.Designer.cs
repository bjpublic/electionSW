﻿namespace Election
{
    partial class frmPic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPic));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCnt = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSelPic = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.txtFooter = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnQuery = new System.Windows.Forms.Button();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.bsCity = new System.Windows.Forms.BindingSource(this.components);
            this.elecDataSet = new Election.DB.ElecDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbElec = new System.Windows.Forms.ComboBox();
            this.bsElec = new System.Windows.Forms.BindingSource(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.dgvCand = new System.Windows.Forms.DataGridView();
            this.elecCatgrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.bsPrec = new System.Windows.Forms.BindingSource(this.components);
            this.ordNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.korNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chaNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partyCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.bsParty = new System.Windows.Forms.BindingSource(this.components);
            this.socialNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addr1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addr2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.schCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradYMDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jobCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.career1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.career2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.career3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.career4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.regGbnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.bsRegGubn = new System.Windows.Forms.BindingSource(this.components);
            this.elecCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.candCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.regYMDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chgYMDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chgResnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsCand = new System.Windows.Forms.BindingSource(this.components);
            this.bsCode = new System.Windows.Forms.BindingSource(this.components);
            this.taCode = new Election.DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter();
            this.taCand = new Election.DB.ElecDataSetTableAdapters.Ele_TCandTableAdapter();
            this.taPrec = new Election.DB.ElecDataSetTableAdapters.Ele_TPrecTableAdapter();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsElec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsParty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsRegGubn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCode)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(849, 53);
            this.panel1.TabIndex = 0;
            // 
            // txtCnt
            // 
            this.txtCnt.Location = new System.Drawing.Point(460, 10);
            this.txtCnt.Name = "txtCnt";
            this.txtCnt.ReadOnly = true;
            this.txtCnt.Size = new System.Drawing.Size(47, 21);
            this.txtCnt.TabIndex = 48;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtCnt);
            this.panel2.Controls.Add(this.btnSelPic);
            this.panel2.Controls.Add(this.btnExit);
            this.panel2.Controls.Add(this.btnCreate);
            this.panel2.Controls.Add(this.txtFooter);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.btnQuery);
            this.panel2.Controls.Add(this.cmbCity);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cmbElec);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 53);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(849, 45);
            this.panel2.TabIndex = 1;
            // 
            // btnSelPic
            // 
            this.btnSelPic.Location = new System.Drawing.Point(513, 9);
            this.btnSelPic.Name = "btnSelPic";
            this.btnSelPic.Size = new System.Drawing.Size(65, 23);
            this.btnSelPic.TabIndex = 53;
            this.btnSelPic.Text = "사진선택";
            this.btnSelPic.UseVisualStyleBackColor = true;
            this.btnSelPic.Click += new System.EventHandler(this.btnSelPic_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(782, 9);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(55, 23);
            this.btnExit.TabIndex = 52;
            this.btnExit.Text = "종료";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(701, 9);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(63, 23);
            this.btnCreate.TabIndex = 51;
            this.btnCreate.Text = "사진생성";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // txtFooter
            // 
            this.txtFooter.Location = new System.Drawing.Point(648, 10);
            this.txtFooter.Name = "txtFooter";
            this.txtFooter.Size = new System.Drawing.Size(47, 21);
            this.txtFooter.TabIndex = 50;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(585, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 21);
            this.label3.TabIndex = 49;
            this.label3.Text = "꼬리말";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(382, 9);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(55, 23);
            this.btnQuery.TabIndex = 46;
            this.btnQuery.Text = "조회";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // cmbCity
            // 
            this.cmbCity.DataSource = this.bsCity;
            this.cmbCity.DisplayMember = "ADesc";
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Location = new System.Drawing.Point(296, 10);
            this.cmbCity.MaxLength = 2;
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.Size = new System.Drawing.Size(81, 20);
            this.cmbCity.TabIndex = 45;
            this.cmbCity.ValueMember = "Code";
            // 
            // bsCity
            // 
            this.bsCity.AllowNew = true;
            this.bsCity.DataMember = "Ele_TCode";
            this.bsCity.DataSource = this.elecDataSet;
            // 
            // elecDataSet
            // 
            this.elecDataSet.DataSetName = "ElecDataSet";
            this.elecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(203, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 21);
            this.label1.TabIndex = 44;
            this.label1.Text = "시도";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbElec
            // 
            this.cmbElec.DataSource = this.bsElec;
            this.cmbElec.DisplayMember = "ADesc";
            this.cmbElec.FormattingEnabled = true;
            this.cmbElec.Location = new System.Drawing.Point(105, 10);
            this.cmbElec.MaxLength = 2;
            this.cmbElec.Name = "cmbElec";
            this.cmbElec.Size = new System.Drawing.Size(90, 20);
            this.cmbElec.TabIndex = 43;
            this.cmbElec.ValueMember = "Code";
            // 
            // bsElec
            // 
            this.bsElec.AllowNew = true;
            this.bsElec.DataMember = "Ele_TCode";
            this.bsElec.DataSource = this.elecDataSet;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(12, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 21);
            this.label7.TabIndex = 42;
            this.label7.Text = "선거종류";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvCand
            // 
            this.dgvCand.AllowUserToAddRows = false;
            this.dgvCand.AllowUserToDeleteRows = false;
            this.dgvCand.AllowUserToResizeRows = false;
            this.dgvCand.AutoGenerateColumns = false;
            this.dgvCand.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCand.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.elecCatgrDataGridViewTextBoxColumn,
            this.precIDDataGridViewTextBoxColumn,
            this.ordNoDataGridViewTextBoxColumn,
            this.korNameDataGridViewTextBoxColumn,
            this.chaNameDataGridViewTextBoxColumn,
            this.partyCodeDataGridViewTextBoxColumn,
            this.socialNoDataGridViewTextBoxColumn,
            this.addr1DataGridViewTextBoxColumn,
            this.telDataGridViewTextBoxColumn,
            this.addr2DataGridViewTextBoxColumn,
            this.schCodeDataGridViewTextBoxColumn,
            this.gradYMDDataGridViewTextBoxColumn,
            this.jobCodeDataGridViewTextBoxColumn,
            this.career1DataGridViewTextBoxColumn,
            this.career2DataGridViewTextBoxColumn,
            this.career3DataGridViewTextBoxColumn,
            this.career4DataGridViewTextBoxColumn,
            this.regGbnDataGridViewTextBoxColumn,
            this.elecCntDataGridViewTextBoxColumn,
            this.candCntDataGridViewTextBoxColumn,
            this.regYMDDataGridViewTextBoxColumn,
            this.chgYMDDataGridViewTextBoxColumn,
            this.chgResnDataGridViewTextBoxColumn});
            this.dgvCand.DataSource = this.bsCand;
            this.dgvCand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCand.Location = new System.Drawing.Point(0, 98);
            this.dgvCand.MultiSelect = false;
            this.dgvCand.Name = "dgvCand";
            this.dgvCand.ReadOnly = true;
            this.dgvCand.RowHeadersVisible = false;
            this.dgvCand.RowTemplate.Height = 23;
            this.dgvCand.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCand.Size = new System.Drawing.Size(849, 406);
            this.dgvCand.TabIndex = 48;
            // 
            // elecCatgrDataGridViewTextBoxColumn
            // 
            this.elecCatgrDataGridViewTextBoxColumn.DataPropertyName = "ElecCatgr";
            this.elecCatgrDataGridViewTextBoxColumn.HeaderText = "ElecCatgr";
            this.elecCatgrDataGridViewTextBoxColumn.Name = "elecCatgrDataGridViewTextBoxColumn";
            this.elecCatgrDataGridViewTextBoxColumn.ReadOnly = true;
            this.elecCatgrDataGridViewTextBoxColumn.Visible = false;
            // 
            // precIDDataGridViewTextBoxColumn
            // 
            this.precIDDataGridViewTextBoxColumn.DataPropertyName = "PrecID";
            this.precIDDataGridViewTextBoxColumn.DataSource = this.bsPrec;
            this.precIDDataGridViewTextBoxColumn.DisplayMember = "PrecName";
            this.precIDDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.precIDDataGridViewTextBoxColumn.HeaderText = "선거구명";
            this.precIDDataGridViewTextBoxColumn.Name = "precIDDataGridViewTextBoxColumn";
            this.precIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.precIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.precIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.precIDDataGridViewTextBoxColumn.ValueMember = "PrecID";
            // 
            // bsPrec
            // 
            this.bsPrec.AllowNew = true;
            this.bsPrec.DataMember = "Ele_TPrec";
            this.bsPrec.DataSource = this.elecDataSet;
            // 
            // ordNoDataGridViewTextBoxColumn
            // 
            this.ordNoDataGridViewTextBoxColumn.DataPropertyName = "OrdNo";
            this.ordNoDataGridViewTextBoxColumn.HeaderText = "기호";
            this.ordNoDataGridViewTextBoxColumn.Name = "ordNoDataGridViewTextBoxColumn";
            this.ordNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // korNameDataGridViewTextBoxColumn
            // 
            this.korNameDataGridViewTextBoxColumn.DataPropertyName = "KorName";
            this.korNameDataGridViewTextBoxColumn.HeaderText = "성명";
            this.korNameDataGridViewTextBoxColumn.Name = "korNameDataGridViewTextBoxColumn";
            this.korNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // chaNameDataGridViewTextBoxColumn
            // 
            this.chaNameDataGridViewTextBoxColumn.DataPropertyName = "ChaName";
            this.chaNameDataGridViewTextBoxColumn.HeaderText = "ChaName";
            this.chaNameDataGridViewTextBoxColumn.Name = "chaNameDataGridViewTextBoxColumn";
            this.chaNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.chaNameDataGridViewTextBoxColumn.Visible = false;
            // 
            // partyCodeDataGridViewTextBoxColumn
            // 
            this.partyCodeDataGridViewTextBoxColumn.DataPropertyName = "PartyCode";
            this.partyCodeDataGridViewTextBoxColumn.DataSource = this.bsParty;
            this.partyCodeDataGridViewTextBoxColumn.DisplayMember = "ADesc";
            this.partyCodeDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.partyCodeDataGridViewTextBoxColumn.HeaderText = "정당";
            this.partyCodeDataGridViewTextBoxColumn.Name = "partyCodeDataGridViewTextBoxColumn";
            this.partyCodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.partyCodeDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.partyCodeDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.partyCodeDataGridViewTextBoxColumn.ValueMember = "Code";
            // 
            // bsParty
            // 
            this.bsParty.AllowNew = true;
            this.bsParty.DataMember = "Ele_TCode";
            this.bsParty.DataSource = this.elecDataSet;
            // 
            // socialNoDataGridViewTextBoxColumn
            // 
            this.socialNoDataGridViewTextBoxColumn.DataPropertyName = "SocialNo";
            this.socialNoDataGridViewTextBoxColumn.HeaderText = "SocialNo";
            this.socialNoDataGridViewTextBoxColumn.Name = "socialNoDataGridViewTextBoxColumn";
            this.socialNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.socialNoDataGridViewTextBoxColumn.Visible = false;
            // 
            // addr1DataGridViewTextBoxColumn
            // 
            this.addr1DataGridViewTextBoxColumn.DataPropertyName = "Addr1";
            this.addr1DataGridViewTextBoxColumn.HeaderText = "Addr1";
            this.addr1DataGridViewTextBoxColumn.Name = "addr1DataGridViewTextBoxColumn";
            this.addr1DataGridViewTextBoxColumn.ReadOnly = true;
            this.addr1DataGridViewTextBoxColumn.Visible = false;
            // 
            // telDataGridViewTextBoxColumn
            // 
            this.telDataGridViewTextBoxColumn.DataPropertyName = "Tel";
            this.telDataGridViewTextBoxColumn.HeaderText = "Tel";
            this.telDataGridViewTextBoxColumn.Name = "telDataGridViewTextBoxColumn";
            this.telDataGridViewTextBoxColumn.ReadOnly = true;
            this.telDataGridViewTextBoxColumn.Visible = false;
            // 
            // addr2DataGridViewTextBoxColumn
            // 
            this.addr2DataGridViewTextBoxColumn.DataPropertyName = "Addr2";
            this.addr2DataGridViewTextBoxColumn.HeaderText = "Addr2";
            this.addr2DataGridViewTextBoxColumn.Name = "addr2DataGridViewTextBoxColumn";
            this.addr2DataGridViewTextBoxColumn.ReadOnly = true;
            this.addr2DataGridViewTextBoxColumn.Visible = false;
            // 
            // schCodeDataGridViewTextBoxColumn
            // 
            this.schCodeDataGridViewTextBoxColumn.DataPropertyName = "SchCode";
            this.schCodeDataGridViewTextBoxColumn.HeaderText = "SchCode";
            this.schCodeDataGridViewTextBoxColumn.Name = "schCodeDataGridViewTextBoxColumn";
            this.schCodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.schCodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // gradYMDDataGridViewTextBoxColumn
            // 
            this.gradYMDDataGridViewTextBoxColumn.DataPropertyName = "GradYMD";
            this.gradYMDDataGridViewTextBoxColumn.HeaderText = "GradYMD";
            this.gradYMDDataGridViewTextBoxColumn.Name = "gradYMDDataGridViewTextBoxColumn";
            this.gradYMDDataGridViewTextBoxColumn.ReadOnly = true;
            this.gradYMDDataGridViewTextBoxColumn.Visible = false;
            // 
            // jobCodeDataGridViewTextBoxColumn
            // 
            this.jobCodeDataGridViewTextBoxColumn.DataPropertyName = "JobCode";
            this.jobCodeDataGridViewTextBoxColumn.HeaderText = "JobCode";
            this.jobCodeDataGridViewTextBoxColumn.Name = "jobCodeDataGridViewTextBoxColumn";
            this.jobCodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.jobCodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // career1DataGridViewTextBoxColumn
            // 
            this.career1DataGridViewTextBoxColumn.DataPropertyName = "Career1";
            this.career1DataGridViewTextBoxColumn.HeaderText = "경력";
            this.career1DataGridViewTextBoxColumn.Name = "career1DataGridViewTextBoxColumn";
            this.career1DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // career2DataGridViewTextBoxColumn
            // 
            this.career2DataGridViewTextBoxColumn.DataPropertyName = "Career2";
            this.career2DataGridViewTextBoxColumn.HeaderText = "Career2";
            this.career2DataGridViewTextBoxColumn.Name = "career2DataGridViewTextBoxColumn";
            this.career2DataGridViewTextBoxColumn.ReadOnly = true;
            this.career2DataGridViewTextBoxColumn.Visible = false;
            // 
            // career3DataGridViewTextBoxColumn
            // 
            this.career3DataGridViewTextBoxColumn.DataPropertyName = "Career3";
            this.career3DataGridViewTextBoxColumn.HeaderText = "Career3";
            this.career3DataGridViewTextBoxColumn.Name = "career3DataGridViewTextBoxColumn";
            this.career3DataGridViewTextBoxColumn.ReadOnly = true;
            this.career3DataGridViewTextBoxColumn.Visible = false;
            // 
            // career4DataGridViewTextBoxColumn
            // 
            this.career4DataGridViewTextBoxColumn.DataPropertyName = "Career4";
            this.career4DataGridViewTextBoxColumn.HeaderText = "Career4";
            this.career4DataGridViewTextBoxColumn.Name = "career4DataGridViewTextBoxColumn";
            this.career4DataGridViewTextBoxColumn.ReadOnly = true;
            this.career4DataGridViewTextBoxColumn.Visible = false;
            // 
            // regGbnDataGridViewTextBoxColumn
            // 
            this.regGbnDataGridViewTextBoxColumn.DataPropertyName = "RegGbn";
            this.regGbnDataGridViewTextBoxColumn.DataSource = this.bsRegGubn;
            this.regGbnDataGridViewTextBoxColumn.DisplayMember = "ADesc";
            this.regGbnDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.regGbnDataGridViewTextBoxColumn.HeaderText = "등록구분";
            this.regGbnDataGridViewTextBoxColumn.Name = "regGbnDataGridViewTextBoxColumn";
            this.regGbnDataGridViewTextBoxColumn.ReadOnly = true;
            this.regGbnDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.regGbnDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.regGbnDataGridViewTextBoxColumn.ValueMember = "Code";
            // 
            // bsRegGubn
            // 
            this.bsRegGubn.AllowNew = true;
            this.bsRegGubn.DataMember = "Ele_TCode";
            this.bsRegGubn.DataSource = this.elecDataSet;
            // 
            // elecCntDataGridViewTextBoxColumn
            // 
            this.elecCntDataGridViewTextBoxColumn.DataPropertyName = "ElecCnt";
            this.elecCntDataGridViewTextBoxColumn.HeaderText = "ElecCnt";
            this.elecCntDataGridViewTextBoxColumn.Name = "elecCntDataGridViewTextBoxColumn";
            this.elecCntDataGridViewTextBoxColumn.ReadOnly = true;
            this.elecCntDataGridViewTextBoxColumn.Visible = false;
            // 
            // candCntDataGridViewTextBoxColumn
            // 
            this.candCntDataGridViewTextBoxColumn.DataPropertyName = "CandCnt";
            this.candCntDataGridViewTextBoxColumn.HeaderText = "CandCnt";
            this.candCntDataGridViewTextBoxColumn.Name = "candCntDataGridViewTextBoxColumn";
            this.candCntDataGridViewTextBoxColumn.ReadOnly = true;
            this.candCntDataGridViewTextBoxColumn.Visible = false;
            // 
            // regYMDDataGridViewTextBoxColumn
            // 
            this.regYMDDataGridViewTextBoxColumn.DataPropertyName = "RegYMD";
            this.regYMDDataGridViewTextBoxColumn.HeaderText = "RegYMD";
            this.regYMDDataGridViewTextBoxColumn.Name = "regYMDDataGridViewTextBoxColumn";
            this.regYMDDataGridViewTextBoxColumn.ReadOnly = true;
            this.regYMDDataGridViewTextBoxColumn.Visible = false;
            // 
            // chgYMDDataGridViewTextBoxColumn
            // 
            this.chgYMDDataGridViewTextBoxColumn.DataPropertyName = "ChgYMD";
            this.chgYMDDataGridViewTextBoxColumn.HeaderText = "ChgYMD";
            this.chgYMDDataGridViewTextBoxColumn.Name = "chgYMDDataGridViewTextBoxColumn";
            this.chgYMDDataGridViewTextBoxColumn.ReadOnly = true;
            this.chgYMDDataGridViewTextBoxColumn.Visible = false;
            // 
            // chgResnDataGridViewTextBoxColumn
            // 
            this.chgResnDataGridViewTextBoxColumn.DataPropertyName = "ChgResn";
            this.chgResnDataGridViewTextBoxColumn.HeaderText = "ChgResn";
            this.chgResnDataGridViewTextBoxColumn.Name = "chgResnDataGridViewTextBoxColumn";
            this.chgResnDataGridViewTextBoxColumn.ReadOnly = true;
            this.chgResnDataGridViewTextBoxColumn.Visible = false;
            // 
            // bsCand
            // 
            this.bsCand.AllowNew = true;
            this.bsCand.DataMember = "Ele_TCand";
            this.bsCand.DataSource = this.elecDataSet;
            // 
            // bsCode
            // 
            this.bsCode.AllowNew = true;
            this.bsCode.DataMember = "Ele_TCode";
            this.bsCode.DataSource = this.elecDataSet;
            // 
            // taCode
            // 
            this.taCode.ClearBeforeFill = true;
            // 
            // taCand
            // 
            this.taCand.ClearBeforeFill = true;
            // 
            // taPrec
            // 
            this.taPrec.ClearBeforeFill = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // frmPic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 504);
            this.Controls.Add(this.dgvCand);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmPic";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "후보사진생성";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsElec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsParty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsRegGubn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCode)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cmbElec;
        private System.Windows.Forms.Label label7;
        private DB.ElecDataSet elecDataSet;
        private System.Windows.Forms.BindingSource bsCode;
        private System.Windows.Forms.BindingSource bsElec;
        private System.Windows.Forms.BindingSource bsCity;
        private DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter taCode;
        private System.Windows.Forms.ComboBox cmbCity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.DataGridView dgvCand;
        private System.Windows.Forms.BindingSource bsCand;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCnt;
        private System.Windows.Forms.TextBox txtFooter;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCreate;
        private DB.ElecDataSetTableAdapters.Ele_TCandTableAdapter taCand;
        private System.Windows.Forms.BindingSource bsPrec;
        private DB.ElecDataSetTableAdapters.Ele_TPrecTableAdapter taPrec;
        private System.Windows.Forms.BindingSource bsParty;
        private System.Windows.Forms.BindingSource bsRegGubn;
        private System.Windows.Forms.DataGridViewTextBoxColumn elecCatgrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn precIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ordNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn korNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn chaNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn partyCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn socialNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addr1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addr2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn schCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradYMDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jobCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn career1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn career2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn career3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn career4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn regGbnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn elecCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn candCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn regYMDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn chgYMDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn chgResnDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnSelPic;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}