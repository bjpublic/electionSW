﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Election
{
    public partial class frmPrec : Form
    {
        //콤보박스용 데이터테이블
        private DB.ElecDataSet.Ele_TCodeDataTable dtCity;       //시도
        private DB.ElecDataSet.Ele_TCodeDataTable dtElecCatgr;  //선거종류
        //선거구용 데이터테이블
        private DB.ElecDataSet.Ele_TPrecDataTable dtPrec;

        private Boolean isNew = false;
        private Boolean isSearch = false;

        public frmPrec()
        {
            InitializeComponent();
            //초기화작업
            Init();
        }

        private void Init()
        {
            //소스좀 갱신해라... login시 CompLikeString설정값 넘어온다.
            //지금은 걍 
            //Global.CompLikeString = "____Y__";

            //조회용 콤보박스 초기화 - 선거종류
            dtElecCatgr = taCode.GetDataByCompLikeStr("010", Global.CompLikeString);
            cbElecCatgr.DataSource = dtElecCatgr;
            //조회용 콤보박스 초기화 - 시도
            dtCity = taCode.GetDataByCompLikeStr("600", Global.CompLikeString);
            cbCity.DataSource = dtCity;
            //리스트콤보용 초기화
            bsElecCatgr.DataSource = taCode.GetDataByCompLikeStr("010", Global.CompLikeString);
            bsCity.DataSource = taCode.GetDataByCompLikeStr("600", Global.CompLikeString);


            setControl();
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            isNew = false;
            isSearch = true;
            //조회조건 설정
            string elecCatgr = cbElecCatgr.SelectedValue.ToString();
            string city = cbCity.SelectedValue.ToString();

            //선거구데이터 조회
            //dtPrec = taPrec.GetData(elecCatgr, city);
            taPrec.Fill(elecDataSet.Ele_TPrec, elecCatgr, city);
            //bsPrec.DataSource = dtPrec;

            setControl();
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            isNew = false;
            if (isSearch)
            {
                this.txtPrecID.ReadOnly = true;
                bsPrec.EndEdit();
                taPrec.Update(elecDataSet.Ele_TPrec);
            }
            setControl();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            isNew = false;
            if (bsPrec.Count > 0)
            {
                bsPrec.RemoveCurrent();
                //dgvPrec.SelectedRows = bsPrec.Current;
            }

            setControl();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            isNew = true;
            //선거구코드 활성화  
            elecDataSet.Ele_TPrec.AddEle_TPrecRow(cbElecCatgr.SelectedValue.ToString(), "", 0, "", cbCity.SelectedValue.ToString().Trim(), 0, 0, 0, 0);
            bsPrec.MoveLast();
            //bsPrec.AddNew();
            //DataRowView drv = (DataRowView)bsPrec.Current;
            //drv["ElecCatgr"] = cbElecCatgr.SelectedValue.ToString();
            //drv["City"] = cbCity.SelectedValue.ToString().Trim();
            
            setControl();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvPrec_SelectionChanged(object sender, EventArgs e)
        {
            //선거구코드 비활성화
            if(isNew) this.txtPrecID.ReadOnly = false;
            else this.txtPrecID.ReadOnly = true;
        }


        public void setControl()
        {
            

            if (bsPrec.Count == 0)
            {
                this.btnDel.Enabled = false;
                this.tsmDel.Enabled = false;

            }
            else
            {
                this.btnDel.Enabled = true;
                this.tsmDel.Enabled = true;
            }

        }

        private void txtPollDist_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e);
        }

        private void txtPopCnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e);
        }

        private void txtHomeCnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e);
        }

        private void txtAdultCnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e);
        }


        private void txtKeyPress(object sender, KeyPressEventArgs e)
        {
            int keyCode = (int)e.KeyChar;  // 46: Point  
            if ((keyCode < 48 || keyCode > 57) && keyCode != 8 && keyCode != 46)
            {
                e.Handled = true;
            }

        }

        private void tsmNew_Click(object sender, EventArgs e)
        {
            this.btnNew_Click(sender, e);
        }

        private void tsmDel_Click(object sender, EventArgs e)
        {
            this.btnDel_Click(sender, e);
        }

        private void tsmSave_Click(object sender, EventArgs e)
        {
            this.btnSave_Click(sender, e);
        }

        private void tsmQuery_Click(object sender, EventArgs e)
        {
            this.btnQuery_Click(sender, e);
        }

        private void tsmExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

       
    }
}

