﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Knn
{
    //개표방송에 필요한 몇가지 문자열처리 함수
    class StrFuncs 
    {
        //숫자를 한글로 표시하는 함수
        //  number : 처리할 숫자 문자열
        //  isAll : 전체숫자 처리여부
        // ex : NumToHangul("12345678", false) = "1234만5678", NumToHangul("12345678", true) = "일천이백삼십사만오천육백칠십팔"
        public static string NumToHangul(string number, bool isAll = true)
        {
            //일단위
            string[] Nums = { "", "일", "이", "삼", "사", "오", "육", "칠", "팔", "구" };
            //4자리단위의 안쪽 단위
            string[] InUnits = {"", "십", "백", "천"};
            //4자리단위의 바깥쪽 단위
            string[] OutUnits = { "", "만", "억", "조", "경", "해" };

            string result = "";
            int idx = 0;

            while (number.Length > idx)
            {
                //오른쪽(1자리부터 위로 이동) 한글자 get
                string sNum = number.Substring(number.Length - idx - 1, 1);
                int iNum = Convert.ToInt32(sNum);
                int iInUnit = idx % 4;
                int iOutUnit = idx / 4;

                //전체 숫자를 한글로 표시
                if(isAll)
                {
                    if (iInUnit == 0 && iOutUnit > 0)
                        result = Nums[iNum] + InUnits[iInUnit] + OutUnits[iOutUnit] + result;
                    else if(iNum > 0)
                        result = Nums[iNum] + InUnits[iInUnit] + result;
                }
                //일부 숫자를 한글로 표시
                else
                {
                    //4자리 바깥단위와 숫자문자열 사용
                    if (iInUnit == 0 && iOutUnit > 0)
                        result = sNum + OutUnits[iOutUnit] + " " + result;
                    //4자리 안쪽단위는 생략
                    else
                        result = sNum + "" + result;
                }
                idx++;
            }

            if (!isAll && result.Length > 4) 
            {
                result = result.Substring(0, result.Length - 4) + Convert.ToInt32(result.Substring(result.Length - 4)).ToString();
            }

            return result;
        }
    }
}
