﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using K3DAsyncEngineLib;

namespace TornadoAPI
{
    //토네이도 이벤트핸들러 선언
    public delegate void TornadoAPIEventHandler(bool result);
    public delegate void TornadoAPINoneEventHandler();
    public delegate void TornadoAPILogEventHandler(string msg);
    public delegate void TornadoAPINumEventHandler(uint num);

    public class Tornado
    {
        //토네이도API 관련변수
        protected KAEngine tnEngine;
        protected KAScenePlayer tnPlayer;
        protected KAObject tnObject;
        protected APIEventHandler tnEventHandler;

        //토네이도 장면 스왑용 변수
        private KAScene SwapScene1;
        //private KAScene SwapScene2;   //기능제거
        private bool SwapFlag = false;  //SwapScene1,2 선택용 flag
        private int FPlayedLayerNo = 1;

        //현재 준비된 Scene을 설정/취득
        protected KAScene ReadyScene
        {
            //현재 기능제거 항상 SwapScene1
            get { return SwapFlag ? SwapScene1 : SwapScene1; }
            set { if(SwapFlag) SwapScene1 = value; else SwapScene1 = value; }
        }
        protected KAScene ActScene
        {
            get { return SwapFlag ? SwapScene1 : SwapScene1; }
            set { if (SwapFlag) SwapScene1 = value; else SwapScene1 = value; }
        }


        //토네이도 관련변수
        private string TornadoIP;       //토네이도 IP
        private string TornadoPort;     //토네이도 Port
        private bool   isTCP;          //TCP사용여부 (true:TCP, false:UDP)

        //장면관련 변수
        private Dictionary<string,string> SceneList;

        //토네이도 이벤트 Delegate(현재 로그메세지만 처리)

        public event TornadoAPILogEventHandler OnLogMessage;
        /* 
               public event TornadoAPIEventHandler OnSetCounterNumber;

                public event TornadoAPIEventHandler OnAddPause;
                public event TornadoAPIEventHandler OnAddPauseByName;
                public event TornadoAPIEventHandler OnAddText;
                public event TornadoAPIEventHandler OnBeginTransaction;
                public event TornadoAPIEventHandler OnDeletePause;
                public event TornadoAPIEventHandler OnDeletePauseByName;
                public event TornadoAPIEventHandler OnEditText;
                public event TornadoAPIEventHandler OnEndTransaction;
                public event TornadoAPIEventHandler OnHeartBeat;
                public event TornadoAPINoneEventHandler OnHello;
                public event TornadoAPIEventHandler OnLoadProject;
                public event TornadoAPIEventHandler OnCloseProject;
                public event TornadoAPIEventHandler OnSelectProject;
                public event TornadoAPIEventHandler OnLoadScene;
                public event TornadoAPILogEventHandler OnLogMessage;
                public event TornadoAPINumEventHandler OnMessageNo;
                public event TornadoAPIEventHandler OnPause;
                public event TornadoAPIEventHandler OnPlay;
                public event TornadoAPIEventHandler OnPlayOut;
                public event TornadoAPIEventHandler OnQueryAnimationCount;
                public event TornadoAPIEventHandler OnQueryAnimationNames;
                public event TornadoAPIEventHandler OnQueryChartDataTable;
                public event TornadoAPIEventHandler OnQueryChartObjects;
                public event TornadoAPIEventHandler OnQueryClassType;
                public event TornadoAPIEventHandler OnQueryIsOnAir;
                public event TornadoAPIEventHandler OnQueryLightNames;
                public event TornadoAPIEventHandler OnQueryObjectAttribute;
                public event TornadoAPIEventHandler OnQuerySceneEffectType;
                public event TornadoAPIEventHandler OnQuerySize;
                public event TornadoAPIEventHandler OnQueryVariables;
                public event TornadoAPIEventHandler OnReloadScene;
                public event TornadoAPIEventHandler OnReplaceWithAFile;
                public event TornadoAPIEventHandler OnResume;
                public event TornadoAPIEventHandler OnRollbackTransaction;
                public event TornadoAPIEventHandler OnSaveImageFile;
                public event TornadoAPIEventHandler OnSaveScene;
                public event TornadoAPIEventHandler OnScenePaused;
                public event TornadoAPIEventHandler OnScenePlayed;
                public event TornadoAPIEventHandler OnScenePrepare;
                public event TornadoAPIEventHandler OnScenePrepareEx;
                public event TornadoAPIEventHandler OnSetBackground;
                public event TornadoAPIEventHandler OnSetBackgroundFill;
                public event TornadoAPIEventHandler OnSetBackgroundTexture;
                public event TornadoAPIEventHandler OnSetBackgroundVideo;
                public event TornadoAPIEventHandler OnSetBackgroundLiveIn;
                public event TornadoAPIEventHandler OnUseBackground;
                public event TornadoAPIEventHandler OnSetChangeOut;
                public event TornadoAPIEventHandler OnSetChartCellData;
                public event TornadoAPIEventHandler OnSetChartCSVFile;
                public event TornadoAPIEventHandler OnSetCircleAngleKey;
                public event TornadoAPIEventHandler OnSetCountDown;
                public event TornadoAPIEventHandler OnSetCounterNumberKey;
                public event TornadoAPIEventHandler OnSetCropKey;
                public event TornadoAPIEventHandler OnSetCylinderAngleKey;
                public event TornadoAPIEventHandler OnSetEdgeAttribute;
                public event TornadoAPIEventHandler OnSetFaceAttribute;
                public event TornadoAPIEventHandler OnSetFont;
                public event TornadoAPIEventHandler OnSetLightAttribute;
                public event TornadoAPIEventHandler OnSetLightColor;
                public event TornadoAPIEventHandler OnSetMaterial;
                public event TornadoAPIEventHandler OnSetMaterialKey;
                public event TornadoAPIEventHandler OnSetLensFlaresKey;
                public event TornadoAPIEventHandler OnSetObjectAttribute;
                public event TornadoAPIEventHandler OnSetPosition;
                public event TornadoAPIEventHandler OnSetPositionKey;
                public event TornadoAPIEventHandler OnSetRotation;
                public event TornadoAPIEventHandler OnSetRotationKey;
                public event TornadoAPIEventHandler OnSetScale;
                public event TornadoAPIEventHandler OnSetScaleKey;
                public event TornadoAPIEventHandler OnSetSceneEffectType;
                public event TornadoAPIEventHandler OnSetShadowAttribute;
                public event TornadoAPIEventHandler OnSetSize;
                public event TornadoAPIEventHandler OnSetSphereAngleKey;
                public event TornadoAPIEventHandler OnSetStyleColor;
                public event TornadoAPIEventHandler OnSetFaceColor;
                public event TornadoAPIEventHandler OnSetEdgeColor;
                public event TornadoAPIEventHandler OnSetShadowColor;
                public event TornadoAPIEventHandler OnSetTextStyle;
                public event TornadoAPIEventHandler OnSetValue;
                public event TornadoAPIEventHandler OnSetTextTexture;
                public event TornadoAPIEventHandler OnSetStyleTexture;
                public event TornadoAPIEventHandler OnSetDiffuseTexture;
                public event TornadoAPIEventHandler OnSetSpecularTexture;
                public event TornadoAPIEventHandler OnSetTransparencyTexture;
                public event TornadoAPIEventHandler OnSetNormalTexture;
                public event TornadoAPIEventHandler OnSetReflectionTexture;
                public event TornadoAPIEventHandler OnSetRefractionTexture;
                public event TornadoAPIEventHandler OnSetVisible;
                public event TornadoAPIEventHandler OnStop;
                public event TornadoAPIEventHandler OnStopAll;
                public event TornadoAPIEventHandler OnStoreTextStyle;
                public event TornadoAPIEventHandler OnTrigger;
                public event TornadoAPIEventHandler OnTriggerByName;
                public event TornadoAPIEventHandler OnTriggerObject;
                public event TornadoAPIEventHandler OnTriggerObjectByName;
                public event TornadoAPIEventHandler OnUnloadAll;
                public event TornadoAPIEventHandler OnUnloadScene;
                public event TornadoAPIEventHandler OnUpdateTextures;
                public event TornadoAPIEventHandler OnAddPathPoint;
                public event TornadoAPIEventHandler OnClearPathPoints;
                public event TornadoAPIEventHandler OnAddPathShapePoint;
                public event TornadoAPIEventHandler OnClearPathShapePoints;
                public event TornadoAPIEventHandler OnQueryScrollRemainingDistance;
                public event TornadoAPIEventHandler OnAddScrollObject;
                public event TornadoAPIEventHandler OnSetVariableName;
                public event TornadoAPIEventHandler OnAdjustScrollSpeed;
                public event TornadoAPIEventHandler OnSetScrollSpeed;
                public event TornadoAPIEventHandler OnSetDiffuse;
                public event TornadoAPIEventHandler OnSetAmbient;
                public event TornadoAPIEventHandler OnSetSpecular;
                public event TornadoAPIEventHandler OnSetEmissive;
                public event TornadoAPIEventHandler OnSetOpacity;
                public event TornadoAPIEventHandler OnSetDiffuseKey;
                public event TornadoAPIEventHandler OnSetAmbientKey;
                public event TornadoAPIEventHandler OnSetSpecularKey;
                public event TornadoAPIEventHandler OnSetEmissiveKey;
                public event TornadoAPIEventHandler OnSetOpacityKey;
                public event TornadoAPIEventHandler OnSetLoftPositionKey;
                public event TornadoAPIEventHandler OnModifyPathPoint;
                public event TornadoAPIEventHandler OnSetVideoFrame;
                public event TornadoAPIEventHandler OnSetVideoRepeatInfo;
                public event TornadoAPIEventHandler OnSetTextStyleLibrary;
                public event TornadoAPIEventHandler OnAddTextStyleLibrary;
                public event TornadoAPIEventHandler OnInitScrollObject;
                public event TornadoAPIEventHandler OnSetCounterInfo;
                public event TornadoAPIEventHandler OnSetCounterNumber;
                public event TornadoAPIEventHandler OnSetCounterRange;
                public event TornadoAPIEventHandler OnSetCounterRemainingTime;
                public event TornadoAPIEventHandler OnSetCounterElapsedTime;
                public event TornadoAPIEventHandler OnSaveObjectImage;
                public event TornadoAPIEventHandler OnSendMosMessage;
                public event TornadoAPIEventHandler OnReceiveFile;
                public event TornadoAPIEventHandler OnAddObject;
                public event TornadoAPIEventHandler OnSavePreviewImage;
                public event TornadoAPIEventHandler OnNewProject;
                public event TornadoAPIEventHandler OnQueryPickedObjects;
                public event TornadoAPIEventHandler OnDragObject;
                public event TornadoAPIEventHandler OnResetDrag;
                public event TornadoAPIEventHandler OnCreateStory;
                public event TornadoAPIEventHandler OnInsertStory;
                public event TornadoAPIEventHandler OnMoveStory;
                public event TornadoAPIEventHandler OnSwapStory;
                public event TornadoAPIEventHandler OnDeleteStory;
                public event TornadoAPIEventHandler OnCreateItem;
                public event TornadoAPIEventHandler OnPrepareItem;
                public event TornadoAPIEventHandler OnSceneSaved;
                public event TornadoAPIEventHandler OnSetSceneScrollSpeed;
                public event TornadoAPIEventHandler OnCreateWithAFile;
                public event TornadoAPIEventHandler OnSetSceneAudioFile;
                public event TornadoAPIEventHandler OnSetScrollSpeedByScenePlayer;
                public event TornadoAPIEventHandler OnAdjustScrollSpeedByScenePlayer;
                public event TornadoAPIEventHandler OnEnableSceneAudio;
                public event TornadoAPIEventHandler OnInsertItem;
                public event TornadoAPIEventHandler OnDeleteItem;
                public event TornadoAPIEventHandler OnMoveItem;
                public event TornadoAPIEventHandler OnSwapItem;
                public event TornadoAPIEventHandler OnUpdateItems;
        */
        public Tornado()
        {
            this.tnEngine = new KAEngine();
            this.tnEventHandler = new APIEventHandler(this);
            this.SceneList = new Dictionary<string,string>();
        }

        //토네이도용 명령어====================================================
        //토네이도에 접속
        //  tcp : tcp사용여부 true = tcp, false = udp
        //  ip  : 토네이도가 실행된 장비의 IP
        //  port : 토네이도 포트
        public bool Connect(bool tcp, string ip, string port)
        {
            if(tnEngine == null) return false;

            //토네이도 엔진은 bool값없음 true = 1, false = 0으로 변환
            int istcp = tcp ? 1 : 0;

            //파라메터값 설정
            this.TornadoIP = ip;
            this.TornadoPort = port;
            this.isTCP = tcp;

            //토네이도 연결시도
            bool result = tnEngine.KTAPConnect(istcp, ip, Convert.ToInt32(port), 0, tnEventHandler) == 1 ? true : false;

            //연결 성공시
            if (result)
            {
                //토네이도 플레이어 취득 및 초기값 설정
                tnPlayer = tnEngine.GetScenePlayer();
                this.ReadyScene = null;
                this.ActScene = null;
            }

            return result;
        }

        //토네이도 접속해제
        public void Disconnect()
        {
            //현재 플레이되고 있는 모든 장면을 지우고, 엔진 해제 및 연결해제
            StopAll();
            tnEngine.UnloadAll();
            tnEngine.Disconnect();
            DoLogMessage("Disconnected...");
        }

        //토네이도 장면등록
        //  alias : 장면 별칭(현재 코드화해서 사용중)
        //  filename : t2s(토네이도2 장면 확장자명) full path
        public void RegisterScene(string alias, string filename)
        {
            KAScene scene = null;

            //장면리스트에 등록된 것이면
            if (SceneList.ContainsKey(alias))
                SceneList[alias] = filename;    //해당 장면리스트에 덮어쓰기
            else
                SceneList.Add(alias, filename); //아니면, 장면리스트에 추가

            //장면 로딩
            scene = tnEngine.LoadScene(filename, alias);
            //해당파일이 토네이도 장면파일이면
            if (scene is KAScene)
                scene.Unload();     //장면 다시 해제(t2s파일이 맞는지 확인위해 load한것일뿐)
            else
                MessageBox.Show("not found");   //아니면, 메세지 출력
        }

        //토네이도 장면등록 해제
        //  alias : 장면 별칭(현재 코드화해서 사용중)
        public void UnregisterScene(string alias)
        {
            //장면리스트에 해당 장면 있으면, 제거
            if (SceneList.ContainsKey(alias))
                SceneList.Remove(alias);
        }

        //토네이도 모든 송출화면 중단
        // - 현재 송출된 모든 장면을 제거한다(결국, 블랙화면만 보임)
        public void StopAll()
        {
            //토네이도 엔진 및 플레이어가 있어야 송출중단
            if (tnEngine != null && tnPlayer != null) tnPlayer.StopAll();
        }

        //토네이도 특정 레이어만 송출중단
        //  layerno : 송출중단할 레이어번호
        public void Stop(int layerno)
        {
            if (tnEngine == null || tnPlayer == null)
                return;

            tnPlayer.Stop(layerno);
        }

        //자동 Swap하여 장면준비
        // alias : 준비할 장면별칭
        protected bool SwapReady(string alias)
        {
            //장면등록여부
            if (!SceneList.ContainsKey(alias))
                return false;

            //준비장면이 할당되어 있으면 기존 장면 삭제(현재 기능해제)
            /*
            if(ReadyScene != null && ReadyScene.GetSceneName() != alias)
            {
                //ReadyScene.Unload();
                MessageBox.Show(ReadyScene.GetSceneName() + "//" + alias);
            }
            */
            //ReadyScene은 항상 SwapScene1로 고정됨
            //이전 준비장면 해제
            if (ReadyScene != null) ReadyScene.Unload();

            //장면생성
            //토네이도에 장면 준비(파일만 읽는것임)
            ReadyScene = tnEngine.LoadScene(SceneList[alias], alias);
            return true;
        }

        //장면을 송출하게될 레이어번호 지정
        // layerno : 송출할 레이어번호
        // - 이 함수 호출이전에 장면의 각종변수를 재설정해 두어야함.
        protected void SwapPrepare(int layerno)
        {
            if (tnPlayer != null) tnPlayer.Prepare(layerno, ReadyScene);
        }

        //장면 송출
        //  layerno : 송출할 레이어번호
        protected void SwapIn(int layerno)
        {   //기존 송출된 화면이 있으면 Out Effect 송출후, 신규화면 송출
            //tnPlayer.PlayOut(SWAP_LAYER_NO);
            tnPlayer.Play(layerno);
            FPlayedLayerNo = layerno;
            //SwapFlag = !SwapFlag;   //현재 기능제거
        }

        //장면내의 특정 오브젝트 취득
        // name : 장면내의 오브젝트 이름
        // - 오브젝트 종류에 따라 property가 다름 (토네이도 API 매뉴얼 참고)
        // - 송출전 오브젝트의 속성등을 변경
        protected KAObject GetObject(string name)
        {
            if (ReadyScene == null) return null;
            return ReadyScene.GetObject(name);
        }

        //장면의 OUT 트리거 설정
        // type : out type명(CHANGEOUT = change_out_type_out 트리거, OUT = change_out_type_default 트리거, 그외 = change_out_type_cut 의 플레이 프레임으로 out 실행)
        protected bool SetChangeOut(string type)
        {
            eKChangeOutType ctype = new eKChangeOutType();

/* 트리거에러 
  
            switch (type.ToUpper())
            {
                //eKChangeOutType 열거형상수 오류
                // changeout = CHANGE_OUT_TYPE_CUT, out = CHANGE_OUT_TYPE_DEFAULT, cut = CHANGE_OUT_TYPE_OUT
                case "CHANGEOUT": ctype = eKChangeOutType.CHANGE_OUT_TYPE_OUT; break;
                case "OUT": ctype = eKChangeOutType.CHANGE_OUT_TYPE_DEFAULT; break;
                default: ctype = eKChangeOutType.CHANGE_OUT_TYPE_CUT; break;
            }
*/

            //chage out은 장면에 설정함
            //현재 송출된 화면을 구해서 change out 설정
            KAScene Scene = tnPlayer.GetPlayingScene(FPlayedLayerNo);
            if(Scene != null) Scene.SetChangeOut(ctype);

            return true;
        }

        //토네이도에서 발생한 로그를 받아서, 로그처리 함수 호출

        public void DoLogMessage(string LogMessage) { if (OnLogMessage != null) OnLogMessage(LogMessage); }
        //public void DoSetBackgroundVideo(int bSuccess, string SceneName, string VideoFileName, int LoopCount, int LoopInfinite) { if (OnSetBackgroundVideo != null) OnSetBackgroundVideo(bSuccess == 1 ? true : false); }



        /*
                public void DoSetCounterNumber(int bSuccess, string ObjectName, double Number) { if (OnSetCounterNumber != null) OnSetCounterNumber(bSuccess == 1 ? true : false); }
                public void DoAddPause(int bSuccess, string SceneName, int AnimationType, int FrameNo, int Delay, int bAuto){if(OnAddPause != null) OnAddPause(bSuccess == 1 ? true : false);}
                public void DoAddPauseByName(int bSuccess, string SceneName, string AnimationName, int FrameNo, int Delay, int bAuto){if(OnAddPauseByName != null) OnAddPauseByName(bSuccess == 1 ? true : false);}
                public void DoAddText(int bSuccess, string ObjectName, string Text, int StyleNo){if(OnAddText != null) OnAddText(bSuccess == 1 ? true : false);}
                public void DoBeginTransaction(int iSuccess){if(OnBeginTransaction != null) OnBeginTransaction(iSuccess == 1 ? true : false);}
                public void DoDeletePause(int bSuccess, string SceneName, int AnimationType, int FrameNo, int bAll){if(OnDeletePause != null) OnDeletePause(bSuccess == 1 ? true : false);}
                public void DoDeletePauseByName(int bSuccess, string SceneName, string AnimationName, int FrameNo, int bAll){if(OnDeletePauseByName != null) OnDeletePauseByName(bSuccess == 1 ? true : false);}
                public void DoEditText(int bSuccess, string ObjectName, string Text, int BeginPos, int EndPos, int StyleNo){if(OnEditText != null) OnEditText(bSuccess == 1 ? true : false);}
                public void DoEndTransaction(int iSuccess){if(OnEndTransaction != null) OnEndTransaction(iSuccess == 1 ? true : false);}
                public void DoHeartBeat(int bSuccess){if(OnHeartBeat != null) OnHeartBeat(bSuccess == 1 ? true : false);}
                public void DoHello(){if(OnHello != null) OnHello();}
                public void DoLoadProject(int bSuccess, KAScene pScene, int TotalCount){if(OnLoadProject != null) OnLoadProject(bSuccess == 1 ? true : false);}
                public void DoCloseProject(int bSuccess, string AliasName) { if(OnCloseProject != null) OnCloseProject(bSuccess == 1 ? true : false);}
                public void DoSelectProject(int bSuccess, string AliasName) { if(OnSelectProject != null) OnSelectProject(bSuccess == 1 ? true : false);}
                public void DoLoadScene(int bSuccess, string SceneName){if(OnLoadScene != null) OnLoadScene(bSuccess == 1 ? true : false);}
                public void DoLogMessage(string LogMessage){if(OnLogMessage != null) OnLogMessage(LogMessage);}
                public void DoMessageNo(uint MessageNo) { if (OnMessageNo != null) OnMessageNo(MessageNo); }
                public void DoPause(int bSuccess, int LayerNo){if(OnPause != null) OnPause(bSuccess == 1 ? true : false);}
                public void DoPlay(int bSuccess, int LayerNo){if(OnPlay != null) OnPlay(bSuccess == 1 ? true : false);}
                public void DoPlayOut(int bSuccess, int LayerNo){if(OnPlayOut != null) OnPlayOut(bSuccess == 1 ? true : false);}
                public void DoQueryAnimationCount(int bSuccess, string SceneName, int AnimationCount){if(OnQueryAnimationCount != null) OnQueryAnimationCount(bSuccess == 1 ? true : false);}
                public void DoQueryAnimationNames(int bSuccess, string SceneName, int Index, int TotalCount, string pAnimationName){if(OnQueryAnimationNames != null) OnQueryAnimationNames(bSuccess == 1 ? true : false);}
                public void DoQueryChartDataTable(int bSuccess, string ObjectName, int Index, int TotalCount, ref sKChartDataTable Param){if(OnQueryChartDataTable != null) OnQueryChartDataTable(bSuccess == 1 ? true : false);}
                public void DoQueryChartObjects(int bSuccess, string SceneName, int Index, int TotalCount, ref sKChart Param){if(OnQueryChartObjects != null) OnQueryChartObjects(bSuccess == 1 ? true : false);}
                public void DoQueryClassType(int bSuccess, string ObjectName, int ClassType){if(OnQueryClassType != null) OnQueryClassType(bSuccess == 1 ? true : false);}
                public void DoQueryIsOnAir(int bSuccess, int LayerNo){if(OnQueryIsOnAir != null) OnQueryIsOnAir(bSuccess == 1 ? true : false);}
                public void DoQueryLightNames(int bSuccess, string SceneName, int Index, int TotalCount, string pLightName){if(OnQueryLightNames != null) OnQueryLightNames(bSuccess == 1 ? true : false);}
                public void DoQueryObjectAttribute(int bSuccess, string ObjectName, ref sKObjectAttribute pKObjectAttribute){if(OnQueryObjectAttribute != null) OnQueryObjectAttribute(bSuccess == 1 ? true : false);}
                public void DoQuerySceneEffectType(int bSuccess, string SceneName, int bInEffect, eKSceneEffectType EffectType, int Duration){if(OnQuerySceneEffectType != null) OnQuerySceneEffectType(bSuccess == 1 ? true : false);}
                public void DoQuerySize(int bSuccess, string ObjectName, float Width, float Height, float Depth){if(OnQuerySize != null) OnQuerySize(bSuccess == 1 ? true : false);}
                public void DoQueryVariables(int bSuccess, string SceneName, int Index, int TotalCount, ref sKVariable Param){if(OnQueryVariables != null) OnQueryVariables(bSuccess == 1 ? true : false);}
                public void DoReloadScene(int bSuccess, string FileName, string SceneName){if(OnReloadScene != null) OnReloadScene(bSuccess == 1 ? true : false);}
                public void DoReplaceWithAFile(int bSuccess, string ObjectName, string ReplaceFileName){if(OnReplaceWithAFile != null) OnReplaceWithAFile(bSuccess == 1 ? true : false);}
                public void DoResume(int bSuccess, int LayerNo){if(OnResume != null) OnResume(bSuccess == 1 ? true : false);}
                public void DoRollbackTransaction(int iSuccess){if(OnRollbackTransaction != null) OnRollbackTransaction(iSuccess == 1 ? true : false);}
                public void DoSaveImageFile(int bSuccess, string SceneName, int Width, int Height, int Frame, string ImagePathName){if(OnSaveImageFile != null) OnSaveImageFile(bSuccess == 1 ? true : false);}
                public void DoSaveScene(int bSuccess, string SceneName, string K3SFileName, int UseCollect){if(OnSaveScene != null) OnSaveScene(bSuccess == 1 ? true : false);}
                public void DoScenePaused(int bSuccess, int LayerNo){if(OnScenePaused != null) OnScenePaused(bSuccess == 1 ? true : false);}
                public void DoScenePlayed(int bSuccess, int LayerNo){if(OnScenePlayed != null) OnScenePlayed(bSuccess == 1 ? true : false);}
                public void DoScenePrepare(int bSuccess, string SceneName, int LayerNo){if(OnScenePrepare != null) OnScenePrepare(bSuccess == 1 ? true : false);}
                public void DoScenePrepareEx(int bSuccess, string SceneName, int LayerNo){if(OnScenePrepareEx != null) OnScenePrepareEx(bSuccess == 1 ? true : false);}
                public void DoSetBackground(int bSuccess, string SceneName, ref sKBackground Param){if(OnSetBackground != null) OnSetBackground(bSuccess == 1 ? true : false);}
                public void DoSetBackgroundFill(int bSuccess, string SceneName, int R, int G, int B, int A) { if(OnSetBackgroundFill != null) OnSetBackgroundFill(bSuccess == 1 ? true : false);}
                public void DoSetBackgroundTexture(int bSuccess, string SceneName, string TextureFileName) { if(OnSetBackgroundTexture != null) OnSetBackgroundTexture(bSuccess == 1 ? true : false);}
                public void DoSetBackgroundVideo(int bSuccess, string SceneName, string VideoFileName, int LoopCount, int LoopInfinite) { if(OnSetBackgroundVideo != null) OnSetBackgroundVideo(bSuccess == 1 ? true : false);}
                public void DoSetBackgroundLiveIn(int bSuccess, string SceneName, int InputChannel) { if(OnSetBackgroundLiveIn != null) OnSetBackgroundLiveIn(bSuccess == 1 ? true : false);}
                public void DoUseBackground(int bSuccess, string SceneName, int Use) { if(OnUseBackground != null) OnUseBackground(bSuccess == 1 ? true : false);}
                public void DoSetChangeOut(int bSuccess, string SceneName) { if(OnSetChangeOut != null) OnSetChangeOut(bSuccess == 1 ? true : false);}
                public void DoSetChartCellData(int bSuccess, string ObjectName, float Value){if(OnSetChartCellData != null) OnSetChartCellData(bSuccess == 1 ? true : false);}
                public void DoSetChartCSVFile(int bSuccess, string ObjectName, string FilePath){if(OnSetChartCSVFile != null) OnSetChartCSVFile(bSuccess == 1 ? true : false);}
                public void DoSetCircleAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End){if(OnSetCircleAngleKey != null) OnSetCircleAngleKey(bSuccess == 1 ? true : false);}
                public void DoSetCountDown(int bSuccess, string ObjectName, float Second){if(OnSetCountDown != null) OnSetCountDown(bSuccess == 1 ? true : false);}
                public void DoSetCounterNumberKey(int bSuccess, string ObjectName, int KeyIndex, double Number){if(OnSetCounterNumberKey != null) OnSetCounterNumberKey(bSuccess == 1 ? true : false);}
                public void DoSetCropKey(int bSuccess, string ObjectName, int KeyIndex, float Left, float Top, float Right, float Bottom){if(OnSetCropKey != null) OnSetCropKey(bSuccess == 1 ? true : false);}
                public void DoSetCylinderAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End){if(OnSetCylinderAngleKey != null) OnSetCylinderAngleKey(bSuccess == 1 ? true : false);}
                public void DoSetEdgeAttribute(int bSuccess, string ObjectName, ref sKEdgeAttribute Param){if(OnSetEdgeAttribute != null) OnSetEdgeAttribute(bSuccess == 1 ? true : false);}
                public void DoSetFaceAttribute(int bSuccess, string ObjectName, ref sKFaceAttribute Param){if(OnSetFaceAttribute != null) OnSetFaceAttribute(bSuccess == 1 ? true : false);}
                public void DoSetFont(int bSuccess, string ObjectName, ref sKFont Param){if(OnSetFont != null) OnSetFont(bSuccess == 1 ? true : false);}
                public void DoSetLightAttribute(int bSuccess, string SceneName, string LightName, ref sKLightAttribute Param){if(OnSetLightAttribute != null) OnSetLightAttribute(bSuccess == 1 ? true : false);}
                public void DoSetLightColor(int bSuccess, string SceneName, string LightName, ref sKLightColor Param){if(OnSetLightColor != null) OnSetLightColor(bSuccess == 1 ? true : false);}
                public void DoSetMaterial(int bSuccess, string ObjectName, ref sKMaterial pKMaterial){if(OnSetMaterial != null) OnSetMaterial(bSuccess == 1 ? true : false);}
                public void DoSetMaterialKey(int bSuccess, string ObjectName, int KeyIndex, ref sKMaterial pKMaterial){if(OnSetMaterialKey != null) OnSetMaterialKey(bSuccess == 1 ? true : false);}
                public void DoSetLensFlaresKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { if(OnSetLensFlaresKey != null) OnSetLensFlaresKey(bSuccess == 1 ? true : false);}
                public void DoSetObjectAttribute(int bSuccess, string ObjectName, ref sKObjectAttribute pKObjectAttribute){if(OnSetObjectAttribute != null) OnSetObjectAttribute(bSuccess == 1 ? true : false);}
                public void DoSetPosition(int bSuccess, string ObjectName, float X, float Y, float Z){if(OnSetPosition != null) OnSetPosition(bSuccess == 1 ? true : false);}
                public void DoSetPositionKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z){if(OnSetPositionKey != null) OnSetPositionKey(bSuccess == 1 ? true : false);}
                public void DoSetRotation(int bSuccess, string ObjectName, float X, float Y, float Z){if(OnSetRotation != null) OnSetRotation(bSuccess == 1 ? true : false);}
                public void DoSetRotationKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z){if(OnSetRotationKey != null) OnSetRotationKey(bSuccess == 1 ? true : false);}
                public void DoSetScale(int bSuccess, string ObjectName, float X, float Y, float Z){if(OnSetScale != null) OnSetScale(bSuccess == 1 ? true : false);}
                public void DoSetScaleKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z){if(OnSetScaleKey != null) OnSetScaleKey(bSuccess == 1 ? true : false);}
                public void DoSetSceneEffectType(int bSuccess, string SceneName, int bInEffect, eKSceneEffectType EffectType, int Duration){if(OnSetSceneEffectType != null) OnSetSceneEffectType(bSuccess == 1 ? true : false);}
                public void DoSetShadowAttribute(int bSuccess, string ObjectName, ref sKShadowAttribute Param){if(OnSetShadowAttribute != null) OnSetShadowAttribute(bSuccess == 1 ? true : false);}
                public void DoSetSize(int bSuccess, string ObjectName, float Width, float Height, float Depth){if(OnSetSize != null) OnSetSize(bSuccess == 1 ? true : false);}
                public void DoSetSphereAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End){if(OnSetSphereAngleKey != null) OnSetSphereAngleKey(bSuccess == 1 ? true : false);}
                public void DoSetStyleColor(int bSuccess, string ObjectName, ref sKStyleColor Param){if(OnSetStyleColor != null) OnSetStyleColor(bSuccess == 1 ? true : false);}
                public void DoSetFaceColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { if(OnSetFaceColor != null) OnSetFaceColor(bSuccess == 1 ? true : false);}
                public void DoSetEdgeColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { if(OnSetEdgeColor != null) OnSetEdgeColor(bSuccess == 1 ? true : false);}
                public void DoSetShadowColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { if(OnSetShadowColor != null) OnSetShadowColor(bSuccess == 1 ? true : false);}
                public void DoSetTextStyle(int bSuccess, string ObjectName, int Begin, int Count, int StyleNo){if(OnSetTextStyle != null) OnSetTextStyle(bSuccess == 1 ? true : false);}
                public void DoSetValue(int bSuccess, string ObjectName, string Value){if(OnSetValue != null) OnSetValue(bSuccess == 1 ? true : false);}
                public void DoSetTextTexture(int bSuccess, string ObjectName, string FileName) { if(OnSetTextTexture != null) OnSetTextTexture(bSuccess == 1 ? true : false);}
                public void DoSetStyleTexture(int bSuccess, string ObjectName, string FileName) { if(OnSetStyleTexture != null) OnSetStyleTexture(bSuccess == 1 ? true : false);}
                public void DoSetDiffuseTexture(int bSuccess, string ObjectName, string FileName) { if(OnSetDiffuseTexture != null) OnSetDiffuseTexture(bSuccess == 1 ? true : false);}
                public void DoSetSpecularTexture(int bSuccess, string ObjectName, string FileName) { if(OnSetSpecularTexture != null) OnSetSpecularTexture(bSuccess == 1 ? true : false);}
                public void DoSetTransparencyTexture(int bSuccess, string ObjectName, string FileName) { if(OnSetTransparencyTexture != null) OnSetTransparencyTexture(bSuccess == 1 ? true : false);}
                public void DoSetNormalTexture(int bSuccess, string ObjectName, string FileName) { if(OnSetNormalTexture != null) OnSetNormalTexture(bSuccess == 1 ? true : false);}
                public void DoSetReflectionTexture(int bSuccess, string ObjectName, string FileName) { if(OnSetReflectionTexture != null) OnSetReflectionTexture(bSuccess == 1 ? true : false);}
                public void DoSetRefractionTexture(int bSuccess, string ObjectName, string FileName) { if(OnSetRefractionTexture != null) OnSetRefractionTexture(bSuccess == 1 ? true : false);}
                public void DoSetVisible(int bSuccess, string ObjectName, int bShow){if(OnSetVisible != null) OnSetVisible(bSuccess == 1 ? true : false);}
                public void DoStop(int bSuccess, int LayerNo){if(OnStop != null) OnStop(bSuccess == 1 ? true : false);}
                public void DoStopAll(int iSuccess){if(OnStopAll != null) OnStopAll(iSuccess == 1 ? true : false);}
                public void DoStoreTextStyle(int bSuccess, string ObjectName, string Text, int StyleCount){if(OnStoreTextStyle != null) OnStoreTextStyle(bSuccess == 1 ? true : false);}
                public void DoTrigger(int bSuccess, int LayerNo, int AnimationType){if(OnTrigger != null) OnTrigger(bSuccess == 1 ? true : false);}
                public void DoTriggerByName(int bSuccess, int LayerNo, string AnimationName){if(OnTriggerByName != null) OnTriggerByName(bSuccess == 1 ? true : false);}
                public void DoTriggerObject(int bSuccess, string ObjectName, int LayerNo, int AnimationType, int bWithChildren){if(OnTriggerObject != null) OnTriggerObject(bSuccess == 1 ? true : false);}
                public void DoTriggerObjectByName(int bSuccess, string ObjectName, int LayerNo, string AnimationName, int bWithChildren){if(OnTriggerObjectByName != null) OnTriggerObjectByName(bSuccess == 1 ? true : false);}
                public void DoUnloadAll(int bSuccess){if(OnUnloadAll != null) OnUnloadAll(bSuccess == 1 ? true : false);}
                public void DoUnloadScene(int bSuccess, string SceneName){if(OnUnloadScene != null) OnUnloadScene(bSuccess == 1 ? true : false);}
                public void DoUpdateTextures(int bSuccess, string SceneName){if(OnUpdateTextures != null) OnUpdateTextures(bSuccess == 1 ? true : false);}
                public void DoAddPathPoint(int bSuccess, string ObjectName, int Count){if(OnAddPathPoint != null) OnAddPathPoint(bSuccess == 1 ? true : false);}
                public void DoClearPathPoints(int bSuccess, string ObjectName){if(OnClearPathPoints != null) OnClearPathPoints(bSuccess == 1 ? true : false);}
                public void DoAddPathShapePoint(int bSuccess, string ObjectName, int Count){if(OnAddPathShapePoint != null) OnAddPathShapePoint(bSuccess == 1 ? true : false);}
                public void DoClearPathShapePoints(int bSuccess, string ObjectName){ if(OnClearPathShapePoints  != null) OnClearPathShapePoints(bSuccess == 1 ? true : false); }
                public void DoQueryScrollRemainingDistance(int bSuccess, string ObjectName, int ScrollRemainingDistance){if(OnQueryScrollRemainingDistance	 != null) OnQueryScrollRemainingDistance(bSuccess == 1 ? true : false);}
                public void DoAddScrollObject(int bSuccess, string ObjectName, string ChildName){if(OnAddScrollObject != null) OnAddScrollObject(bSuccess == 1 ? true : false);}
                public void DoSetVariableName(int bSuccess, string ObjectName, string VariableName){if(OnSetVariableName != null) OnSetVariableName(bSuccess == 1 ? true : false);}
                public void DoAdjustScrollSpeed(int bSuccess, string ObjectName, float SpeedDelta) { if(OnAdjustScrollSpeed != null) OnAdjustScrollSpeed(bSuccess == 1 ? true : false);}
                public void DoSetScrollSpeed(int bSuccess, string ObjectName, float Speed) { if(OnSetScrollSpeed != null) OnSetScrollSpeed(bSuccess == 1 ? true : false);}
                public void DoSetDiffuse(int bSuccess, string ObjectName, int R, int G, int B) { if(OnSetDiffuse != null) OnSetDiffuse(bSuccess == 1 ? true : false);}
                public void DoSetAmbient(int bSuccess, string ObjectName, int R, int G, int B) { if(OnSetAmbient != null) OnSetAmbient(bSuccess == 1 ? true : false);}
                public void DoSetSpecular(int bSuccess, string ObjectName, int R, int G, int B) { if(OnSetSpecular != null) OnSetSpecular(bSuccess == 1 ? true : false);}
                public void DoSetEmissive(int bSuccess, string ObjectName, int R, int G, int B) { if(OnSetEmissive != null) OnSetEmissive(bSuccess == 1 ? true : false);}
                public void DoSetOpacity(int bSuccess, string ObjectName, int Opacity) { if(OnSetOpacity != null) OnSetOpacity(bSuccess == 1 ? true : false);}
                public void DoSetDiffuseKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { if(OnSetDiffuseKey != null) OnSetDiffuseKey(bSuccess == 1 ? true : false);}
                public void DoSetAmbientKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { if(OnSetAmbientKey != null) OnSetAmbientKey(bSuccess == 1 ? true : false);}
                public void DoSetSpecularKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { if(OnSetSpecularKey != null) OnSetSpecularKey(bSuccess == 1 ? true : false);}
                public void DoSetEmissiveKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { if(OnSetEmissiveKey != null) OnSetEmissiveKey(bSuccess == 1 ? true : false);}
                public void DoSetOpacityKey(int bSuccess, string ObjectName, int KeyIndex, int Opacity) { if(OnSetOpacityKey != null) OnSetOpacityKey(bSuccess == 1 ? true : false);}
                public void DoSetLoftPositionKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { if(OnSetLoftPositionKey	 != null) OnSetLoftPositionKey(bSuccess == 1 ? true : false);}
                public void DoModifyPathPoint(int bSuccess, string ObjectName, int Index, float X, float Y, float Z)  { if(OnModifyPathPoint != null) OnModifyPathPoint(bSuccess == 1 ? true : false);}
                public void DoSetVideoFrame(int bSuccess, string ObjectName, int StartFrame, int StopFrame) { if(OnSetVideoFrame != null) OnSetVideoFrame(bSuccess == 1 ? true : false);}
                public void DoSetVideoRepeatInfo(int bSuccess, string ObjectName, int StartFrame, int StopFrame, int LoopCount, int bInfinite, int bPlayAsOut) { if(OnSetVideoRepeatInfo  != null) OnSetVideoRepeatInfo(bSuccess == 1 ? true : false);}
                public void DoSetTextStyleLibrary(int bSuccess, string ObjectName, string Text, int StyleID) { if(OnSetTextStyleLibrary != null) OnSetTextStyleLibrary(bSuccess == 1 ? true : false);}
                public void DoAddTextStyleLibrary(int bSuccess, string ObjectName, string Text, int StyleID) { if(OnAddTextStyleLibrary != null) OnAddTextStyleLibrary(bSuccess == 1 ? true : false);}
                public void DoInitScrollObject(int bSuccess, string ObjectName) {if(OnInitScrollObject != null) OnInitScrollObject(bSuccess == 1 ? true : false);}
                public void DoSetCounterInfo(int bSuccess, string ObjectName, string Format, int UpdatePeriod, int bAddPlusSign) { if(OnSetCounterInfo != null) OnSetCounterInfo(bSuccess == 1 ? true : false);}
                public void DoSetCounterRange(int bSuccess, string ObjectName, double StartTime, double EndTime) { if(OnSetCounterRange != null) OnSetCounterRange(bSuccess == 1 ? true : false);}
                public void DoSetCounterRemainingTime(int bSuccess, string ObjectName, double BaseTime) { if(OnSetCounterRemainingTime != null) OnSetCounterRemainingTime(bSuccess == 1 ? true : false);}
                public void DoSetCounterElapsedTime(int bSuccess, string ObjectName, double BaseTime) { if(OnSetCounterElapsedTime != null) OnSetCounterElapsedTime(bSuccess == 1 ? true : false);}
                public void DoSaveObjectImage(int bSuccess, string ObjectName, string FileName) { if(OnSaveObjectImage != null) OnSaveObjectImage(bSuccess == 1 ? true : false);}
                public void DoSendMosMessage(int bSuccess, string MosMessage) { if(OnSendMosMessage != null) OnSendMosMessage(bSuccess == 1 ? true : false);}
                public void DoReceiveFile(int bSuccess, string ExistingFileName, string NewFileName) { if(OnReceiveFile != null) OnReceiveFile(bSuccess == 1 ? true : false);}
                public void DoAddObject(int bSuccess) { if(OnAddObject != null) OnAddObject(bSuccess == 1 ? true : false);}
                public void DoSavePreviewImage(int bSuccess, string ImagePathName, int Width, int Height) { if (OnSavePreviewImage != null) OnSavePreviewImage(bSuccess == 1 ? true : false); }
                public void DoNewProject(int bSuccess, string AliasName) { if(OnNewProject != null) OnNewProject(bSuccess == 1 ? true : false);}
                public void DoQueryPickedObjects(int bSuccess, string SceneName, int index, int TotalCount, ref sKVariable Param) { if(OnQueryPickedObjects != null) OnQueryPickedObjects(bSuccess == 1 ? true : false);}
                public void DoDragObject(int bSuccess, string ObjectName, int X, int Y, int FrameCount) { if(OnDragObject != null) OnDragObject(bSuccess == 1 ? true : false);}
                public void DoResetDrag(int bSuccess, string ObjectName, int FrameCount) { if(OnResetDrag != null) OnResetDrag(bSuccess == 1 ? true : false);}
                public void DoCreateStory(int bSuccess) { if(OnCreateStory != null) OnCreateStory(bSuccess == 1 ? true : false);}
                public void DoInsertStory(int bSuccess) { if(OnInsertStory != null) OnInsertStory(bSuccess == 1 ? true : false);}
                public void DoMoveStory(int bSuccess) { if(OnMoveStory != null) OnMoveStory(bSuccess == 1 ? true : false);}
                public void DoSwapStory(int bSuccess) { if(OnSwapStory != null) OnSwapStory(bSuccess == 1 ? true : false);}
                public void DoDeleteStory(int bSuccess) { if(OnDeleteStory != null) OnDeleteStory(bSuccess == 1 ? true : false);}
                public void DoCreateItem(int bSuccess) { if(OnCreateItem != null) OnCreateItem(bSuccess == 1 ? true : false);}
                public void DoPrepareItem(int bSuccess) { if(OnPrepareItem != null) OnPrepareItem(bSuccess == 1 ? true : false);}
                public void DoSceneSaved(int bSuccess, string FileName) { if(OnSceneSaved != null) OnSceneSaved(bSuccess == 1 ? true : false);}
                public void DoSetSceneScrollSpeed(int bSuccess, string SceneName, float Speed) { if (OnSetSceneScrollSpeed != null) OnSetSceneScrollSpeed(bSuccess == 1 ? true : false); }
                public void DoCreateWithAFile(int bSuccess, string SceneName, string FileName, string VariableName) { if(OnCreateWithAFile != null) OnCreateWithAFile(bSuccess == 1 ? true : false);}
                public void DoSetSceneAudioFile(int bSuccess, string SceneName, int AnimatiionType, string AudioFileName) { if(OnSetSceneAudioFile != null) OnSetSceneAudioFile(bSuccess == 1 ? true : false);}
                public void DoSetScrollSpeedByScenePlayer(int bSuccess, int LayerNo, float Speed) { if(OnSetScrollSpeedByScenePlayer != null) OnSetScrollSpeedByScenePlayer(bSuccess == 1 ? true : false);}
                public void DoAdjustScrollSpeedByScenePlayer(int bSuccess, int LayerNo, float SpeedDelta) { if(OnAdjustScrollSpeedByScenePlayer != null) OnAdjustScrollSpeedByScenePlayer(bSuccess == 1 ? true : false);}
                public void DoEnableSceneAudio(int bSuccess, string SceneName, int AnimatiionType, int bEnable) { if(OnEnableSceneAudio != null) OnEnableSceneAudio(bSuccess == 1 ? true : false);}
                public void DoInsertItem(int bSuccess) { if(OnInsertItem != null) OnInsertItem(bSuccess == 1 ? true : false);}
                public void DoDeleteItem(int bSuccess) { if(OnDeleteItem != null) OnDeleteItem(bSuccess == 1 ? true : false);}
                public void DoMoveItem(int bSuccess) { if(OnMoveItem != null) OnMoveItem(bSuccess == 1 ? true : false);}
                public void DoSwapItem(int bSuccess) { if(OnSwapItem != null) OnSwapItem(bSuccess == 1 ? true : false);}
                public void DoUpdateItems(int bSuccess) { if(OnUpdateItems != null) OnUpdateItems(bSuccess == 1 ? true : false);}
        */
    }
}

namespace TornadoAPI
{
    public class APIEventHandler : EventHandler
    {
        private Tornado owner;

        public APIEventHandler(Tornado _owner)
        {
            owner = _owner;
        }


        public override void OnLogMessage(string LogMessage) { owner.DoLogMessage(LogMessage); }
        //public override void OnSetBackgroundVideo(int bSuccess, string SceneName, string VideoFileName, int LoopCount, int LoopInfinite) { owner.DoSetBackgroundVideo(bSuccess, SceneName, VideoFileName, LoopCount, LoopInfinite); }

        /*
        public override void OnSetCounterNumber(int bSuccess, string ObjectName, double Number) { owner.DoSetCounterNumber(bSuccess, ObjectName, Number); }
         * 
        public override void OnAddPause(int bSuccess, string SceneName, int AnimationType, int FrameNo, int Delay, int bAuto) { owner.DoAddPause(bSuccess, SceneName, AnimationType, FrameNo, Delay, bAuto); }
        public override void OnAddPauseByName(int bSuccess, string SceneName, string AnimationName, int FrameNo, int Delay, int bAuto) { owner.DoAddPauseByName(bSuccess, SceneName, AnimationName, FrameNo, Delay, bAuto); }
        public override void OnAddText(int bSuccess, string ObjectName, string Text, int StyleNo) { owner.DoAddText(bSuccess, ObjectName, Text, StyleNo); }
        public override void OnBeginTransaction(int iSuccess) { owner.DoBeginTransaction(iSuccess); }
        public override void OnDeletePause(int bSuccess, string SceneName, int AnimationType, int FrameNo, int bAll) { owner.DoDeletePause(bSuccess, SceneName, AnimationType, FrameNo, bAll); }
        public override void OnDeletePauseByName(int bSuccess, string SceneName, string AnimationName, int FrameNo, int bAll) { owner.DoDeletePauseByName(bSuccess, SceneName, AnimationName, FrameNo, bAll); }
        public override void OnEditText(int bSuccess, string ObjectName, string Text, int BeginPos, int EndPos, int StyleNo) { owner.DoEditText(bSuccess, ObjectName, Text, BeginPos, EndPos, StyleNo); }
        public override void OnEndTransaction(int iSuccess) { owner.DoEndTransaction(iSuccess); }
        public override void OnHeartBeat(int bSuccess) { owner.DoHeartBeat(bSuccess); }
        public override void OnHello() { owner.DoHello(); }
        public override void OnLoadProject(int bSuccess, KAScene pScene, int TotalCount) { owner.DoLoadProject(bSuccess, pScene, TotalCount); }
        public override void OnCloseProject(int bSuccess, string AliasName) { owner.DoCloseProject(bSuccess, AliasName); }
        public override void OnSelectProject(int bSuccess, string AliasName) { owner.DoSelectProject(bSuccess, AliasName); }
        public override void OnLoadScene(int bSuccess, string SceneName) { owner.DoLoadScene(bSuccess, SceneName); }
        public override void OnLogMessage(string LogMessage) { owner.DoLogMessage(LogMessage); }
        public override void OnMessageNo(uint MessageNo) { owner.DoMessageNo(MessageNo); }
        public override void OnPause(int bSuccess, int LayerNo) { owner.DoPause(bSuccess, LayerNo); }
        public override void OnPlay(int bSuccess, int LayerNo) { owner.DoPlay(bSuccess, LayerNo); }
        public override void OnPlayOut(int bSuccess, int LayerNo) { owner.DoPlayOut(bSuccess, LayerNo); }
        public override void OnQueryAnimationCount(int bSuccess, string SceneName, int AnimationCount) { owner.DoQueryAnimationCount(bSuccess, SceneName, AnimationCount); }
        public override void OnQueryAnimationNames(int bSuccess, string SceneName, int Index, int TotalCount, string pAnimationName) { owner.DoQueryAnimationNames(bSuccess, SceneName, Index, TotalCount, pAnimationName); }
        public override void OnQueryChartDataTable(int bSuccess, string ObjectName, int Index, int TotalCount, ref sKChartDataTable Param)  { owner.DoQueryChartDataTable(bSuccess,ObjectName,Index,TotalCount,ref Param); }
        public override void OnQueryChartObjects(int bSuccess, string SceneName, int Index, int TotalCount, ref sKChart Param)  { owner.DoQueryChartObjects(bSuccess,SceneName,Index,TotalCount,ref Param); }
        public override void OnQueryClassType(int bSuccess, string ObjectName, int ClassType) { owner.DoQueryClassType(bSuccess, ObjectName, ClassType); }
        public override void OnQueryIsOnAir(int bSuccess, int LayerNo) { owner.DoQueryIsOnAir(bSuccess, LayerNo); }
        public override void OnQueryLightNames(int bSuccess, string SceneName, int Index, int TotalCount, string pLightName) { owner.DoQueryLightNames(bSuccess, SceneName, Index, TotalCount, pLightName); }
        public override void OnQueryObjectAttribute(int bSuccess, string ObjectName, ref sKObjectAttribute pKObjectAttribute)  { owner.DoQueryObjectAttribute(bSuccess,ObjectName,ref pKObjectAttribute); }
        public override void OnQuerySceneEffectType(int bSuccess, string SceneName, int bInEffect, eKSceneEffectType EffectType, int Duration) { owner.DoQuerySceneEffectType(bSuccess, SceneName, bInEffect, EffectType, Duration); }
        public override void OnQuerySize(int bSuccess, string ObjectName, float Width, float Height, float Depth) { owner.DoQuerySize(bSuccess, ObjectName, Width, Height, Depth); }
        public override void OnQueryVariables(int bSuccess, string SceneName, int Index, int TotalCount, ref sKVariable Param)  { owner.DoQueryVariables(bSuccess,SceneName,Index,TotalCount,ref Param); }
        public override void OnReloadScene(int bSuccess, string FileName, string SceneName) { owner.DoReloadScene(bSuccess, FileName, SceneName); }
        public override void OnReplaceWithAFile(int bSuccess, string ObjectName, string ReplaceFileName) { owner.DoReplaceWithAFile(bSuccess, ObjectName, ReplaceFileName); }
        public override void OnResume(int bSuccess, int LayerNo) { owner.DoResume(bSuccess, LayerNo); }
        public override void OnRollbackTransaction(int iSuccess) { owner.DoRollbackTransaction(iSuccess); }
        public override void OnSaveImageFile(int bSuccess, string SceneName, int Width, int Height, int Frame, string ImagePathName) { owner.DoSaveImageFile(bSuccess, SceneName, Width, Height, Frame, ImagePathName); }
        public override void OnSaveScene(int bSuccess, string SceneName, string K3SFileName, int UseCollect) { owner.DoSaveScene(bSuccess, SceneName, K3SFileName, UseCollect); }
        public override void OnScenePaused(int bSuccess, int LayerNo) { owner.DoScenePaused(bSuccess, LayerNo); }
        public override void OnScenePlayed(int bSuccess, int LayerNo) { owner.DoScenePlayed(bSuccess, LayerNo); }
        public override void OnScenePrepare(int bSuccess, string SceneName, int LayerNo) { owner.DoScenePrepare(bSuccess, SceneName, LayerNo); }
        public override void OnScenePrepareEx(int bSuccess, string SceneName, int LayerNo) { owner.DoScenePrepareEx(bSuccess, SceneName, LayerNo); }
        public override void OnSetBackground(int bSuccess, string SceneName, ref sKBackground Param)  { owner.DoSetBackground(bSuccess,SceneName,ref Param); }
        public override void OnSetBackgroundFill(int bSuccess, string SceneName, int R, int G, int B, int A) { owner.DoSetBackgroundFill(bSuccess, SceneName, R, G, B, A); }
        public override void OnSetBackgroundTexture(int bSuccess, string SceneName, string TextureFileName) { owner.DoSetBackgroundTexture(bSuccess, SceneName, TextureFileName); }
        public override void OnSetBackgroundVideo(int bSuccess, string SceneName, string VideoFileName, int LoopCount, int LoopInfinite) { owner.DoSetBackgroundVideo(bSuccess, SceneName, VideoFileName, LoopCount, LoopInfinite); }
        public override void OnSetBackgroundLiveIn(int bSuccess, string SceneName, int InputChannel) { owner.DoSetBackgroundLiveIn(bSuccess, SceneName, InputChannel); }
        public override void OnUseBackground(int bSuccess, string SceneName, int Use) { owner.DoUseBackground(bSuccess, SceneName, Use); }
        public override void OnSetChangeOut(int bSuccess, string SceneName) { owner.DoSetChangeOut(bSuccess, SceneName); }
        public override void OnSetChartCellData(int bSuccess, string ObjectName, float Value) { owner.DoSetChartCellData(bSuccess, ObjectName, Value); }
        public override void OnSetChartCSVFile(int bSuccess, string ObjectName, string FilePath) { owner.DoSetChartCSVFile(bSuccess, ObjectName, FilePath); }
        public override void OnSetCircleAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { owner.DoSetCircleAngleKey(bSuccess, ObjectName, KeyIndex, Start, End); }
        public override void OnSetCountDown(int bSuccess, string ObjectName, float Second) { owner.DoSetCountDown(bSuccess, ObjectName, Second); }
        public override void OnSetCounterNumberKey(int bSuccess, string ObjectName, int KeyIndex, double Number) { owner.DoSetCounterNumberKey(bSuccess, ObjectName, KeyIndex, Number); }
        public override void OnSetCropKey(int bSuccess, string ObjectName, int KeyIndex, float Left, float Top, float Right, float Bottom) { owner.DoSetCropKey(bSuccess, ObjectName, KeyIndex, Left, Top, Right, Bottom); }
        public override void OnSetCylinderAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { owner.DoSetCylinderAngleKey(bSuccess, ObjectName, KeyIndex, Start, End); }
        public override void OnSetEdgeAttribute(int bSuccess, string ObjectName, ref sKEdgeAttribute Param)  { owner.DoSetEdgeAttribute(bSuccess,ObjectName,ref Param); }
        public override void OnSetFaceAttribute(int bSuccess, string ObjectName, ref sKFaceAttribute Param)  { owner.DoSetFaceAttribute(bSuccess,ObjectName,ref Param); }
        public override void OnSetFont(int bSuccess, string ObjectName, ref sKFont Param)  { owner.DoSetFont(bSuccess,ObjectName,ref Param); }
        public override void OnSetLightAttribute(int bSuccess, string SceneName, string LightName, ref sKLightAttribute Param)  { owner.DoSetLightAttribute(bSuccess,SceneName,LightName,ref Param); }
        public override void OnSetLightColor(int bSuccess, string SceneName, string LightName, ref sKLightColor Param) { owner.DoSetLightColor(bSuccess, SceneName, LightName, ref Param); }
        public override void OnSetMaterial(int bSuccess, string ObjectName, ref sKMaterial pKMaterial) { owner.DoSetMaterial(bSuccess, ObjectName, ref pKMaterial); }
        public override void OnSetMaterialKey(int bSuccess, string ObjectName, int KeyIndex, ref sKMaterial pKMaterial) { owner.DoSetMaterialKey(bSuccess, ObjectName, KeyIndex, ref pKMaterial); }
        public override void OnSetLensFlaresKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { owner.DoSetLensFlaresKey(bSuccess, ObjectName, KeyIndex, X, Y, Z); }
        public override void OnSetObjectAttribute(int bSuccess, string ObjectName, ref sKObjectAttribute pKObjectAttribute) { owner.DoSetObjectAttribute(bSuccess, ObjectName, ref pKObjectAttribute); }
        public override void OnSetPosition(int bSuccess, string ObjectName, float X, float Y, float Z) { owner.DoSetPosition(bSuccess, ObjectName, X, Y, Z); }
        public override void OnSetPositionKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { owner.DoSetPositionKey(bSuccess, ObjectName, KeyIndex, X, Y, Z); }
        public override void OnSetRotation(int bSuccess, string ObjectName, float X, float Y, float Z) { owner.DoSetRotation(bSuccess, ObjectName, X, Y, Z); }
        public override void OnSetRotationKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { owner.DoSetRotationKey(bSuccess, ObjectName, KeyIndex, X, Y, Z); }
        public override void OnSetScale(int bSuccess, string ObjectName, float X, float Y, float Z) { owner.DoSetScale(bSuccess, ObjectName, X, Y, Z); }
        public override void OnSetScaleKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { owner.DoSetScaleKey(bSuccess, ObjectName, KeyIndex, X, Y, Z); }
        public override void OnSetSceneEffectType(int bSuccess, string SceneName, int bInEffect, eKSceneEffectType EffectType, int Duration) { owner.DoSetSceneEffectType(bSuccess, SceneName, bInEffect, EffectType, Duration); }
        public override void OnSetShadowAttribute(int bSuccess, string ObjectName, ref sKShadowAttribute Param) { owner.DoSetShadowAttribute(bSuccess, ObjectName, ref Param); }
        public override void OnSetSize(int bSuccess, string ObjectName, float Width, float Height, float Depth) { owner.DoSetSize(bSuccess, ObjectName, Width, Height, Depth); }
        public override void OnSetSphereAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { owner.DoSetSphereAngleKey(bSuccess, ObjectName, KeyIndex, Start, End); }
        public override void OnSetStyleColor(int bSuccess, string ObjectName, ref sKStyleColor Param) { owner.DoSetStyleColor(bSuccess, ObjectName, ref Param); }
        public override void OnSetFaceColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { owner.DoSetFaceColor(bSuccess, ObjectName, R, G, B, A); }
        public override void OnSetEdgeColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { owner.DoSetEdgeColor(bSuccess, ObjectName, R, G, B, A); }
        public override void OnSetShadowColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { owner.DoSetShadowColor(bSuccess, ObjectName, R, G, B, A); }
        public override void OnSetTextStyle(int bSuccess, string ObjectName, int Begin, int Count, int StyleNo) { owner.DoSetTextStyle(bSuccess, ObjectName, Begin, Count, StyleNo); }
        public override void OnSetValue(int bSuccess, string ObjectName, string Value) { owner.DoSetValue(bSuccess, ObjectName, Value); }
        public override void OnSetTextTexture(int bSuccess, string ObjectName, string FileName) { owner.DoSetTextTexture(bSuccess, ObjectName, FileName); }
        public override void OnSetStyleTexture(int bSuccess, string ObjectName, string FileName) { owner.DoSetStyleTexture(bSuccess, ObjectName, FileName); }
        public override void OnSetDiffuseTexture(int bSuccess, string ObjectName, string FileName) { owner.DoSetDiffuseTexture(bSuccess, ObjectName, FileName); }
        public override void OnSetSpecularTexture(int bSuccess, string ObjectName, string FileName) { owner.DoSetSpecularTexture(bSuccess, ObjectName, FileName); }
        public override void OnSetTransparencyTexture(int bSuccess, string ObjectName, string FileName) { owner.DoSetTransparencyTexture(bSuccess, ObjectName, FileName); }
        public override void OnSetNormalTexture(int bSuccess, string ObjectName, string FileName) { owner.DoSetNormalTexture(bSuccess, ObjectName, FileName); }
        public override void OnSetReflectionTexture(int bSuccess, string ObjectName, string FileName) { owner.DoSetReflectionTexture(bSuccess, ObjectName, FileName); }
        public override void OnSetRefractionTexture(int bSuccess, string ObjectName, string FileName) { owner.DoSetRefractionTexture(bSuccess, ObjectName, FileName); }
        public override void OnSetVisible(int bSuccess, string ObjectName, int bShow) { owner.DoSetVisible(bSuccess, ObjectName, bShow); }
        public override void OnStop(int bSuccess, int LayerNo) { owner.DoStop(bSuccess, LayerNo); }
        public override void OnStopAll(int iSuccess) { owner.DoStopAll(iSuccess); }
        public override void OnStoreTextStyle(int bSuccess, string ObjectName, string Text, int StyleCount) { owner.DoStoreTextStyle(bSuccess, ObjectName, Text, StyleCount); }
        public override void OnTrigger(int bSuccess, int LayerNo, int AnimationType) { owner.DoTrigger(bSuccess, LayerNo, AnimationType); }
        public override void OnTriggerByName(int bSuccess, int LayerNo, string AnimationName) { owner.DoTriggerByName(bSuccess, LayerNo, AnimationName); }
        public override void OnTriggerObject(int bSuccess, string ObjectName, int LayerNo, int AnimationType, int bWithChildren) { owner.DoTriggerObject(bSuccess, ObjectName, LayerNo, AnimationType, bWithChildren); }
        public override void OnTriggerObjectByName(int bSuccess, string ObjectName, int LayerNo, string AnimationName, int bWithChildren) { owner.DoTriggerObjectByName(bSuccess, ObjectName, LayerNo, AnimationName, bWithChildren); }
        public override void OnUnloadAll(int bSuccess) { owner.DoUnloadAll(bSuccess); }
        public override void OnUnloadScene(int bSuccess, string SceneName) { owner.DoUnloadScene(bSuccess, SceneName); }
        public override void OnUpdateTextures(int bSuccess, string SceneName) { owner.DoUpdateTextures(bSuccess, SceneName); }
        public override void OnAddPathPoint(int bSuccess, string ObjectName, int Count) { owner.DoAddPathPoint(bSuccess, ObjectName, Count); }
        public override void OnClearPathPoints(int bSuccess, string ObjectName) { owner.DoClearPathPoints(bSuccess, ObjectName); }
        public override void OnAddPathShapePoint(int bSuccess, string ObjectName, int Count) { owner.DoAddPathShapePoint(bSuccess, ObjectName, Count); }
        public override void OnClearPathShapePoints(int bSuccess, string ObjectName) { owner.DoClearPathShapePoints(bSuccess, ObjectName); }
        public override void OnQueryScrollRemainingDistance(int bSuccess, string ObjectName, int ScrollRemainingDistance) { owner.DoQueryScrollRemainingDistance(bSuccess, ObjectName, ScrollRemainingDistance); }
        public override void OnAddScrollObject(int bSuccess, string ObjectName, string ChildName) { owner.DoAddScrollObject(bSuccess, ObjectName, ChildName); }
        public override void OnSetVariableName(int bSuccess, string ObjectName, string VariableName) { owner.DoSetVariableName(bSuccess, ObjectName, VariableName); }
        public override void OnAdjustScrollSpeed(int bSuccess, string ObjectName, float SpeedDelta) { owner.DoAdjustScrollSpeed(bSuccess, ObjectName, SpeedDelta); }
        public override void OnSetScrollSpeed(int bSuccess, string ObjectName, float Speed) { owner.DoSetScrollSpeed(bSuccess, ObjectName, Speed); }
        public override void OnSetDiffuse(int bSuccess, string ObjectName, int R, int G, int B) { owner.DoSetDiffuse(bSuccess, ObjectName, R, G, B); }
        public override void OnSetAmbient(int bSuccess, string ObjectName, int R, int G, int B) { owner.DoSetAmbient(bSuccess, ObjectName, R, G, B); }
        public override void OnSetSpecular(int bSuccess, string ObjectName, int R, int G, int B) { owner.DoSetSpecular(bSuccess, ObjectName, R, G, B); }
        public override void OnSetEmissive(int bSuccess, string ObjectName, int R, int G, int B) { owner.DoSetEmissive(bSuccess, ObjectName, R, G, B); }
        public override void OnSetOpacity(int bSuccess, string ObjectName, int Opacity) { owner.DoSetOpacity(bSuccess, ObjectName, Opacity); }
        public override void OnSetDiffuseKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { owner.DoSetDiffuseKey(bSuccess, ObjectName, KeyIndex, R, G, B); }
        public override void OnSetAmbientKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { owner.DoSetAmbientKey(bSuccess, ObjectName, KeyIndex, R, G, B); }
        public override void OnSetSpecularKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { owner.DoSetSpecularKey(bSuccess, ObjectName, KeyIndex, R, G, B); }
        public override void OnSetEmissiveKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { owner.DoSetEmissiveKey(bSuccess, ObjectName, KeyIndex, R, G, B); }
        public override void OnSetOpacityKey(int bSuccess, string ObjectName, int KeyIndex, int Opacity) { owner.DoSetOpacityKey(bSuccess, ObjectName, KeyIndex, Opacity); }
        public override void OnSetLoftPositionKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { owner.DoSetLoftPositionKey(bSuccess, ObjectName, KeyIndex, Start, End); }
        public override void OnModifyPathPoint(int bSuccess, string ObjectName, int Index, float X, float Y, float Z) { owner.DoModifyPathPoint(bSuccess, ObjectName, Index, X, Y, Z); }
        public override void OnSetVideoFrame(int bSuccess, string ObjectName, int StartFrame, int StopFrame) { owner.DoSetVideoFrame(bSuccess, ObjectName, StartFrame, StopFrame); }
        public override void OnSetVideoRepeatInfo(int bSuccess, string ObjectName, int StartFrame, int StopFrame, int LoopCount, int bInfinite, int bPlayAsOut) { owner.DoSetVideoRepeatInfo(bSuccess, ObjectName, StartFrame, StopFrame, LoopCount, bInfinite, bPlayAsOut); }
        public override void OnSetTextStyleLibrary(int bSuccess, string ObjectName, string Text, int StyleID) { owner.DoSetTextStyleLibrary(bSuccess, ObjectName, Text, StyleID); }
        public override void OnAddTextStyleLibrary(int bSuccess, string ObjectName, string Text, int StyleID) { owner.DoAddTextStyleLibrary(bSuccess, ObjectName, Text, StyleID); }
        public override void OnInitScrollObject(int bSuccess, string ObjectName) { owner.DoInitScrollObject(bSuccess, ObjectName); }
        public override void OnSetCounterInfo(int bSuccess, string ObjectName, string Format, int UpdatePeriod, int bAddPlusSign) { owner.DoSetCounterInfo(bSuccess, ObjectName, Format, UpdatePeriod, bAddPlusSign); }
        public override void OnSetCounterNumber(int bSuccess, string ObjectName, double Number) { owner.DoSetCounterNumber(bSuccess, ObjectName, Number); }
        public override void OnSetCounterRange(int bSuccess, string ObjectName, double StartTime, double EndTime) { owner.DoSetCounterRange(bSuccess, ObjectName, StartTime, EndTime); }
        public override void OnSetCounterRemainingTime(int bSuccess, string ObjectName, double BaseTime) { owner.DoSetCounterRemainingTime(bSuccess, ObjectName, BaseTime); }
        public override void OnSetCounterElapsedTime(int bSuccess, string ObjectName, double BaseTime) { owner.DoSetCounterElapsedTime(bSuccess, ObjectName, BaseTime); }
        public override void OnSaveObjectImage(int bSuccess, string ObjectName, string FileName) { owner.DoSaveObjectImage(bSuccess, ObjectName, FileName); }
        public override void OnSendMosMessage(int bSuccess, string MosMessage) { owner.DoSendMosMessage(bSuccess, MosMessage); }
        public override void OnReceiveFile(int bSuccess, string ExistingFileName, string NewFileName) { owner.DoeiveFile(bSuccess, ExistingFileName, NewFileName); }
        public override void OnAddObject(int bSuccess) { owner.DoAddObject(bSuccess); }
        public override void OnSavePreviewImage(int bSuccess, string ImagePathName, int Width, int Height) { owner.DoSavePreviewImage(bSuccess, ImagePathName, Width, Height); }
        public override void OnNewProject(int bSuccess, string AliasName) { owner.DoNewProject(bSuccess, AliasName); }
        public override void OnQueryPickedObjects(int bSuccess, string SceneName, int index, int TotalCount, ref sKVariable Param) { owner.DoQueryPickedObjects(bSuccess, SceneName, index, TotalCount, ref Param); }
        public override void OnDragObject(int bSuccess, string ObjectName, int X, int Y, int FrameCount) { owner.DoDragObject(bSuccess, ObjectName, X, Y, FrameCount); }
        public override void OnResetDrag(int bSuccess, string ObjectName, int FrameCount) { owner.DoResetDrag(bSuccess, ObjectName, FrameCount); }
        public override void OnCreateStory(int bSuccess) { owner.DoCreateStory(bSuccess); }
        public override void OnInsertStory(int bSuccess) { owner.DoInsertStory(bSuccess); }
        public override void OnMoveStory(int bSuccess) { owner.DoMoveStory(bSuccess); }
        public override void OnSwapStory(int bSuccess) { owner.DoSwapStory(bSuccess); }
        public override void OnDeleteStory(int bSuccess) { owner.DoDeleteStory(bSuccess); }
        public override void OnCreateItem(int bSuccess) { owner.DoCreateItem(bSuccess); }
        public override void OnPrepareItem(int bSuccess) { owner.DoPrepareItem(bSuccess); }
        public override void OnSceneSaved(int bSuccess, string FileName) { owner.DoSceneSaved(bSuccess, FileName); }
        public override void OnSetSceneScrollSpeed(int bSuccess, string SceneName, float Speed) { owner.DoSetSceneScrollSpeed(bSuccess, SceneName, Speed); }
        public override void OnCreateWithAFile(int bSuccess, string SceneName, string FileName, string VariableName) { owner.DoCreateWithAFile(bSuccess, SceneName, FileName, VariableName); }
        public override void OnSetSceneAudioFile(int bSuccess, string SceneName, int AnimatiionType, string AudioFileName) { owner.DoSetSceneAudioFile(bSuccess, SceneName, AnimatiionType, AudioFileName); }
        public override void OnSetScrollSpeedByScenePlayer(int bSuccess, int LayerNo, float Speed) { owner.DoSetScrollSpeedByScenePlayer(bSuccess, LayerNo, Speed); }
        public override void OnAdjustScrollSpeedByScenePlayer(int bSuccess, int LayerNo, float SpeedDelta) { owner.DoAdjustScrollSpeedByScenePlayer(bSuccess, LayerNo, SpeedDelta); }
        public override void OnEnableSceneAudio(int bSuccess, string SceneName, int AnimatiionType, int bEnable) { owner.DoEnableSceneAudio(bSuccess, SceneName, AnimatiionType, bEnable); }
        public override void OnInsertItem(int bSuccess) { owner.DoInsertItem(bSuccess); }
        public override void OnDeleteItem(int bSuccess) { owner.DoDeleteItem(bSuccess); }
        public override void OnMoveItem(int bSuccess) { owner.DoMoveItem(bSuccess); }
        public override void OnSwapItem(int bSuccess) { owner.DoSwapItem(bSuccess); }
        public override void OnUpdateItems(int bSuccess) { owner.DoUpdateItems(bSuccess); } */

    }
}