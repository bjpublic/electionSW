﻿using System;
using System.Collections.Generic;
using System.Text;
using K3DAsyncEngineLib;

//K3DAsyncEngineLib.dll 콤포넌트 이벤트 처리위한 핸들러 등록
public class EventHandler : KAEventHandler
{


    virtual public void OnAddPause(int bSuccess, string SceneName, int AnimationType, int FrameNo, int Delay, int bAuto) { }

    virtual public void OnAddPauseByName(int bSuccess, string SceneName, string AnimationName, int FrameNo, int Delay, int bAuto) { }

    virtual public void OnAddText(int bSuccess, string ObjectName, string Text, int StyleNo) { }

    virtual public void OnBeginTransaction(int iSuccess) { }

    virtual public void OnDeletePause(int bSuccess, string SceneName, int AnimationType, int FrameNo, int bAll) { }

    virtual public void OnDeletePauseByName(int bSuccess, string SceneName, string AnimationName, int FrameNo, int bAll) { }

    virtual public void OnEditText(int bSuccess, string ObjectName, string Text, int BeginPos, int EndPos, int StyleNo) { }

    virtual public void OnEndTransaction(int iSuccess) { }

    virtual public void OnHeartBeat(int bSuccess) { }

    virtual public void OnHello() { }

    virtual public void OnClose(int ErrorCode) { }

    virtual public void OnLoadProject(int bSuccess, KAScene pScene, int TotalCount) { }

    virtual public void OnCloseProject(int bSuccess, string AliasName) { }

    virtual public void OnSelectProject(int bSuccess, string AliasName) { }

    virtual public void OnLoadScene(int bSuccess, string SceneName) { }

    virtual public void OnLogMessage(string LogMessage) { }

    virtual public void OnMessageNo(uint MessageNo) { }

    virtual public void OnPause(int bSuccess, int LayerNo) { }

    virtual public void OnPlay(int bSuccess, int LayerNo) { }

    virtual public void OnPlayOut(int bSuccess, int LayerNo) { }

    virtual public void OnQueryAnimationCount(int bSuccess, string SceneName, int AnimationCount) { }

    virtual public void OnQueryAnimationNames(int bSuccess, string SceneName, int Index, int TotalCount, string pAnimationName) { }

    virtual public void OnQueryChartDataTable(int bSuccess, string ObjectName, int Index, int TotalCount, ref sKChartDataTable Param) { }

    virtual public void OnQueryChartObjects(int bSuccess, string SceneName, int Index, int TotalCount, ref sKChart Param) { }

    virtual public void OnQueryClassType(int bSuccess, string ObjectName, int ClassType) { }

    virtual public void OnQueryIsOnAir(int bSuccess, int LayerNo) { }

    virtual public void OnQueryLightNames(int bSuccess, string SceneName, int Index, int TotalCount, string pLightName) { }

    virtual public void OnQueryObjectAttribute(int bSuccess, string ObjectName, ref sKObjectAttribute pKObjectAttribute) { }

    virtual public void OnQuerySceneEffectType(int bSuccess, string SceneName, int bInEffect, eKSceneEffectType EffectType, int Duration) { }

    virtual public void OnQuerySize(int bSuccess, string ObjectName, float Width, float Height, float Depth) { }

    virtual public void OnQueryVariables(int bSuccess, string SceneName, int Index, int TotalCount, ref sKVariable Param) { }

    virtual public void OnReloadScene(int bSuccess, string FileName, string SceneName) { }

    virtual public void OnReplaceWithAFile(int bSuccess, string ObjectName, string ReplaceFileName) { }

    virtual public void OnResume(int bSuccess, int LayerNo) { }

    virtual public void OnRollbackTransaction(int iSuccess) { }

    virtual public void OnSaveImageFile(int bSuccess, string SceneName, int Width, int Height, int Frame, string ImagePathName) { }

    virtual public void OnSaveScene(int bSuccess, string SceneName, string K3SFileName, int UseCollect) { }

    virtual public void OnScenePaused(int bSuccess, int LayerNo) { }

    virtual public void OnScenePlayed(int bSuccess, int LayerNo) { }

    virtual public void OnSceneAnimationPlayed(int bSuccess, int LayerNo) { }

    virtual public void OnScenePrepare(int bSuccess, string SceneName, int LayerNo) { }

    virtual public void OnScenePrepareEx(int bSuccess, string SceneName, int LayerNo) { }

    virtual public void OnSetBackground(int bSuccess, string SceneName, ref sKBackground Param) { }

    virtual public void OnSetBackgroundFill(int bSuccess, string SceneName, int R, int G, int B, int A) { }

    virtual public void OnSetBackgroundTexture(int bSuccess, string SceneName, string TextureFileName) { }

    virtual public void OnSetBackgroundVideo(int bSuccess, string SceneName, string VideoFileName, int LoopCount, int LoopInfinite) { }

    virtual public void OnSetBackgroundLiveIn(int bSuccess, string SceneName, int InputChannel) { }

    virtual public void OnUseBackground(int bSuccess, string SceneName, int Use) { }

    virtual public void OnSetChangeOut(int bSuccess, string SceneName) { }

    virtual public void OnSetChartCellData(int bSuccess, string ObjectName, float Value) { }

    virtual public void OnSetChartCSVFile(int bSuccess, string ObjectName, string FilePath) { }

    virtual public void OnSetCircleAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { }

    virtual public void OnSetCountDown(int bSuccess, string ObjectName, float Second) { }

    virtual public void OnSetCounterNumberKey(int bSuccess, string ObjectName, int KeyIndex, double Number) { }

    virtual public void OnSetCropKey(int bSuccess, string ObjectName, int KeyIndex, float Left, float Top, float Right, float Bottom) { }

    virtual public void OnSetCylinderAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { }

    virtual public void OnSetEdgeAttribute(int bSuccess, string ObjectName, ref sKEdgeAttribute Param) { }

    virtual public void OnSetFaceAttribute(int bSuccess, string ObjectName, ref sKFaceAttribute Param) { }

    virtual public void OnSetFont(int bSuccess, string ObjectName, ref sKFont Param) { }

    virtual public void OnSetLightAttribute(int bSuccess, string SceneName, string LightName, ref sKLightAttribute Param) { }

    virtual public void OnSetLightColor(int bSuccess, string SceneName, string LightName, ref sKLightColor Param) { }

    virtual public void OnSetMaterial(int bSuccess, string ObjectName, ref sKMaterial pKMaterial) { }

    virtual public void OnSetMaterialKey(int bSuccess, string ObjectName, int KeyIndex, ref sKMaterial pKMaterial) { }

    virtual public void OnSetLensFlaresKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { }

    virtual public void OnSetObjectAttribute(int bSuccess, string ObjectName, ref sKObjectAttribute pKObjectAttribute) { }

    virtual public void OnSetPosition(int bSuccess, string ObjectName, float X, float Y, float Z) { }

    virtual public void OnSetPositionKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { }

    virtual public void OnSetRotation(int bSuccess, string ObjectName, float X, float Y, float Z) { }

    virtual public void OnSetRotationKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { }

    virtual public void OnSetScale(int bSuccess, string ObjectName, float X, float Y, float Z) { }

    virtual public void OnSetScaleKey(int bSuccess, string ObjectName, int KeyIndex, float X, float Y, float Z) { }

    virtual public void OnSetSceneEffectType(int bSuccess, string SceneName, int bInEffect, eKSceneEffectType EffectType, int Duration) { }

    virtual public void OnSetShadowAttribute(int bSuccess, string ObjectName, ref sKShadowAttribute Param) { }

    virtual public void OnSetSize(int bSuccess, string ObjectName, float Width, float Height, float Depth) { }

    virtual public void OnSetSphereAngleKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { }

    virtual public void OnSetStyleColor(int bSuccess, string ObjectName, ref sKStyleColor Param) { }

    virtual public void OnSetFaceColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { }

    virtual public void OnSetEdgeColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { }

    virtual public void OnSetShadowColor(int bSuccess, string ObjectName, int R, int G, int B, int A) { }

    virtual public void OnSetTextStyle(int bSuccess, string ObjectName, int Begin, int Count, int StyleNo) { }

    virtual public void OnSetValue(int bSuccess, string ObjectName, string Value) { }

    virtual public void OnSetTextTexture(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSetStyleTexture(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSetDiffuseTexture(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSetSpecularTexture(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSetTransparencyTexture(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSetNormalTexture(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSetReflectionTexture(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSetRefractionTexture(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSetVisible(int bSuccess, string ObjectName, int bShow) { }

    virtual public void OnStop(int bSuccess, int LayerNo) { }

    virtual public void OnStopAll(int iSuccess) { }

    virtual public void OnStoreTextStyle(int bSuccess, string ObjectName, string Text, int StyleCount) { }

    virtual public void OnTriggerByName(int bSuccess, int LayerNo, string AnimationName) { }

    virtual public void OnTriggerObject(int bSuccess, string ObjectName, int LayerNo, int AnimationType, int bWithChildren, int a) { }

    virtual public void OnTriggerObjectByName(int bSuccess, string ObjectName, int LayerNo, int a, string AnimationName, int bWithChildren) { }
  
    virtual public void OnUnloadAll(int bSuccess) { }

    virtual public void OnUnloadScene(int bSuccess, string SceneName) { }

    virtual public void OnUpdateTextures(int bSuccess, string SceneName) { }

    virtual public void OnAddPathPoint(int bSuccess, string ObjectName, int Count) { }

    virtual public void OnClearPathPoints(int bSuccess, string ObjectName) { }

    virtual public void OnAddPathShapePoint(int bSuccess, string ObjectName, int Count) { }

    virtual public void OnClearPathShapePoints(int bSuccess, string ObjectName) { }

    virtual public void OnQueryScrollRemainingDistance(int bSuccess, string ObjectName, int ScrollRemainingDistance) { }

    virtual public void OnAddScrollObject(int bSuccess, string ObjectName, string ChildName) { }

    virtual public void OnSetVariableName(int bSuccess, string ObjectName, string VariableName) { }

    virtual public void OnAdjustScrollSpeed(int bSuccess, string ObjectName, float SpeedDelta) { }

    virtual public void OnSetScrollSpeed(int bSuccess, string ObjectName, float Speed) { }

    virtual public void OnSetDiffuse(int bSuccess, string ObjectName, int R, int G, int B) { }

    virtual public void OnSetAmbient(int bSuccess, string ObjectName, int R, int G, int B) { }

    virtual public void OnSetSpecular(int bSuccess, string ObjectName, int R, int G, int B) { }

    virtual public void OnSetEmissive(int bSuccess, string ObjectName, int R, int G, int B) { }

    virtual public void OnSetOpacity(int bSuccess, string ObjectName, int Opacity) { }

    virtual public void OnSetDiffuseKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { }

    virtual public void OnSetAmbientKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { }

    virtual public void OnSetSpecularKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { }

    virtual public void OnSetEmissiveKey(int bSuccess, string ObjectName, int KeyIndex, int R, int G, int B) { }

    virtual public void OnSetOpacityKey(int bSuccess, string ObjectName, int KeyIndex, int Opacity) { }

    virtual public void OnSetLoftPositionKey(int bSuccess, string ObjectName, int KeyIndex, float Start, float End) { }

    virtual public void OnModifyPathPoint(int bSuccess, string ObjectName, int Index, float X, float Y, float Z) { }

    virtual public void OnSetVideoFrame(int bSuccess, string ObjectName, int StartFrame, int StopFrame) { }

    virtual public void OnSetVideoRepeatInfo(int bSuccess, string ObjectName, int StartFrame, int StopFrame, int LoopCount, int bInfinite, int bPlayAsOut) { }

    virtual public void OnSetTextStyleLibrary(int bSuccess, string ObjectName, string Text, int StyleID) { }

    virtual public void OnAddTextStyleLibrary(int bSuccess, string ObjectName, string Text, int StyleID) { }

    virtual public void OnInitScrollObject(int bSuccess, string ObjectName) { }

    virtual public void OnSetCounterInfo(int bSuccess, string ObjectName, string Format, int UpdatePeriod, int bAddPlusSign) { }

    virtual public void OnSetCounterNumber(int bSuccess, string ObjectName, double Number) { }

    virtual public void OnSetCounterRange(int bSuccess, string ObjectName, double StartTime, double EndTime) { }

    virtual public void OnSetCounterRemainingTime(int bSuccess, string ObjectName, double BaseTime) { }

    virtual public void OnSetCounterElapsedTime(int bSuccess, string ObjectName, double BaseTime) { }

    virtual public void OnSaveObjectImage(int bSuccess, string ObjectName, string FileName) { }

    virtual public void OnSendMosMessage(int bSuccess, string MosMessage) { }

    virtual public void OnReceiveFile(int bSuccess, string ExistingFileName, string NewFileName) { }

    virtual public void OnAddObject(int bSuccess) { }

    virtual public void OnSavePreviewImage(int bSuccess, string ImagePathName, int Width, int Height) { }

    virtual public void OnNewProject(int bSuccess, string AliasName) { }

    virtual public void OnQueryPickedObjects(int bSuccess, string SceneName, int index, int TotalCount, ref sKVariable Param) { }

    virtual public void OnSetSceneDuration(int bSuccess, string SceneName, int AnimationType, int Duration) { }

    virtual public void OnSetBackgroundChangeType(int bSuccess, string SceneName, eKBackgroundType  ChangeType) { }

    virtual public void OnSetBackgroundPauseType(int bSuccess, string SceneName, eKBackgroundType PauseType) { }

    virtual public void OnDragObject(int bSuccess, string ObjectName, int X, int Y, int FrameCount) { }

    virtual public void OnResetDrag(int bSuccess, string ObjectName, int FrameCount) { }

    virtual public void OnCreateStory(int bSuccess) { }

    virtual public void OnInsertStory(int bSuccess) { }

    virtual public void OnMoveStory(int bSuccess) { }

    virtual public void OnSwapStory(int bSuccess) { }

    virtual public void OnDeleteStory(int bSuccess) { }

    virtual public void OnCreateItem(int bSuccess) { }

    virtual public void OnPrepareItem(int bSuccess) { }

    virtual public void OnSceneSaved(int bSuccess, string FileName) { }

    virtual public void OnResumeBackground(int bSuccess, int LayerNo) { }

    virtual public void OnSetSceneScrollSpeed(int bSuccess, string SceneName, float Speed) { }

    virtual public void OnCreateWithAFile(int bSuccess, string SceneName, string FileName, string VariableName) { }

    virtual public void OnSetSceneAudioFile(int bSuccess, string SceneName, int AnimatiionType, string AudioFileName) { }

    virtual public void OnSetScrollSpeedByScenePlayer(int bSuccess, int LayerNo, float Speed) { }

    virtual public void OnAdjustScrollSpeedByScenePlayer(int bSuccess, int LayerNo, float SpeedDelta) { }

    virtual public void OnEnableSceneAudio(int bSuccess, string SceneName, int AnimatiionType, int bEnable) { }

    virtual public void OnInsertItem(int bSuccess) { }

    virtual public void OnDeleteItem(int bSuccess) { }

    virtual public void OnMoveItem(int bSuccess) { }

    virtual public void OnSwapItem(int bSuccess) { }

    virtual public void OnUpdateItems(int bSuccess) { }

    virtual public void OnSetPositionOfPathAnimation(int bSuccess, string ObjectName, float Position) { }

    virtual public void OnSetPositionKeyOfPathAnimation(int bSuccess, string ObjectName, int KeyIndex, float Position) { }

    virtual public void OnUpdateThumbnail(int bSuccess, string SceneName) { }

    virtual public void OnSetStyleItemTexture(int bSuccess, string ObjectName, eKStyleType ItemType, int ItemIndex, string FileName) { }

    virtual public void OnSetKeyFrame(int bSuccess, eKObjectAttribute AttributeType, string ObjectName, int KeyIndex, int Frame, eKKeyFrameType KeyFrameType) { }

    virtual public void OnSetKeyInterpolation(int bSuccess, eKObjectAttribute AttributeType, string ObjectName, int KeyIndex, eKKeyInterpolationType InInterpolation, eKKeyInterpolationType OutInterpolation) { }

    virtual public void OnSetStartFrame(int bSuccess, string ObjectName, int Frame) { }

    virtual public void OnStartVideoCapture(int bSuccess, string FilePath, int VideoCodec) { }

    virtual public void OnStopVideoCapture(int bSuccess) { }

    virtual public void OnCaptureImage(int bSuccess, string FilePath) { }

    virtual public void OnAddAbsolutePause(int bSuccess, string SceneName, int AnimationType, int FrameNo, int Delay, int bAuto) { }

    virtual public void OnResetTotalTime(int bSuccess, string SceneName, int AnimationType) { }

    virtual public void OnSetTotalTime(int bSuccess, string SceneName, int AnimationType, int Frame) { }




    virtual public void OnEnablePathShapeOutline(int bSuccess, string SceneName, string ObjectName, int enable) { }
    virtual public void OnEnablePathShapeOutlineThickness(int bSuccess, string SceneName, string ObjectName, float Thickness) { }
    virtual public void OnSetPathShapeOutlineThickness(int bSuccess, string SceneName, string ObjectName, float Thickness) { }

    virtual public void OnAddCloneObject(int bSuccess, string SceneName, string NewValiable) { }
    virtual public void OnCheckVersion(int bSuccess, string SceneName, string SDKVersion) { }
    virtual public void OnClearNextPreview(int bSuccess, int LayerNo) { }
    virtual public void OnCutIn(int bSuccess, int LayerNo) { }
    virtual public void OnCutOut(int bSuccess, int LayerNo) { }
    virtual public void OnDownloadThumbnail(int bSuccess, string ImagePathName, int ImageWidth, int ImageHeight, int Frame, string result) { }
    virtual public void OnEnableMaterialItem(int bSuccess, string item, eKMaterialType type, int i) { }
    virtual public void OnLoadAnimationLibrarys(int bSuccess, string LibraryPath) { }
    virtual public void OnLoadMaterialLibrarys(int bSuccess, string item) { }
    virtual public void OnLoadSceneForce(int bSuccess, string SceneName) { }
    virtual public void OnLoadStyleLibrarys(int bSuccess, string LibraryPath) { }
    virtual public void OnMoveCamera(int bSuccess, string s, int i, int j, int k, int m) { }
    virtual public void OnPlayDirect(int bSuccess, string SceneName, int LayerNo) { }
    virtual public void OnQueryFont(int bSuccess, string ObjectName, ref sKFont Param) { }
    virtual public void OnQueryGroupType(int bSuccess, string ObjectName, eKGroupType GroupType) { }
    virtual public void OnQueryImageType(int bSuccess, string ObjectName, eKTextureTarget TextureTarget, eKImageType ImageType) { }
    virtual public void OnQueryIs3D(int bSuccess, string ObjectName, int b3D) { }
    virtual public void OnQueryMemo(int bSuccess, string ObjectName, string Memo) { }
    virtual public void OnQueryPauseCount(int bSuccess, string ObjectName, int count, int b) { }
    virtual public void OnQueryPauseCountByName(int bSuccess, string ObjectName, string Name, int a) { }
    virtual public void OnQueryScrollChildRemainingDistance(int bSuccess, string ObjectName, string ChildName, int ScrollRemainingDistance) { }
    virtual public void OnQueryTableValue(int bSuccess, string ObjectName, string Name, int a, int b, string c) { }
    virtual public void OnQueryTableValues(int bSuccess, string ObjectName, string Name, int a, int b, int c, int d, string e) { }
    virtual public void OnQueryVideoPlayInfo(int bSuccess, string ObjectName, eKTextureTarget TextureTarget, ref sKVideoPlayInfo Param) { }
    virtual public void OnSetAmbientColor(int bSuccess, string ObjectName, sKColor Color) { }
    virtual public void OnSetAmbientColorKey(int bSuccess, string ObjectName, int a, sKColor color) { }
    virtual public void OnSetAnimationLibrary(int bSuccess, string ObjectName, string s, int a) { }
    virtual public void OnSetAudioOutput(int bSuccess, eKPlayAudioType PlayAudioType) { }
    virtual public void OnSetBackgroundChangeType(int bSuccess, string SceneName, eKBackgroundChangeType BackgroundChangeType) { }
    virtual public void OnSetBackgroundPauseAtZeroFrameAsStandBy(int bSuccess, string SceneName, int pause) { }
    virtual public void OnSetDiffuseColor(int bSuccess, string SceneName, sKColor color) { }
    virtual public void OnSetBackgroundPauseType(int bSuccess, string SceneName, eKBackgroundPauseType BackgroundPauseType) { }
    virtual public void OnSetDiffuseColorKey(int bSuccess, string SceneName, int key, sKColor color) { }
    virtual public void OnSetDiffuseTextColor(int bSuccess, string SceneName, int beginpos, int count, int r, int g, int b, int a) { }
    virtual public void OnSetEdgeTextColor(int bSuccess, string SceneName, int beginpos, int count, int r, int g, int b, int a) { }
    virtual public void OnSetEffectBlink(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectBlur(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectColor(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectCrop(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectCurl(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectCutOut(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectDistortion(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectFade(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectNone(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectParticle(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectPush(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectRipple(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectSidefade(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectTransform(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectSideWipe(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEffectWipe(int bSuccess, string SceneName, string a, int b) { }
    virtual public void OnSetEmissiveColor(int bSuccess, string SceneName, sKColor color) { }
    virtual public void OnSetEmissiveColorKey(int bSuccess, string SceneName, int key, sKColor color) { }
    virtual public void OnSetFaceTextColor(int bSuccess, string SceneName, int beginpos, int count, int r, int g, int b, int a) { }
    virtual public void OnSetImageOriginalSize(int bSuccess, string SceneName, string objectname) { }
    virtual public void OnSetImageType(int bSuccess, string SceneName, eKTextureTarget TextureTarget, eKImageType ImageType) { }
    virtual public void OnSetMaterialLibrary(int bSuccess, string SceneName, string objectname) { }
    virtual public void OnSetMaterialTextureAddress(int bSuccess, string SceneName, eKTextureAddress TextureAddress) { }
    virtual public void OnSetMaterialTextureBlending(int bSuccess, string SceneName, eKTextureBlending TextureBlending) { }
    virtual public void OnSetMaterialTextureFile(int bSuccess, string SceneName, string file) { }
    virtual public void OnSetMaterialTextureFilter(int bSuccess, string SceneName, eKTextureFilter TextureFilter) { }
    virtual public void OnSetMaterialTextureOffset(int bSuccess, string SceneName, float x, float y) { }
    virtual public void OnSetMaterialTextureOffsetKey(int bSuccess, string SceneName, int key, float x, float y) { }
    virtual public void OnSetMaterialTextureOpacity(int bSuccess, string SceneName, byte opacity) { }
    virtual public void OnSetMaterialTextureRotation(int bSuccess, string SceneName, float x) { }
    virtual public void OnSetMaterialTextureRotationKey(int bSuccess, string SceneName, int key, float x) { }
    virtual public void OnSetMaterialTextureTiling(int bSuccess, string SceneName, float x, float y) { }
    virtual public void OnSetMaterialTextureTilingKey(int bSuccess, string SceneName, int key, float x, float y) { }
    virtual public void OnSetMaterialTextureType(int bSuccess, string SceneName, eKTextureType TextureType) { }
    virtual public void OnSetMemo(int bSuccess, string SceneName, string s) { }
    virtual public void OnSetObjectEffectType(int bSuccess, string SceneName, int a, eKEffectType EffectType, int b) { }
    virtual public void OnSetShadowTextColor(int bSuccess, string SceneName, int beginpos, int count, int r, int g, int b, int a) { }
    virtual public void OnSetSpecularColor(int bSuccess, string SceneName, sKColor color) { }
    virtual public void OnSetSpecularColorKey(int bSuccess, string SceneName, int key, sKColor color) { }
    virtual public void OnSetSpecularSharpness(int bSuccess, string SceneName, float Sharpness) { }
    virtual public void OnSetStyleLibrary(int bSuccess, string SceneName, string style) { }
    virtual public void OnSetTableColor(int bSuccess, string SceneName, string s, int a, int b, sKColor color) { }
    virtual public void OnSetTableValue(int bSuccess, string SceneName, string s, int a, int b, string c) { }
    virtual public void OnSetTransparencyOpacity(int bSuccess, string SceneName, byte opacity) { }
    virtual public void OnSetTrialPlayMode(int bSuccess) { }
    virtual public void OnSetVideoPlayInfo(int bSuccess, string s, eKTextureTarget target, ref sKVideoPlayInfo VideoPlayInfo) { }


    virtual public void OnAdjustScrollSpeedByScenePlayer(int bSuccess, int LayerNo, int a, float SpeedDelda) { }
    virtual public void OnApplyLibrary(int bSuccess, string a, string b, string c, eKEffectTarget target) { }
    virtual public void OnClearNextPreview(int bSuccess, int a, int b) { }
    virtual public void OnCutIn(int bSuccess, int a, int b) { }
    virtual public void OnCutOut(int bSuccess, int a, int b) { }
    virtual public void OnEndTransactionOnChannel(int bSuccess, int a) { }
    virtual public void OnPause(int bSuccess, int a, int b) { }
    virtual public void OnPlay(int bSuccess, int a, int b) { }
    virtual public void OnPlayDirect(int bSuccess, string s, int a, int b) { }
    virtual public void OnPlayOut(int bSuccess, int a, int b) { }
    virtual public void OnPlayRange(int bSuccess, int a, int b, int c) { }
    virtual public void OnQueryIsOnAir(int bSuccess, int a, int b) { }

    virtual public void OnQueryPlaybackRange(int bSuccess, string s, int a, int b, int c) { }
    virtual public void OnQueryPlaybackRangeCount(int bSuccess, string s, int a) { }
    virtual public void OnQueryOutputChannelIndex(int bSuccess, string s, int a) { }
    virtual public void OnQueryTotalTime(int bSuccess, string s, int a, int b) { }
    virtual public void OnResumeBackground(int bSuccess, int a, int b) { }
    virtual public void OnSceneAnimationPlayed(int bSuccess, int a, int b) { }
    virtual public void OnResume(int bSuccess, int a, int b) { }
    virtual public void OnScenePaused(int bSuccess, int a, int b) { }
    virtual public void OnScenePlayed(int bSuccess, int a, int b) { }
    virtual public void OnScenePrepare(int bSuccess, string s, int a, int b) { }
    virtual public void OnScenePrepareEx(int bSuccess, string s, int a, int b) { }
    virtual public void OnSetOutputChannelIndex(int bSuccess, string s, int a) { }
    virtual public void OnSetScrollSpeedByScenePlayer(int bSuccess, int a, int b, float x) { }
    virtual public void OnSetVROffset(int bSuccess, string s, float x, float y) { }
    virtual public void OnStop(int bSuccess, int a, int b) { }
    virtual public void OnTrigger(int bSuccess, int a, int b, int c) { }
    virtual public void OnTriggerByName(int bSuccess, int a, int b, string s) { }



}

