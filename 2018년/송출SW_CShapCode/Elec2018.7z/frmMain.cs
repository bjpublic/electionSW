﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using TornadoAPI;
using Knn;

namespace Election
{
    public partial class frmMain : Form
    {
        #region //내부변수 선언부=================================
        // sub form용 변수
        private static frmCode FCodeForm;   //코드
        private static frmCand FCandForm;   //후보자
        private static frmPrec FPrecForm;   //선거구
        private static frmLog  FLogForm;    //로그
        private static frmPic  FPicForm;    //후보사진생성
        private static frmVote FVoteForm;   //투표율
        private static frmOpen FOpenForm;   //개표

        //큐시트 작성용 data table 변수
        OpenDataSet.Ele_MCompCodeDataTable dtElecCatgr;     //선거종류 콤보박스용
        OpenDataSet.Ele_MCompCodeDataTable dtCity;          //시도 콤보박스용
        OpenDataSet.Ele_MCompCodeDataTable dtLowBack;       //하단배경 콤보박스용
        OpenDataSet.Ele_MCompCodeDataTable dtScene;         //화면리스트 테이블용
        OpenDataSet.Ele_TPrecDataTable dtPrec;              //선거구 테이블용

        //토네이도 관련변수
        private TornadoElec2018 FCG;

        //화면송출 관련변수
        private bool FisOnAir = false;                      //On air상태여부
        private string FOldRowPrecID = "";                  //큐시트 이전행의 선거구코드
        private string FReadyAlias = "";                    //Ready한 화면코드
        private string FReadyElecCatgr = "";                //Ready한 선거구분코드
        private string FReadyCity = "";                     //Ready한 도시코드
        private string FReadyPrecID = "";                   //Ready한 선거구코드
        private string FInAlias = "";                       //In한 화면코드
        private string FInElecCatgr = "";                   //In한 선거구분코드
        private string FInCity = "";                        //In한 도시코드
        private string FInPrecID = "";                      //In한 선거구코드

        //프로그램 작동관련
        private bool FQsheetFlag = false;                   //큐시트 행변환에 따른 개표자료 조회 여부
        private bool FAutoLoopFlag = false;                 //자동 루프일경우, 루핑 순환 가능 여부
        //=========================================================
        #endregion

        public frmMain()
        {
            InitializeComponent();

            //각종 초기화
            Init();
        }

        #region //메뉴 아이템 클릭=========================================
        //메뉴 설정 선택시
        private void miMenuConf_Click(object sender, EventArgs e)
        {
            //설정화면 열기
            frmConf form = new frmConf();
            form.ShowDialog(this);
        }

        //메뉴 선거자료/코드관리 선택시
        private void miCode_Click(object sender, EventArgs e)
        {
            if (FCodeForm == null) FCodeForm = new frmCode();
            SubForm_Opening(FCodeForm);
        }

        //메뉴 선거자료/선거구관리 선택시
        private void miPrec_Click(object sender, EventArgs e)
        {
            if (FPrecForm == null) FPrecForm = new frmPrec();
            SubForm_Opening(FPrecForm);
        }

        //메뉴 선거자료/후보관리 선택시
        private void miCand_Click(object sender, EventArgs e)
        {
            if (FCandForm == null) FCandForm = new frmCand();
            SubForm_Opening(FCandForm);
        }

        //메뉴 임시자료/후보사진생성 선택시
        private void miMakePhoto_Click(object sender, EventArgs e)
        {
            if (FPicForm == null) FPicForm = new frmPic();
            SubForm_Opening(FPicForm);
        }

        //메뉴 임시자료/개표자료발생기 선택시
        private void miMakeOpenData_Click(object sender, EventArgs e)
        {
            if (FVoteForm == null) FVoteForm = new frmVote();
            SubForm_Opening(FVoteForm);
        }

        //메뉴 선거자료/개표자료관리 선택시
        private void miOpen_Click(object sender, EventArgs e)
        {
            if (FOpenForm == null) FOpenForm = new frmOpen();
            SubForm_Opening(FOpenForm);
        }

        //메인에서 서브폼 열때, 서브폼 클로징 콜백함수 설정위해
        private void SubForm_Opening(Form form)
        {
            form.FormClosing += new FormClosingEventHandler(SubForm_Closing);
            form.WindowState = FormWindowState.Normal;
            form.Show();
            form.BringToFront();
        }

        //각 서브폼이 닫힐때 호출되며, 해당 자신 폼변수를 초기화한다.
        private void SubForm_Closing(object sender, FormClosingEventArgs e)
        {
            if (sender.Equals(FCodeForm))
                FCodeForm = null;
            else if (sender.Equals(FPrecForm))
                FPrecForm = null;
            else if (sender.Equals(FCandForm))
                FCandForm = null;
            else if (sender.Equals(FPicForm))
                FPicForm = null;
            else if (sender.Equals(FVoteForm))
                FVoteForm = null;
            else if (sender.Equals(FOpenForm))
                FOpenForm = null;
        }
        //================================================================
        #endregion

        #region //각종 버튼 클릭============================================
        private void btnOnair_Click(object sender, EventArgs e)
        {
            if (!FisOnAir)
                CG_Connect();
            else
                CG_Disconnect();
        }
        private void btnReady_Click(object sender, EventArgs e)
        {
            DataRowView row = (DataRowView)bsQsheet.Current;
            bool result = true;
            string[] codes = row["Params"].ToString().Split('/');
            string[] names = row["CutName"].ToString().Split('/');
            string alias = row["CutCode"].ToString();
            string ctype = row["ScrType"].ToString().Substring(0,1);   //송출화면 타입(1번째 문자)
            Dictionary<string, string> vals = new Dictionary<string, string>();


            //각 화면에 대응하는 변수값 설정
            switch(alias)
            {
                case "100": result = Elec_VoteRate1(names, codes, ref vals); break;                 //역대투표율
                case "101": result = false; break;                                                             //선거구별투표율 - 미사용
                case "102": result = Elec_VoteRate2(names, codes, ref vals); break;                 //울산 역대투표율
                case "103": result = Elec_VoteRate3(names, codes, ref vals); break;                 //울산 시간대별투표율
                case "104": result = Elec_VoteRate4(names, codes, ref vals); break;                 //울산 역대 지선투표율

                case "105": result = BridgeMajor1(names, codes, ref vals); break;                   //브릿지 국회의원
                case "106": result = BridgeMajor2(names, codes, ref vals); break;                   //브릿지 시도지사
                case "107": result = BridgeMajor3(names, codes, ref vals); break;                   //브릿지 교육감
                case "108": result = BridgeMajor4(names, codes, ref vals); break;                   //브릿지 구군시장

                case "113": result = Elec_Photo5ManExit1(names, codes, ref vals); break;          //사진5인경쟁-출구조사판1
                case "114": result = Elec_Photo5ManExit1(names, codes, ref vals); break;          //사진5인경쟁-출구조사판2
                case "115": result = Elec_Photo5ManExit1(names, codes, ref vals); break;          //사진5인경쟁-출구조사판3

                case "200": result = false; break;                                                               //3인전후보(가로) - 미사용
                case "202": result = Elec_Mov2Man(names, codes, ref vals); break;                   //영상2인경쟁-광역- 미사용
                case "203": result = Elec_Mov5Man(names, codes, ref vals); break;                   //영상5인경쟁-광역- 미사용

                case "204": result = Elec_Photo2Man(names, codes, ref vals); break;                 //사진2인경쟁-광역
                case "205": result = Elec_Photo5Man(names, codes, ref vals); break;                 //사진5인경쟁-광역

                case "206": result = Elec_Edu2Man(names, codes, ref vals); break;                   //교육2인경쟁
                case "207": result = Elec_Edu5Man(names, codes, ref vals); break;                   //교육5인경쟁

                case "208": result = Elec_2Man(names, codes, ref vals); break;                       //SBS 2인경쟁                
                                    
                case "210": result = Elec_3ManAll(names, codes, ref vals); break;                    //3인 전후보-기초            
  
                case "213": result = Elec_3ManAllMask(names, codes, ref vals); break;              //3인 전후보-마스킹 

                case "217": result = Elec_3ManAllEdu(names, codes, ref vals); break;                //3인 전후보-교육감 

                case "220": result = Elec_2ManSejong(names, codes, ref vals); break;               //대전전용  2인경쟁  세종 
                case "221": result = Elec_3ManAllSejong(names, codes, ref vals); break;            //대전전용  3인 전후보-기초  세종    

                case "300": result = false;  break;                                                            //3인 선거구별 1위- 사용안함 
                case "310": result = Elec_4Man(names, codes, ref vals); break;                       //4인 선거구별1위-기초
                case "311": result = Elec_4ManDrone(names, codes, ref vals); break;               //NTEK 드론 4인선거구별1위

                case "320": result = Elec_MovWinner(names, codes, ref vals); break;                //영상당선-광역-사용안함


                case "325": result = BridgeMajorRibbon(names, codes, ref vals); break;            //리본당선 
                case "326": result = Elec_PhotoWinner(names, codes, ref vals); break;              //사진 당선-광역/국회/교육감/기초


                case "332": result = Elec_PhotoWinner(names, codes, ref vals); break;              //사진 당선2-광역

                case "333": result = Elec_CandManProfile(names, codes, ref vals); break;          //후보자프로필
                case "335": result = Elec_PhotoWinner(names, codes, ref vals); break;              //당선 오리지날 


                case "340": result = Elec_PhotoWinner(names, codes, ref vals); break;               //사진당선-교육
                case "350": result = Elec_PhotoWinner(names, codes, ref vals); break;               //사진당선-기초

                case "400":
                case "401":
                case "402":
                case "403":
                case "404": 
                case "405": case "406": case "407": case "408": case "409": 
                case "410": case "411": case "412": case "413": case "414":
                case "415": result = false; break;                                                               //정당우세지역- 사용안함 


                case "420": result = Elec_2ManDrone(names, codes, ref vals); break;                 //NTEK 드론 2인 경쟁 
                case "421": result = Elec_3ManAllDrone(names, codes, ref vals); break;              //NTEK 3인전후보-기초        
                case "422": result = Elec_2ManCloseFight(names, codes, ref vals); break;            //NTEK 접전 2인 경쟁 


                case "500": result = Elec_2Dan2Man(names, codes, ref vals); break;                  //2단 2인
                case "501": result = Elec_2Dan3ManAll(names, codes, ref vals); break;               //2단 3인 전후보

                case "503": result = Elec_Corner2ManAll(names, codes, ref vals); break;             //좌상단 2인 전후보                      사진2장 있음               
                case "504": result = Elec_Corner2Man(names, codes, ref vals); break;                //좌상단 2인 1,2위                         사진2장 있음      

                case "510": result = Elec_2Dan2ManEdu(names, codes, ref vals); break;               //2단2인 교육감 전용
                case "511": result = Elec_2Dan3ManAllEdu(names, codes, ref vals); break;            //2단3인 교육감 전후보

                case "512": result = Elec_Corner2ManAllEdu(names, codes, ref vals); break;          //좌상단 교육감 2인 전후보            사진2장 있음 
                case "513": result = Elec_Corner2ManEdu(names, codes, ref vals); break;             //좌상단 교육감 2인 1,2위              사진2장 있음 

                case "514": result = Elec_Corner2ManAllEdu1(names, codes, ref vals); break;         //좌상단 NTEK 교육감 득표율 전후보  사진없음
                case "515": result = Elec_Corner2ManAllEdu2(names, codes, ref vals); break;         //좌상단 NTEK 교육감 1인사진          사진1장 
              
                case "517": result = Elec_Corner2ManAllNtek1(names, codes, ref vals); break;        //좌상단 NTEK 득표율 2인 전후보      사진없음
                case "518": result = Elec_Corner2ManAllNtek2(names, codes, ref vals); break;        //좌상단 NTEK 1인사진                    사진1장 


                case "602": result = false; break;                                                  //3단2인 전후보- 사용안함 
                case "603": result = false; break;                                                  //3단2인 경쟁- 사용안함 
                case "604": result = false; break;                                                  //좌상단 전후보- 사용안함 
                case "605": result = false; break;                                                  //좌상단 경쟁- 사용안함 

                case "700": result = Elec_Photo2ManIronMan(names, codes, ref vals); break;                //아이언맨2인경쟁 
                case "701": result = Elec_Photo2ManCaptain(names, codes, ref vals); break;                 //캡틴아메리카2인경쟁 
                case "702": result = Elec_Photo4ManCaptain(names, codes, ref vals); break;                 //캡틴아메리카4인경쟁 

                case "900": result = Elec_TestCand(names, codes, ref vals); break;                  //후보자 점검

                default: result = false; break;
            }

            if (result)
            {
                FReadyAlias = alias;
                FReadyElecCatgr = codes[0];
                FReadyCity = codes[2];
                if (ctype == "A") //A타입 : 전후보 송출
                    FReadyPrecID = codes[3];
                else
                    FReadyPrecID = "";

                //송출전 첫화면 반복화면 설정
                switch (FReadyAlias)
                {
                    case "208": //기초 2인경쟁. 시도변화에 따른 화면 전환 처리
                        alias = (FInAlias != "208" || FInCity != FReadyCity) ? "20A" : "20B";
                        break;
                    case "210": //기초 3인 전후보. 선거구변화에 따른 화면 전환 처리
                        alias = (FInAlias != "210" || FInPrecID != FReadyPrecID) ? "211" : "212";
                        break;

                    case "213": //마스킹 전후보. 선거구변화에 따른 화면 전환 처리
                        alias = (FInAlias != "213" || FInPrecID != FReadyPrecID) ? "214" : "215";
                        break;

                    case "217": //aktmz교육감 전용 전후보. 선거구변화에 따른 화면 전환 처리
                        alias = (FInAlias != "217" || FInPrecID != FReadyPrecID) ? "218" : "219";
                        break;
/*
                    case "310": //4인 현재1위. 시도가 다르면 화면 전환
                        alias = (FInAlias != "310" || FInCity != FReadyCity) ? "311" : "312";
                        break;
*/ 
  
                    case "320": //당선 영상 광역. 선거종류 다르면 전환
                        alias = (FInAlias != "320") ? "321" : "322";
                        break;
/*
                    case "330": //당선 광역. 선거종류 다르면 전환
                        alias = (FInAlias != "330") ? "331" : "332";
                        break;
*/

                    case "340": //당선 교육. 선거종류 다르면 전환
                        alias = (FInAlias != "340") ? "341" : "342";
                        break;
                    case "350": //당선 기초. 선거종류 다르면 전환
                        alias = (FInAlias != "350") ? "351" : "352";
                        break;
                }

                //송출된 화면 Out Effect 설정
                switch (FInAlias)
                {
                    case "208": //기초 2인경쟁
                        vals["OutTrigger"] = (FReadyAlias != "208" || FInCity != FReadyCity) ? "OUT" : "ChangeOut";
                        break;
                    case "210": //기초 3인 전후보
                        vals["OutTrigger"] = (FReadyAlias != "210") ? "CutOut" : ((FInPrecID != FReadyPrecID) ? "OUT" : "ChangeOut");
                        break;
                    case "213": //기초 3인 전후보
                        vals["OutTrigger"] = (FReadyAlias != "213") ? "CutOut" : ((FInPrecID != FReadyPrecID) ? "OUT" : "ChangeOut");
                        break;
                    case "217": //교육감 
                        vals["OutTrigger"] = (FReadyAlias != "217") ? "CutOut" : ((FInPrecID != FReadyPrecID) ? "OUT" : "ChangeOut");
                        break;
/*
                    case "310": //4인 현재1위
                        vals["OutTrigger"] = (FReadyAlias != "310" || FInCity != FReadyCity) ? "OUT" : "ChangeOut";
                        break;

                    case "320": //광역 영상 당선
                        vals["OutTrigger"] = (FReadyAlias != "320") ? "CutOut" : "ChangeOut";
                        break;
*/
                    

                    case "340": //교육 사진 당선
                    case "350": //기초 사진 당선
                        vals["OutTrigger"] = (FReadyAlias != FInAlias || FInElecCatgr != FReadyElecCatgr) ? "CutOut" : "ChangeOut";
                        break;
                }
                bool isready = FCG.Ready(alias, vals);
                if (isready) FAutoLoopFlag = true;
                btnIn.Enabled = true;
                btnIn.Focus();
            }
            else
            {
                CG_OnLogMessage("[선거코더] 화면스킵 : 큐시트=" + row["CutName"].ToString());
                btnSkip_Click(btnSkip, null);
            }

        }
        private void btnSkip_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(bsQsheet.Position.ToString() + "//" + bsQsheet.Count.ToString());
            if (bsQsheet.Position < bsQsheet.Count - 1)
            {
                bsQsheet.MoveNext();
                btnReady_Click(btnReady, null);
            }else if(rbLoop.Checked)
            {
                bsQsheet.MoveFirst();
                if (FAutoLoopFlag)
                    btnReady_Click(btnReady, null);
                else
                    TimerStart();
            }else
            {
                rbInAuto.Checked = false;
                rbInMan.Checked = true;
            }
        }
        private void btnIn_Click(object sender, EventArgs e)
        {
            FCG.PlayIn();
            btnIn.Enabled = false;
            //In값 설정
            FInElecCatgr = FReadyElecCatgr;
            FInCity = FReadyCity;
            FInAlias = FReadyAlias;
            FInPrecID = FReadyPrecID;
            //자동 송출여부 확인
            if (rbInAuto.Checked)
                TimerStart();
            else
                tmAuto.Enabled = false;
            //다음 큐시트로 이동
            btnSkip_Click(btnSkip, null);
            //다음 큐시트 준비
            btnReady.Focus();
        }
        private void btnOut_Click(object sender, EventArgs e)
        {
            if(cbOut.SelectedIndex == 0 || cbOut.SelectedIndex == 1)
            {
                if (ModifierKeys.HasFlag(Keys.Control))
                {
                    if(cbOut.SelectedIndex == 1)
                        FCG.Stop(0);
                    else
                        FCG.StopAll();
                    btnIn.Enabled = false;
                }
                else
                {
                    btnBlank_Click(btnBlank, null);
                }
            }
            else
            {
                FCG.Stop(cbOut.SelectedIndex - 1);
            }
        }
        private void btnBlank_Click(object sender, EventArgs e)
        {
            string bgalias;
            switch(cbBG.SelectedIndex)
            {
                case 0: bgalias = "BG1"; break;
                case 1: bgalias = "BG2"; break;
                case 2: bgalias = "BG3"; break;
                case 3: bgalias = "BG4"; break;  //국회의원
                default: return;
            }
            FCG.Ready(bgalias, null);
            FCG.PlayIn();
        }
        private void btnQsheetSave_Click(object sender, EventArgs e)
        {
            //저장할 큐시트 파일명 선택
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "큐시트|*.qsh";
            sfd.Title = "큐시트 저장하기";
            sfd.ShowDialog();
            if (sfd.FileName == "") return;

            //스트링 빌더 생성
            StringBuilder sb = new StringBuilder();
            //컬럼헤드추가
            //모든 컬럼이름 추가시는 아래코드 유효, but 큐시트 Id컬럼은 저장하지 않음
            //IEnumerable<string> colNames = openDataSet.Ele_TQsheet.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
            //sb.AppendLine(string.Join(",", colNames));

            //각 행의 값을 ','구분된 문자열로 변환
            foreach (DataRow row in openDataSet.Ele_TQsheet)
            {
                IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                sb.AppendLine(string.Join(",", fields));
            }

            System.IO.File.WriteAllText(sfd.FileName, sb.ToString());
        }
        private void btnQsheetLoad_Click(object sender, EventArgs e)
        {
            //불러올 파일선택
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "큐시트|*.qsh";
            ofd.Title = "큐시트 불러오기";
            ofd.ShowDialog();
            if (ofd.FileName == "") return;

            //현재 표시된 큐시트 삭제후 저장
            Cursor.Current = Cursors.WaitCursor;
            dgvQsheet.SuspendLayout();
            while (bsQsheet.Count > 0)
                bsQsheet.RemoveCurrent();
            bsQsheet.EndEdit();
            taQsheet.Update(openDataSet.Ele_TQsheet);

            //파일저장된 큐시트를 DB로 저장
            TransferCSVToTable(openDataSet.Ele_TQsheet, ofd.FileName);
            taQsheet.Update(openDataSet.Ele_TQsheet);
            
            dgvQsheet.ResumeLayout();

            Cursor.Current = Cursors.Default;
        }
        private void btnQsheetDel_Click(object sender, EventArgs e)
        {
            //큐시트에 선택된행이 없으면
            if (bsQsheet.Count == 0) return;
            Cursor.Current = Cursors.WaitCursor;
            FQsheetFlag = true;
            dgvQsheet.SuspendLayout();
            //큐시트에서 선택된행 삭제;
            bsQsheet.RemoveCurrent();
            //행번호 재설정
            Qsheet_RowsRenumbering();
            dgvQsheet.ResumeLayout();
            FQsheetFlag = false;
            Cursor.Current = Cursors.Default;
        }
        private void btnQsheetDelAll_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            //현재 표시된 큐시트 삭제후 저장
            FQsheetFlag = true;
            dgvQsheet.SuspendLayout();
            while (bsQsheet.Count > 0)
                bsQsheet.RemoveCurrent();
            bsQsheet.EndEdit();
            taQsheet.Update(openDataSet.Ele_TQsheet);

            dgvQsheet.ResumeLayout();
            FQsheetFlag = true;
            Cursor.Current = Cursors.Default;
        }
        private void btnLog_Click(object sender, EventArgs e)
        {
            FLogForm.Show();
        }
        private void btnQone_Click(object sender, EventArgs e)
        {
            dgvQsheet.SuspendLayout();
            Scene_SetQsheet();
            Qsheet_RowsRenumbering();
            dgvQsheet.ResumeLayout();
        }
        private void btnQall_Click(object sender, EventArgs e)
        {
            DataRowView drvScene = (DataRowView)bsScene.Current;
            string cuttype;
            int cnt;

            try
            {
                cuttype = drvScene["Resv3"].ToString().Substring(1, 1);   //송출화면 타입(2번째 문자)
            }
            catch (Exception ex)
            {
                cuttype = ex.Message;
                return;
            }

            dgvQsheet.SuspendLayout();
            switch (cuttype)
            {
                case "A":       //시도 반복생성형
                    cnt = cbQcity.Items.Count;
                    for (int i = 0; i < cnt; i++ )
                    {
                        cbQcity.SelectedIndex = i;
                        Scene_SetQsheet();
                    }
                    break;
                case "B":       //선거구 반복생성형
                    cnt = bsPrec.Count;
                    for (int i = 0; i < cnt; i++ )
                    {
                        bsPrec.Position = i;
                        Scene_SetQsheet();
                    }
                    break;
                case "C":       //단독형
                    Scene_SetQsheet();
                    break;
            }
            Qsheet_RowsRenumbering();
            dgvQsheet.ResumeLayout();
        }
        //=============================================================
        #endregion

        #region //각종 콘트롤 이벤트 처리 함수======================
        private void panQbutton_Resize(object sender, EventArgs e)
        {
            btnQone.Height = panQbutton.ClientSize.Height / 2;
        }

        private void gbIn_EnabledChanged(object sender, EventArgs e)
        {
            if (gbIn.Enabled)
            {
                gbAuto.Enabled = rbInAuto.Checked;
            }
        }

        private void cbQElecCatgr_SelectedIndexChanged(object sender, EventArgs e)
        {
            Scene_Retrieve_PrecNScene();
        }

        private void cbQcity_SelectedIndexChanged(object sender, EventArgs e)
        {
            Scene_Retrieve_PrecNScene();
        }

        private void panOnairControll_EnabledChanged(object sender, EventArgs e)
        {
            if(panOnairControll.Enabled && bsQsheet.Count > 0)
            {
                btnReady.Enabled = true;
                btnSkip.Enabled = true;
                btnIn.Enabled = false;
                btnOut.Enabled = true;
            }
        }

        private void dgvQsheet_SelectionChanged(object sender, EventArgs e)
        {
            if (bsQsheet.Count == 0) return;

            //큐시트상의 화면중 선거구와 후보자의 개표현황이 필요한것은 해당 선거구 개표상황 표시
            DataRowView row = (DataRowView)bsQsheet.Current;
            string scrtype = row["ScrType"].ToString();
            string[] codes = row["Params"].ToString().Split('/');
            string[] names = row["CutName"].ToString().Split('/');
            switch(scrtype)
            {
                case "A":   //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
                case "C":   //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
                case "E":   //E타입 : Loop(선거종류 + 화면 + 시도 + 선거구 + 기호)
                    string eleccatgr = codes[0];
                    string precid = codes[3];
                    //if(precid != FOldRowPrecID)
                    //{
                        Qsheet_RetriveOpenStat(eleccatgr, precid);
                        FOldRowPrecID = precid;
                    //}
                    break;
                default:
                    //B타입 : 전선거구 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구순번)
                    //D타입 : 1시도 1송출화면 Once(선거종류 + 화면 + 시도)
                    break;
            }
        }
        private void frmMain_KeyDown(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.F1:       //Ready
                    btnReady_Click(btnReady, null);
                    break;
                case Keys.F2:
                case Keys.Space: 
                case Keys.Enter:    //In
                    if (btnIn.Enabled) btnIn_Click(btnIn, null); 
                    break;
                case Keys.F3:       //Out
                    if (btnOut.Enabled) btnOut_Click(btnOut, null);
                    break;
                case Keys.Escape:   //빈화면
                    if (btnBlank.Enabled) btnBlank_Click(btnBlank, null);
                    break;
            }
        }
        private void rbInAuto_CheckedChanged(object sender, EventArgs e)
        {
            gbAuto.Enabled = rbInAuto.Checked;
            if (!rbInAuto.Checked) tmAuto.Enabled = false;
        }
        private void tmAuto_Tick(object sender, EventArgs e)
        {
            if (FAutoLoopFlag)
                btnIn_Click(btnIn, null);
            else
                btnReady_Click(btnReady, null);
        }
        //==========================================================
        #endregion

        #region //각종 작동 함수===================================
        //글로벌 설정변경시 초기화
        private void Init()
        {
            //타이틀변경
            this.Text = Global.Title + " (Version " + Global.Version + ")";

            try
            {
                //큐시트 읽어오기
                this.taQsheet.Fill(this.openDataSet.Ele_TQsheet, Global.CompID, Global.SystemName);

                //큐시트 작성 - 선거종류 콤보박스 설정
                dtElecCatgr = taCompCode.GetData("010", Global.CompLikeString);
                cbQElecCatgr.DataSource = dtElecCatgr;

                //큐시트 작성 - 시도 콤보박스 설정
                dtCity = taCompCode.GetData("600", Global.CompLikeString);
                cbQcity.DataSource = dtCity;

                //메인 하단배경 - 배경 불투명도 콤보박스 설정
                dtLowBack = taCompCode.GetDataByCatgr("810");
                cbLowBack.DataSource = dtLowBack;

                //로그윈도 생성
                FLogForm = new frmLog();

                //토네이도 관련 초기화
                FCG = new TornadoElec2018();
                FCG.OnLogMessage += CG_OnLogMessage;
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

            //배경화면 선택 초기화
            cbBG.SelectedIndex = 0;
            //아웃 카테고리
            cbOut.SelectedIndex = 0;
            //각종 변수 초기화
            FOldRowPrecID = "";
        }
        private static void TransferCSVToTable(DataTable dt, string filePath)
        {
            dt.Clear();

            string[] csvRows = System.IO.File.ReadAllLines(filePath);
            string[] fields = null;
            foreach (string csvRow in csvRows)
            {
                fields = csvRow.Split(',');
                DataRow row = dt.NewRow();
                row.ItemArray = fields;
                dt.Rows.Add(row);
            }
        }
        private void Qsheet_RowsRenumbering()
        {
            foreach (DataGridViewRow row in dgvQsheet.Rows)
            {
                dgvQsheet.Rows[row.Index].Cells["Seq"].Value = (row.Index + 1);
            }
            bsQsheet.EndEdit();
            taQsheet.Update(openDataSet.Ele_TQsheet);

                        
                    }
        //우측 개표현황 조회함수
        private void Qsheet_RetriveOpenStat(string eleccatgr, string precid)
        {
            taPrecSBS.Fill(openDataSet.Ele_TPrecSBS, eleccatgr, precid);
            taCandSBS.Fill(openDataSet.Ele_TCandSBS, eleccatgr, precid);
        }
        //화면작성 - 선거구 조회 함수
        private void Scene_Retrieve_PrecNScene()
        {
            string elec, city, eleclikestr;
            int iElec;

            try
            {
                elec = cbQElecCatgr.SelectedValue.ToString().Trim();
                city = cbQcity.SelectedValue.ToString().Trim();

            }
            catch (Exception e)
            {
                elec = e.Message;
                return;    
            }

            if (elec == null || city == null || elec == "" || city == "") return;
            iElec = Convert.ToInt32(elec.Trim());
            eleclikestr = "";
            for (int i = 0; i < 10; i++ )
            {
                if (iElec == i)
                    eleclikestr += "Y";
                else
                    eleclikestr += "_";
            }
            dtPrec = taPrec.GetData(elec, city);
            bsPrec.DataSource = dtPrec;
            dtScene = taCompCode.GetDataByElec("800", Global.CompLikeString, eleclikestr);
            bsScene.DataSource = dtScene;
        }
        private void Scene_SetQsheet()
        {
            int iCnt = 0;
            int iScrCnt = 0;
            DataRow row;

            //선거구가 없을 경우, 스킵(세종 기초단체장)
            if (bsPrec.Count == 0) return;
            //큐시트에 추가할 선거구, 화면명 Row
            DataRowView drvPrec = (DataRowView)bsPrec.Current;
            DataRowView drvScene = (DataRowView)bsScene.Current;
            //큐시트에 추가할 값들
            string eleccatgr = cbQElecCatgr.SelectedValue.ToString();       //선거종류코드
            string elecname = cbQElecCatgr.Text;                            //선거종류명
            string citycode = cbQcity.SelectedValue.ToString();             //시도코드
            string cityname = cbQcity.Text;                                 //시도명
            string precid = drvPrec["PrecID"].ToString();                   //선거구코드
            string precname = drvPrec["PrecName"].ToString();               //선거구명
            string scrcode = drvScene["Code"].ToString();                   //송출화면코드
            string scrname = drvScene["ADesc"].ToString();                  //송출화면명
            string cuttype = drvScene["Resv3"].ToString().Substring(0,1);   //송출화면 타입(1번째 문자)
            int iObjCnt = Convert.ToInt32(drvScene["Resv4"].ToString());    //전후보,전선거구 송출화면의 화면당 개체표시수


            switch (cuttype)
            {
                //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
                case "A":
                    iCnt = (int)drvPrec["CandCnt"];     //후보자수
                    iScrCnt = (int)Math.Ceiling((double)iCnt / (double)iObjCnt);        //송출화면수
                    for (int i = 0; i < iScrCnt; i++)
                    {
                        row = openDataSet.Ele_TQsheet.NewRow();
                        row["SysName"] = Global.SystemName;
                        row["Catgr"] = Global.CompID;
                        row["Seq"] = 0;
                        row["CutCode"] = scrcode;
                        row["CutName"] = elecname + "/" + scrname + "/" + cityname + "/" + precname + "/" + (i * iObjCnt + 1).ToString();
                        row["Params"] = eleccatgr + "/" + scrcode + "/" + citycode + "/" + precid + "/" + (i * iObjCnt + 1).ToString();
                        row["ScrType"] = cuttype;
                        openDataSet.Ele_TQsheet.Rows.InsertAt(row, bsQsheet.Position + 1);
                        bsQsheet.Position += 1;
                    }
                    break;

                //B타입 : 전선거구 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구순번)
                case "B":
                    iCnt = bsPrec.Count;        //선거구수
                    iScrCnt = (int)Math.Ceiling((double)iCnt / (double)iObjCnt);    //송출화면수
                    for (int i = 0; i < iScrCnt; i++)
                    {
                        row = openDataSet.Ele_TQsheet.NewRow();
                        row["SysName"] = Global.SystemName;
                        row["Catgr"] = Global.CompID;
                        row["Seq"] = 0;
                        row["CutCode"] = scrcode;
                        row["CutName"] = elecname + "/" + scrname + "/" + cityname + "/" + (i * iObjCnt + 1).ToString();
                        row["Params"] = eleccatgr + "/" + scrcode + "/" + citycode + "/" + (i * iObjCnt + 1).ToString();
                        row["ScrType"] = cuttype;
                        openDataSet.Ele_TQsheet.Rows.InsertAt(row, bsQsheet.Position + 1);
                        bsQsheet.Position += 1;
                    }
                    break;

                //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
                case "C":
                    row = openDataSet.Ele_TQsheet.NewRow();
                    row["SysName"] = Global.SystemName;
                    row["Catgr"] = Global.CompID;
                    row["Seq"] = 0;
                    row["CutCode"] = scrcode;
                    row["CutName"] = elecname + "/" + scrname + "/" + cityname + "/" + precname;
                    row["Params"] = eleccatgr + "/" + scrcode + "/" + citycode + "/" + precid;
                    row["ScrType"] = cuttype;
                    openDataSet.Ele_TQsheet.Rows.InsertAt(row, bsQsheet.Position + 1);
                    bsQsheet.Position += 1;
                    break;
                //D타입 : 1시도 1송출화면 Once(선거종류 + 화면 + 시도)
                case "D":
                    row = openDataSet.Ele_TQsheet.NewRow();
                    row["SysName"] = Global.SystemName;
                    row["Catgr"] = Global.CompID;
                    row["Seq"] = 0;
                    row["CutCode"] = scrcode;
                    row["CutName"] = elecname + "/" + scrname + "/" + cityname;
                    row["Params"] = eleccatgr + "/" + scrcode + "/" + citycode;
                    row["ScrType"] = cuttype;
                    openDataSet.Ele_TQsheet.Rows.InsertAt(row, bsQsheet.Position + 1);
                    bsQsheet.Position += 1;
                    break;
                //E타입 : Loop(선거종류 + 화면 + 시도 + 선거구 + 기호)
                case "E":
                    iCnt = (int)drvPrec["CandCnt"];     //후보자수
                    string ordno = "";
                    for (int i = 0; i < iCnt; i++ )
                    {
                        ordno = taQueries.GetNextOrdNo(eleccatgr, precid, ordno);
                        row = openDataSet.Ele_TQsheet.NewRow();
                        row["SysName"] = Global.SystemName;
                        row["Catgr"] = Global.CompID;
                        row["Seq"] = 0;
                        row["CutCode"] = scrcode;
                        row["CutName"] = elecname + "/" + scrname + "/" + cityname + "/" + precname + "/" + ordno;
                        row["Params"] = eleccatgr + "/" + scrcode + "/" + citycode + "/" + precid + "/" + ordno;
                        row["ScrType"] = cuttype;
                        openDataSet.Ele_TQsheet.Rows.InsertAt(row, bsQsheet.Position + 1);
                        bsQsheet.Position += 1;
                    }
                    break;
            }

        }
        private int Scene_GetSceneCount(string scrcode)
        {
            int scnt = 0;

            return scnt;
        }
        private string getElecGbnPath(string elecgbn, string type)
        {
            string path = Global.TornadoScenePath + "Data\\당선\\";
            elecgbn = elecgbn.Trim();
            switch(elecgbn)
            {
                case "40": path += "유력"; break;
                case "50": path += "확실"; break;
                case "60": 
                case "80":
                case "90": path += "당선"; break;
                default: return "";
            }
            
            switch(type)
            {
                case "A": path += "A.vrv"; break;
                case "B": path += "B.png"; break;
                case "C": path += "C.png"; break;
                case "D": path += ".vrv"; break;
                default: return "";
            }
            return path;
        }
        private string getOpenRate(string openrate)
        {
            openrate = openrate.Trim();
            if (openrate == "100.0")
                openrate = "개표완료";
            else
                openrate = "개표 : " + openrate + "%";

            return openrate;
        }
        private string getPartyPath(string partycode, string type)
        {
            string path = Global.TornadoScenePath + "Data\\정당\\";
            partycode = partycode.Trim();
            switch(partycode)
            {
                case "01":
                case "02":
                case "03":
                case "04":
                case "05":
                case "06":
                case "07":
                case "08":
                case "09":
                case "10":
                case "11":
                case "12":
                case "13":
                case "14":
                case "15":
                case "16":
                case "17":
                case "18":
                case "29":
                case "32":
                case "97":
                case "98":
                    path += partycode;
                    break;
                default:        //기타 및 교육
                    path += "99";
                    break;
            }

            path += type;
            switch (type.Substring(0,1))
            {
                case "L": 
                  path += "LB.vrv"; break;
                case "W":
                    path += "LB.vrv"; break;
                default: 
                   path += ".png"; break;
            }

            return path;
        }
        private string getPhotoPath(string elecctgr,  string precid, string ordno, string type)
        {
            //A타입 : 광역단체 큰 사진
            //B타입 : 기초/광역/ 작은사진
            //E타입 : 교육감 큰사진 
            //F타입 : 교육감 작은사진 
            // G타입   캡틴아메리카 
            // H타입  아이언맨  


            string path = Global.TornadoScenePath + "Data\\후보\\";
            path += elecctgr.Trim() + "_"+ precid.Trim() + "_" + ordno.Trim();
            //사진명명법이 프로그램 타입과 조금 다름(동영상=A,큰사진=A,작은사진=B)
            //동영상과 큰사진은 확장자만 다름
            switch (type.Substring(0, 1))
            {
                case "A": path += "A.png"; break;
                case "B": path += "B.png"; break;
                case "E": path += "E.png"; break;
                case "F": path += "F.png"; break;
                case "G": path += "G.png"; break;
                case "H": path += "H.png"; break;
                /*
                                case "C":
                                    try
                                    {
                                        //해당 선거구의 시도코드를 구해서
                                        string city = precid.Substring(2, 2);
                                        //해당 시도의 사용동영상 타입을 구한다
                                        OpenDataSet.Ele_MCompCodeDataTable dtMov = taCompCode.GetMovieTypes(city);
                                        path += dtMov.Rows[0]["Resv" + type.Substring(1, 1)].ToString() + ".vrv";
                                    }
                                    catch (Exception ex)
                                    {
                                        CG_OnLogMessage("### getPhotoPath 오류 : " + ex.Message);
                                        return "";
                                    }
                                    break;
                */

                default: return "";
            }
            return path;
        }


        private string getPhotoPathProfile(string elecctgr, string precid, string ordno, string type, string sNo)
        {
         
            string path = Global.TornadoScenePath + "Data\\후보\\사진첩\\";
            path = path + elecctgr.Trim() + "_" + precid.Trim() + "_" + ordno.Trim();

            switch (type.Substring(0, 1))
            {
                case "A": path += "A"; break;
                case "B": path += "B"; break;
                case "E": path += "E"; break;
                case "F": path += "F"; break;            

                default: path += "A"; break;
            }

            path = path + "_" + sNo.Trim() + ".png";

            return path;
        }


        private string getPhotoPathIronMan(string jdcode, string type  )
        {

            string path = Global.TornadoScenePath + "Data\\기타\\아이언\\";
            path = path + jdcode.Trim() + type.Trim() + ".png";

            return path;
        }



        private string getETCPeopleSelectionPath(string sggname )
        {
            //국민의선택 파일 위치  
     
            string path = Global.TornadoScenePath + "Data\\기타\\국민의선택\\";
           // path +=  cityid.Trim()              

            switch (sggname.Trim())
            {
                case "부산":   path += "당선_상단2.png"; break;
                case "대구":   path += "당선_상단2_대구경북.png"; break;
                case "광주":   path += "당선_상단2_광주전남.png"; break;
                case "대전":   path += "당선_상단2_대전충남.png"; break;
                case "울산":   path += "당선_상단2_울산.png";     break;
                case "강원":   path += "당선_상단2_강원.png";     break;
                case "충남":   path += "당선_상단2_대전충남.png"; break;
                case "전남":   path += "당선_상단2_광주전남.png"; break;
                case "경북":   path += "당선_상단2_대구경북.png"; break;
                case "경남":   path += "당선_상단2_부산경남.png"; break;
                case "세종":   path += "당선_상단2_세종.png";     break;
/*
                case "C":
                    try
                    {
                        //해당 선거구의 시도코드를 구해서
                        string city = precid.Substring(2, 2);
                        //해당 시도의 사용동영상 타입을 구한다
                        OpenDataSet.Ele_MCompCodeDataTable dtMov = taCompCode.GetMovieTypes(city);
                        path += dtMov.Rows[0]["Resv" + type.Substring(1, 1)].ToString() + ".vrv";
                    }
                    catch (Exception ex)
                    {
                        CG_OnLogMessage("### getETCPeopleSelectionPath 오류 : " + ex.Message);
                        return "";
                    }
                    break;
*/
                default: path += "당선_상단2.png"; break;  //국민의선택 
            }
            return path;
        }



        

        private string getCityPhotoPath(string sggname )
        {

            string path = Global.TornadoScenePath + "Data\\배경\\";

            switch (sggname.Trim())
            {
                case "대전": path += "대전.png"; break;
                case "울산": path += "울산.png"; break;
                case "부산": path += "부산.png"; break;
                case "대구": path += "대구.png"; break;
                case "광주": path += "광주.png"; break;
                case "강원": path += "강원.png"; break;
                case "충남": path += "충남.png"; break;
                case "전남": path += "전남.png"; break;
                case "경북": path += "경북.png"; break;
                case "경남": path += "경남.png"; break;
                case "세종": path += "세종.png"; break;


                default: path += "울산.png"; break;  //시티 
            }
            return path;
        }


        private string getCityDroneMoviePath(string sggname)
        {

            string path = Global.TornadoScenePath + "Data\\배경\\";

            switch (sggname.Trim())
            {
                case "대전": path += "대전.vrv"; break;
                case "울산": path += "울산.vrv"; break;
                case "부산": path += "부산.vrv"; break;
                case "대구": path += "대구.vrv"; break;
                case "광주": path += "광주.vrv"; break;
                case "강원": path += "강원.vrv"; break;
                case "충남": path += "충남.vrv"; break;
                case "전남": path += "전남.vrv"; break;
                case "경북": path += "경북.vrv"; break;
                case "경남": path += "경남.vrv"; break;
                case "세종": path += "세종.vrv"; break;


                default: path += "울산.png"; break;  //시티 
            }
            return path;
        }



        private string getDroneCityNamePath(string PrecName)
        {

            string path = Global.TornadoScenePath + "Data\\배경\\";

            switch (PrecName.Trim())
            {
                              default: path += PrecName.Trim() + ".vrv";  break;  // "울산 중구.vrv" 
            }
            return path;
        }






        private string getLowBack()
        {
            string path = Global.TornadoScenePath + "Data\\하단바\\";
            string file = cbLowBack.SelectedValue.ToString();

            if (file == "") return "";
            return path + file;
        }
        private void TimerStart()
        {
            tmAuto.Interval = int.Parse(tbTimer.Text) * 1000;
            tmAuto.Enabled = true;
        }
        #endregion

        #region //토네이도 관련 함수==================================
        private void CG_Connect()
        {
            FCG.Connect(true, Global.TornadoIP, Global.TornadoPort);
        }
        private void CG_Connected()
        {
            btnOnair.Text = "OFF";
            lbOnair.Text = "ON AIR";
            lbOnair.BackColor = Color.Red;
            lbOnair.ForeColor = Color.Yellow;

            //송출제어 버튼
            if (bsQsheet.Count > 0)
            {
                panQControll.Enabled = false;
                panOnairControll.Enabled = true;
                panOnairOption.Enabled = true;
            }
            CG_LoadScene();
            CG_LoadPartyInfo();
            FisOnAir = true;
            FReadyAlias = "";
            FReadyCity = "";
            FReadyElecCatgr = "";
            FReadyPrecID = "";
            FInAlias = "";
            FInCity = "";
            FInElecCatgr = "";
            FInPrecID = "";
            FAutoLoopFlag = false;
        }
        private void CG_Disconnect()
        {
            rbInAuto.Checked = false;
            rbInMan.Checked = true;
            FCG.Disconnect();
            btnOnair.Text = "ON";
            lbOnair.Text = "READY";
            lbOnair.BackColor = Color.Green;
            lbOnair.ForeColor = Color.Black;

            panQControll.Enabled = true;
            panOnairControll.Enabled = false;
            panOnairOption.Enabled = false;
            FisOnAir = false;
        }
        private void CG_LoadScene()
        {
            string filename, alias;

            OpenDataSet.Ele_MCompCodeDataTable dtCut;
            dtCut = taCompCode.GetData("800", Global.CompLikeString);
            for(int i=0; i<dtCut.Count; i++)
            {
                filename = dtCut.Rows[i]["BDesc"].ToString();
                if(filename != "")
                {
                    filename = Global.TornadoScenePath + filename;
                    alias = dtCut.Rows[i]["Code"].ToString();
                    FCG.RegisterScene(alias, filename);
                }
            }
        }
        private void CG_LoadPartyInfo()
        {
            //정당색 정보를 CG에 미리 등록함
            DataTable dt = taCompCode.GetDataByCatgr("100");
            foreach(DataRow row in dt.Rows)
            {
                FCG.AddParty(row["Code"].ToString(), row["Resv2"].ToString(), row["Resv3"].ToString(), row["Resv4"].ToString());
            }
        }
        private void CG_StopAll()
        {
            //tnPlayer.StopAll();
        }
        private void CG_OnLogMessage(string msg)
        {
            if(msg == "[SUCCESS] Hello") CG_Connected();
            FLogForm.LogMessage(msg);
        }
        private void Tornado_Scene_PastVoteRate(string namepack, string codepack)
        {
        }
        private void dgvQsheet_KeyDown(object sender, KeyEventArgs e)
        {

        }
        private void Etc_ConvTxtEventHandler()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "텍스트|*.txt";
            ofd.Title = "텍스트 불러오기";
            ofd.ShowDialog();
            if (ofd.FileName == "") return;

            string[] csvRows = System.IO.File.ReadAllLines(ofd.FileName);
            string str, fname;
            StringBuilder sb = new StringBuilder();

            foreach (string row in csvRows)
            {
                str = row.Substring(row.IndexOf('(') + 1);
                str = str.Substring(0, str.IndexOf(')'));
                fname = row.Substring(23);
                fname = "Do" + fname.Substring(0, fname.IndexOf('('));

                string[] cols = str.Split(',');
                for (int i = 0; i < cols.Length; i++)
                {
                    cols[i] = cols[i].Trim();
                    cols[i] = cols[i].Substring(cols[i].IndexOf(' ') + 1);
                }
                str = row + " { owner." + fname + "(" + string.Join(",", cols) + "); }";
                sb.AppendLine(str);
            }
            System.IO.File.WriteAllText(ofd.FileName + "1", sb.ToString());
        }
        #endregion

        #region //선거방송 송출용 데이터 처리 함수=====================
        private bool Elec_VoteRate1(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //역대투표율
            //파라미터 : 선거종류 + 화면 + 시도
            //출력 : 시도 + 4 * (선거명n + 투표율n)

            try
            {

                //시도별 현재 투표율설정(ele_tcode 시도코드에 현재투표율 설정)
               // taQueries.UpdateVoteRate();

                //해당 시도의 투표율을 가져온다
                OpenDataSet.Ele_MCompCodeDataTable dtRate = taCompCode.GetVoteRate(codes[2]);
                //선거명을 구한다
                string[] votes = dtRate.Rows[0]["BDesc"].ToString().Split('/');

                //출력변수에 할당(시도명 + 선거명1 + 투표율1 + ... + 선거명4 + 투표율4)
                vals["시도"]     = names[2];
                vals["선거명1"] = votes[0];
                vals["투표율1"] = dtRate.Rows[0]["Resv2"].ToString();
                vals["선거명2"] = votes[1];
                vals["투표율2"] = dtRate.Rows[0]["Resv3"].ToString();
                vals["선거명3"] = votes[2];
                vals["투표율3"] = dtRate.Rows[0]["Resv4"].ToString();
                vals["선거명4"] = votes[3];
                vals["투표율4"] = dtRate.Rows[0]["Resv5"].ToString();
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_VoteRate1 오류 : " + ex.Message);
                return false;
            }
            return true;
        }


        private bool Elec_VoteRate2(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //울산 드론방식 역대투표율
            //파라메터 : 선거종류 + 화면 + 시도
            //출력 : 시도 + 4 * (선거명n + 투표율n)

            try
            {
                //시도별 현재 투표율설정(ele_tcode 시도코드에 현재투표율 설정)

                //해당 시도의 투표율을 가져온다
                OpenDataSet.Ele_MCompCodeDataTable dtRate = taCompCode.GetVoteRate(codes[2]);
                //선거명을 구한다
                string[] votes = dtRate.Rows[0]["BDesc"].ToString().Split('/');

                //출력변수에 할당(시도명 + 선거명1 + 투표율1 + ... + 선거명4 + 투표율4)
                vals["시도"] = names[2];
                vals["선거명1"] = votes[0];
                vals["투표율1"] = dtRate.Rows[0]["Resv2"].ToString();
                vals["선거명2"] = votes[1];
                vals["투표율2"] = dtRate.Rows[0]["Resv3"].ToString();
                vals["선거명3"] = votes[2];
                vals["투표율3"] = dtRate.Rows[0]["Resv4"].ToString();
                vals["선거명4"] = votes[3];
                vals["투표율4"] = dtRate.Rows[0]["Resv5"].ToString();
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_VoteRate1 오류 : " + ex.Message);
                return false;
            }
            return true;
        }

        private bool Elec_VoteRate3(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //울산 드론방식 수동 시간대별 투표율
            return true;
        }


        private bool Elec_VoteRate4(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //울산 드론방식 역대 지선투표율 태화루
             return true;
        }



        private bool BridgeMajor1(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //브릿지 국회의원: 울산 

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함


                vals["선거코드"] = codes[0].Trim();
                vals["시도"] = names[2];  //울산      

                vals["국민의선택"] = getETCPeopleSelectionPath(names[2]);
                vals["직책"] = "국회의원";



            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### BridgeMajor1 오류 : " + ex.Message);
                return false;
            }


            return true;

        }

        private bool BridgeMajor2(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //브릿지 시도지사
            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
           

                vals["선거코드"] = codes[0].Trim();
                vals["시도"] = names[2];  //울산 

                vals["국민의선택"] = getETCPeopleSelectionPath(names[2]);
                vals["직책"] = "시도지사";



            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### BridgeMajor2 오류 : " + ex.Message);
                return false;
            }


            return true;

        }


        private bool BridgeMajor3(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //브릿지 교육감: 울산 

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
             

                vals["선거코드"] = codes[0].Trim();
                vals["시도"] = names[2];  //울산 
                vals["국민의선택"] = getETCPeopleSelectionPath(names[2]);
                vals["직책"] = "교육감";



            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### BridgeMajor 오류 : " + ex.Message);
                return false;
            }


            return true;

        }


        private bool BridgeMajor4(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //브릿지 시도지사: 울산 

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
             

                vals["선거코드"] = codes[0].Trim();
                vals["시도"] = names[2];  //울산 

                vals["국민의선택"] = getETCPeopleSelectionPath(names[2]);
                vals["직책"] = "기초단체장";



            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### BridgeMajor 오류 : " + ex.Message);
                return false;
            }


            return true;

        }

        private bool BridgeMajorRibbon(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //브릿지 리본당선
            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함


                vals["선거코드"] = codes[0].Trim();

            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### BridgeMajorRibbon 오류 : " + ex.Message);
                return false;
            }


            return true;

        }


        private bool Elec_Photo2Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //사진 2인경쟁 - 광역단체장, 국회의원 
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An)

          try
            { 
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;

                // names[2] =울산 
                // vals["직책"] = names[2] + row["PrecName"].ToString();


                if (codes[0].Trim() == "01"  && names[2].Trim() == "울산" )
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }
                  



                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;
                //string type = "";
                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                   
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["정당" + i.ToString()] = row["PartyName"].ToString();

                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "L");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");


                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());

                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Photo2Man 오류 : " + ex.Message);
                return false;
            }


            return true; 

        }

        private bool Elec_Photo5Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //광역/국회 5인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 사진 + 5 * (성명n + 득표수n + 투표율n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                } else 
                    vals["직책"] = row["PrecName"].ToString();

                
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                for (int i = 1; i <= 5; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    //후보자수가 5인보다 적을경우
                     if (bsCandSBS.Count < i) break;

                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();


                    //1위 상세정보 지정
                    if (i == 1)
                    {
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                        vals["사진톤" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");

                        vals["정당바" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "L");
                        vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    }
                    else
                    {
                        vals["정당바" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "UB");
                    }
                    
                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_photo5Man 오류 : " + ex.Message);
                return false;
            }

            return true;

        }//



        private bool Elec_Edu2Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //교육감 2인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 표차 + 2 * (사진n + 성명n + 득표수n + 투표율n)

            try
            { 
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;

                //vals["직책"] = names[2] + row["JobName"].ToString();

                vals["직책"] = row["PrecName"].ToString(); 
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;
                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = "97";
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                    vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");
                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "W");

                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());
                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Edu2Man 오류 : " + ex.Message);
                return false;
            }
            return true;
        }

        private bool Elec_Edu5Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //교육감 5인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 사진 + 5 * (성명n + 득표수n + 투표율n)

            try
            { 
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;

                // vals["직책"] = names[2] + row["JobName"].ToString();

                vals["직책"] = row["PrecName"].ToString(); 
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                for (int i = 1; i <= 5; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;

                    //후보자수가 5인보다 적을경우
                    if (bsCandSBS.Count < i) break;

                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = "97";

                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();


                    //1위 상세정보 지정
                    if (i == 1)
                    {
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                        vals["사진톤" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                        vals["정당바" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "W");

                        vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");


                    }
                    else
                    {
                       // vals["정당바" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "UB");
                    }


                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Edu5Man 오류 : " + ex.Message);
                return false;
            }

            return true;
        }
        private bool Elec_2Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //SBS 2인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn + 정당코드n)

            try
            { 
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                } else
                    vals["직책"] = row["PrecName"].ToString();



                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                
                int votecnt1 = 0;
                int votecnt2 = 0;

                // string type = "";

                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();


                    if (codes[0].Trim() == "03") //교육감
                    {
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");

                    } else
                    {
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    }
                                    

                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "QB" );                      
                    vals["정당B" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "QB" );
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());
                    bsCandSBS.MoveNext();
                }//for 

                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_2Man 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//


        private bool Elec_2ManSejong(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //대전전용 대전세종  2인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn + 정당코드n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                    vals["직책"] = row["PrecName"].ToString();



                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");
                vals["백그림"] = getCityPhotoPath(names[2].Trim());

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();

                int votecnt1 = 0;
                int votecnt2 = 0;

                // string type = "";

                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();


                    if (codes[0].Trim() == "03") //교육감
                    {
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");

                    }
                    else
                    {
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    }


                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "QB");
                    vals["정당B" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "QB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());
                    bsCandSBS.MoveNext();
                }//for 

                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_2Man 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//



        private bool Elec_2ManDrone(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //NTEK 2인경쟁 드론 
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn + 정당코드n)


            vals["시도"] = names[2];

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;

                
                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")   //북구국회의원만  선거구명 + 국회의원 
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원" ;
                }
                else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }

                
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");
                vals["백그림"] = getDroneCityNamePath(row["PrecName"].ToString());


                //백그림이 있는지 체크해서 없으면 울산.vrv로 대체 
                if (Convert.ToString(System.IO.File.Exists(vals["백그림"])) == "False")
                {
                    vals["백그림"] = getCityDroneMoviePath(vals["시도"].Trim()) ;
                }


                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();

                int votecnt1 = 0;
                int votecnt2 = 0;
               

                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();

                    if (codes[0].Trim() == "03") { // 교육감 
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");

                    } else
                    {
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    }

                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "NB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SC");

                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());

                    bsCandSBS.MoveNext();
                }//for end

                vals["표차"] = Convert.ToInt32(votecnt1 - votecnt2).ToString();
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_2ManDrone  오류 : " + ex.Message);
                return false;
            }

            return true;
        } //

        private bool Elec_2ManCloseFight(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //NTEK 2인경쟁 접전표출  
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn + 정당코드n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;



                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")   //북구국회의원
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else {
                    vals["직책"] = row["PrecName"].ToString();
                }


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"]   = getElecGbnPath(row["ElecGbn"].ToString(), "D");
                vals["백그림"] = getCityPhotoPath(names[2].Trim());

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();

                int votecnt1 = 0;
                int votecnt2 = 0;
             //   int count = 0;


                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;

                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "NB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SC");

                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());

                    bsCandSBS.MoveNext();
                }//for 

                vals["표차"] = Convert.ToInt32(votecnt1 - votecnt2).ToString();
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_2ManCloseFight  오류 : " + ex.Message);
                return false;
            }

            return true;
        } //


        private bool Elec_3ManAll(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //SBS  3인 전후보
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try 
            { 
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")   //북구국회의원
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                } else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;

                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 3; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = "97";

                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //작은 사진
                    vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //작은 사진
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");
                        
                    
                    //인물뒤 3가지 뒷백판 순위따라서 값 세팅 
 
                       switch (i) 
                       {
                           case 1: 
                                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "Back");
                                    break;
                           case 2: 
                                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "BackC");
                                    break;
                           case 3: 
                                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "Back");
                                    break;
                           default:           
                                    break;     
                      }

                    bsCandSBS.MoveNext();
                } //for
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_3ManAll 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//


        private bool Elec_3ManAllSejong(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //대전전용 세종  3인 전후보
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")   //북구국회의원
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["백그림"] = getCityPhotoPath(names[2].Trim());


                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;

                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 3; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = "97";

                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //작은 사진
                    vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //작은 사진
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");


                    //인물뒤 3가지 뒷백판 순위따라서 값 세팅 

                    switch (i)
                    {
                        case 1:
                            vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "Back");
                            break;
                        case 2:
                            vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "BackC");
                            break;
                        case 3:
                            vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "Back");
                            break;
                        default:
                            break;
                    }

                    bsCandSBS.MoveNext();
                } //for
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_3ManAll 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//



        private bool Elec_3ManAllMask(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //마스킹  3인 전후보
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["선거코드"] = codes[0].Trim();
                vals["시도"] = names[2];

                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")   //북구국회의원
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                } else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;

                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 3; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;

                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위


                    if (codes[0].Trim() == "03") //교육감만 
                    {
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");   //큰 사진
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");   //큰 사진
                        vals["사진톤" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");   //큰 사진
                    }

                    else {

                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //큰 사진
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //큰 사진
                        vals["사진톤" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //큰 사진

                    }

                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");
                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "TB");


                    bsCandSBS.MoveNext();
                } //for
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_3ManAllMask 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//



        private bool Elec_3ManAllEdu(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //교육감 전용 3인 전후보
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["선거코드"] = codes[0].Trim();


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")   //북구국회의원
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원" ;
                }
                else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }
 

                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;

                bsCandSBS.Position = startno - 1;

                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 3; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;

                    //vals["정당코드" + i.ToString()] = "97";    //교육감 후보는 무소속 이지만, 가상코드 "99"로 변환하여 색상 조정
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");   //작은 사진
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");            
                        

                        switch (i)
                        {
                            case 1:
                                vals["정당A" + i.ToString()] = getPartyPath("97", "Back");
                                break;
                            case 2:
                                vals["정당A" + i.ToString()] = getPartyPath("97", "BackC");
                                break;
                            case 3:
                                vals["정당A" + i.ToString()] = getPartyPath("97", "Back");
                                break;
                            default:
                                break;
                        }


                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_3ManAllEdu 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//


        private bool Elec_3ManAllDrone(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //드론 3인  전후보
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            //vals["시도"] = names[2];
            
            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")   //북구국회의원
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }

                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["백그림"] = getDroneCityNamePath(row["PrecName"].ToString() );


                //백그림이 있는지 체크해서 없으면 울산.vrv로 대체 
                if (Convert.ToString(System.IO.File.Exists(vals["백그림"])) == "False")
                {
                    vals["백그림"] = getCityDroneMoviePath(names[2].Trim());
                }


                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;

                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 3; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString() + "위";                           //순위

                    // 교육감 
                    if (codes[0].Trim() == "03")  
                    { 
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");  
                    }
                    else
                    {
                        vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //작은 사진
                    }

                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");
                    vals["정당A"  + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "NB");
 
                    bsCandSBS.MoveNext();
                } //for
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_3ManAllDrone 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//




        private bool Elec_4Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //기초단체장 4인 현재1위
            //B타입 : 전선거구 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구순번)
            //출력  : 시도 + 4 * (직책n + 당선n + 사진n + 성명n + 득표율n + 득표수n + 정당n + 정당An + 정당코드n)

            try
            {
                //필요변수 파싱
                string eleccatgr = codes[0];                        //선거종류
                string city = codes[2];                             //시도코드
                int ordno = Convert.ToInt32(codes[3]);             //출력 시작할 선거구 순번

                //해당 시도의 기초단체장 1위 리스트를 가져온다.
                OpenDataSet.Ele_TCandSBS1DataTable dtWinners = taCandSBS1.GetData(eleccatgr, city);
                //출력할 선거구가 리스트수 보다 크면 패스
                if (ordno > dtWinners.Count) return false;

                //한 화면에 총4명 표출
                vals["시도"] = names[2];

                for (int i = 0; i < 4; i++)
                {
                    string no = (i + 1).ToString();
                    int precno = ordno + i - 1;

                    if (precno >= dtWinners.Count) break;

                    vals["직책" + no] = dtWinners.Rows[precno]["PrecName"].ToString();
                    vals["당선" + no] = getElecGbnPath(dtWinners.Rows[precno]["ElecGbn"].ToString(), "D");
                    vals["사진" + no] = getPhotoPath(eleccatgr, dtWinners.Rows[precno]["PrecID"].ToString(), dtWinners.Rows[precno]["OrdNo"].ToString(), "A");
                    vals["성명" + no] = dtWinners.Rows[precno]["KorName"].ToString();
                    vals["득표율" + no] = dtWinners.Rows[precno]["VotesRate"].ToString();
                    vals["득표수" + no] = Knn.StrFuncs.NumToHangul(dtWinners.Rows[precno]["VotesCnt"].ToString(), false);
                    vals["정당코드" + no] = dtWinners.Rows[precno]["PartyCode"].ToString();

                    vals["정당A" + no] = getPartyPath(dtWinners.Rows[precno]["PartyCode"].ToString(), "KB");
                    vals["정당SB" + no] = getPartyPath(dtWinners.Rows[precno]["PartyCode"].ToString(), "SB");

                }

            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_4Man 현재1위 오류 : " + ex.Message);
                return false;
            }
            return true;
        }//


        private bool Elec_4ManDrone(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //NTEK 드론 구군시장 4인 현재1위
            //values : 시도 + 4 * (직책n + 당선n + 사진n + 성명n + 득표율n + 득표수n + 정당n + 정당An + 정당코드n)

            try
            {
                //필요변수 파싱
                string eleccatgr = codes[0];                        //선거종류
                string city = codes[2];                             //시도코드
                int ordno = Convert.ToInt32(codes[3]);             //출력 시작할 선거구 순번

                //해당 시도의 기초단체장 1위 리스트를 가져온다.
                OpenDataSet.Ele_TCandSBS1DataTable dtWinners = taCandSBS1.GetData(eleccatgr, city);
                //출력할 선거구가 리스트수 보다 크면 패스
                if (ordno > dtWinners.Count) return false;

                //한 화면에 총4명 표출
                vals["시도"] = names[2];

                for (int i = 0; i < 4; i++)
                {
                    string no = (i + 1).ToString();
                    int precno = ordno + i - 1;

                    if (precno >= dtWinners.Count) break;

                    vals["직책" + no] = dtWinners.Rows[precno]["PrecName"].ToString();

                    if (i ==0 )
                    {
                        vals["백그림"] = getDroneCityNamePath(vals["직책1"]);

                        //백그림이 있는지 체크해서 없으면 울산.vrv로 대체 
                        if (Convert.ToString(System.IO.File.Exists(vals["백그림"])) == "False")
                        {
                            vals["백그림"] = getCityDroneMoviePath(vals["시도"].Trim());
        
                        }
                    }

                    vals["당선" + no] = getElecGbnPath(dtWinners.Rows[precno]["ElecGbn"].ToString(), "D");
                    vals["사진" + no] = getPhotoPath(eleccatgr, dtWinners.Rows[precno]["PrecID"].ToString(), dtWinners.Rows[precno]["OrdNo"].ToString(), "A");
                    vals["성명" + no] = dtWinners.Rows[precno]["KorName"].ToString();

                    vals["득표율" + no] = dtWinners.Rows[precno]["VotesRate"].ToString();
                    vals["득표수" + no] = Knn.StrFuncs.NumToHangul(dtWinners.Rows[precno]["VotesCnt"].ToString(), false);
                    vals["정당코드" + no] = dtWinners.Rows[precno]["PartyCode"].ToString();

                    vals["정당A" + no] = getPartyPath(dtWinners.Rows[precno]["PartyCode"].ToString(), "KB");
                    vals["정당SB" + no] = getPartyPath(dtWinners.Rows[precno]["PartyCode"].ToString(), "SB");

                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_4ManDrone 현재1위 오류 : " + ex.Message);
                return false;
            }
            return true;
        }//


        private bool Elec_MovWinner(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //광역단체장 영상당선 
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 사진 + 성명 + 프로필1 + 프로필2 + 프로필3 + 프로필4 + 득표수 + 득표율 + 정당 + 정당A + 당선구분

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //당선이 아니면 표출안함
                string elecgbn = row["ElecGbn"].ToString().Trim();
                if (!(elecgbn == "60" || elecgbn == "80" || elecgbn == "90")) return false;

                //vals["직책"] = names[2] + row["JobName"].ToString();
                
                vals["직책"] = row["PrecName"].ToString(); 
                bsCandSBS.MoveFirst();

                row = (DataRowView)bsCandSBS.Current;
                vals["사진"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "C4");
                vals["성명"] = row["KorName"].ToString();
                vals["프로필1"] = row["Career1"].ToString();
                vals["프로필2"] = row["Career2"].ToString();
                vals["프로필3"] = row["Career3"].ToString();
                vals["프로필4"] = row["Career4"].ToString();
                vals["득표수"] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                vals["득표율"] = row["VotesRate"].ToString();
                vals["정당"] = row["PartyName"].ToString();
                vals["정당A"] = getPartyPath(row["PartyCode"].ToString(), "F");
                vals["당선구분"] = elecgbn;
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_MovWinner 오류 : " + ex.Message);
                return false;
            }

            return true;
        }
        private bool Elec_PhotoWinner(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //광역/교육/기초 사진당선  
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 선거코드 + 직책 + 사진 + 성명 + 프로필1 + 프로필2 + 프로필3 + 프로필4 + 득표수 + 득표율 + 정당 + 정당A + 당선구분

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                
                //당선이 아니면 표출안함
                string elecgbn = row["ElecGbn"].ToString().Trim();

                if (!(elecgbn == "60" || elecgbn == "80" || elecgbn == "90")) return false;

                vals["선거코드"] = codes[0].Trim();
                vals["시도"] = names[2];

                if (codes[0].Trim() == "01")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";

                } else 
                    vals["직책"] = row["PrecName"].ToString(); 

                bsCandSBS.MoveFirst();

                row = (DataRowView)bsCandSBS.Current;
                vals["국민의선택"] = getETCPeopleSelectionPath(names[2]) ;

                if (codes[0].Trim() == "03") //교육감
                {
                    vals["사진"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                    vals["사진반사"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                }

                else {
                    vals["사진"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["사진반사"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                } 


                vals["성명"] = row["KorName"].ToString();
                vals["프로필1"] = row["Career1"].ToString();
                vals["프로필2"] = row["Career2"].ToString();
                vals["프로필3"] = row["Career3"].ToString();
                vals["프로필4"] = row["Career4"].ToString();
                vals["득표율"] = row["VotesRate"].ToString();

                vals["정당SA"] = getPartyPath(row["PartyCode"].ToString(), "SA");
                vals["정당KB"] = getPartyPath(row["PartyCode"].ToString(), "KB");

                vals["당선구분"] = elecgbn;
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_PhotoWinner 오류 : " + ex.Message);
                return false;
            }

            return true;
        }
        private bool Elec_4Winner(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            return true;
        }

        private bool Elec_2Dan3ManAll(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //광역/국회/기초 2단 3인 전후보
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["직책"] = row["PrecName"].ToString();  
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;
                //1위 장면에서만 당선표시
                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //C타입 당선이미지
                else
                    vals["당선"] = "";
                //하단배경설정
                vals["하단바"] = getLowBack();

                for (int i = 1; i <= 3; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");   //큰 사진
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");
                    vals["정당KB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "KB");

                    bsCandSBS.MoveNext();
                } //for
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_2Dan3ManAll 오류 : " + ex.Message);
                return false;
            }


            return true;
        } //



        private bool Elec_2Dan2Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //국회의원/광역/기초 2단 2인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함 & 무투표 당선도 개표수 0
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["선거코드"] = codes[0].Trim();
                //vals["시도"] = names[2];
                //vals["직책"] = row["JobName"].ToString();
 
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["직책"] = row["PrecName"].ToString(); 
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //하단배경설정
                vals["하단바"] = getLowBack();

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;
                //string type = "";
                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당SB" + i.ToString()] =  getPartyPath(row["PartyCode"].ToString(), "SB");
                    vals["정당KB" + i.ToString()] =  getPartyPath(row["PartyCode"].ToString(), "KB");


                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());
                    bsCandSBS.MoveNext();
                } //for 

                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_2Dan2Man 오류 : " + ex.Message);
                return false;
            }


            return true;
        }//




        private bool Elec_3Dan2ManAll(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            return true;
        }
        private bool Elec_3Dan2Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            return true;
        }

        private bool Elec_Corner2ManAll(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //좌상단 2인 전후보 광역/국회/기초  (503) (504) 사진2장 
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 2 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["직책"] = row["PrecName"].ToString();
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;
                //1위 장면에서만 당선표시
                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 2; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "B");
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
     
                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["정당KB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Corner2ManAll 오류 : " + ex.Message);
                return false;
            }

            return true;
        }
        private bool Elec_Corner2Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //광역/교육/기초 좌상단 2인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;



                if (codes[0].Trim() == "01")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                    vals["직책"] = row["PrecName"].ToString();

                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;

                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = i.ToString();                           //순위
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "B");
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                   
                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();

                    vals["정당KB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");
  
                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Conner2Man 오류 : " + ex.Message);
                return false;
            }

            return true;
        } //


        private bool Elec_Corner2ManNtek(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //NTEK 좌상단 1인 1사진 
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                            
                if (codes[0].Trim() == "01")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";

                }
                else
                    vals["직책"] = row["PrecName"].ToString();


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;

                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = i.ToString();                           //순위
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "B");
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();

                    vals["정당KB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Conner2Man 오류 : " + ex.Message);
                return false;
            }

            return true;
        } //


        private bool Elec_Corner2ManAllNtek1(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //NTEK 좌상단 2인  (517) 사진없음
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 2 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;


                if (codes[0].Trim() == "01")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                    vals["직책"] = row["PrecName"].ToString();


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;
                //1위 장면에서만 당선표시
                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 2; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["정당KB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Corner2ManAllNtek 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//


        private bool Elec_Corner2ManAllNtek2(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //NTEK 좌상단 1인 사진 전후보 득표율 (518) 사진1장 
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 2 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                if (codes[0].Trim() == "01")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                    vals["직책"] = row["PrecName"].ToString();


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;
                //1위 장면에서만 당선표시
                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 2; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "B");
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["정당KB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Corner2ManAllNtek2 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//



        private bool Elec_Corner2ManAllEdu1(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //NTEK 좌상단 2인 교육감 전후보 득표율   (514) 사진없음 
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 2 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                if (codes[0].Trim() == "01")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                    vals["직책"] = row["PrecName"].ToString();


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;
                //1위 장면에서만 당선표시
                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 2; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = "97";
                    vals["정당KB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Corner2ManAllEdu1 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//


        private bool Elec_Corner2ManAllEdu2(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //NTEK 좌상단 교육감 1인 전후보 사진 (515)  사진1장 
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 2 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["직책"] = row["PrecName"].ToString();
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;
                //1위 장면에서만 당선표시
                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 2; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위

                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "F");

                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = "97";
                    vals["정당KB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Corner2ManAllNtek2 오류 : " + ex.Message);
                return false;
            }

            return true;
        }//




        private bool Elec_2Dan2ManEdu(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //교육감 전용 2단 2인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함 & 무투표 당선도 개표수 0
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["선거코드"] = codes[0].Trim();
                //vals["시도"] = names[2];
                //vals["직책"] = row["JobName"].ToString();

                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["직책"] = row["PrecName"].ToString();
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //하단배경설정
                vals["하단바"] = getLowBack();

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;
                //string type = "";
                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                   // 교육감 후보

                     vals["정당코드" + i.ToString()] = "97";            //교육감 후보는 무소속 이지만, 가상코드 "97"로 변환하여 색상 조정
                     vals["정당" + i.ToString()] = "";                  //정당명 없음.
                     vals["정당A" + i.ToString()] = getPartyPath("97", "KB");
                     vals["정당SB" + i.ToString()] = getPartyPath("97", "SB");
                     vals["정당KB" + i.ToString()] = getPartyPath("97", "KB");

                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());
                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_2Dan2Man 오류 : " + ex.Message);
                return false;
            }


            return true;
        }//

        private bool Elec_2Dan3ManAllEdu(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //교육감전용  2단 3인 전후보
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["선거코드"] = codes[0].Trim();

                //vals["시도"] = names[2];
                //vals["직책"] = row["JobName"].ToString();
                vals["직책"] = row["PrecName"].ToString();
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;
                //1위 장면에서만 당선표시
                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //C타입 당선이미지
                else
                    vals["당선"] = "";

                //하단배경설정
                vals["하단바"] = getLowBack();

                for (int i = 1; i <= 3; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString() + "위";                           //순위
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");   //작은 사진
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
  
                    //교육감은 정당이 무소속이나, 가상정당 "97"로 설정해 정당색 맞춤
                    vals["정당" + i.ToString()] = "";

                    //수정요망 
                    vals["정당코드" + i.ToString()] = "97";
                    vals["정당KB" + i.ToString()] = getPartyPath("97", "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath("97", "SB");

                  
                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_2Dan3ManAll 오류 : " + ex.Message);
                return false;
            }


            return true;
        } //


        private bool Elec_Corner2ManAllEdu(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //좌상단 교육감전용  2인 전후보  (512)
            //A타입 : 전후보 송출화면 Loop(선거종류 + 화면 + 시도 + 선거구 + 순위)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 2 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["선거코드"] = codes[0].Trim();
                //vals["시도"] = names[2];
                //vals["직책"] = row["JobName"].ToString();


                vals["직책"] = row["PrecName"].ToString();
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());

                //후보 시작 순위로 이동
                int startno = int.Parse(codes[4]);
                if (startno > bsCandSBS.Count) return false;
                bsCandSBS.Position = startno - 1;
                //1위 장면에서만 당선표시
                if (startno == 1)
                    vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지
                else
                    vals["당선"] = "";

                for (int i = 1; i <= 2; i++)
                {
                    if ((startno + i - 1) > bsCandSBS.Count) break;
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = (startno + i - 1).ToString();                           //순위
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "F");   //작은 사진
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    //교육감은 정당이 무소속이나, 가상정당 "97"로 설정해 정당색 맞춤
                    vals["정당" + i.ToString()] = "";
                    vals["정당코드" + i.ToString()] = "97";
                    vals["정당KB" + i.ToString()] = getPartyPath("97", "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath("97", "SB");

                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Corner2ManAllEdu 오류 : " + ex.Message);
                return false;
            }

            return true;
        } //


        private bool Elec_Corner2ManEdu(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //교육감전용 좌상단 2인경쟁  (513) 사진2장 있음 
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 선거코드 + 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn 정당코드n)

            try
            {
                //개표수 0이면 표출안함. 무투표당선도 개표수 0
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                if (row["OpenCnt"].ToString() == "0") return false;

                vals["선거코드"] = codes[0].Trim();
                //vals["시도"] = names[2];

                //vals["직책"] = row["JobName"].ToString();

                vals["직책"] = row["PrecName"].ToString();
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");    //D타입 당선이미지

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;
               // string type = "";
                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["순위" + i.ToString()] = i.ToString();                           //순위
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "F");   //작은 사진
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                   //교육감은 정당이 무소속이나, 가상정당 "97"로 설정해 정당색 맞춤
                    vals["정당" + i.ToString()] = "";
                    vals["정당KB" + i.ToString()] = getPartyPath("97", "KB");
                    vals["정당SB" + i.ToString()] = getPartyPath("97", "SB");
                    vals["정당코드" + i.ToString()] = "97";
                 
                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Conner2ManEdu 오류 : " + ex.Message);
                return false;
            }

            return true;
        }



        private bool Elec_Mov2Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //광역단체장 영상 2인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 표차 + 2 * (사진n + 성명n + 득표수n + 투표율n + 정당An + 정당Bn + 정당코드n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;

                // vals["직책"] = names[2] + row["JobName"].ToString();

                vals["직책"] = row["PrecName"].ToString();   //울산 북구  
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;
                string type = "";
                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    string mtype = (i == 1) ? "C1" : "C2";
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), mtype);
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    if (i == 1) type = "AL"; else type = "AR";
                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), type);
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());
                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Mov2Man 오류 : " + ex.Message);
                return false;
            }
            return true;
        }

        private bool Elec_Mov5Man(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //광역단체장 영상 5인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 사진 + 5 * (성명n + 득표수n + 투표율n + 정당n + 정당An  + 정당코드n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;

                //              vals["직책"] = names[2] + row["JobName"].ToString();

                vals["직책"] = row["PrecName"].ToString();
                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                for (int i = 1; i <= 5; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    //후보자수가 5인보다 적을경우
                    if (bsCandSBS.Count < i) break;
                    //1위 상세정보 지정
                    if (i == 1)
                    {
                        vals["사진"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "C3");
                        vals["정당A1"] = getPartyPath(row["PartyCode"].ToString(), "AL");
                    }
                    else
                    {
                        vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "B");
                    }
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당" + i.ToString()] = row["PartyName"].ToString();
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Mov5Man 오류 : " + ex.Message);
                return false;
            }
            return true;
        }


        private bool Elec_CandManProfile(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //후보프로필 
            //E타입 : Loop(선거종류 + 화면 + 시도 + 선거구 + 기호)
            //출력 : 선거코드 + 시도 + 직책 + 영상A + 사진A + 사진B + 기호 + 성명 + 프로필1 + 프로필2 + 프로필3 + 프로필4 + 득표수 + 득표율 + 정당 + 정당A

            try
            {
                DataRowView prec = (DataRowView)bsPrecSBS.Current;
                vals["선거코드"] = codes[0].Trim();
                vals["시도"] = names[0] + " " + names[2];
                vals["국민의선택"] = getETCPeopleSelectionPath(names[2]);
                
                if (codes[0].Trim() == "01")
                {
                    vals["직책"] = prec["PrecName"].ToString() + " 국회의원";
                }
                else
                    vals["직책"] = prec["PrecName"].ToString();


                OpenDataSet.Ele_TCandSBSDataTable dtCand = taCandSBS.GetDataByOrdNo(codes[0], codes[3], codes[4]);
                DataRow row = dtCand.Rows[0];

                if (codes[0].Trim() == "03") //교육감 
                {
                    vals["사진1"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                    vals["사진반사1"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                    vals["포토1"] = getPhotoPathProfile(codes[0], codes[3], row["OrdNo"].ToString(), "E", "1");
                    vals["포토2"] = getPhotoPathProfile(codes[0], codes[3], row["OrdNo"].ToString(), "E", "2");
                    vals["포토3"] = getPhotoPathProfile(codes[0], codes[3], row["OrdNo"].ToString(), "E", "3");
                    vals["기호"] = "";

                    if (Convert.ToString(System.IO.File.Exists(vals["포토1"])) == "False")
                    {
                        vals["포토1"] = "";
                    }
                    if (Convert.ToString(System.IO.File.Exists(vals["포토2"])) == "False")
                    {
                        vals["포토2"] = "";
                    }
                    if (Convert.ToString(System.IO.File.Exists(vals["포토3"])) == "False")
                    {
                        vals["포토3"] = "";
                    }

                }  // 교육감 03이 아니면 
                else
                {
                    vals["기호"] = row["OrdNo"].ToString().Trim() + " 번";
                    vals["사진1"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["사진반사1"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["포토1"] = getPhotoPathProfile(codes[0], codes[3], row["OrdNo"].ToString(), "A", "1");
                    vals["포토2"] = getPhotoPathProfile(codes[0], codes[3], row["OrdNo"].ToString(), "A", "2");
                    vals["포토3"] = getPhotoPathProfile(codes[0], codes[3], row["OrdNo"].ToString(), "A", "3");

                    if (Convert.ToString(System.IO.File.Exists(vals["포토1"])) == "False")
                    {
                        vals["포토1"] = "";
                    }
                    if (Convert.ToString(System.IO.File.Exists(vals["포토2"])) == "False")
                    {
                        vals["포토2"] = "";
                    }
                    if (Convert.ToString(System.IO.File.Exists(vals["포토3"])) == "False")
                    {
                        vals["포토3"] = "";
                    }
                }



                vals["성명1"] = row["KorName"].ToString();
                vals["프로필1"] = row["Career1"].ToString();
                vals["프로필2"] = row["Career2"].ToString();
                vals["프로필3"] = row["Career3"].ToString();
                vals["프로필4"] = row["Career4"].ToString();

                vals["정당"] = row["PartyName"].ToString();
                vals["정당SB1"] = getPartyPath(row["PartyCode"].ToString(), "SB");
                vals["정당KB1"] = getPartyPath(row["PartyCode"].ToString(), "KB");


            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_TestCand 오류 : " + ex.Message);
                return false;
            }

            return true;
        }
        #endregion



        private bool Elec_Photo2ManIronMan(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //아이언맨 2인경쟁 - 광역단체장, 국회의원 
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;

                // names[2] =울산 
                // vals["직책"] = names[2] + row["PrecName"].ToString();


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }

                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;
                //string type = "";
                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "H");
                    vals["닫힌헬멧" + i.ToString()] = getPhotoPathIronMan(row["PartyCode"].ToString().Trim() , "K");
                    vals["바디" + i.ToString()] = getPhotoPathIronMan(row["PartyCode"].ToString().Trim(),  "J");

                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();

                    vals["정당" + i.ToString()] = row["PartyName"].ToString();

                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "NB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");


                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());

                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Photo2ManIronMan 오류 : " + ex.Message);
                return false;
            }


            return true;

        }


        private bool Elec_Photo2ManCaptain(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //캡틴아메리카 2인경쟁 
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;

                // names[2] =울산 
                // vals["직책"] = names[2] + row["PrecName"].ToString();


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                {
                    vals["직책"] = row["PrecName"].ToString();
                }

                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                int votecnt1 = 0;
                int votecnt2 = 0;
                //string type = "";
                for (int i = 1; i <= 2; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "G");

                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당" + i.ToString()] = row["PartyName"].ToString();

                    vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "CB");
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");


                    if (i == 1) votecnt1 = Convert.ToInt32(row["VotesCnt"].ToString()); else votecnt2 = Convert.ToInt32(row["VotesCnt"].ToString());

                    bsCandSBS.MoveNext();
                }
                vals["표차"] = Knn.StrFuncs.NumToHangul((votecnt1 - votecnt2).ToString(), false);
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Photo2ManCaptain 오류 : " + ex.Message);
                return false;
            }


            return true;

        }


        private bool Elec_Photo4ManCaptain(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //캡틴아메리카 4인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 사진 + 5 * (성명n + 득표수n + 투표율n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                    vals["직책"] = row["PrecName"].ToString();


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                for (int i = 1; i <= 4; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    //후보자수가 5인보다 적을경우
                    if (bsCandSBS.Count < i) break;

                    //vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "G");
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();
                    vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    //1위 상세정보 지정
                    if (i == 1)
                    {
                        vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "CB");
                    }
                    else
                    {
                        vals["정당A" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "NB");
                    }

                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_Photo4ManCaptain 오류 : " + ex.Message);
                return false;
            }

            return true;

        }//



        private bool Elec_Photo5ManExit1(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {

            vals["직책"] = "출구조사";

            return true;

        }

        private bool Elec_Photo5ManExit(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //광역/국회 5인경쟁
            //C타입 : 1선거구 1송출화면 Once(선거종류 + 화면 + 시도 + 선거구)
            //출력 : 직책 + 개표율 + 당선구분 + 사진 + 5 * (성명n + 득표수n + 투표율n)

            try
            {
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                //개표수 0이면 표출안함
                if (row["OpenCnt"].ToString() == "0") return false;


                if (codes[0].Trim() == "01" && names[2].Trim() == "울산")
                {
                    vals["직책"] = row["PrecName"].ToString() + " 국회의원";
                }
                else
                    vals["직책"] = row["PrecName"].ToString();


                vals["개표율"] = getOpenRate(row["OpenRate"].ToString());
                vals["당선"] = getElecGbnPath(row["ElecGbn"].ToString(), "D");

                //해당 선거구의 후보자정보를 순위정렬로 가져온다
                bsCandSBS.MoveFirst();
                for (int i = 1; i <= 5; i++)
                {
                    row = (DataRowView)bsCandSBS.Current;
                    //후보자수가 5인보다 적을경우
                    if (bsCandSBS.Count < i) break;

                    vals["정당코드" + i.ToString()] = row["PartyCode"].ToString().Trim();
                    vals["사진" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["성명" + i.ToString()] = row["KorName"].ToString();
                    vals["득표수" + i.ToString()] = Knn.StrFuncs.NumToHangul(row["VotesCnt"].ToString(), false);
                    vals["득표율" + i.ToString()] = row["VotesRate"].ToString();


                    //1위 상세정보 지정
                    if (i == 1)
                    {
                        vals["사진반사" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                        vals["사진톤" + i.ToString()] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");

                        vals["정당바" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "L");
                        vals["정당SB" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "SB");

                    }
                    else
                    {
                        vals["정당바" + i.ToString()] = getPartyPath(row["PartyCode"].ToString(), "UB");
                    }

                    bsCandSBS.MoveNext();
                }
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_photo5Man 오류 : " + ex.Message);
                return false;
            }

            return true;

        }//




        private bool Elec_TestCand(string[] names, string[] codes, ref Dictionary<string, string> vals)
        {
            //후보 점검
            //E타입 : Loop(선거종류 + 화면 + 시도 + 선거구 + 기호)
            //출력 : 선거코드 + 시도 + 직책 + 영상A + 사진A + 사진B + 기호 + 성명 + 프로필1 + 프로필2 + 프로필3 + 프로필4 + 득표수 + 득표율 + 정당 + 정당A

            try
            {
                DataRowView prec = (DataRowView)bsPrecSBS.Current;
                vals["선거코드"] = codes[0].Trim();

                vals["직책"] = prec["PrecName"].ToString();

                vals["시도"] = names[0] + " " + names[2];

                OpenDataSet.Ele_TCandSBSDataTable dtCand = taCandSBS.GetDataByOrdNo(codes[0], codes[3], codes[4]);
                DataRow row = dtCand.Rows[0];


                if (codes[0].Trim() == "03") //교육감 
                {
                    vals["사진A"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "E");
                    vals["사진B"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "F");
                }
                else {
                    vals["사진A"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "A");
                    vals["사진B"] = getPhotoPath(codes[0], codes[3], row["OrdNo"].ToString(), "B");
                }

                vals["기호"] = row["OrdNo"].ToString() +" 번"; 
                vals["성명"] = row["KorName"].ToString();
                vals["프로필1"] = row["Career1"].ToString();
                vals["프로필2"] = row["Career2"].ToString();
                vals["프로필3"] = row["Career3"].ToString();
                vals["프로필4"] = row["Career4"].ToString();


                vals["정당"] = row["PartyName"].ToString();
                vals["정당SA"] = getPartyPath(row["PartyCode"].ToString(), "SA");
                vals["정당SB"] = getPartyPath(row["PartyCode"].ToString(), "SB");
                vals["정당SC"] = getPartyPath(row["PartyCode"].ToString(), "SC");

                vals["정당A"] = getPartyPath(row["PartyCode"].ToString(), "KB");
                vals["정당B"] = getPartyPath(row["PartyCode"].ToString(), "L");
                vals["정당C"] = getPartyPath(row["PartyCode"].ToString(), "W");
                vals["정당D"] = getPartyPath(row["PartyCode"].ToString(), "QB");
                vals["정당E"] = getPartyPath(row["PartyCode"].ToString(), "TB");
                vals["정당F"] = getPartyPath(row["PartyCode"].ToString(), "NB");
                vals["정당G"] = getPartyPath(row["PartyCode"].ToString(), "UB");
                vals["정당H"] = getPartyPath(row["PartyCode"].ToString(), "BackC");
                vals["정당I"] = getPartyPath(row["PartyCode"].ToString(), "Back");

            
            }
            catch (Exception ex)
            {
                CG_OnLogMessage("### Elec_TestCand 오류 : " + ex.Message);
                return false;
            }

            return true;
        }


        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dgvQsheet_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbBG_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }
    }
}


