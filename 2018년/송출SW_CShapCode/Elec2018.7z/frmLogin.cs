﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Election
{
    public partial class frmLogin : Form
    {
        //방송사 리스트(ini에 설정)
        private static Dictionary<string, string> complist;
        //방송사별 접속가능 DB리스트
        private static Dictionary<string, string> dblist;
        
        public frmLogin()
        {
            InitializeComponent();

			//백그라운드 이미지 크기로 로긴창 크기 변경
            this.ClientSize = this.BackgroundImage.Size;

            //판넬 투명도 조절
            panBack.BackColor = Color.FromArgb(100, Color.Black);
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            //기본 초기화값은 Global파일에 설정되어 있음
            //타이틀 변경
            this.Text = Global.Title + " (Version " + Global.Version + ")";

            //방송사 콤보박스 채우기
            complist = new Dictionary<string, string>();
            string comps = Global.IniFile.GetString("Election", "CompList");
            string[] items = comps.TrimEnd(';').Split(';');
            foreach (string item in items)
            {
                string[] keyval = item.Split('=');
                complist.Add(keyval[0], keyval[1]);
            }
            // or ===> complist = comps.TrimEnd(';').Split(';').ToDictionary(item => item.Split('=')[0], item => item.Split('=')[1]);

            cbxComp.DisplayMember = "Value";
            cbxComp.ValueMember = "Key";
            cbxComp.DataSource = new BindingSource(complist, null);
            cbxComp.SelectedValue = Global.CompID;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            //전역변수설정
            Global.CompID = cbxComp.SelectedValue.ToString();
            Global.DbID = cbxDb.SelectedValue.ToString();

            //DB접속 문자열 처리
            //Properties.Settings.Default["ConnectionString"] = Global.DbConnectionString;
            Properties.Settings.Default["ElectionConnectionString"] = Global.DbConnectionString;

            //방송사 검색스트링 설정
            OpenDataSet.Ele_MCompCodeDataTable dt = taCompInfo.GetDataByCompID("001", Global.CompID);
            Global.CompLikeString = dt.Rows[0]["Resv2"].ToString();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void ReloadDBList(string compid)
        {
            //DB 콤보박스 채우기
            dblist = new Dictionary<string, string>();
            string dbs = Global.IniFile.GetString(compid, "DbList");
            string[] dbitems = dbs.TrimEnd(';').Split(';');
            foreach (string item in dbitems)
            {
                string[] keyval = item.Split('=');
                dblist.Add(keyval[0], keyval[1]);
            }
            // or ===> dblist = dbs.TrimEnd(';').Split(';').ToDictionary(item => item.Split('=')[0], item => item.Split('=')[1]);

            cbxDb.DisplayMember = "Value";
            cbxDb.ValueMember = "Key";
            cbxDb.DataSource = new BindingSource(dblist, null);
            cbxDb.SelectedValue = Global.IniFile.GetString(compid, "DbID");
        }

        //방송사 선택 콤보박스값이 바뀔때
        private void cbxComp_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxComp.SelectedValue == null) return;

            //해당 방송사의 DB 리스트로 DB콤보박스 갱신
            string compid = cbxComp.SelectedValue.ToString();
            ReloadDBList(compid);
        }

        //어플리케이션 데이타 폴더 열기
        private void btnData_Click(object sender, EventArgs e)
        {
            //어플리케이션 데이타 폴더를 파일탐색기 오픈
            System.Diagnostics.Process.Start("explorer.exe", Global.DataPath);
        }

        //실행폴더 버튼 클릭시
        private void btnFolder_Click(object sender, EventArgs e)
        {
            //실행파일 폴더를 파일탐색기로 오픈
            System.Diagnostics.Process.Start("explorer.exe", Global.StartupPath);
        }

        //ini열기 버튼 클릭시
        private void btnIni_Click(object sender, EventArgs e)
        {
            //어플리케이션 폴더의 election.ini파일을 메모장으로 열기
            System.Diagnostics.Process.Start("notepad.exe", Global.DataPath + "\\Election.ini");
        }

        //다시시작 버튼 클릭시
        private void btnReload_Click(object sender, EventArgs e)
        {
            //어플리케이션 재실행
            Application.Restart();
        }

    }
}
