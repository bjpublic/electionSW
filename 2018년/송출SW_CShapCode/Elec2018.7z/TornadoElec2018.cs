﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TornadoAPI;
using K3DAsyncEngineLib;

namespace TornadoAPI
{
    public class TornadoElec2018 : Tornado
    {
        //슬래쉬로 나누어진 RGB색상(ex 0/0/255)을 해당 R, G, B로 변환
        public struct Color
        {
            public int A, R, G, B;
            public Color(string rgb)
            {
                string[] c = rgb.Split('/');
                A = 255;
                R = Convert.ToInt32(c[0]);
                G = Convert.ToInt32(c[1]);
                B = Convert.ToInt32(c[2]);
            }
        }

        //정당 색상 3가지 타입
        public struct PartyColor
        {
            public Color C1, C2, C3;
            public PartyColor(string rgb1, string rgb2, string rgb3)
            {
                C1 = new Color(rgb1);
                C2 = new Color(rgb2);
                C3 = new Color(rgb3);
            }
        }

        //정당별 색상 리스트
        private Dictionary<string, PartyColor> FPartyList = new Dictionary<string, PartyColor>();

        //기본적으로 모든 노멀한 장면은 레이어 0에서 처리
        public int FLayerNo = 0;

        public TornadoElec2018()
        {

        }

        //장면을 적절한 값으로 치환하여 준비
        //  alias : 최초 RegistScene으로 등록한 장면 별칭명
        //  values : 큐시트의 코드,값 dictionary(장면마다 필요한 코드,값이 다름)
        // - Dictionary에 "OutTrigger"가 있으면 장면의 change out 설정함
        public bool Ready(string alias, Dictionary<string, string> values)
        {
            //Out Trigger있으면 설정
            if (values != null && values.ContainsKey("OutTrigger")) this.SetChangeOut(values["OutTrigger"]);

            //장면 로딩
            bool result = this.SwapReady(alias);

            if (!result) return false;

            //송출 레이어번호는 기본값 = 0
            FLayerNo = 0;
            //각 장면별칭별 변수설정값을 구함
            switch (alias)
            {
                case "100": result = PastVoteRate(values); break;       //역대투표율
                case "102": result = PastVoteRate2(values); break;      //울산 드론방식 역대 투표율 종합 
                case "103": result = PastVoteRate3(values); break;      //울산 드론방식 시간대별투표율
                case "104": result = PastVoteRate4(values); break;      //울산 드론방식 역대 지선투표율

                case "105":
                case "106":
                case "107":
                case "108": result = Bridge_major1(values); break;      //브릿지  

                case "113": result = Bridge_majorExit(values); break;      //출구조사판  
                case "114": result = Bridge_majorExit(values); break;      //출구조사판  
                case "115": result = Bridge_majorExit(values); break;      //출구조사판  

                case "202": result = Man2Pic(values); break;            //2인경쟁-광역
                case "203": result = Man5Mov(values); break;            //영상5인경쟁-광역
                case "204": result = Man2Pic(values); break;            //사진2인경쟁-광역
                case "205": result = Man5Pic(values); break;            //사진5인경쟁-광역
                case "206": result = Man2Edu(values); break;            //교육2인경쟁
                case "207": result = Man5Edu(values); break;            //교육5인경쟁
                case "208": result = false; break;                           //SBS 2인경쟁
                case "20A": result = Man2Bas(values); break;            //SBS2인경쟁 
                case "20B": result = Man2Bas(values); break;            //SBS2인경쟁

                case "210": result = false; break;                          //3인 전후보-기초
                case "211": result = Man3All(values); break;            //3인 전후보1 첫화면
                case "212": result = Man3All(values); break;            //3인 전후보2 반복화면

                case "213": result = false; break;                           //교육감 3인 
                case "214": result = Man3AllMask(values); break;      //3인 마스킹 전후보 
                case "215": result = Man3AllMask(values); break;      //3인 마스킹 전후보 

                case "217": result = false; break;                          //교육감 3인 
                case "218": result = Man3AllEdu(values); break;       //3인 전후보1 첫화면
                case "219": result = Man3AllEdu(values); break;       //3인 전후보2 반복화면


                case "220": result = Man2BasSejong(values); break;           //대전세종2인경쟁 세종  
                case "221": result = Man3AllSejong(values); break;            //대전세종  3인 전후보1 첫화면

                case "310": result = Man4Bas(values); break;            //기초4인 현재1위
                case "311": result = Man4BasDrone(values); break;     //드론 4인  현재1위


                case "320": result = false; break;                           //영상당선-광역
                case "321": result = WinMov(values); break;             //영상당선-광역 1
                case "322": result = WinMov(values); break;             //영상당선-광역 2

                case "325": result = Bridge_majorRibbon(values); break;    //브릿지  리본당선 
                case "326": result = WinPic(values); break;             //사진당선-1


                case "332": result = WinPic(values); break;             //사진당선-2
                case "333": result = CandManProfile(values); break;  //후보프로필화면 
                case "335": result = WinPic(values); break;             //당선 오리지날


                case "340": result = false; break;                      //사진당선-교육
                case "341": result = WinPic(values); break;             //사진당선-1
                case "342": result = WinPic(values); break;             //사진당선-2
                case "350": result = false; break;                      //사진당선-기초
                case "351": result = WinPic(values); break;             //사진당선-1
                case "352": result = WinPic(values); break;             //사진당선-2

                case "420": result = Man2PicDrone(values); break;       //엔텍 드론 2인 경쟁 
                case "421": result = Man3AllDrone(values); break;       //엔텍 드론 3인 전후보 
                case "422": result = Man2PicCloseFight(values); break;  //엔텍 접전 2인 경쟁

                case "500": result = Low2Man2(values); FLayerNo = 1; break;           //2단 2인 경쟁
                case "501": result = Low2Man3(values); FLayerNo = 1; break;           //2단 3인 전후보

                case "503": result = Conner2Man(values); FLayerNo = 2; break;         //좌상단 2인 전후보   사진2장있음
                case "504": result = Conner2Man(values); FLayerNo = 2; break;         //좌상단 2인 1,2위     사진2장있음

                case "510": result = Low2Man2Edu(values); FLayerNo = 1; break;        //교육감 2단 2인 경쟁
                case "511": result = Low2Man3Edu(values); FLayerNo = 1; break;        //교육감 2단 3인 전후보

                case "512": result = Conner2ManEdu(values); FLayerNo = 2; break;       //좌상단 2인 교육감 전후보 득표수   사진2장있음
                case "513": result = Conner2ManEdu(values); FLayerNo = 2; break;       //좌상단 2인 교육감 1,2위              사진2장있음

                case "514": result = Conner2ManEdu1(values); FLayerNo = 2; break;     //좌상단 2인 전후보득표율 NTEK       사진없음 
                case "515": result = Conner2ManEdu2(values); FLayerNo = 2; break;     //좌상단 1인 사진 NTEK                  사진1장 

                case "517": result = Conner2ManNtek1(values); FLayerNo = 2; break;     //좌상단 2인 전후보득표율 NTEK     사진없음 
                case "518": result = Conner2ManNtek2(values); FLayerNo = 2; break;     //좌상단 1인 사진 NTEK                 사진1장 

                case "700": result = Man2PicIronMan(values); break;            // 아이언맨 2인 경쟁 
                case "701": result = Man2PicCaptain(values); break;             // 캡틴아메리카 2인 경쟁 
                case "702": result = Man4PicCaptain(values); break;                       // 캡틴아메리카 4인 경쟁 

                case "900": result = CandMan(values); break;            //후보점검
                case "BG1":
                case "BG2":
                case "BG3": result = true; break;                       //빈화면
                default:
                    return false;
            }

            if (result) this.SwapPrepare(FLayerNo);

            return result;
        }

        public void PlayIn()
        {
            this.SwapIn(FLayerNo);
        }

        //기타 함수
        public void AddParty(string partycode, string rgb1, string rgb2, string rgb3)
        {
            partycode = partycode.Trim();
            if (FPartyList.ContainsKey(partycode))
                FPartyList[partycode] = new PartyColor(rgb1, rgb2, rgb3);
            else
                FPartyList.Add(partycode, new PartyColor(rgb1, rgb2, rgb3));
        }
        public void RemoveParty(string partycode)
        {
            if (FPartyList.ContainsKey(partycode))
                FPartyList.Remove(partycode);
        }
        //선거화면처리





        //역대투표율
        private bool PastVoteRate(Dictionary<string, string> values)
        {
            //역대투표율
            //values = 시/도명 + 4*(선거명n + 투표율n) = 9 items

            if (values.Count() != 9) return false;

            tnEngine.BeginTransaction();

            //시도명 변경
            this.GetObject("시도").SetValue(values["시도"]);
            for (int i = 1; i <= 4; i++)
            {
                this.ReadyScene.GetObject("선거명" + i.ToString()).SetValue(values["선거명" + i.ToString()]);
                this.ReadyScene.GetObject("투표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.ReadyScene.GetObject("투표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["투표율" + i.ToString()]));


                float scale = float.Parse(values["투표율" + i.ToString()]);
                if (scale > 0.0) scale = scale / 100.0f;
                this.ReadyScene.GetObject("그래프" + i.ToString()).SetScaleKey(1, 1.0f, scale, 1.0f, eKVectorType.VECTOR_TYPE_Y);
            }
            tnEngine.EndTransaction();

            return true;
        }


        private bool PastVoteRate2(Dictionary<string, string> values)
        {
            //울산 드론 방식 역대투표율
            //values = 시/도명 + 4*(선거명n + 투표율n) = 9 items

            if (values.Count() != 9) return false;

            tnEngine.BeginTransaction();

            //시도명 변경
            this.GetObject("시도").SetValue(values["시도"]);
            for (int i = 1; i <= 4; i++)
            {
                this.ReadyScene.GetObject("선거명" + i.ToString()).SetValue(values["선거명" + i.ToString()]);
                this.ReadyScene.GetObject("투표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.ReadyScene.GetObject("투표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["투표율" + i.ToString()]));


                float scale = float.Parse(values["투표율" + i.ToString()]);
                if (scale > 0.0) scale = scale / 100.0f;
                this.ReadyScene.GetObject("그래프" + i.ToString()).SetScaleKey(1, 1.0f, scale, 1.0f, eKVectorType.VECTOR_TYPE_Y);
            }
            tnEngine.EndTransaction();

            return true;
        }


        private bool PastVoteRate3(Dictionary<string, string> values)
        {
            //울산 드론 방식 역대투표율
            return true;
        }



        private bool PastVoteRate4(Dictionary<string, string> values)
        {
            // 역대 지선 투표율 
    
            return true;
        }




        private bool Bridge_major1(Dictionary<string, string> values)
        {
            //브릿지 공통 

            try
            {
                tnEngine.BeginTransaction();

                this.GetObject("선거코드").SetValue(values["선거코드"]);
                this.GetObject("국민의선택").SetValue(values["국민의선택"]);
                this.GetObject("시도").SetValue(values["시도"]);
                this.GetObject("직책").SetValue(values["직책"]);

                tnEngine.EndTransaction();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Bridge_major1 오류 : " + ex.Message);
                return false;
            }

            return true;
        }

        private bool Bridge_majorExit(Dictionary<string, string> values)
        {
            //브릿지 출구조사 공통 

            try
            {
                tnEngine.BeginTransaction();

                this.GetObject("직책").SetValue(values["직책"]);

                tnEngine.EndTransaction();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Bridge_majorExit 오류 : " + ex.Message);
                return false;
            }

            return true;
        }


        private bool Bridge_majorRibbon(Dictionary<string, string> values)
        {
            //브릿지 리본 

            try
            {
                tnEngine.BeginTransaction();

                this.GetObject("선거코드").SetValue(values["선거코드"]);

                tnEngine.EndTransaction();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Bridge_majorRibbon 오류 : " + ex.Message);
                return false;
            }
            return true;
        }


        private bool Man3All(Dictionary<string, string> values)
        {
            //광역/국회/기초 3인 전후보
            //values : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            try
            {
                tnEngine.BeginTransaction();

                this.GetObject("직책").SetValue(values["직책"]);
                this.GetObject("개표율").SetValue(values["개표율"]);

                if (values["당선"] == "")
                    this.GetObject("당선").SetVisible(0);
                else
                {
                    this.GetObject("당선").SetValue(values["당선"]);
                    this.GetObject("1위박스").SetVisible(0);
                }

                for (int i = 1; i <= 3; i++)
                {
                    if (values.ContainsKey("성명" + i.ToString()))
                    {
                        this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                        this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                        this.GetObject("사진반사" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                        this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                        this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                        this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                        this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);

                    }
                    else

                        this.GetObject("그룹" + i.ToString()).SetVisible(0);

                }
                tnEngine.EndTransaction();



            } catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Man3All 오류 : " + ex.Message);
                return false;
            }

            return true;
        }


        private bool Man3AllMask(Dictionary<string, string> values)
        {
            //마스킹 광역/국회/기초  3인 전후보
            //values : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            Color c;


            try
            {
                tnEngine.BeginTransaction();

                this.GetObject("직책").SetValue(values["직책"]);
                this.GetObject("개표율").SetValue(values["개표율"]);

                if (values["당선"] == "")
                    this.GetObject("당선").SetVisible(0);
                else
                {
                    this.GetObject("당선").SetValue(values["당선"]);
                    this.GetObject("1위박스").SetVisible(0);
                }

                for (int i = 1; i <= 3; i++)
                {
                    if (values.ContainsKey("성명" + i.ToString()))
                    {
                        this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                        this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                        this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                        this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                        this.GetObject("사진반사" + i.ToString()).SetValue(values["사진반사" + i.ToString()]);
                        this.GetObject("사진톤" + i.ToString()).SetValue(values["사진톤" + i.ToString()]);

                        //마스킹처리
                        c = FPartyList[values["정당코드" + i.ToString()]].C1;
                        this.GetObject("사진톤" + i.ToString()).SetFaceColor(c.R, c.G, c.B, 230);


                        this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                        this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);

                    }
                    else

                        this.GetObject("그룹" + i.ToString()).SetVisible(0);

                }
                tnEngine.EndTransaction();



            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Man3All 오류 : " + ex.Message);
                return false;
            }

            return true;
        }



        private bool Man3AllSejong(Dictionary<string, string> values)
        {
            //대전전용 대전세종 3인 전후보
            //values : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            try
            {
                tnEngine.BeginTransaction();

                this.GetObject("직책").SetValue(values["직책"]);
                this.GetObject("개표율").SetValue(values["개표율"]);
                this.GetObject("백그림").SetValue(values["백그림"]);

                if (values["당선"] == "")
                    this.GetObject("당선").SetVisible(0);
                else
                {
                    this.GetObject("당선").SetValue(values["당선"]);
                    this.GetObject("1위박스").SetVisible(0);
                }

                for (int i = 1; i <= 3; i++)
                {
                    if (values.ContainsKey("성명" + i.ToString()))
                    {
                        this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                        this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                        this.GetObject("사진반사" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                        this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                        this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                        this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                        this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);

                    }
                    else

                        this.GetObject("그룹" + i.ToString()).SetVisible(0);

                }
                tnEngine.EndTransaction();



            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Man3All 오류 : " + ex.Message);
                return false;
            }

            return true;
        }





        private bool Man3AllEdu(Dictionary<string, string> values)
        {
            //교육감 전용 3인판
            //values : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            try
            {
                tnEngine.BeginTransaction();

                //this.GetObject("시도").SetValue(values["시도"]);
                this.GetObject("직책").SetValue(values["직책"]);
                this.GetObject("개표율").SetValue(values["개표율"]);
                if (values["당선"] == "")
                    this.GetObject("당선").SetVisible(0);
                else
                {
                    this.GetObject("당선").SetValue(values["당선"]);
                    this.GetObject("1위박스").SetVisible(0);
                }

                for (int i = 1; i <= 3; i++)
                {
                    if (values.ContainsKey("성명" + i.ToString()))
                    {
                        this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                        this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                        this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                        this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);


                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                        this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                        this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);

                    }
                    else
                    {
                        this.GetObject("그룹" + i.ToString()).SetVisible(0);
                    }
                }
                tnEngine.EndTransaction();



            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Man3AllEdu 오류 : " + ex.Message);
                return false;
            }

            return true;
        } //


        private bool Man3AllDrone(Dictionary<string, string> values)
        {
            //엔텍 드론 광역/국회/기초 3인 전후보
            //values : 시도 + 직책 + 개표율 + 당선 + 3 * (순위n + 성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            try
            {
                tnEngine.BeginTransaction();

                this.GetObject("직책").SetValue(values["직책"]);
                this.GetObject("개표율").SetValue(values["개표율"]);

                if (values["당선"] == "")
                    this.GetObject("당선").SetVisible(0);
                else
                    this.GetObject("당선").SetValue(values["당선"]);


                //드론 백그라운드 세팅 
                this.GetObject("백그림").SetValue(values["백그림"]);
                this.ReadyScene.SetBackgroundVideo(values["백그림"].Trim(), 1, 1);

                for (int i = 1; i <= 3; i++)
                {
                    if (values.ContainsKey("성명" + i.ToString()))
                    {
                        this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                        this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                        this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                        this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                        this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                        this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);

                    }
                    else

                        this.GetObject("그룹" + i.ToString()).SetVisible(0);

                }
                tnEngine.EndTransaction();



            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Man3All 오류 : " + ex.Message);
                return false;
            }

            return true;
        } //



        private bool Man2PicDrone(Dictionary<string, string> values)
        {
            //NTEK 드론 2인경쟁
            //values : 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An)

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            //드론 백그라운드 세팅 
            this.GetObject("백그림").SetValue(values["백그림"]);
            this.ReadyScene.SetBackgroundVideo(values["백그림"].Trim(), 1, 1);


            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            int pyocha = Convert.ToInt32(values["표차"]);
            this.GetObject("표차").SetValue(values["표차"]);

            /*
            //접전그룹 오픈  
            if (Convert.ToInt32(pyocha) < 3000)
            {
                this.GetObject("접전그룹1").SetVisible(1);
                this.GetObject("접전그룹2").SetVisible(1);
            }
            else
            {
                this.GetObject("접전그룹1").SetVisible(0);
                this.GetObject("접전그룹2").SetVisible(0);
            }
            */



            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("사진반사" + i.ToString()).SetValue(values["사진반사" + i.ToString()]);
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);

                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
            }

            tnEngine.EndTransaction();

            return true;
        }


        private bool Man2PicCloseFight(Dictionary<string, string> values)
        {
            //NTEK 접전 2인경쟁 표차 500
            //values : 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An)

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);
            this.GetObject("백그림").SetValue(values["백그림"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            int pyocha = Convert.ToInt32(values["표차"]);
            this.GetObject("표차").SetValue(values["표차"]);

            //접전그룹 오픈  
            if (Convert.ToInt32(pyocha) < 500)
            {
                this.GetObject("접전그룹1").SetVisible(1);
                this.GetObject("접전그룹2").SetVisible(1);
            }
            else
            {
                this.GetObject("접전그룹1").SetVisible(0);
                this.GetObject("접전그룹2").SetVisible(0);
            }


            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);

                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
            }

            tnEngine.EndTransaction();

            return true;
        }


        private bool Man2Pic(Dictionary<string, string> values)
        {
            //광역단체장 사진 2인경쟁
            //values : 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An)

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            this.GetObject("표차").SetValue(values["표차"]);

            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("사진반사" + i.ToString()).SetValue(values["사진반사" + i.ToString()]);
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);

                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
            }

            tnEngine.EndTransaction();

            return true;
        }

        private bool Man5Pic(Dictionary<string, string> values)
        {
            //광역단체장 사진 5인경쟁
            //values : 직책 + 개표율 + 당선 + 사진 + 정당A + 5 * (성명n + 득표수n + 투표율n + 정당Bn)

            Color c;

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            for (int i = 1; i <= 5; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);

                    if (i == 1)
                    {
                        this.GetObject("사진반사" + i.ToString()).SetValue(values["사진반사" + i.ToString()]);
                        this.GetObject("사진톤" + i.ToString()).SetValue(values["사진톤" + i.ToString()]);
                        this.GetObject("정당바" + i.ToString()).SetValue(values["정당바" + i.ToString()]);
                        this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);

                        //마스킹처리
                        c = FPartyList[values["정당코드" + i.ToString()]].C1;
                        this.GetObject("사진톤" + i.ToString()).SetFaceColor(c.R, c.G, c.B, 230);
                    }
                    else
                    {
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                        this.GetObject("정당바" + i.ToString()).SetValue(values["정당바" + i.ToString()]);
                    }

                }
                else
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
            } //for

            tnEngine.EndTransaction();

            return true;

        }

        private bool Man2Edu(Dictionary<string, string> values)
        {
            //교육감 2인경쟁
            //values : 직책 + 개표율 + 당선구분 + 표차 + 2 * (사진n + 성명n + 득표수n + 투표율n)
            // 정당A(정당명), 정당B(이름백)


            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);

            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            this.GetObject("표차").SetValue(values["표차"]);

            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("사진반사" + i.ToString()).SetValue(values["사진반사" + i.ToString()]);
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

            }
            tnEngine.EndTransaction();

            return true;
        }

        private bool Man5Edu(Dictionary<string, string> values)
        {
            //교육감 5인경쟁
            //values : 직책 + 개표율 + 당선 + 사진 + 정당A + 5 * (성명n + 득표수n + 투표율n + 정당Bn)

            Color c;

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);

            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }


            for (int i = 1; i <= 5; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);


                    if (i == 1)
                    {
                        this.GetObject("사진반사" + i.ToString()).SetValue(values["사진반사" + i.ToString()]);
                        this.GetObject("사진톤" + i.ToString()).SetValue(values["사진톤" + i.ToString()]);
                        this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);

                        //마스킹처리
                        c = FPartyList[values["정당코드" + i.ToString()]].C1;
                        this.GetObject("정당바" + i.ToString()).SetValue(values["정당바" + i.ToString()]);
                        this.GetObject("사진톤" + i.ToString()).SetFaceColor(c.R, c.G, c.B, 230);
                    }
                    else
                    {
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                    }
                } //if
                else
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
            } //for
            tnEngine.EndTransaction();

            return true;
        }

        private bool Man2Bas(Dictionary<string, string> values)
        {
            //SBS 2인경쟁
            //values : 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn + 정당코드n) + OutTrigger

            //Color c;

            tnEngine.BeginTransaction();

            //시도에러 수정요망  
            this.GetObject("직책").SetValue(values["직책"]);

            //시도 숨김
            this.GetObject("시도").SetVisible(0);

            this.GetObject("개표율").SetValue(values["개표율"]);
            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("당선").SetVisible(1);
                this.GetObject("1위박스").SetVisible(0);
            }

            this.GetObject("표차").SetValue(values["표차"]);

            for (int i = 1; i <= 2; i++)
            {

                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                    this.GetObject("사진반사" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);

                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                    this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                    this.GetObject("정당B" + i.ToString()).SetValue(values["정당B" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
            } //for

            tnEngine.EndTransaction();

            return true;
        }

        private bool Man4Bas(Dictionary<string, string> values)
        {
            //사진  구군시장 4인 현재1위
            //values : 시도 + 4 * (직책n + 당선n + 사진n + 성명n + 득표율n + 득표수n + 정당n + 정당An + 정당코드n)

            tnEngine.BeginTransaction();
            this.GetObject("시도").SetValue(values["시도"]);

            for (int i = 1; i <= 4; i++)
            {
                string no = i.ToString();
                if (values.ContainsKey("당선" + no))
                {
                    this.GetObject("직책" + no).SetValue(values["직책" + no]);

                    if (values["당선" + no] == "")
                        this.GetObject("당선" + no).SetVisible(0);
                    else
                        this.GetObject("당선" + no).SetValue(values["당선" + no]);

                    this.GetObject("사진" + no).SetValue(values["사진" + no]);
                    this.GetObject("성명" + no).SetValue(values["성명" + no]);
                    this.GetObject("득표수" + no).SetValue(values["득표수" + no]);

                    this.GetObject("득표율" + no).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + no).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    this.GetObject("정당A" + no).SetValue(values["정당A" + no]);
                    this.GetObject("정당SB" + no).SetValue(values["정당SB" + no]);
                }
                else
                    this.GetObject("그룹" + no).SetVisible(0);
            }
            tnEngine.EndTransaction();

            return true;
        }


        private bool Man2BasSejong(Dictionary<string, string> values)
        {
            //대전전용 세종 2인경쟁
            //values : 시도 + 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당Bn + 정당코드n) + OutTrigger

            //Color c;

            tnEngine.BeginTransaction();

            //시도에러 수정요망  
            this.GetObject("직책").SetValue(values["직책"]);

            //시도 숨김
            this.GetObject("시도").SetVisible(0);

            this.GetObject("개표율").SetValue(values["개표율"]);
            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("당선").SetVisible(1);
                this.GetObject("1위박스").SetVisible(0);
            }

            this.GetObject("표차").SetValue(values["표차"]);
            this.GetObject("백그림").SetValue(values["백그림"]);

            for (int i = 1; i <= 2; i++)
            {

                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                    this.GetObject("사진반사" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);

                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                    this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                    this.GetObject("정당B" + i.ToString()).SetValue(values["정당B" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
            } //for

            tnEngine.EndTransaction();

            return true;
        }
        private bool Man4BasDrone(Dictionary<string, string> values)
        {
            //NTEK 드론 구군시장 4인 현재1위
            //values : 시도 + 4 * (직책n + 당선n + 사진n + 성명n + 득표율n + 득표수n + 정당n + 정당An + 정당코드n)

            //드론 백그라운드 세팅 
            this.GetObject("백그림").SetValue(values["백그림"]);
            this.ReadyScene.SetBackgroundVideo(values["백그림"].Trim(), 1, 1);

            try {

                tnEngine.BeginTransaction();

                this.GetObject("시도").SetValue(values["시도"]);

                this.ReadyScene.SetBackgroundVideo(values["백그림"].Trim(), 1, 1);

                for (int i = 1; i <= 4; i++)
                {
                    string no = i.ToString();
                    if (values.ContainsKey("당선" + no))
                    {
                        this.GetObject("직책" + no).SetValue(values["직책" + no]);

                        if (values["당선" + no] == "")
                            this.GetObject("당선" + no).SetVisible(0);
                        else
                            this.GetObject("당선" + no).SetValue(values["당선" + no]);

                        this.GetObject("사진" + no).SetValue(values["사진" + no]);
                        this.GetObject("성명" + no).SetValue(values["성명" + no]);
                        this.GetObject("득표수" + no).SetValue(values["득표수" + no]);

                        this.GetObject("득표율" + no).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + no).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                        this.GetObject("정당A" + no).SetValue(values["정당A" + no]);
                        this.GetObject("정당SB" + no).SetValue(values["정당SB" + no]);
                    }
                    else
                        this.GetObject("그룹" + no).SetVisible(0);
                }
                tnEngine.EndTransaction();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("### Man4BasDrone 오류 : " + ex.Message);
                return false;
            }

            return true;
        } //



        private bool WinMov(Dictionary<string, string> values)
        {
            //광역단체장 영상 당선
            //values : 직책 + 사진 + 성명 + 프로필1 + 프로필2 + 프로필3 + 프로필4 + 득표수 + 득표율 + 정당 + 정당A

            tnEngine.BeginTransaction();
            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("사진").SetValue(values["사진"]);
            this.GetObject("성명").SetValue(values["성명"]);
            this.GetObject("프로필1").SetValue(values["프로필1"]);
            this.GetObject("프로필2").SetValue(values["프로필2"]);
            this.GetObject("프로필3").SetValue(values["프로필3"]);
            this.GetObject("프로필4").SetValue(values["프로필4"]);
            if (values["당선구분"] == "80")
            {
                this.GetObject("득표율").SetVisible(0);
                this.GetObject("무투표").SetVisible(1);
            }
            else
            {
                this.GetObject("득표율").SetCounterNumber(Convert.ToDouble(values["득표율"]));
                this.GetObject("무투표").SetVisible(0);
            }
            this.GetObject("정당").SetValue(values["정당"]);
            this.GetObject("정당A").SetValue(values["정당A"]);
            tnEngine.EndTransaction();

            return true;
        }

        private bool WinPic(Dictionary<string, string> values)
        {
            //광역/기초/교육감/국회의원 공통 당선
            //values : 선거코드 + 직책 + 사진 + 성명 + 프로필1 + 프로필2 + 프로필3 + 프로필4 + 득표수 + 득표율 + 정당 + 정당A

            values["선거코드"] = values["선거코드"].Trim();
            tnEngine.BeginTransaction();
            this.GetObject("국민의선택").SetValue(values["국민의선택"]);
            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("사진").SetValue(values["사진"]);
            this.GetObject("사진반사").SetValue(values["사진반사"]);
            this.GetObject("성명").SetValue(values["성명"]);
            this.GetObject("프로필1").SetValue(values["프로필1"]);
            this.GetObject("프로필2").SetValue(values["프로필2"]);
            this.GetObject("프로필3").SetValue(values["프로필3"]);
            this.GetObject("프로필4").SetValue(values["프로필4"]);

            this.GetObject("정당KB").SetValue(values["정당KB"]);
            this.GetObject("정당SA").SetValue(values["정당SA"]);

            if (values["당선구분"] == "80")
            {
                this.GetObject("득표율").SetVisible(0);
                this.GetObject("무투표").SetVisible(1);
            }
            else

            {
                this.GetObject("득표율").SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율").SetCounterNumberKey(1, Convert.ToDouble(values["득표율"]));
                this.GetObject("무투표").SetVisible(0);

            }



            tnEngine.EndTransaction();

            return true;
        }

        private bool Low2Man2(Dictionary<string, string> values)
        {
            //국회/광역/기초 2단 2인경쟁
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선구분 + 표차 + + 하단바 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            //Color c;

            tnEngine.BeginTransaction();
            values["선거코드"] = values["선거코드"].Trim();

            this.GetObject("직책").SetValue(values["직책"]);
            //this.GetObject("시도").SetVisible(0);


            this.GetObject("개표율").SetValue(values["개표율"]);
            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            this.GetObject("표차").SetValue(values["표차"]);
            this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));


            }
            tnEngine.EndTransaction();

            return true;
        }//



        private bool Low2Man3(Dictionary<string, string> values)
        {
            //국회/광역/기초 2단 3인 전후보
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            //Color c;

            tnEngine.BeginTransaction();


            //r고쳐

            // this.GetObject("시도").SetVisible(0);
            this.GetObject("직책").SetValue(values["직책"]);


            //3인판에서 삭제처리 
            this.GetObject("지역구1").SetVisible(0);
            this.GetObject("지역구2").SetVisible(0);
            this.GetObject("지역구3").SetVisible(0);


            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 3; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                    this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                }
                else
                {
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
                }
            }
            tnEngine.EndTransaction();

            return true;
        }

        private bool Low2Man2Edu(Dictionary<string, string> values)
        {
            //교육감전용 2단 2인경쟁
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선구분 + 표차 + + 하단바 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            //Color c;

            tnEngine.BeginTransaction();
            values["선거코드"] = values["선거코드"].Trim();

            this.GetObject("직책").SetValue(values["직책"]);
            //this.GetObject("시도").SetVisible(0);

            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            this.GetObject("표차").SetValue(values["표차"]);

            this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);


            }
            tnEngine.EndTransaction();

            return true;
        }//

        private bool Low2Man3Edu(Dictionary<string, string> values)
        {
            //교육감전용  2단 3인 전후보
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            tnEngine.BeginTransaction();
            values["선거코드"] = values["선거코드"].Trim();
            //this.GetObject("시도").SetVisible(0);
            this.GetObject("직책").SetValue(values["직책"]);


            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }
            this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 3; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                    this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);

                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                }
                else
                {
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
                }
            }
            tnEngine.EndTransaction();

            return true;
        } //



        private bool Conner2Man(Dictionary<string, string> values)
        {
            //상단 2인 1,2위 광역/교육/기초 좌  (503) 사진  2장 
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
                this.GetObject("당선").SetValue(values["당선"]);

            //this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 3; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                    this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);

                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                {
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
                }
            }
            tnEngine.EndTransaction();

            return true;
        }//

        private bool Conner2ManEdu(Dictionary<string, string> values)
        {
            //좌상단 2인 1,2위 교육감  (513) (512) 사진2장 있음
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
                this.GetObject("당선").SetValue(values["당선"]);

            //this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 3; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                    this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);

                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                {
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
                }
            }
            tnEngine.EndTransaction();

            return true;
        }//




        private bool Conner2ManEdu1(Dictionary<string, string> values)
        {
            //NTEK 좌상단 교육감 전후보 2인 득표율 출력   (514) 사진없음 
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
                this.GetObject("당선").SetValue(values["당선"]);

            //this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 3; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                    this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);

                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                {
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
                }
            }
            tnEngine.EndTransaction();

            return true;
        }//


        private bool Conner2ManEdu2(Dictionary<string, string> values)
        {
            //NTEK 좌상단 1인 사진용 출력  (515) 사진1장 
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
                this.GetObject("당선").SetValue(values["당선"]);

            //this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 3; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);

                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);

                    this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);

                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                {
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
                }
            }
            tnEngine.EndTransaction();

            return true;
        }//


        private bool Conner2ManNtek1(Dictionary<string, string> values)
        {
            //NTEK 좌상단 2인 득표율 출력   (517) 사진없음 
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
                this.GetObject("당선").SetValue(values["당선"]);

            //this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 3; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                    this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);

                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                {
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
                }
            }
            tnEngine.EndTransaction();

            return true;
        }//


        private bool Conner2ManNtek2(Dictionary<string, string> values)
        {
            //NTEK 좌상단 1인 사진용 출력 
            //values : 선거코드 + 시도 + 직책 + 개표율 + 당선 + 3 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)


            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
                this.GetObject("당선").SetValue(values["당선"]);

            //this.GetObject("하단바").SetValue(values["하단바"]);

            for (int i = 1; i <= 3; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                    this.GetObject("순위" + i.ToString()).SetValue(values["순위" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);

                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    this.GetObject("정당KB" + i.ToString()).SetValue(values["정당KB" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                {
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
                }
            }
            tnEngine.EndTransaction();

            return true;
        }//


        private bool Man2Mov(Dictionary<string, string> values)
        {
            //광역단체장 영상 2인경쟁
            //values : 직책 + 개표율 + 당선구분 + 표차 + 2 * (사진n + 성명n + 득표수n + 투표율n + 정당An + 정당Bn + 정당코드n)
            // 정당A(정당명), 정당B(이름백)

            Color c;

            tnEngine.BeginTransaction();
            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);
            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
                this.GetObject("당선").SetValue(values["당선"]);
            this.GetObject("표차").SetValue(values["표차"]);
            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);


                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                c = FPartyList[values["정당코드" + i.ToString()]].C2;
                this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                this.GetObject("정당" + i.ToString()).SetFaceColor(c.R, c.G, c.B, 230);
                this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
            }


            tnEngine.EndTransaction();

            return true;
        }

        private bool Man5Mov(Dictionary<string, string> values)
        {
            //광역단체장 영상 5인경쟁
            //values : 직책 + 개표율 + 당선구분 + 사진 + 정당A + 5 * (성명n + 득표수n + 투표율n + 정당n + 정당An + 정당코드n)

            Color c;

            tnEngine.BeginTransaction();
            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);


            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
                this.GetObject("당선").SetValue(values["당선"]);


            this.GetObject("사진").SetValue(values["사진"]);

            for (int i = 1; i <= 5; i++)
            {
                if (values.ContainsKey("성명" + i.ToString()))
                {
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);

                    if (i == 1)
                    {

                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    }
                    else
                    {
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                        this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));
                    }

                    c = FPartyList[values["정당코드" + i.ToString()]].C2;
                    this.GetObject("정당" + i.ToString()).SetFaceColor(c.R, c.G, c.B, c.A);
                    this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                    this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                }
                else
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
            } //랙



            tnEngine.EndTransaction();

            return true;
        } //



        private bool CandManProfile(Dictionary<string, string> values)
        {
            //후보프로필 
            //values : 선거코드 + 직책 + 영상A + 사진A + 사진B + 기호 + 성명 + 프로필1 + 프로필2 + 프로필3 + 프로필4 + 득표수 + 득표율 + 정당 + 정당A

            values["선거코드"] = values["선거코드"].Trim();

            tnEngine.BeginTransaction();

            this.GetObject("시도").SetValue(values["시도"]);
            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("국민의선택").SetValue(values["국민의선택"]);

            this.GetObject("성명1").SetValue(values["성명1"]);


            if (values["포토1"] == "" ||  values["포토2"] =="" || values["포토3"] == "")
            {
                this.GetObject("사진첩").SetVisible(0);
            }  else
                this.GetObject("사진첩").SetVisible(1);


            this.GetObject("기호").SetValue(values["기호"]);
            this.GetObject("사진1").SetValue(values["사진1"]);
            this.GetObject("사진반사1").SetValue(values["사진반사1"]);

            this.GetObject("포토1").SetValue(values["포토1"]);
            this.GetObject("포토2").SetValue(values["포토2"]);
            this.GetObject("포토3").SetValue(values["포토3"]);

            this.GetObject("프로필1").SetValue(values["프로필1"]);
            this.GetObject("프로필2").SetValue(values["프로필2"]);
            this.GetObject("프로필3").SetValue(values["프로필3"]);
            this.GetObject("프로필4").SetValue(values["프로필4"]);

            this.GetObject("정당").SetValue(values["정당"]);
            this.GetObject("정당SB1").SetValue(values["정당SB1"]);
            this.GetObject("정당KB1").SetValue(values["정당KB1"]);

            tnEngine.EndTransaction();

            return true;
        }


        private bool Man2PicIronMan(Dictionary<string, string> values)
        {
            //아이언맨  2인경쟁
            //values : 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An)

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
            }

            this.GetObject("표차").SetValue(values["표차"]);

            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);
                this.GetObject("닫힌헬멧" + i.ToString()).SetValue(values["닫힌헬멧" + i.ToString()]);
                this.GetObject("바디" + i.ToString()).SetValue(values["바디" + i.ToString()]);

                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
            }

            tnEngine.EndTransaction();

            return true;
        }

        private bool Man2PicCaptain(Dictionary<string, string> values)
        {
            //캡틴아메리카  2인경쟁
            //values : 직책 + 개표율 + 당선구분 + 표차 + 2 * (성명n + 득표수n + 투표율n + 정당n + 정당An)

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
            }

            this.GetObject("표차").SetValue(values["표차"]);

            for (int i = 1; i <= 2; i++)
            {
                this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);

                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
            }

            tnEngine.EndTransaction();

            return true;
        }


        private bool Man4PicCaptain(Dictionary<string, string> values)
        {
            //캡틴아메리카 4인경쟁
            //values : 직책 + 개표율 + 당선 + 사진 + 정당A + 5 * (성명n + 득표수n + 투표율n + 정당Bn)

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("개표율").SetValue(values["개표율"]);

            if (values["당선"] == "")
                this.GetObject("당선").SetVisible(0);
            else
            {
                this.GetObject("당선").SetValue(values["당선"]);
                this.GetObject("1위박스").SetVisible(0);
            }

            //this.GetObject("표차").SetValue(values["표차"]);

            for (int i = 1; i <= 4; i++)
            {
                if (values.ContainsKey("성명" + i.ToString())) {
                    this.GetObject("사진" + i.ToString()).SetValue(values["사진" + i.ToString()]);
                    this.GetObject("성명" + i.ToString()).SetValue(values["성명" + i.ToString()]);
                    this.GetObject("득표수" + i.ToString()).SetValue(values["득표수" + i.ToString()]);

                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(0, 0.0);
                    this.GetObject("득표율" + i.ToString()).SetCounterNumberKey(1, Convert.ToDouble(values["득표율" + i.ToString()]));

                    //   this.GetObject("정당" + i.ToString()).SetValue(values["정당" + i.ToString()]);
                    this.GetObject("정당A" + i.ToString()).SetValue(values["정당A" + i.ToString()]);
                    this.GetObject("정당SB" + i.ToString()).SetValue(values["정당SB" + i.ToString()]);
                }
                else
                    this.GetObject("그룹" + i.ToString()).SetVisible(0);
            }  //for 

            tnEngine.EndTransaction();

            return true;

        }



        private bool CandMan(Dictionary<string, string> values)
        {
            //후보점검
            //values : 선거코드 + 직책 + 영상A + 사진A + 사진B + 기호 + 성명 + 프로필1 + 프로필2 + 프로필3 + 프로필4 + 득표수 + 득표율 + 정당 + 정당A

            values["선거코드"] = values["선거코드"].Trim();

            tnEngine.BeginTransaction();

            this.GetObject("직책").SetValue(values["직책"]);
            this.GetObject("시도").SetValue(values["시도"]);

            this.GetObject("기호").SetValue(values["기호"]);
            this.GetObject("사진A").SetValue(values["사진A"]);
            this.GetObject("사진B").SetValue(values["사진B"]);
            this.GetObject("성명").SetValue(values["성명"]);
            this.GetObject("프로필1").SetValue(values["프로필1"]);
            this.GetObject("프로필2").SetValue(values["프로필2"]);
            this.GetObject("프로필3").SetValue(values["프로필3"]);
            this.GetObject("프로필4").SetValue(values["프로필4"]);

            this.GetObject("정당").SetValue(values["정당"]);
            this.GetObject("정당SA").SetValue(values["정당SA"]);
            this.GetObject("정당SB").SetValue(values["정당SB"]);
            this.GetObject("정당SC").SetValue(values["정당A"]);

            this.GetObject("정당A").SetValue(values["정당A"]);
            this.GetObject("정당B").SetValue(values["정당B"]);
            this.GetObject("정당C").SetValue(values["정당C"]);
            this.GetObject("정당D").SetValue(values["정당D"]);
            this.GetObject("정당E").SetValue(values["정당E"]);
            this.GetObject("정당F").SetValue(values["정당F"]);
            this.GetObject("정당G").SetValue(values["정당G"]);
            this.GetObject("정당H").SetValue(values["정당H"]);
            this.GetObject("정당I").SetValue(values["정당I"]);

            tnEngine.EndTransaction();

            return true;
        }
    }
}
