﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Election
{
    public partial class frmConf : Form
    {
        public frmConf()
        {
            InitializeComponent();
        }

        private void frmConf_Load(object sender, EventArgs e)
        {
            tbSysName.Text = Global.SystemName;
            tbIP.Text = Global.TornadoIP;
            tbPort.Text = Global.TornadoPort;
            tbScenePath.Text = Global.TornadoScenePath;
            //tbTgaSeqPath.Text = Global.TornadoTgaSeqPath;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Global.SystemName = tbSysName.Text;
            Global.TornadoIP = tbIP.Text;
            Global.TornadoPort = tbPort.Text;
            Global.TornadoScenePath = tbScenePath.Text;
            //Global.TornadoTgaSeqPath = tbTgaSeqPath.Text;
        }
    }
}
