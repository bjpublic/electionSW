﻿namespace Election
{
    partial class frmMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.mnMain = new System.Windows.Forms.MenuStrip();
            this.miMenuElec = new System.Windows.Forms.ToolStripMenuItem();
            this.miCode = new System.Windows.Forms.ToolStripMenuItem();
            this.miPrec = new System.Windows.Forms.ToolStripMenuItem();
            this.miCand = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.miOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.miMenuTemp = new System.Windows.Forms.ToolStripMenuItem();
            this.miMakePhoto = new System.Windows.Forms.ToolStripMenuItem();
            this.miMakeOpenData = new System.Windows.Forms.ToolStripMenuItem();
            this.miMenuConf = new System.Windows.Forms.ToolStripMenuItem();
            this.panTop = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.btnLog = new System.Windows.Forms.Button();
            this.btnOnair = new System.Windows.Forms.Button();
            this.lbOnair = new System.Windows.Forms.Label();
            this.bsQsheet = new System.Windows.Forms.BindingSource(this.components);
            this.openDataSet = new Election.OpenDataSet();
            this.panLeft = new System.Windows.Forms.Panel();
            this.dgvQsheet = new System.Windows.Forms.DataGridView();
            this.Seq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panQsheetSum = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panQControll = new System.Windows.Forms.Panel();
            this.btnQsheetDelAll = new System.Windows.Forms.Button();
            this.btnQsheetDel = new System.Windows.Forms.Button();
            this.btnQsheetSave = new System.Windows.Forms.Button();
            this.btnQsheetLoad = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.panRight = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpOnair = new System.Windows.Forms.TabPage();
            this.dgvCand = new System.Windows.Forms.DataGridView();
            this.rankDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.korNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.votesCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.votesRateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PartyName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsCandSBS = new System.Windows.Forms.BindingSource(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.dgvPrec = new System.Windows.Forms.DataGridView();
            this.PrecName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openRateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openYNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fstNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ElecGbnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modHMSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsPrecSBS = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.panOnairOption = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.cbBG = new System.Windows.Forms.ComboBox();
            this.btnBlank = new System.Windows.Forms.Button();
            this.gbAuto = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbTimer = new System.Windows.Forms.TextBox();
            this.rbUnloop = new System.Windows.Forms.RadioButton();
            this.rbLoop = new System.Windows.Forms.RadioButton();
            this.gbIn = new System.Windows.Forms.GroupBox();
            this.rbInMan = new System.Windows.Forms.RadioButton();
            this.rbInAuto = new System.Windows.Forms.RadioButton();
            this.gbBack = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbLowBack = new System.Windows.Forms.ComboBox();
            this.bsCompCode = new System.Windows.Forms.BindingSource(this.components);
            this.tpQsheet = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dgvQscene = new System.Windows.Forms.DataGridView();
            this.aDescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsScene = new System.Windows.Forms.BindingSource(this.components);
            this.splitter4 = new System.Windows.Forms.Splitter();
            this.dgvQprec = new System.Windows.Forms.DataGridView();
            this.precNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.candCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsPrec = new System.Windows.Forms.BindingSource(this.components);
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.panQbutton = new System.Windows.Forms.Panel();
            this.btnQall = new System.Windows.Forms.Button();
            this.btnQone = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbQcity = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbQElecCatgr = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panOnairControll = new System.Windows.Forms.Panel();
            this.cbOut = new System.Windows.Forms.ComboBox();
            this.btnOut = new System.Windows.Forms.Button();
            this.btnIn = new System.Windows.Forms.Button();
            this.btnSkip = new System.Windows.Forms.Button();
            this.btnReady = new System.Windows.Forms.Button();
            this.taQsheet = new Election.OpenDataSetTableAdapters.Ele_TQsheetTableAdapter();
            this.taCompCode = new Election.OpenDataSetTableAdapters.Ele_MCompCodeTableAdapter();
            this.taPrec = new Election.OpenDataSetTableAdapters.Ele_TPrecTableAdapter();
            this.taQueries = new Election.OpenDataSetTableAdapters.QueriesTableAdapter();
            this.taPrecSBS = new Election.OpenDataSetTableAdapters.Ele_TPrecSBSTableAdapter();
            this.taCandSBS = new Election.OpenDataSetTableAdapters.Ele_TCandSBSTableAdapter();
            this.taCandSBS1 = new Election.OpenDataSetTableAdapters.Ele_TCandSBS1TableAdapter();
            this.tmAuto = new System.Windows.Forms.Timer(this.components);
            this.mnMain.SuspendLayout();
            this.panTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsQsheet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.openDataSet)).BeginInit();
            this.panLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQsheet)).BeginInit();
            this.panQsheetSum.SuspendLayout();
            this.panQControll.SuspendLayout();
            this.panRight.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpOnair.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCandSBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecSBS)).BeginInit();
            this.panOnairOption.SuspendLayout();
            this.gbAuto.SuspendLayout();
            this.gbIn.SuspendLayout();
            this.gbBack.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsCompCode)).BeginInit();
            this.tpQsheet.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQscene)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsScene)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQprec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrec)).BeginInit();
            this.panQbutton.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panOnairControll.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnMain
            // 
            this.mnMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miMenuElec,
            this.miMenuTemp,
            this.miMenuConf});
            this.mnMain.Location = new System.Drawing.Point(0, 0);
            this.mnMain.Name = "mnMain";
            this.mnMain.Size = new System.Drawing.Size(1073, 24);
            this.mnMain.TabIndex = 0;
            this.mnMain.Text = "menuStrip1";
            // 
            // miMenuElec
            // 
            this.miMenuElec.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miCode,
            this.miPrec,
            this.miCand,
            this.toolStripMenuItem1,
            this.miOpen});
            this.miMenuElec.Name = "miMenuElec";
            this.miMenuElec.Size = new System.Drawing.Size(67, 20);
            this.miMenuElec.Text = "선거자료";
            // 
            // miCode
            // 
            this.miCode.Name = "miCode";
            this.miCode.Size = new System.Drawing.Size(146, 22);
            this.miCode.Text = "코드관리";
            this.miCode.Click += new System.EventHandler(this.miCode_Click);
            // 
            // miPrec
            // 
            this.miPrec.Name = "miPrec";
            this.miPrec.Size = new System.Drawing.Size(146, 22);
            this.miPrec.Text = "선거구관리";
            this.miPrec.Click += new System.EventHandler(this.miPrec_Click);
            // 
            // miCand
            // 
            this.miCand.Name = "miCand";
            this.miCand.Size = new System.Drawing.Size(146, 22);
            this.miCand.Text = "후보관리";
            this.miCand.Click += new System.EventHandler(this.miCand_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(143, 6);
            // 
            // miOpen
            // 
            this.miOpen.Name = "miOpen";
            this.miOpen.Size = new System.Drawing.Size(146, 22);
            this.miOpen.Text = "개표자료관리";
            this.miOpen.Click += new System.EventHandler(this.miOpen_Click);
            // 
            // miMenuTemp
            // 
            this.miMenuTemp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miMakePhoto,
            this.miMakeOpenData});
            this.miMenuTemp.Name = "miMenuTemp";
            this.miMenuTemp.Size = new System.Drawing.Size(67, 20);
            this.miMenuTemp.Text = "임시자료";
            // 
            // miMakePhoto
            // 
            this.miMakePhoto.Name = "miMakePhoto";
            this.miMakePhoto.Size = new System.Drawing.Size(158, 22);
            this.miMakePhoto.Text = "후보사진생성";
            this.miMakePhoto.Click += new System.EventHandler(this.miMakePhoto_Click);
            // 
            // miMakeOpenData
            // 
            this.miMakeOpenData.Name = "miMakeOpenData";
            this.miMakeOpenData.Size = new System.Drawing.Size(158, 22);
            this.miMakeOpenData.Text = "개표자료발생기";
            this.miMakeOpenData.Click += new System.EventHandler(this.miMakeOpenData_Click);
            // 
            // miMenuConf
            // 
            this.miMenuConf.Name = "miMenuConf";
            this.miMenuConf.Size = new System.Drawing.Size(43, 20);
            this.miMenuConf.Text = "설정";
            this.miMenuConf.Click += new System.EventHandler(this.miMenuConf_Click);
            // 
            // panTop
            // 
            this.panTop.Controls.Add(this.label12);
            this.panTop.Controls.Add(this.btnLog);
            this.panTop.Controls.Add(this.btnOnair);
            this.panTop.Controls.Add(this.lbOnair);
            this.panTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panTop.Location = new System.Drawing.Point(0, 24);
            this.panTop.Name = "panTop";
            this.panTop.Size = new System.Drawing.Size(1073, 42);
            this.panTop.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(388, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(577, 12);
            this.label12.TabIndex = 3;
            this.label12.Text = "※ F1:Ready, F2:In, F3:빈화면, Ctrl+F3:Out, Esc:빈화면, Space:In, Out Click:빈화면, Ctrl+Ou" +
    "t Click: Out";
            // 
            // btnLog
            // 
            this.btnLog.Location = new System.Drawing.Point(243, 6);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(130, 30);
            this.btnLog.TabIndex = 2;
            this.btnLog.Text = "Tornado Log";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // btnOnair
            // 
            this.btnOnair.Location = new System.Drawing.Point(119, 6);
            this.btnOnair.Name = "btnOnair";
            this.btnOnair.Size = new System.Drawing.Size(118, 30);
            this.btnOnair.TabIndex = 1;
            this.btnOnair.Text = "ON";
            this.btnOnair.UseVisualStyleBackColor = true;
            this.btnOnair.Click += new System.EventHandler(this.btnOnair_Click);
            // 
            // lbOnair
            // 
            this.lbOnair.BackColor = System.Drawing.Color.Green;
            this.lbOnair.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbOnair.Font = new System.Drawing.Font("HY견고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbOnair.Location = new System.Drawing.Point(6, 6);
            this.lbOnair.Name = "lbOnair";
            this.lbOnair.Size = new System.Drawing.Size(107, 30);
            this.lbOnair.TabIndex = 0;
            this.lbOnair.Text = "READY";
            this.lbOnair.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bsQsheet
            // 
            this.bsQsheet.DataMember = "Ele_TQsheet";
            this.bsQsheet.DataSource = this.openDataSet;
            // 
            // openDataSet
            // 
            this.openDataSet.DataSetName = "OpenDataSet";
            this.openDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panLeft
            // 
            this.panLeft.Controls.Add(this.dgvQsheet);
            this.panLeft.Controls.Add(this.panQsheetSum);
            this.panLeft.Controls.Add(this.label1);
            this.panLeft.Controls.Add(this.panQControll);
            this.panLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panLeft.Location = new System.Drawing.Point(0, 66);
            this.panLeft.MinimumSize = new System.Drawing.Size(500, 0);
            this.panLeft.Name = "panLeft";
            this.panLeft.Size = new System.Drawing.Size(520, 526);
            this.panLeft.TabIndex = 3;
            // 
            // dgvQsheet
            // 
            this.dgvQsheet.AllowUserToAddRows = false;
            this.dgvQsheet.AllowUserToDeleteRows = false;
            this.dgvQsheet.AllowUserToResizeColumns = false;
            this.dgvQsheet.AllowUserToResizeRows = false;
            this.dgvQsheet.AutoGenerateColumns = false;
            this.dgvQsheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQsheet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Seq,
            this.dataGridViewTextBoxColumn5});
            this.dgvQsheet.DataSource = this.bsQsheet;
            this.dgvQsheet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvQsheet.Location = new System.Drawing.Point(0, 24);
            this.dgvQsheet.MultiSelect = false;
            this.dgvQsheet.Name = "dgvQsheet";
            this.dgvQsheet.ReadOnly = true;
            this.dgvQsheet.RowHeadersVisible = false;
            this.dgvQsheet.RowTemplate.Height = 23;
            this.dgvQsheet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQsheet.Size = new System.Drawing.Size(520, 433);
            this.dgvQsheet.TabIndex = 7;
            this.dgvQsheet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQsheet_CellContentClick);
            this.dgvQsheet.SelectionChanged += new System.EventHandler(this.dgvQsheet_SelectionChanged);
            this.dgvQsheet.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvQsheet_KeyDown);
            // 
            // Seq
            // 
            this.Seq.DataPropertyName = "Seq";
            this.Seq.HeaderText = "No";
            this.Seq.Name = "Seq";
            this.Seq.ReadOnly = true;
            this.Seq.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Seq.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CutName";
            this.dataGridViewTextBoxColumn5.HeaderText = "화면명";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 450;
            // 
            // panQsheetSum
            // 
            this.panQsheetSum.Controls.Add(this.label9);
            this.panQsheetSum.Controls.Add(this.label8);
            this.panQsheetSum.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panQsheetSum.Location = new System.Drawing.Point(0, 457);
            this.panQsheetSum.Name = "panQsheetSum";
            this.panQsheetSum.Size = new System.Drawing.Size(520, 30);
            this.panQsheetSum.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(152, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "잔여수 :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "화면수 :";
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(520, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "선거방송 큐시트";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panQControll
            // 
            this.panQControll.Controls.Add(this.btnQsheetDelAll);
            this.panQControll.Controls.Add(this.btnQsheetDel);
            this.panQControll.Controls.Add(this.btnQsheetSave);
            this.panQControll.Controls.Add(this.btnQsheetLoad);
            this.panQControll.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panQControll.Location = new System.Drawing.Point(0, 487);
            this.panQControll.Name = "panQControll";
            this.panQControll.Size = new System.Drawing.Size(520, 39);
            this.panQControll.TabIndex = 1;
            // 
            // btnQsheetDelAll
            // 
            this.btnQsheetDelAll.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnQsheetDelAll.Location = new System.Drawing.Point(379, 5);
            this.btnQsheetDelAll.Name = "btnQsheetDelAll";
            this.btnQsheetDelAll.Size = new System.Drawing.Size(118, 30);
            this.btnQsheetDelAll.TabIndex = 5;
            this.btnQsheetDelAll.Text = "모두삭제";
            this.btnQsheetDelAll.UseVisualStyleBackColor = true;
            this.btnQsheetDelAll.Click += new System.EventHandler(this.btnQsheetDelAll_Click);
            // 
            // btnQsheetDel
            // 
            this.btnQsheetDel.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnQsheetDel.Location = new System.Drawing.Point(255, 5);
            this.btnQsheetDel.Name = "btnQsheetDel";
            this.btnQsheetDel.Size = new System.Drawing.Size(118, 30);
            this.btnQsheetDel.TabIndex = 4;
            this.btnQsheetDel.Text = "삭제";
            this.btnQsheetDel.UseVisualStyleBackColor = true;
            this.btnQsheetDel.Click += new System.EventHandler(this.btnQsheetDel_Click);
            // 
            // btnQsheetSave
            // 
            this.btnQsheetSave.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnQsheetSave.Location = new System.Drawing.Point(131, 5);
            this.btnQsheetSave.Name = "btnQsheetSave";
            this.btnQsheetSave.Size = new System.Drawing.Size(118, 30);
            this.btnQsheetSave.TabIndex = 3;
            this.btnQsheetSave.Text = "저장하기";
            this.btnQsheetSave.UseVisualStyleBackColor = true;
            this.btnQsheetSave.Click += new System.EventHandler(this.btnQsheetSave_Click);
            // 
            // btnQsheetLoad
            // 
            this.btnQsheetLoad.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnQsheetLoad.Location = new System.Drawing.Point(7, 5);
            this.btnQsheetLoad.Name = "btnQsheetLoad";
            this.btnQsheetLoad.Size = new System.Drawing.Size(118, 30);
            this.btnQsheetLoad.TabIndex = 2;
            this.btnQsheetLoad.Text = "불러오기";
            this.btnQsheetLoad.UseVisualStyleBackColor = true;
            this.btnQsheetLoad.Click += new System.EventHandler(this.btnQsheetLoad_Click);
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(520, 66);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 526);
            this.splitter1.TabIndex = 4;
            this.splitter1.TabStop = false;
            // 
            // panRight
            // 
            this.panRight.Controls.Add(this.tabControl1);
            this.panRight.Controls.Add(this.panOnairControll);
            this.panRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panRight.Location = new System.Drawing.Point(523, 66);
            this.panRight.Name = "panRight";
            this.panRight.Size = new System.Drawing.Size(550, 526);
            this.panRight.TabIndex = 5;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpOnair);
            this.tabControl1.Controls.Add(this.tpQsheet);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(550, 426);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 1;
            // 
            // tpOnair
            // 
            this.tpOnair.Controls.Add(this.dgvCand);
            this.tpOnair.Controls.Add(this.label3);
            this.tpOnair.Controls.Add(this.dgvPrec);
            this.tpOnair.Controls.Add(this.label2);
            this.tpOnair.Controls.Add(this.panOnairOption);
            this.tpOnair.Location = new System.Drawing.Point(4, 22);
            this.tpOnair.Name = "tpOnair";
            this.tpOnair.Padding = new System.Windows.Forms.Padding(3);
            this.tpOnair.Size = new System.Drawing.Size(542, 400);
            this.tpOnair.TabIndex = 0;
            this.tpOnair.Text = "방송";
            this.tpOnair.UseVisualStyleBackColor = true;
            // 
            // dgvCand
            // 
            this.dgvCand.AllowUserToAddRows = false;
            this.dgvCand.AllowUserToDeleteRows = false;
            this.dgvCand.AllowUserToResizeColumns = false;
            this.dgvCand.AllowUserToResizeRows = false;
            this.dgvCand.AutoGenerateColumns = false;
            this.dgvCand.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCand.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rankDataGridViewTextBoxColumn,
            this.korNameDataGridViewTextBoxColumn,
            this.votesCntDataGridViewTextBoxColumn,
            this.votesRateDataGridViewTextBoxColumn,
            this.PartyName});
            this.dgvCand.DataSource = this.bsCandSBS;
            this.dgvCand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCand.Location = new System.Drawing.Point(3, 110);
            this.dgvCand.MultiSelect = false;
            this.dgvCand.Name = "dgvCand";
            this.dgvCand.ReadOnly = true;
            this.dgvCand.RowHeadersVisible = false;
            this.dgvCand.RowTemplate.Height = 23;
            this.dgvCand.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCand.Size = new System.Drawing.Size(536, 157);
            this.dgvCand.TabIndex = 9;
            // 
            // rankDataGridViewTextBoxColumn
            // 
            this.rankDataGridViewTextBoxColumn.DataPropertyName = "Rank";
            this.rankDataGridViewTextBoxColumn.HeaderText = "순위";
            this.rankDataGridViewTextBoxColumn.Name = "rankDataGridViewTextBoxColumn";
            this.rankDataGridViewTextBoxColumn.ReadOnly = true;
            this.rankDataGridViewTextBoxColumn.Width = 60;
            // 
            // korNameDataGridViewTextBoxColumn
            // 
            this.korNameDataGridViewTextBoxColumn.DataPropertyName = "KorName";
            this.korNameDataGridViewTextBoxColumn.HeaderText = "성명";
            this.korNameDataGridViewTextBoxColumn.Name = "korNameDataGridViewTextBoxColumn";
            this.korNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // votesCntDataGridViewTextBoxColumn
            // 
            this.votesCntDataGridViewTextBoxColumn.DataPropertyName = "VotesCnt";
            this.votesCntDataGridViewTextBoxColumn.HeaderText = "득표수";
            this.votesCntDataGridViewTextBoxColumn.Name = "votesCntDataGridViewTextBoxColumn";
            this.votesCntDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // votesRateDataGridViewTextBoxColumn
            // 
            this.votesRateDataGridViewTextBoxColumn.DataPropertyName = "VotesRate";
            this.votesRateDataGridViewTextBoxColumn.HeaderText = "득표율";
            this.votesRateDataGridViewTextBoxColumn.Name = "votesRateDataGridViewTextBoxColumn";
            this.votesRateDataGridViewTextBoxColumn.ReadOnly = true;
            this.votesRateDataGridViewTextBoxColumn.Width = 70;
            // 
            // PartyName
            // 
            this.PartyName.DataPropertyName = "PartyName";
            this.PartyName.HeaderText = "정당";
            this.PartyName.Name = "PartyName";
            this.PartyName.ReadOnly = true;
            // 
            // bsCandSBS
            // 
            this.bsCandSBS.AllowNew = false;
            this.bsCandSBS.DataMember = "Ele_TCandSBS";
            this.bsCandSBS.DataSource = this.openDataSet;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Location = new System.Drawing.Point(3, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(536, 19);
            this.label3.TabIndex = 8;
            this.label3.Text = "후보자";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvPrec
            // 
            this.dgvPrec.AllowUserToAddRows = false;
            this.dgvPrec.AllowUserToDeleteRows = false;
            this.dgvPrec.AllowUserToOrderColumns = true;
            this.dgvPrec.AllowUserToResizeColumns = false;
            this.dgvPrec.AllowUserToResizeRows = false;
            this.dgvPrec.AutoGenerateColumns = false;
            this.dgvPrec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrec.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PrecName,
            this.openCntDataGridViewTextBoxColumn,
            this.openRateDataGridViewTextBoxColumn,
            this.openYNDataGridViewTextBoxColumn,
            this.fstNoDataGridViewTextBoxColumn,
            this.ElecGbnName,
            this.modHMSDataGridViewTextBoxColumn});
            this.dgvPrec.DataSource = this.bsPrecSBS;
            this.dgvPrec.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvPrec.Location = new System.Drawing.Point(3, 22);
            this.dgvPrec.MultiSelect = false;
            this.dgvPrec.Name = "dgvPrec";
            this.dgvPrec.ReadOnly = true;
            this.dgvPrec.RowHeadersVisible = false;
            this.dgvPrec.RowTemplate.Height = 23;
            this.dgvPrec.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrec.Size = new System.Drawing.Size(536, 69);
            this.dgvPrec.TabIndex = 7;
            // 
            // PrecName
            // 
            this.PrecName.DataPropertyName = "PrecName";
            this.PrecName.HeaderText = "선거구";
            this.PrecName.Name = "PrecName";
            this.PrecName.ReadOnly = true;
            this.PrecName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // openCntDataGridViewTextBoxColumn
            // 
            this.openCntDataGridViewTextBoxColumn.DataPropertyName = "OpenCnt";
            this.openCntDataGridViewTextBoxColumn.HeaderText = "개표수";
            this.openCntDataGridViewTextBoxColumn.Name = "openCntDataGridViewTextBoxColumn";
            this.openCntDataGridViewTextBoxColumn.ReadOnly = true;
            this.openCntDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // openRateDataGridViewTextBoxColumn
            // 
            this.openRateDataGridViewTextBoxColumn.DataPropertyName = "OpenRate";
            this.openRateDataGridViewTextBoxColumn.HeaderText = "개표율";
            this.openRateDataGridViewTextBoxColumn.Name = "openRateDataGridViewTextBoxColumn";
            this.openRateDataGridViewTextBoxColumn.ReadOnly = true;
            this.openRateDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.openRateDataGridViewTextBoxColumn.Width = 60;
            // 
            // openYNDataGridViewTextBoxColumn
            // 
            this.openYNDataGridViewTextBoxColumn.DataPropertyName = "OpenYN";
            this.openYNDataGridViewTextBoxColumn.HeaderText = "개표";
            this.openYNDataGridViewTextBoxColumn.Name = "openYNDataGridViewTextBoxColumn";
            this.openYNDataGridViewTextBoxColumn.ReadOnly = true;
            this.openYNDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.openYNDataGridViewTextBoxColumn.Width = 50;
            // 
            // fstNoDataGridViewTextBoxColumn
            // 
            this.fstNoDataGridViewTextBoxColumn.DataPropertyName = "FstNo";
            this.fstNoDataGridViewTextBoxColumn.HeaderText = "1위";
            this.fstNoDataGridViewTextBoxColumn.Name = "fstNoDataGridViewTextBoxColumn";
            this.fstNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.fstNoDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.fstNoDataGridViewTextBoxColumn.Width = 50;
            // 
            // ElecGbnName
            // 
            this.ElecGbnName.DataPropertyName = "ElecGbnName";
            this.ElecGbnName.HeaderText = "당선";
            this.ElecGbnName.Name = "ElecGbnName";
            this.ElecGbnName.ReadOnly = true;
            this.ElecGbnName.Width = 70;
            // 
            // modHMSDataGridViewTextBoxColumn
            // 
            this.modHMSDataGridViewTextBoxColumn.DataPropertyName = "ModHMS";
            this.modHMSDataGridViewTextBoxColumn.HeaderText = "전송일시";
            this.modHMSDataGridViewTextBoxColumn.Name = "modHMSDataGridViewTextBoxColumn";
            this.modHMSDataGridViewTextBoxColumn.ReadOnly = true;
            this.modHMSDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // bsPrecSBS
            // 
            this.bsPrecSBS.AllowNew = false;
            this.bsPrecSBS.DataMember = "Ele_TPrecSBS";
            this.bsPrecSBS.DataSource = this.openDataSet;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(536, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "선거구";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panOnairOption
            // 
            this.panOnairOption.Controls.Add(this.label10);
            this.panOnairOption.Controls.Add(this.cbBG);
            this.panOnairOption.Controls.Add(this.btnBlank);
            this.panOnairOption.Controls.Add(this.gbAuto);
            this.panOnairOption.Controls.Add(this.gbIn);
            this.panOnairOption.Controls.Add(this.gbBack);
            this.panOnairOption.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panOnairOption.Enabled = false;
            this.panOnairOption.Location = new System.Drawing.Point(3, 267);
            this.panOnairOption.Name = "panOnairOption";
            this.panOnairOption.Size = new System.Drawing.Size(536, 130);
            this.panOnairOption.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(295, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 8;
            this.label10.Text = "배경종류";
            // 
            // cbBG
            // 
            this.cbBG.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBG.FormattingEnabled = true;
            this.cbBG.Items.AddRange(new object[] {
            "국민의선택",
            "폭포",
            "물방울",
            "후보프로필"});
            this.cbBG.Location = new System.Drawing.Point(272, 104);
            this.cbBG.Name = "cbBG";
            this.cbBG.Size = new System.Drawing.Size(76, 20);
            this.cbBG.TabIndex = 7;
            this.cbBG.SelectedIndexChanged += new System.EventHandler(this.cbBG_SelectedIndexChanged);
            // 
            // btnBlank
            // 
            this.btnBlank.Location = new System.Drawing.Point(357, 76);
            this.btnBlank.Name = "btnBlank";
            this.btnBlank.Size = new System.Drawing.Size(173, 49);
            this.btnBlank.TabIndex = 6;
            this.btnBlank.Text = "빈화면 송출";
            this.btnBlank.UseVisualStyleBackColor = true;
            this.btnBlank.Click += new System.EventHandler(this.btnBlank_Click);
            // 
            // gbAuto
            // 
            this.gbAuto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gbAuto.Controls.Add(this.label5);
            this.gbAuto.Controls.Add(this.label4);
            this.gbAuto.Controls.Add(this.tbTimer);
            this.gbAuto.Controls.Add(this.rbUnloop);
            this.gbAuto.Controls.Add(this.rbLoop);
            this.gbAuto.Location = new System.Drawing.Point(3, 66);
            this.gbAuto.Name = "gbAuto";
            this.gbAuto.Size = new System.Drawing.Size(257, 63);
            this.gbAuto.TabIndex = 5;
            this.gbAuto.TabStop = false;
            this.gbAuto.Text = "자동";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(98, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "초";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "지연시간";
            // 
            // tbTimer
            // 
            this.tbTimer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbTimer.Location = new System.Drawing.Point(45, 39);
            this.tbTimer.Name = "tbTimer";
            this.tbTimer.Size = new System.Drawing.Size(47, 21);
            this.tbTimer.TabIndex = 3;
            this.tbTimer.Text = "8";
            this.tbTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // rbUnloop
            // 
            this.rbUnloop.AutoSize = true;
            this.rbUnloop.Checked = true;
            this.rbUnloop.Location = new System.Drawing.Point(155, 39);
            this.rbUnloop.Name = "rbUnloop";
            this.rbUnloop.Size = new System.Drawing.Size(59, 16);
            this.rbUnloop.TabIndex = 2;
            this.rbUnloop.TabStop = true;
            this.rbUnloop.Text = "비순환";
            this.rbUnloop.UseVisualStyleBackColor = true;
            // 
            // rbLoop
            // 
            this.rbLoop.AutoSize = true;
            this.rbLoop.Location = new System.Drawing.Point(155, 19);
            this.rbLoop.Name = "rbLoop";
            this.rbLoop.Size = new System.Drawing.Size(47, 16);
            this.rbLoop.TabIndex = 1;
            this.rbLoop.Text = "순환";
            this.rbLoop.UseVisualStyleBackColor = true;
            // 
            // gbIn
            // 
            this.gbIn.Controls.Add(this.rbInMan);
            this.gbIn.Controls.Add(this.rbInAuto);
            this.gbIn.Location = new System.Drawing.Point(3, 3);
            this.gbIn.Name = "gbIn";
            this.gbIn.Size = new System.Drawing.Size(257, 63);
            this.gbIn.TabIndex = 4;
            this.gbIn.TabStop = false;
            this.gbIn.Text = "송출";
            this.gbIn.EnabledChanged += new System.EventHandler(this.gbIn_EnabledChanged);
            // 
            // rbInMan
            // 
            this.rbInMan.AutoSize = true;
            this.rbInMan.Checked = true;
            this.rbInMan.Location = new System.Drawing.Point(155, 29);
            this.rbInMan.Name = "rbInMan";
            this.rbInMan.Size = new System.Drawing.Size(47, 16);
            this.rbInMan.TabIndex = 1;
            this.rbInMan.TabStop = true;
            this.rbInMan.Text = "수동";
            this.rbInMan.UseVisualStyleBackColor = true;
            // 
            // rbInAuto
            // 
            this.rbInAuto.AutoSize = true;
            this.rbInAuto.Location = new System.Drawing.Point(45, 29);
            this.rbInAuto.Name = "rbInAuto";
            this.rbInAuto.Size = new System.Drawing.Size(47, 16);
            this.rbInAuto.TabIndex = 0;
            this.rbInAuto.Text = "자동";
            this.rbInAuto.UseVisualStyleBackColor = true;
            this.rbInAuto.CheckedChanged += new System.EventHandler(this.rbInAuto_CheckedChanged);
            // 
            // gbBack
            // 
            this.gbBack.Controls.Add(this.label11);
            this.gbBack.Controls.Add(this.cbLowBack);
            this.gbBack.Location = new System.Drawing.Point(272, 3);
            this.gbBack.Name = "gbBack";
            this.gbBack.Size = new System.Drawing.Size(257, 63);
            this.gbBack.TabIndex = 3;
            this.gbBack.TabStop = false;
            this.gbBack.Text = "하단배경";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 31);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 9;
            this.label11.Text = "불투명도";
            // 
            // cbLowBack
            // 
            this.cbLowBack.DataSource = this.bsCompCode;
            this.cbLowBack.DisplayMember = "ADesc";
            this.cbLowBack.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLowBack.FormattingEnabled = true;
            this.cbLowBack.Location = new System.Drawing.Point(85, 28);
            this.cbLowBack.Name = "cbLowBack";
            this.cbLowBack.Size = new System.Drawing.Size(166, 20);
            this.cbLowBack.TabIndex = 8;
            this.cbLowBack.ValueMember = "BDesc";
            // 
            // bsCompCode
            // 
            this.bsCompCode.DataMember = "Ele_MCompCode";
            this.bsCompCode.DataSource = this.openDataSet;
            // 
            // tpQsheet
            // 
            this.tpQsheet.Controls.Add(this.panel5);
            this.tpQsheet.Controls.Add(this.panQbutton);
            this.tpQsheet.Controls.Add(this.panel3);
            this.tpQsheet.Location = new System.Drawing.Point(4, 22);
            this.tpQsheet.Name = "tpQsheet";
            this.tpQsheet.Padding = new System.Windows.Forms.Padding(3);
            this.tpQsheet.Size = new System.Drawing.Size(542, 400);
            this.tpQsheet.TabIndex = 1;
            this.tpQsheet.Text = "큐시트작성";
            this.tpQsheet.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dgvQscene);
            this.panel5.Controls.Add(this.splitter4);
            this.panel5.Controls.Add(this.dgvQprec);
            this.panel5.Controls.Add(this.splitter3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(66, 41);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(473, 356);
            this.panel5.TabIndex = 2;
            // 
            // dgvQscene
            // 
            this.dgvQscene.AllowUserToAddRows = false;
            this.dgvQscene.AllowUserToDeleteRows = false;
            this.dgvQscene.AllowUserToResizeRows = false;
            this.dgvQscene.AutoGenerateColumns = false;
            this.dgvQscene.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQscene.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.aDescDataGridViewTextBoxColumn});
            this.dgvQscene.DataSource = this.bsScene;
            this.dgvQscene.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvQscene.Location = new System.Drawing.Point(0, 184);
            this.dgvQscene.MultiSelect = false;
            this.dgvQscene.Name = "dgvQscene";
            this.dgvQscene.ReadOnly = true;
            this.dgvQscene.RowHeadersVisible = false;
            this.dgvQscene.RowTemplate.Height = 23;
            this.dgvQscene.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQscene.Size = new System.Drawing.Size(473, 172);
            this.dgvQscene.TabIndex = 7;
            // 
            // aDescDataGridViewTextBoxColumn
            // 
            this.aDescDataGridViewTextBoxColumn.DataPropertyName = "ADesc";
            this.aDescDataGridViewTextBoxColumn.HeaderText = "송출화면";
            this.aDescDataGridViewTextBoxColumn.Name = "aDescDataGridViewTextBoxColumn";
            this.aDescDataGridViewTextBoxColumn.ReadOnly = true;
            this.aDescDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.aDescDataGridViewTextBoxColumn.Width = 350;
            // 
            // bsScene
            // 
            this.bsScene.DataMember = "Ele_MCompCode";
            this.bsScene.DataSource = this.openDataSet;
            // 
            // splitter4
            // 
            this.splitter4.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter4.Location = new System.Drawing.Point(0, 181);
            this.splitter4.Name = "splitter4";
            this.splitter4.Size = new System.Drawing.Size(473, 3);
            this.splitter4.TabIndex = 6;
            this.splitter4.TabStop = false;
            // 
            // dgvQprec
            // 
            this.dgvQprec.AllowUserToAddRows = false;
            this.dgvQprec.AllowUserToDeleteRows = false;
            this.dgvQprec.AllowUserToResizeColumns = false;
            this.dgvQprec.AllowUserToResizeRows = false;
            this.dgvQprec.AutoGenerateColumns = false;
            this.dgvQprec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQprec.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.precNameDataGridViewTextBoxColumn,
            this.candCntDataGridViewTextBoxColumn});
            this.dgvQprec.DataSource = this.bsPrec;
            this.dgvQprec.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvQprec.Location = new System.Drawing.Point(0, 3);
            this.dgvQprec.MultiSelect = false;
            this.dgvQprec.Name = "dgvQprec";
            this.dgvQprec.ReadOnly = true;
            this.dgvQprec.RowHeadersVisible = false;
            this.dgvQprec.RowTemplate.Height = 23;
            this.dgvQprec.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQprec.Size = new System.Drawing.Size(473, 178);
            this.dgvQprec.TabIndex = 5;
            // 
            // precNameDataGridViewTextBoxColumn
            // 
            this.precNameDataGridViewTextBoxColumn.DataPropertyName = "PrecName";
            this.precNameDataGridViewTextBoxColumn.HeaderText = "선거구명";
            this.precNameDataGridViewTextBoxColumn.Name = "precNameDataGridViewTextBoxColumn";
            this.precNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.precNameDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.precNameDataGridViewTextBoxColumn.Width = 300;
            // 
            // candCntDataGridViewTextBoxColumn
            // 
            this.candCntDataGridViewTextBoxColumn.DataPropertyName = "CandCnt";
            this.candCntDataGridViewTextBoxColumn.HeaderText = "후보수";
            this.candCntDataGridViewTextBoxColumn.Name = "candCntDataGridViewTextBoxColumn";
            this.candCntDataGridViewTextBoxColumn.ReadOnly = true;
            this.candCntDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.candCntDataGridViewTextBoxColumn.Width = 80;
            // 
            // bsPrec
            // 
            this.bsPrec.DataMember = "Ele_TPrec";
            this.bsPrec.DataSource = this.openDataSet;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter3.Location = new System.Drawing.Point(0, 0);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(473, 3);
            this.splitter3.TabIndex = 4;
            this.splitter3.TabStop = false;
            // 
            // panQbutton
            // 
            this.panQbutton.Controls.Add(this.btnQall);
            this.panQbutton.Controls.Add(this.btnQone);
            this.panQbutton.Dock = System.Windows.Forms.DockStyle.Left;
            this.panQbutton.Location = new System.Drawing.Point(3, 41);
            this.panQbutton.Name = "panQbutton";
            this.panQbutton.Size = new System.Drawing.Size(63, 356);
            this.panQbutton.TabIndex = 1;
            this.panQbutton.Resize += new System.EventHandler(this.panQbutton_Resize);
            // 
            // btnQall
            // 
            this.btnQall.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQall.Location = new System.Drawing.Point(0, 181);
            this.btnQall.Name = "btnQall";
            this.btnQall.Size = new System.Drawing.Size(63, 175);
            this.btnQall.TabIndex = 1;
            this.btnQall.Text = "<<";
            this.btnQall.UseVisualStyleBackColor = true;
            this.btnQall.Click += new System.EventHandler(this.btnQall_Click);
            // 
            // btnQone
            // 
            this.btnQone.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQone.Location = new System.Drawing.Point(0, 0);
            this.btnQone.Name = "btnQone";
            this.btnQone.Size = new System.Drawing.Size(63, 181);
            this.btnQone.TabIndex = 0;
            this.btnQone.Text = "<";
            this.btnQone.UseVisualStyleBackColor = true;
            this.btnQone.Click += new System.EventHandler(this.btnQone_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cbQcity);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.cbQElecCatgr);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(536, 38);
            this.panel3.TabIndex = 0;
            // 
            // cbQcity
            // 
            this.cbQcity.DataSource = this.bsCompCode;
            this.cbQcity.DisplayMember = "ADesc";
            this.cbQcity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQcity.FormattingEnabled = true;
            this.cbQcity.Location = new System.Drawing.Point(276, 10);
            this.cbQcity.Name = "cbQcity";
            this.cbQcity.Size = new System.Drawing.Size(108, 20);
            this.cbQcity.TabIndex = 9;
            this.cbQcity.ValueMember = "Code";
            this.cbQcity.SelectedIndexChanged += new System.EventHandler(this.cbQcity_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(221, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 38);
            this.label7.TabIndex = 8;
            this.label7.Text = "시도";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbQElecCatgr
            // 
            this.cbQElecCatgr.DataSource = this.bsCompCode;
            this.cbQElecCatgr.DisplayMember = "ADesc";
            this.cbQElecCatgr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQElecCatgr.FormattingEnabled = true;
            this.cbQElecCatgr.Location = new System.Drawing.Point(69, 10);
            this.cbQElecCatgr.Name = "cbQElecCatgr";
            this.cbQElecCatgr.Size = new System.Drawing.Size(146, 20);
            this.cbQElecCatgr.TabIndex = 7;
            this.cbQElecCatgr.ValueMember = "Code";
            this.cbQElecCatgr.SelectedIndexChanged += new System.EventHandler(this.cbQElecCatgr_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 38);
            this.label6.TabIndex = 6;
            this.label6.Text = "선거종류";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panOnairControll
            // 
            this.panOnairControll.Controls.Add(this.cbOut);
            this.panOnairControll.Controls.Add(this.btnOut);
            this.panOnairControll.Controls.Add(this.btnIn);
            this.panOnairControll.Controls.Add(this.btnSkip);
            this.panOnairControll.Controls.Add(this.btnReady);
            this.panOnairControll.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panOnairControll.Enabled = false;
            this.panOnairControll.Location = new System.Drawing.Point(0, 426);
            this.panOnairControll.MinimumSize = new System.Drawing.Size(460, 0);
            this.panOnairControll.Name = "panOnairControll";
            this.panOnairControll.Size = new System.Drawing.Size(550, 100);
            this.panOnairControll.TabIndex = 0;
            this.panOnairControll.EnabledChanged += new System.EventHandler(this.panOnairControll_EnabledChanged);
            // 
            // cbOut
            // 
            this.cbOut.DisplayMember = "BDesc";
            this.cbOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOut.FormattingEnabled = true;
            this.cbOut.Items.AddRange(new object[] {
            "전체",
            "바탕화면",
            "하단",
            "좌상단"});
            this.cbOut.Location = new System.Drawing.Point(364, 6);
            this.cbOut.Name = "cbOut";
            this.cbOut.Size = new System.Drawing.Size(174, 20);
            this.cbOut.TabIndex = 9;
            this.cbOut.ValueMember = "BDesc";
            // 
            // btnOut
            // 
            this.btnOut.Enabled = false;
            this.btnOut.Font = new System.Drawing.Font("Impact", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOut.Location = new System.Drawing.Point(364, 31);
            this.btnOut.Name = "btnOut";
            this.btnOut.Size = new System.Drawing.Size(173, 65);
            this.btnOut.TabIndex = 3;
            this.btnOut.Text = "OUT";
            this.btnOut.UseVisualStyleBackColor = true;
            this.btnOut.Click += new System.EventHandler(this.btnOut_Click);
            // 
            // btnIn
            // 
            this.btnIn.Enabled = false;
            this.btnIn.Font = new System.Drawing.Font("Impact", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIn.Location = new System.Drawing.Point(185, 7);
            this.btnIn.Name = "btnIn";
            this.btnIn.Size = new System.Drawing.Size(173, 90);
            this.btnIn.TabIndex = 2;
            this.btnIn.Text = "IN";
            this.btnIn.UseVisualStyleBackColor = true;
            this.btnIn.Click += new System.EventHandler(this.btnIn_Click);
            // 
            // btnSkip
            // 
            this.btnSkip.Font = new System.Drawing.Font("Impact", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSkip.Location = new System.Drawing.Point(6, 51);
            this.btnSkip.Name = "btnSkip";
            this.btnSkip.Size = new System.Drawing.Size(173, 45);
            this.btnSkip.TabIndex = 1;
            this.btnSkip.Text = "SKIP";
            this.btnSkip.UseVisualStyleBackColor = true;
            this.btnSkip.Click += new System.EventHandler(this.btnSkip_Click);
            // 
            // btnReady
            // 
            this.btnReady.Font = new System.Drawing.Font("Impact", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReady.Location = new System.Drawing.Point(6, 6);
            this.btnReady.Name = "btnReady";
            this.btnReady.Size = new System.Drawing.Size(173, 45);
            this.btnReady.TabIndex = 0;
            this.btnReady.Text = "READY";
            this.btnReady.UseVisualStyleBackColor = true;
            this.btnReady.Click += new System.EventHandler(this.btnReady_Click);
            // 
            // taQsheet
            // 
            this.taQsheet.ClearBeforeFill = true;
            // 
            // taCompCode
            // 
            this.taCompCode.ClearBeforeFill = true;
            // 
            // taPrec
            // 
            this.taPrec.ClearBeforeFill = true;
            // 
            // taPrecSBS
            // 
            this.taPrecSBS.ClearBeforeFill = true;
            // 
            // taCandSBS
            // 
            this.taCandSBS.ClearBeforeFill = true;
            // 
            // taCandSBS1
            // 
            this.taCandSBS1.ClearBeforeFill = true;
            // 
            // tmAuto
            // 
            this.tmAuto.Interval = 4000;
            this.tmAuto.Tick += new System.EventHandler(this.tmAuto_Tick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1073, 592);
            this.Controls.Add(this.panRight);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panLeft);
            this.Controls.Add(this.panTop);
            this.Controls.Add(this.mnMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.mnMain;
            this.MinimumSize = new System.Drawing.Size(1089, 628);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "2018-2022 6.1 지방선거 개표방송시스템";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmMain_KeyDown);
            this.mnMain.ResumeLayout(false);
            this.mnMain.PerformLayout();
            this.panTop.ResumeLayout(false);
            this.panTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsQsheet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.openDataSet)).EndInit();
            this.panLeft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQsheet)).EndInit();
            this.panQsheetSum.ResumeLayout(false);
            this.panQsheetSum.PerformLayout();
            this.panQControll.ResumeLayout(false);
            this.panRight.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpOnair.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCandSBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecSBS)).EndInit();
            this.panOnairOption.ResumeLayout(false);
            this.panOnairOption.PerformLayout();
            this.gbAuto.ResumeLayout(false);
            this.gbAuto.PerformLayout();
            this.gbIn.ResumeLayout(false);
            this.gbIn.PerformLayout();
            this.gbBack.ResumeLayout(false);
            this.gbBack.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsCompCode)).EndInit();
            this.tpQsheet.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQscene)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsScene)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQprec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrec)).EndInit();
            this.panQbutton.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panOnairControll.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnMain;
        private System.Windows.Forms.ToolStripMenuItem miMenuElec;
        private System.Windows.Forms.ToolStripMenuItem miCode;
        private System.Windows.Forms.ToolStripMenuItem miPrec;
        private System.Windows.Forms.ToolStripMenuItem miCand;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem miOpen;
        private System.Windows.Forms.ToolStripMenuItem miMenuTemp;
        private System.Windows.Forms.ToolStripMenuItem miMakePhoto;
        private System.Windows.Forms.ToolStripMenuItem miMakeOpenData;
        private System.Windows.Forms.ToolStripMenuItem miMenuConf;
        private System.Windows.Forms.Panel panTop;
        private System.Windows.Forms.Panel panLeft;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panRight;
        private System.Windows.Forms.Button btnOnair;
        private System.Windows.Forms.Label lbOnair;
        private System.Windows.Forms.Panel panQControll;
        private System.Windows.Forms.Button btnQsheetDelAll;
        private System.Windows.Forms.Button btnQsheetDel;
        private System.Windows.Forms.Button btnQsheetSave;
        private System.Windows.Forms.Button btnQsheetLoad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpOnair;
        private System.Windows.Forms.TabPage tpQsheet;
        private System.Windows.Forms.Panel panOnairControll;
        private System.Windows.Forms.Button btnOut;
        private System.Windows.Forms.Button btnIn;
        private System.Windows.Forms.Button btnSkip;
        private System.Windows.Forms.Button btnReady;
        private System.Windows.Forms.DataGridView dgvCand;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgvPrec;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panOnairOption;
        private System.Windows.Forms.Button btnBlank;
        private System.Windows.Forms.GroupBox gbAuto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbTimer;
        private System.Windows.Forms.RadioButton rbUnloop;
        private System.Windows.Forms.RadioButton rbLoop;
        private System.Windows.Forms.GroupBox gbIn;
        private System.Windows.Forms.RadioButton rbInMan;
        private System.Windows.Forms.RadioButton rbInAuto;
        private System.Windows.Forms.GroupBox gbBack;
        private System.Windows.Forms.Panel panQbutton;
        private System.Windows.Forms.Button btnQall;
        private System.Windows.Forms.Button btnQone;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbQElecCatgr;
        private System.Windows.Forms.Splitter splitter4;
        private System.Windows.Forms.DataGridView dgvQprec;
        private System.Windows.Forms.Splitter splitter3;
        private System.Windows.Forms.ComboBox cbQcity;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgvQscene;
        private OpenDataSet openDataSet;
        private System.Windows.Forms.BindingSource bsQsheet;
        private OpenDataSetTableAdapters.Ele_TQsheetTableAdapter taQsheet;
        private System.Windows.Forms.BindingSource bsCompCode;
        private OpenDataSetTableAdapters.Ele_MCompCodeTableAdapter taCompCode;
        private System.Windows.Forms.BindingSource bsPrec;
        private OpenDataSetTableAdapters.Ele_TPrecTableAdapter taPrec;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDescDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn precNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn candCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bsScene;
        private OpenDataSetTableAdapters.QueriesTableAdapter taQueries;
        private System.Windows.Forms.Panel panQsheetSum;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dgvQsheet;
        private System.Windows.Forms.Button btnLog;
        private OpenDataSetTableAdapters.Ele_TPrecSBSTableAdapter taPrecSBS;
        private System.Windows.Forms.BindingSource bsPrecSBS;
        private OpenDataSetTableAdapters.Ele_TCandSBSTableAdapter taCandSBS;
        private System.Windows.Forms.BindingSource bsCandSBS;
        private System.Windows.Forms.DataGridViewTextBoxColumn rankDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn korNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn votesCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn votesRateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn PartyName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrecName;
        private System.Windows.Forms.DataGridViewTextBoxColumn openCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn openRateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn openYNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fstNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ElecGbnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn modHMSDataGridViewTextBoxColumn;
        private OpenDataSetTableAdapters.Ele_TCandSBS1TableAdapter taCandSBS1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbBG;
        private System.Windows.Forms.Timer tmAuto;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbLowBack;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbOut;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seq;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}

