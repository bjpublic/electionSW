﻿namespace Election
{


    public partial class OpenDataSet
    {
        partial class Ele_TCandSBS1DataTable
        {
        }

        partial class Ele_TQsheetDataTable
        {
        }
    }
}

namespace Election.OpenDataSetTableAdapters {
    
    
    public partial class Ele_TCandSBS1TableAdapter {
    }
}
