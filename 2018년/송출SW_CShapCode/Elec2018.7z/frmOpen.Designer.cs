﻿namespace Election
{
    partial class frmOpen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOpen));
            this.bsCandSBS = new System.Windows.Forms.BindingSource(this.components);
            this.openDataSet = new Election.OpenDataSet();
            this.bsPrecSBS = new System.Windows.Forms.BindingSource(this.components);
            this.taPrecSBS = new Election.OpenDataSetTableAdapters.Ele_TPrecSBSTableAdapter();
            this.taCandSBS = new Election.OpenDataSetTableAdapters.Ele_TCandSBSTableAdapter();
            this.bsCompCode = new System.Windows.Forms.BindingSource(this.components);
            this.taCompCode = new Election.OpenDataSetTableAdapters.Ele_MCompCodeTableAdapter();
            this.dgvCand = new System.Windows.Forms.DataGridView();
            this.rankDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.korNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.votesCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.votesRateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PartyName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnQuery = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbCnt2 = new System.Windows.Forms.Label();
            this.lbCnt3 = new System.Windows.Forms.Label();
            this.lbCnt4 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbCntT = new System.Windows.Forms.Label();
            this.dgvPrec = new System.Windows.Forms.DataGridView();
            this.ElecCatgr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrecName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openRateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openYNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fstNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ElecGbnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modHMSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.bsCandSBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.openDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecSBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCompCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrec)).BeginInit();
            this.SuspendLayout();
            // 
            // bsCandSBS
            // 
            this.bsCandSBS.DataMember = "Ele_TCandSBS";
            this.bsCandSBS.DataSource = this.openDataSet;
            // 
            // openDataSet
            // 
            this.openDataSet.DataSetName = "OpenDataSet";
            this.openDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsPrecSBS
            // 
            this.bsPrecSBS.DataMember = "Ele_TPrecSBS";
            this.bsPrecSBS.DataSource = this.openDataSet;
            // 
            // taPrecSBS
            // 
            this.taPrecSBS.ClearBeforeFill = true;
            // 
            // taCandSBS
            // 
            this.taCandSBS.ClearBeforeFill = true;
            // 
            // bsCompCode
            // 
            this.bsCompCode.DataMember = "Ele_MCompCode";
            this.bsCompCode.DataSource = this.openDataSet;
            // 
            // taCompCode
            // 
            this.taCompCode.ClearBeforeFill = true;
            // 
            // dgvCand
            // 
            this.dgvCand.AllowUserToAddRows = false;
            this.dgvCand.AllowUserToDeleteRows = false;
            this.dgvCand.AllowUserToResizeColumns = false;
            this.dgvCand.AllowUserToResizeRows = false;
            this.dgvCand.AutoGenerateColumns = false;
            this.dgvCand.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCand.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rankDataGridViewTextBoxColumn,
            this.korNameDataGridViewTextBoxColumn,
            this.votesCntDataGridViewTextBoxColumn,
            this.votesRateDataGridViewTextBoxColumn,
            this.PartyName});
            this.dgvCand.DataSource = this.bsCandSBS;
            this.dgvCand.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvCand.Location = new System.Drawing.Point(0, 323);
            this.dgvCand.MultiSelect = false;
            this.dgvCand.Name = "dgvCand";
            this.dgvCand.ReadOnly = true;
            this.dgvCand.RowHeadersVisible = false;
            this.dgvCand.RowTemplate.Height = 23;
            this.dgvCand.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCand.Size = new System.Drawing.Size(622, 161);
            this.dgvCand.TabIndex = 10;
            // 
            // rankDataGridViewTextBoxColumn
            // 
            this.rankDataGridViewTextBoxColumn.DataPropertyName = "Rank";
            this.rankDataGridViewTextBoxColumn.HeaderText = "순위";
            this.rankDataGridViewTextBoxColumn.Name = "rankDataGridViewTextBoxColumn";
            this.rankDataGridViewTextBoxColumn.ReadOnly = true;
            this.rankDataGridViewTextBoxColumn.Width = 60;
            // 
            // korNameDataGridViewTextBoxColumn
            // 
            this.korNameDataGridViewTextBoxColumn.DataPropertyName = "KorName";
            this.korNameDataGridViewTextBoxColumn.HeaderText = "성명";
            this.korNameDataGridViewTextBoxColumn.Name = "korNameDataGridViewTextBoxColumn";
            this.korNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // votesCntDataGridViewTextBoxColumn
            // 
            this.votesCntDataGridViewTextBoxColumn.DataPropertyName = "VotesCnt";
            this.votesCntDataGridViewTextBoxColumn.HeaderText = "득표수";
            this.votesCntDataGridViewTextBoxColumn.Name = "votesCntDataGridViewTextBoxColumn";
            this.votesCntDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // votesRateDataGridViewTextBoxColumn
            // 
            this.votesRateDataGridViewTextBoxColumn.DataPropertyName = "VotesRate";
            this.votesRateDataGridViewTextBoxColumn.HeaderText = "득표율";
            this.votesRateDataGridViewTextBoxColumn.Name = "votesRateDataGridViewTextBoxColumn";
            this.votesRateDataGridViewTextBoxColumn.ReadOnly = true;
            this.votesRateDataGridViewTextBoxColumn.Width = 70;
            // 
            // PartyName
            // 
            this.PartyName.DataPropertyName = "PartyName";
            this.PartyName.HeaderText = "정당";
            this.PartyName.Name = "PartyName";
            this.PartyName.ReadOnly = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvPrec);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(622, 285);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbCntT);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lbCnt4);
            this.panel2.Controls.Add(this.lbCnt3);
            this.panel2.Controls.Add(this.lbCnt2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 241);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(622, 44);
            this.panel2.TabIndex = 11;
            // 
            // btnQuery
            // 
            this.btnQuery.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnQuery.Location = new System.Drawing.Point(12, 9);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 23);
            this.btnQuery.TabIndex = 10;
            this.btnQuery.Text = "조회";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnQuery);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(622, 38);
            this.panel3.TabIndex = 1;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter1.Location = new System.Drawing.Point(0, 38);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(622, 3);
            this.splitter1.TabIndex = 12;
            this.splitter1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "광역 :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(120, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "교육 :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(208, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "기초 :";
            // 
            // lbCnt2
            // 
            this.lbCnt2.AutoSize = true;
            this.lbCnt2.Location = new System.Drawing.Point(75, 16);
            this.lbCnt2.Name = "lbCnt2";
            this.lbCnt2.Size = new System.Drawing.Size(23, 12);
            this.lbCnt2.TabIndex = 3;
            this.lbCnt2.Text = "0/0";
            // 
            // lbCnt3
            // 
            this.lbCnt3.AutoSize = true;
            this.lbCnt3.Location = new System.Drawing.Point(163, 16);
            this.lbCnt3.Name = "lbCnt3";
            this.lbCnt3.Size = new System.Drawing.Size(23, 12);
            this.lbCnt3.TabIndex = 4;
            this.lbCnt3.Text = "0/0";
            // 
            // lbCnt4
            // 
            this.lbCnt4.AutoSize = true;
            this.lbCnt4.Location = new System.Drawing.Point(251, 16);
            this.lbCnt4.Name = "lbCnt4";
            this.lbCnt4.Size = new System.Drawing.Size(23, 12);
            this.lbCnt4.TabIndex = 5;
            this.lbCnt4.Text = "0/0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(307, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "합계 :";
            // 
            // lbCntT
            // 
            this.lbCntT.AutoSize = true;
            this.lbCntT.Location = new System.Drawing.Point(350, 16);
            this.lbCntT.Name = "lbCntT";
            this.lbCntT.Size = new System.Drawing.Size(23, 12);
            this.lbCntT.TabIndex = 7;
            this.lbCntT.Text = "0/0";
            // 
            // dgvPrec
            // 
            this.dgvPrec.AllowUserToAddRows = false;
            this.dgvPrec.AllowUserToDeleteRows = false;
            this.dgvPrec.AllowUserToOrderColumns = true;
            this.dgvPrec.AllowUserToResizeColumns = false;
            this.dgvPrec.AllowUserToResizeRows = false;
            this.dgvPrec.AutoGenerateColumns = false;
            this.dgvPrec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrec.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ElecCatgr,
            this.PrecName,
            this.openCntDataGridViewTextBoxColumn,
            this.openRateDataGridViewTextBoxColumn,
            this.openYNDataGridViewTextBoxColumn,
            this.fstNoDataGridViewTextBoxColumn,
            this.ElecGbnName,
            this.modHMSDataGridViewTextBoxColumn});
            this.dgvPrec.DataSource = this.bsPrecSBS;
            this.dgvPrec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPrec.Location = new System.Drawing.Point(0, 0);
            this.dgvPrec.MultiSelect = false;
            this.dgvPrec.Name = "dgvPrec";
            this.dgvPrec.ReadOnly = true;
            this.dgvPrec.RowHeadersVisible = false;
            this.dgvPrec.RowTemplate.Height = 23;
            this.dgvPrec.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrec.Size = new System.Drawing.Size(622, 241);
            this.dgvPrec.TabIndex = 12;
            this.dgvPrec.SelectionChanged += new System.EventHandler(this.dgvPrec_SelectionChanged);
            // 
            // ElecCatgr
            // 
            this.ElecCatgr.DataPropertyName = "ElecCatgr";
            this.ElecCatgr.HeaderText = "선거";
            this.ElecCatgr.Name = "ElecCatgr";
            this.ElecCatgr.ReadOnly = true;
            this.ElecCatgr.Width = 60;
            // 
            // PrecName
            // 
            this.PrecName.DataPropertyName = "PrecName";
            this.PrecName.HeaderText = "선거구";
            this.PrecName.Name = "PrecName";
            this.PrecName.ReadOnly = true;
            this.PrecName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // openCntDataGridViewTextBoxColumn
            // 
            this.openCntDataGridViewTextBoxColumn.DataPropertyName = "OpenCnt";
            this.openCntDataGridViewTextBoxColumn.HeaderText = "개표수";
            this.openCntDataGridViewTextBoxColumn.Name = "openCntDataGridViewTextBoxColumn";
            this.openCntDataGridViewTextBoxColumn.ReadOnly = true;
            this.openCntDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // openRateDataGridViewTextBoxColumn
            // 
            this.openRateDataGridViewTextBoxColumn.DataPropertyName = "OpenRate";
            this.openRateDataGridViewTextBoxColumn.HeaderText = "개표율";
            this.openRateDataGridViewTextBoxColumn.Name = "openRateDataGridViewTextBoxColumn";
            this.openRateDataGridViewTextBoxColumn.ReadOnly = true;
            this.openRateDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.openRateDataGridViewTextBoxColumn.Width = 60;
            // 
            // openYNDataGridViewTextBoxColumn
            // 
            this.openYNDataGridViewTextBoxColumn.DataPropertyName = "OpenYN";
            this.openYNDataGridViewTextBoxColumn.HeaderText = "개표";
            this.openYNDataGridViewTextBoxColumn.Name = "openYNDataGridViewTextBoxColumn";
            this.openYNDataGridViewTextBoxColumn.ReadOnly = true;
            this.openYNDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.openYNDataGridViewTextBoxColumn.Width = 50;
            // 
            // fstNoDataGridViewTextBoxColumn
            // 
            this.fstNoDataGridViewTextBoxColumn.DataPropertyName = "FstNo";
            this.fstNoDataGridViewTextBoxColumn.HeaderText = "1위";
            this.fstNoDataGridViewTextBoxColumn.Name = "fstNoDataGridViewTextBoxColumn";
            this.fstNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.fstNoDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.fstNoDataGridViewTextBoxColumn.Width = 50;
            // 
            // ElecGbnName
            // 
            this.ElecGbnName.DataPropertyName = "ElecGbnName";
            this.ElecGbnName.HeaderText = "당선";
            this.ElecGbnName.Name = "ElecGbnName";
            this.ElecGbnName.ReadOnly = true;
            this.ElecGbnName.Width = 70;
            // 
            // modHMSDataGridViewTextBoxColumn
            // 
            this.modHMSDataGridViewTextBoxColumn.DataPropertyName = "ModHMS";
            this.modHMSDataGridViewTextBoxColumn.HeaderText = "전송일시";
            this.modHMSDataGridViewTextBoxColumn.Name = "modHMSDataGridViewTextBoxColumn";
            this.modHMSDataGridViewTextBoxColumn.ReadOnly = true;
            this.modHMSDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // frmOpen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 484);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvCand);
            this.Controls.Add(this.panel3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmOpen";
            this.Text = "개표자료관리";
            ((System.ComponentModel.ISupportInitialize)(this.bsCandSBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.openDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecSBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCompCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrec)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private OpenDataSet openDataSet;
        private System.Windows.Forms.BindingSource bsPrecSBS;
        private OpenDataSetTableAdapters.Ele_TPrecSBSTableAdapter taPrecSBS;
        private System.Windows.Forms.BindingSource bsCandSBS;
        private OpenDataSetTableAdapters.Ele_TCandSBSTableAdapter taCandSBS;
        private System.Windows.Forms.BindingSource bsCompCode;
        private OpenDataSetTableAdapters.Ele_MCompCodeTableAdapter taCompCode;
        private System.Windows.Forms.DataGridView dgvCand;
        private System.Windows.Forms.DataGridViewTextBoxColumn rankDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn korNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn votesCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn votesRateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn PartyName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbCntT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbCnt4;
        private System.Windows.Forms.Label lbCnt3;
        private System.Windows.Forms.Label lbCnt2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvPrec;
        private System.Windows.Forms.DataGridViewTextBoxColumn ElecCatgr;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrecName;
        private System.Windows.Forms.DataGridViewTextBoxColumn openCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn openRateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn openYNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fstNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ElecGbnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn modHMSDataGridViewTextBoxColumn;

    }
}