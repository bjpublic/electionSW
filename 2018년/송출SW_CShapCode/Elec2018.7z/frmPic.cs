﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Election
{
    public partial class frmPic : Form
    {
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb1; //시도
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb2; //선거종류 
        private DB.ElecDataSet.Ele_TPrecDataTable dtCmb3; //선거구
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb4; //정당
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb5; //사퇴여부

        public DB.ElecDataSet.Ele_TCandDataTable dtCand;

        private ArrayList imgLst = new ArrayList();
        

        public frmPic()
        {
            InitializeComponent();
            Init();
        }

        private void Init()
        {
            dtCmb1 = this.taCode.GetDataByCompLikeStr("600", Global.CompLikeString);
            bsCity.DataSource = dtCmb1;

            dtCmb2 = this.taCode.GetDataByCompLikeStr("010", Global.CompLikeString);
            bsElec.DataSource = dtCmb2;

            //정당
            dtCmb4 = this.taCode.GetData("100");
            bsParty.DataSource = dtCmb4;

            //사퇴여부
            dtCmb5 = this.taCode.GetData("500");
            bsRegGubn.DataSource = dtCmb5;

            dtCand = new DB.ElecDataSet.Ele_TCandDataTable();

        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            //조회조건 설정
            string catgr = cmbElec.SelectedValue.ToString();
            string city = cmbCity.SelectedValue.ToString();


            dtCmb3 = this.taPrec.GetData(catgr, city);
            bsPrec.DataSource = dtCmb3;

            dtCand = this.taCand.GetDataBy(catgr, city);
            bsCand.DataSource = dtCand;


            

           
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.bsCand.Count < 1)
                {
                    MessageBox.Show("후보목록을 조회하세요","알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if (this.txtCnt.Text == "")
                {
                    MessageBox.Show("생성할 후보 사진을 선택하세요", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (this.txtFooter.Text == "")
                {
                    MessageBox.Show("꼬리말을 입력하세요", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.txtFooter.Focus();
                    return;
                }
                //그리드 선거종류, 시도, 선거구, 기호를 읽어온다
                int j = 0;
                for (int i = 0; i < dtCand.Count; i++)
                {

                    DataRow dr = dtCand.Rows[i];
                    String catgr = dr["ElecCatgr"].ToString().Trim();
                    String city = cmbCity.SelectedValue.ToString();
                    String prec = dr["PrecID"].ToString().Trim();
                    String ordNo = dr["OrdNo"].ToString().Trim();

                    int cnt = imgLst.Count;//txtCnt.Text.ToString().Trim();
                    string path = Global.TornadoScenePath + "\\Data\\후보\\";
                    //String path = @"E:\dev\KNN\Elec2014\images\";
                    String strFooter = this.txtFooter.Text.ToString().Trim();

                    string fullFileName = imgLst[j].ToString();
                    string fileName = fullFileName.Substring(0, fullFileName.LastIndexOf("."));
                    string extName = fullFileName.Substring(fullFileName.LastIndexOf("."));
                    FileInfo file = new FileInfo(fullFileName);

                    //MessageBox.Show(fileName + extName);

                    //file.CopyTo(path + prec + ordNo + strFooter + extName, true);


                    file.CopyTo(path + catgr+ "_"+ prec + "_" + ordNo + strFooter + extName, true);

                    j++;
                    if (j >= cnt) j = 0;

                }

                MessageBox.Show("사진 생성이 완료되었습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSelPic_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "후보사진파일(*.png;*.tga;*.vrv)|*.png;*.tga;*.vrv";
            dlg.Multiselect = true;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                imgLst.Clear();
                foreach (string file in dlg.FileNames)
                {
                   // MessageBox.Show(file);
                    imgLst.Add(file);

                }

            }

            this.txtCnt.Text = imgLst.Count.ToString();

        }

        
    }
}
