﻿namespace Election
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            this.panBack = new System.Windows.Forms.Panel();
            this.btnConnect = new System.Windows.Forms.Button();
            this.cbxDb = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbxComp = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.openDataSet = new Election.OpenDataSet();
            this.bsCompInfo = new System.Windows.Forms.BindingSource(this.components);
            this.taCompInfo = new Election.OpenDataSetTableAdapters.Ele_MCompCodeTableAdapter();
            this.btnIni = new System.Windows.Forms.Button();
            this.btnExec = new System.Windows.Forms.Button();
            this.btnReload = new System.Windows.Forms.Button();
            this.btnData = new System.Windows.Forms.Button();
            this.panBack.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.openDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCompInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panBack
            // 
            this.panBack.BackColor = System.Drawing.SystemColors.Desktop;
            this.panBack.Controls.Add(this.btnConnect);
            this.panBack.Controls.Add(this.cbxDb);
            this.panBack.Controls.Add(this.label2);
            this.panBack.Controls.Add(this.cbxComp);
            this.panBack.Controls.Add(this.label1);
            this.panBack.Location = new System.Drawing.Point(109, 222);
            this.panBack.Name = "panBack";
            this.panBack.Size = new System.Drawing.Size(392, 101);
            this.panBack.TabIndex = 0;
            // 
            // btnConnect
            // 
            this.btnConnect.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnConnect.Location = new System.Drawing.Point(257, 23);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(94, 57);
            this.btnConnect.TabIndex = 7;
            this.btnConnect.Text = "접속";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // cbxDb
            // 
            this.cbxDb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxDb.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cbxDb.FormattingEnabled = true;
            this.cbxDb.Location = new System.Drawing.Point(109, 57);
            this.cbxDb.Name = "cbxDb";
            this.cbxDb.Size = new System.Drawing.Size(142, 23);
            this.cbxDb.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(36, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "방송사";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbxComp
            // 
            this.cbxComp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxComp.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cbxComp.FormattingEnabled = true;
            this.cbxComp.Location = new System.Drawing.Point(109, 23);
            this.cbxComp.Name = "cbxComp";
            this.cbxComp.Size = new System.Drawing.Size(142, 23);
            this.cbxComp.TabIndex = 2;
            this.cbxComp.SelectedIndexChanged += new System.EventHandler(this.cbxComp_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(33, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "접속DB";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // openDataSet
            // 
            this.openDataSet.DataSetName = "OpenDataSet";
            this.openDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsCompInfo
            // 
            this.bsCompInfo.DataMember = "Ele_MCompCode";
            this.bsCompInfo.DataSource = this.openDataSet;
            // 
            // taCompInfo
            // 
            this.taCompInfo.ClearBeforeFill = true;
            // 
            // btnIni
            // 
            this.btnIni.Location = new System.Drawing.Point(169, 21);
            this.btnIni.Name = "btnIni";
            this.btnIni.Size = new System.Drawing.Size(75, 23);
            this.btnIni.TabIndex = 1;
            this.btnIni.Text = "INI 열기";
            this.btnIni.UseVisualStyleBackColor = true;
            this.btnIni.Click += new System.EventHandler(this.btnIni_Click);
            // 
            // btnExec
            // 
            this.btnExec.Location = new System.Drawing.Point(7, 21);
            this.btnExec.Name = "btnExec";
            this.btnExec.Size = new System.Drawing.Size(75, 23);
            this.btnExec.TabIndex = 2;
            this.btnExec.Text = "실행폴더";
            this.btnExec.UseVisualStyleBackColor = true;
            this.btnExec.Click += new System.EventHandler(this.btnFolder_Click);
            // 
            // btnReload
            // 
            this.btnReload.Location = new System.Drawing.Point(250, 21);
            this.btnReload.Name = "btnReload";
            this.btnReload.Size = new System.Drawing.Size(75, 23);
            this.btnReload.TabIndex = 3;
            this.btnReload.Text = "다시시작";
            this.btnReload.UseVisualStyleBackColor = true;
            this.btnReload.Click += new System.EventHandler(this.btnReload_Click);
            // 
            // btnData
            // 
            this.btnData.Location = new System.Drawing.Point(88, 21);
            this.btnData.Name = "btnData";
            this.btnData.Size = new System.Drawing.Size(75, 23);
            this.btnData.TabIndex = 4;
            this.btnData.Text = "INI폴더";
            this.btnData.UseVisualStyleBackColor = true;
            this.btnData.Click += new System.EventHandler(this.btnData_Click);
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(599, 402);
            this.Controls.Add(this.btnData);
            this.Controls.Add(this.btnReload);
            this.Controls.Add(this.btnExec);
            this.Controls.Add(this.btnIni);
            this.Controls.Add(this.panBack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "6.4 지방선거 개표방송 시스템";
            this.Load += new System.EventHandler(this.frmLogin_Load);
            this.panBack.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.openDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCompInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panBack;
        private System.Windows.Forms.ComboBox cbxComp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbxDb;
        private System.Windows.Forms.Button btnConnect;
        private OpenDataSet openDataSet;
        private System.Windows.Forms.BindingSource bsCompInfo;
        private OpenDataSetTableAdapters.Ele_MCompCodeTableAdapter taCompInfo;
        private System.Windows.Forms.Button btnIni;
        private System.Windows.Forms.Button btnExec;
        private System.Windows.Forms.Button btnReload;
        private System.Windows.Forms.Button btnData;
    }
}