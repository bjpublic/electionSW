﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Election
{
    public partial class frmCode : Form
    {
        private DB.ElecDataSet.Ele_TCodeDataTable dtCatgr;
        //private DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter tCode;
        private DB.ElecDataSet.Ele_TCodeDataTable dtCode;

        //private SqlDataAdapter dataAdapter = new SqlDataAdapter();

        private String catgr = "";

        DataGridViewRow row;

        public frmCode()
        {
            InitializeComponent();
            
            setControl(); //버튼컨트롤

        
           
        }

       

        private void btnQuery_Click(object sender, EventArgs e)
        {
            dtCatgr = this.taCatgr.GetData("000");
            bsCatgr.DataSource = dtCatgr;
           
            row = null;
            
        }


        private void btnDel_Click(object sender, EventArgs e)
        {
            try
            {
                DataRowView drv = (DataRowView)bsCode.Current;

                if (drv["Catgr"].ToString() == "000" && drv["CCnt"].ToString() != "0")
                {
                    MessageBox.Show("하위 코드가 존재하여 삭제할 수 없습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    if (bsCode.Count > 0)
                    {
                        bsCode.RemoveCurrent();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                setControl();
            }


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //Code값 검사
                //Boolean flag = true;
                //for (int i = 0; i < bsCode.Count; i++)
                //{
                //    bsCode.Position = i;
                //    DataRowView drv1 = (DataRowView)bsCode.Current;
                //    if (drv1["Code"].ToString().Trim() == "")
                //    {
                //        flag = false;
                //        break;
                //    }
                    
                //}
                

                //if (!flag)
                //{
                //    MessageBox.Show("입력하지 않은 필드가 있습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}


                bsCode.EndEdit();
                taCode.Update(dtCode); //데이터 저장
                
                if (catgr == "000") /*카테고리 새로고침*/
                {
                    dtCatgr = this.taCatgr.GetData(catgr);
                    bsCatgr.DataSource = dtCatgr;
                    
                    getCodeList(sender, e);
                }

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("에러발생 : " + ex.Message);
            }
            finally { setControl(); }
        }

        
        private void gdvCatgr_SelectionChanged(object sender, EventArgs e)
        {
            getCodeList(sender, e);
        }


        public void getCodeList(object sender, EventArgs e)
        {
            
           
            if (gdvCatgr.SelectedRows.Count == 0)
            {
                
            }
            else
            {
                row = gdvCatgr.SelectedRows[0];
                //row = gdvCatgr.SelectedRows[0];

                if (row != null)
                {
                    //row = gdvCatgr.SelectedRows[0];
                    //selRowCell = row.Cells[1].Value.ToString();
                    try
                    {
                        string code = row.Cells["cCode"].Value.ToString();
                        
                        catgr = code;                        
                        dtCode = this.taCode.GetData(code);

                        bsCode.DataSource = dtCode;
                        
                    }catch(Exception ex){
                        MessageBox.Show(ex.Message);
                    }
                }

                
            }
            //dgvCode.ResumeLayout();
            setControl();
        }

        public void setControl()
        {
            if (catgr != "")
            {
                this.btnNew.Enabled = true;
                this.tsmNew.Enabled = true;
            }
            else
            {
                this.btnNew.Enabled = false;
                this.tsmNew.Enabled = false;
            }

            if (dgvCode.Rows.Count == 0)
            {
                //this.btnNew.Enabled = false;
                this.btnDel.Enabled = false;                
                this.tsmDel.Enabled = false;
                
            }
            else
            {
                //this.btnNew.Enabled = true;
                this.btnDel.Enabled = true;
                this.tsmNew.Enabled = true;
                this.tsmDel.Enabled = true;

            }
            
        }


        private void btnNew_Click(object sender, EventArgs e)
        {
            

            try
            {
                //Boolean flag = true;
                //for (int i = 0; i < bsCode.Count; i++)
                //{
                //    bsCode.Position = i;
                //    DataRowView drv1 = (DataRowView)bsCode.Current;
                //    if(drv1["Code"].ToString().Trim() == ""){
                //        flag = false;
                //        break;
                //    }

                //}
                

                //if (!flag)
                //{
                //    //MessageBox.Show("입력하지 않은 필드가 있습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}

                DataRowView drv = (DataRowView)bsCode.AddNew();
                drv["Catgr"] = catgr;
                drv["Code"] = "";
                drv["CCnt"] = "0";

                
                

                setControl();

            }
            catch (Exception ex)
            {
                MessageBox.Show("에러발생 : " + ex.Message);
            }


        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvCode_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                if (e.Value != null)
                {
                    e.Value = e.Value.ToString().Trim();
                }
            }  
        }

        private void gdvCatgr_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                if (e.Value != null)
                {
                    e.Value = e.Value.ToString().Trim();
                }
            } 
        }

        private void tsmNew_Click(object sender, EventArgs e)
        {
            this.btnNew_Click(sender, e);
        }

        private void tsmDel_Click(object sender, EventArgs e)
        {
            this.btnDel_Click(sender, e);
        }

        private void tsmSave_Click(object sender, EventArgs e)
        {
            this.btnSave_Click(sender, e);
        }

        private void tsmQuery_Click(object sender, EventArgs e)
        {
            this.btnQuery_Click(sender, e);
        }

        private void tsmExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       


        
    }
}
