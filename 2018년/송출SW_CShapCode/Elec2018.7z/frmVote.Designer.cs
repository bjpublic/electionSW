﻿namespace Election
{
    partial class frmVote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVote));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOpenRate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPollRate = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnInit = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnRndSave = new System.Windows.Forms.Button();
            this.btnRnd = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.dgvCand = new System.Windows.Forms.DataGridView();
            this.elecCatgrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ElecCatgrNm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRECNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ordNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VotesCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VotesRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rank = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsCandSBS = new System.Windows.Forms.BindingSource(this.components);
            this.elecDataSet = new Election.DB.ElecDataSet();
            this.bsCand = new System.Windows.Forms.BindingSource(this.components);
            this.taCand = new Election.DB.ElecDataSetTableAdapters.Ele_TCandSBSTableAdapter();
            this.taCandSBS = new Election.DB.ElecDataSetTableAdapters.Ele_TCandSBSTableAdapter();
            this.bsPrecSBS = new System.Windows.Forms.BindingSource(this.components);
            this.taPrecSBS = new Election.DB.ElecDataSetTableAdapters.Ele_TPrecSBSTableAdapter();
            this.cbElecGbn = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnElec = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCandSBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecSBS)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnElec);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.cbElecGbn);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtOpenRate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtPollRate);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.btnInit);
            this.panel1.Controls.Add(this.btnCalc);
            this.panel1.Controls.Add(this.btnRndSave);
            this.panel1.Controls.Add(this.btnRnd);
            this.panel1.Controls.Add(this.btnQuery);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1029, 67);
            this.panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(576, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(576, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "%";
            // 
            // txtOpenRate
            // 
            this.txtOpenRate.Location = new System.Drawing.Point(513, 35);
            this.txtOpenRate.Name = "txtOpenRate";
            this.txtOpenRate.Size = new System.Drawing.Size(60, 21);
            this.txtOpenRate.TabIndex = 9;
            this.txtOpenRate.Text = "50.0";
            this.txtOpenRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOpenRate_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(466, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "개표율";
            // 
            // txtPollRate
            // 
            this.txtPollRate.Location = new System.Drawing.Point(513, 12);
            this.txtPollRate.Name = "txtPollRate";
            this.txtPollRate.Size = new System.Drawing.Size(60, 21);
            this.txtPollRate.TabIndex = 7;
            this.txtPollRate.Text = "50.0";
            this.txtPollRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPollRate_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(466, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "투표율";
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Location = new System.Drawing.Point(930, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(85, 44);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "종료";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnInit
            // 
            this.btnInit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInit.Location = new System.Drawing.Point(792, 12);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(132, 44);
            this.btnInit.TabIndex = 4;
            this.btnInit.Text = "방송전 초기화";
            this.btnInit.UseVisualStyleBackColor = true;
            this.btnInit.Click += new System.EventHandler(this.btnInit_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(323, 12);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(132, 44);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "득표율 및 순위계산";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnRndSave
            // 
            this.btnRndSave.Location = new System.Drawing.Point(214, 12);
            this.btnRndSave.Name = "btnRndSave";
            this.btnRndSave.Size = new System.Drawing.Size(106, 44);
            this.btnRndSave.TabIndex = 2;
            this.btnRndSave.Text = "랜덤값 저장";
            this.btnRndSave.UseVisualStyleBackColor = true;
            this.btnRndSave.Click += new System.EventHandler(this.btnRndSave_Click);
            // 
            // btnRnd
            // 
            this.btnRnd.Location = new System.Drawing.Point(89, 12);
            this.btnRnd.Name = "btnRnd";
            this.btnRnd.Size = new System.Drawing.Size(122, 44);
            this.btnRnd.TabIndex = 1;
            this.btnRnd.Text = "랜덤 득표수 발생";
            this.btnRnd.UseVisualStyleBackColor = true;
            this.btnRnd.Click += new System.EventHandler(this.btnRnd_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(12, 12);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 44);
            this.btnQuery.TabIndex = 0;
            this.btnQuery.Text = "조회";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // dgvCand
            // 
            this.dgvCand.AllowUserToAddRows = false;
            this.dgvCand.AllowUserToDeleteRows = false;
            this.dgvCand.AllowUserToResizeColumns = false;
            this.dgvCand.AllowUserToResizeRows = false;
            this.dgvCand.AutoGenerateColumns = false;
            this.dgvCand.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCand.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.elecCatgrDataGridViewTextBoxColumn,
            this.ElecCatgrNm,
            this.PRECNAME,
            this.precIDDataGridViewTextBoxColumn,
            this.ordNoDataGridViewTextBoxColumn,
            this.VotesCnt,
            this.VotesRate,
            this.Rank});
            this.dgvCand.DataSource = this.bsCandSBS;
            this.dgvCand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCand.Location = new System.Drawing.Point(0, 67);
            this.dgvCand.MultiSelect = false;
            this.dgvCand.Name = "dgvCand";
            this.dgvCand.ReadOnly = true;
            this.dgvCand.RowHeadersVisible = false;
            this.dgvCand.RowTemplate.Height = 23;
            this.dgvCand.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCand.Size = new System.Drawing.Size(1029, 437);
            this.dgvCand.TabIndex = 1;
            // 
            // elecCatgrDataGridViewTextBoxColumn
            // 
            this.elecCatgrDataGridViewTextBoxColumn.DataPropertyName = "ElecCatgr";
            this.elecCatgrDataGridViewTextBoxColumn.HeaderText = "ElecCatgr";
            this.elecCatgrDataGridViewTextBoxColumn.Name = "elecCatgrDataGridViewTextBoxColumn";
            this.elecCatgrDataGridViewTextBoxColumn.ReadOnly = true;
            this.elecCatgrDataGridViewTextBoxColumn.Visible = false;
            // 
            // ElecCatgrNm
            // 
            this.ElecCatgrNm.DataPropertyName = "ElecCatgrNm";
            this.ElecCatgrNm.HeaderText = "선거";
            this.ElecCatgrNm.Name = "ElecCatgrNm";
            this.ElecCatgrNm.ReadOnly = true;
            // 
            // PRECNAME
            // 
            this.PRECNAME.DataPropertyName = "PRECNAME";
            this.PRECNAME.HeaderText = "선거구";
            this.PRECNAME.Name = "PRECNAME";
            this.PRECNAME.ReadOnly = true;
            // 
            // precIDDataGridViewTextBoxColumn
            // 
            this.precIDDataGridViewTextBoxColumn.DataPropertyName = "PrecID";
            this.precIDDataGridViewTextBoxColumn.HeaderText = "PrecID";
            this.precIDDataGridViewTextBoxColumn.Name = "precIDDataGridViewTextBoxColumn";
            this.precIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.precIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // ordNoDataGridViewTextBoxColumn
            // 
            this.ordNoDataGridViewTextBoxColumn.DataPropertyName = "OrdNo";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ordNoDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.ordNoDataGridViewTextBoxColumn.HeaderText = "기호";
            this.ordNoDataGridViewTextBoxColumn.Name = "ordNoDataGridViewTextBoxColumn";
            this.ordNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // VotesCnt
            // 
            this.VotesCnt.DataPropertyName = "VotesCnt";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VotesCnt.DefaultCellStyle = dataGridViewCellStyle2;
            this.VotesCnt.HeaderText = "득표수";
            this.VotesCnt.Name = "VotesCnt";
            this.VotesCnt.ReadOnly = true;
            // 
            // VotesRate
            // 
            this.VotesRate.DataPropertyName = "VotesRate";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.VotesRate.DefaultCellStyle = dataGridViewCellStyle3;
            this.VotesRate.HeaderText = "득표율";
            this.VotesRate.Name = "VotesRate";
            this.VotesRate.ReadOnly = true;
            // 
            // Rank
            // 
            this.Rank.DataPropertyName = "Rank";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Rank.DefaultCellStyle = dataGridViewCellStyle4;
            this.Rank.HeaderText = "순위";
            this.Rank.Name = "Rank";
            this.Rank.ReadOnly = true;
            // 
            // bsCandSBS
            // 
            this.bsCandSBS.AllowNew = true;
            this.bsCandSBS.DataMember = "Ele_TCandSBS";
            this.bsCandSBS.DataSource = this.elecDataSet;
            // 
            // elecDataSet
            // 
            this.elecDataSet.DataSetName = "ElecDataSet";
            this.elecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsCand
            // 
            this.bsCand.AllowNew = true;
            this.bsCand.DataMember = "Ele_TCand";
            this.bsCand.DataSource = this.elecDataSet;
            // 
            // taCand
            // 
            this.taCand.ClearBeforeFill = true;
            // 
            // taCandSBS
            // 
            this.taCandSBS.ClearBeforeFill = true;
            // 
            // bsPrecSBS
            // 
            this.bsPrecSBS.AllowNew = true;
            this.bsPrecSBS.DataMember = "Ele_TPrecSBS";
            this.bsPrecSBS.DataSource = this.elecDataSet;
            // 
            // taPrecSBS
            // 
            this.taPrecSBS.ClearBeforeFill = true;
            // 
            // cbElecGbn
            // 
            this.cbElecGbn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbElecGbn.FormattingEnabled = true;
            this.cbElecGbn.Items.AddRange(new object[] {
            "없음",
            "유력",
            "확실",
            "당선",
            "렌덤"});
            this.cbElecGbn.Location = new System.Drawing.Point(597, 35);
            this.cbElecGbn.Name = "cbElecGbn";
            this.cbElecGbn.Size = new System.Drawing.Size(71, 20);
            this.cbElecGbn.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(611, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "당선 설정";
            // 
            // btnElec
            // 
            this.btnElec.Location = new System.Drawing.Point(674, 12);
            this.btnElec.Name = "btnElec";
            this.btnElec.Size = new System.Drawing.Size(95, 44);
            this.btnElec.TabIndex = 14;
            this.btnElec.Text = "당선처리";
            this.btnElec.UseVisualStyleBackColor = true;
            this.btnElec.Click += new System.EventHandler(this.btnElec_Click);
            // 
            // frmVote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1029, 504);
            this.Controls.Add(this.dgvCand);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmVote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "개표데이터 생성 및 초기화";
            this.Load += new System.EventHandler(this.frmVote_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCandSBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecSBS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvCand;
        private System.Windows.Forms.Button btnRndSave;
        private System.Windows.Forms.Button btnRnd;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnInit;
        private DB.ElecDataSet elecDataSet;
        private System.Windows.Forms.BindingSource bsCand;
        private DB.ElecDataSetTableAdapters.Ele_TCandSBSTableAdapter taCand;
        private DB.ElecDataSetTableAdapters.Ele_TCandSBSTableAdapter taCandSBS;
        private System.Windows.Forms.BindingSource bsCandSBS;
        private System.Windows.Forms.DataGridViewTextBoxColumn elecCatgrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ElecCatgrNm;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRECNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn precIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ordNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn VotesCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn VotesRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rank;
        private System.Windows.Forms.TextBox txtOpenRate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPollRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource bsPrecSBS;
        private DB.ElecDataSetTableAdapters.Ele_TPrecSBSTableAdapter taPrecSBS;
        private System.Windows.Forms.Button btnElec;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbElecGbn;
    }
}