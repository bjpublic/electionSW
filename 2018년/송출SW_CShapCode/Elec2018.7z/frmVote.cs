﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Election
{
    public partial class frmVote : Form    
    {
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb2; //선거종류                       
        private DB.ElecDataSet.Ele_TPrecDataTable dtCmb3; //선거구
        private DB.ElecDataSet.Ele_TCandDataTable dtCand;
        private DB.ElecDataSet.Ele_TCandSBSDataTable dtCandSBS;
        private DB.ElecDataSet.Ele_TCandSBSDataTable dtCandSBS2;

        
        
        public frmVote()
        {
            InitializeComponent();

            cbElecGbn.SelectedIndex = 0;

            setControl();
        }


        private void btnQuery_Click(object sender, EventArgs e)
        {
            dtCandSBS = this.taCandSBS.GetData();
            //dtCandSBS2 = this.taCandSBS.GetDataBy();



            bsCandSBS.DataSource = dtCandSBS;

            setControl();
        }

        private void frmVote_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'elecDataSet.Ele_TPrecSBS' 테이블에 로드합니다. 필요한 경우 이 코드를 이동하거나 제거할 수 있습니다.
            this.taPrecSBS.Fill(this.elecDataSet.Ele_TPrecSBS);
            // TODO: 이 코드는 데이터를 'elecDataSet.Ele_TCandSBS' 테이블에 로드합니다. 필요한 경우 이 코드를 이동하거나 제거할 수 있습니다.
            //this.taCand.Fill(this.elecDataSet.Ele_TCandSBS);

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRnd_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(bsCandSBS.Count+"");
            Random r = new Random();
            for (int i = 0; i < bsCandSBS.Count; i++){
            
                bsCandSBS.Position = i;
                DataRowView drv = (DataRowView)this.bsCandSBS.Current;
                //MessageBox.Show(drv["PrecID"].ToString());
                drv["VotesCnt"] = r.Next(1, 100000);
                //drv["VotesRate"] = 0;
                //drv["Rank"] = 0;
            }
        }

        private void setControl()
        {
            if (bsCandSBS.Count > 0)
            {
                this.btnRnd.Enabled = true;
                this.btnRndSave.Enabled = true;
                this.btnCalc.Enabled = true;
            }
            else
            {
                this.btnRnd.Enabled = false;
                this.btnRndSave.Enabled = false;
                this.btnCalc.Enabled = false;
            }
        }

        private void btnRndSave_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                bsCandSBS.EndEdit();
                taCandSBS.Update(dtCandSBS);//후보자 득표수저장

                bsCandSBS.MoveFirst();
            }
            catch (DBConcurrencyException ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally { this.Cursor = Cursors.Arrow; }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (this.txtPollRate.Text == "")
            {
                MessageBox.Show("투표율을 입력하세요");
                this.txtPollRate.Focus();
                return;
            }
            if (this.txtOpenRate.Text == "")
            {
                MessageBox.Show("개표율을 입력하세요");
                this.txtOpenRate.Focus();
                return;
            }

            //선거구 득표수, 득표율 저장
            //무투표당선자 처리(출마자 1명인곳은 득표수, 득표율 0)
            taCandSBS.UpdateNoVoteMan();
            //선거구별 유권자수, 투표자수, 개표수 역 계산
            taPrecSBS.UpdatePrec(this.txtOpenRate.Text.ToString().Trim(), this.txtPollRate.Text.ToString().Trim());
            //무투표 당선자 당선처리(개표수가 0인것을 80처리)
            taPrecSBS.UpdateNoVotePrec();
            //득표율 및 순위구해서 넣어준다.
            taCandSBS.UpdateCand(); //득표율 계산
            taCandSBS.UpdateRank(); //순위계산
            taPrecSBS.UpdateRank(); //1위 순위

            btnQuery_Click(sender, e);
            bsCandSBS.MoveFirst();
        }

        private void txtPollRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            int keyCode = (int)e.KeyChar;  // 46: Point  
            if ((keyCode < 48 || keyCode > 57) && keyCode != 8 && keyCode != 46)
            {
                e.Handled = true;
            }
        }

        private void txtOpenRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            int keyCode = (int)e.KeyChar;  // 46: Point  
            if ((keyCode < 48 || keyCode > 57) && keyCode != 8 && keyCode != 46)
            {
                e.Handled = true;
            }
        }

        private void btnInit_Click(object sender, EventArgs e)
        {
            taCandSBS.DeleteAll();  //전 후보삭제
            taCandSBS.InsertAll();  //전 후보생성
            taPrecSBS.DeleteAll();  //전 선거구삭제
            taPrecSBS.InsertAll();  //전 선거구생성
            btnQuery_Click(sender, e);
        }

        private void btnElec_Click(object sender, EventArgs e)
        {

            DB.ElecDataSet.Ele_TPrecSBSDataTable tPrec = taPrecSBS.GetData();
            bsPrecSBS.DataSource = tPrec;

            Random r = new Random();
            for (int i = 0; i < bsPrecSBS.Count; i++)
            {
                bsPrecSBS.Position = i;
                DataRowView drv = (DataRowView)this.bsPrecSBS.Current;

                int cnt = int.Parse(drv["OpenCnt"].ToString());
                bool fin = drv["OpenRate"].ToString() == "100.0" ? true : false;

                // elecgbn index -> 0:없음, 1:유력, 2:확실, 3:당선, 4:렌덤
                int idx = cbElecGbn.SelectedIndex;
                string elecgbn = "00";
                if(idx == 4) idx = r.Next(0, 4);
                switch(idx)
                {
                    case 1: elecgbn = "40"; break;
                    case 2: elecgbn = "50"; break;
                    case 3: elecgbn = fin ? "90" : "60"; break;
                    default: elecgbn = "00"; break;
                }
                if (cnt == 0) elecgbn = "80";   //개표수가 없으면, 무투표당선 처리
                drv["ElecGbn"] = elecgbn;
            }

            try
            {
                this.Cursor = Cursors.WaitCursor;
                bsPrecSBS.EndEdit();
                taPrecSBS.Update(tPrec);
            }
            catch (DBConcurrencyException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally 
            { 
                this.Cursor = Cursors.Arrow; 
            }
        }



        
    }
}
