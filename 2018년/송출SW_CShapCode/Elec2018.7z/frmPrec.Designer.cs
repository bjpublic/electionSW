﻿namespace Election
{
    partial class frmPrec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrec));
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbElecCatgr = new System.Windows.Forms.ComboBox();
            this.bsCode = new System.Windows.Forms.BindingSource(this.components);
            this.elecDataSet = new Election.DB.ElecDataSet();
            this.cbCity = new System.Windows.Forms.ComboBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmbElecCatgr = new System.Windows.Forms.ComboBox();
            this.bsPrec = new System.Windows.Forms.BindingSource(this.components);
            this.bsElecCatgr = new System.Windows.Forms.BindingSource(this.components);
            this.txtPollDist = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAdultCnt = new System.Windows.Forms.TextBox();
            this.txtPrecName = new System.Windows.Forms.TextBox();
            this.txtHomeCnt = new System.Windows.Forms.TextBox();
            this.txtPrecOrd = new System.Windows.Forms.TextBox();
            this.txtPrecID = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPopCnt = new System.Windows.Forms.TextBox();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.bsCity = new System.Windows.Forms.BindingSource(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTxt1 = new System.Windows.Forms.Label();
            this.dgvPrec = new System.Windows.Forms.DataGridView();
            this.pCity = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.pElecCatgr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CatgrName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pPrecID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pPrecName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pPopCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pHomeCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pAdultCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pPollDist = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pPrecOrd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmQuery = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmNew = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmDel = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmSave = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmExit = new System.Windows.Forms.ToolStripMenuItem();
            this.taCode = new Election.DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter();
            this.taPrec = new Election.DB.ElecDataSetTableAdapters.Ele_TPrecTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsElecCatgr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrec)).BeginInit();
            this.contextMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbElecCatgr);
            this.panel1.Controls.Add(this.cbCity);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.btnDel);
            this.panel1.Controls.Add(this.btnNew);
            this.panel1.Controls.Add(this.btnQuery);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(849, 50);
            this.panel1.TabIndex = 0;
            // 
            // cbElecCatgr
            // 
            this.cbElecCatgr.DataSource = this.bsCode;
            this.cbElecCatgr.DisplayMember = "ADesc";
            this.cbElecCatgr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbElecCatgr.FormattingEnabled = true;
            this.cbElecCatgr.Location = new System.Drawing.Point(75, 15);
            this.cbElecCatgr.Name = "cbElecCatgr";
            this.cbElecCatgr.Size = new System.Drawing.Size(171, 20);
            this.cbElecCatgr.TabIndex = 1;
            this.cbElecCatgr.ValueMember = "Code";
            // 
            // bsCode
            // 
            this.bsCode.AllowNew = true;
            this.bsCode.DataMember = "Ele_TCode";
            this.bsCode.DataSource = this.elecDataSet;
            // 
            // elecDataSet
            // 
            this.elecDataSet.DataSetName = "ElecDataSet";
            this.elecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cbCity
            // 
            this.cbCity.DataSource = this.bsCode;
            this.cbCity.DisplayMember = "ADesc";
            this.cbCity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCity.FormattingEnabled = true;
            this.cbCity.Location = new System.Drawing.Point(315, 15);
            this.cbCity.Name = "cbCity";
            this.cbCity.Size = new System.Drawing.Size(100, 20);
            this.cbCity.TabIndex = 2;
            this.cbCity.ValueMember = "Code";
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Location = new System.Drawing.Point(758, 9);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 34);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "종료";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(677, 9);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 34);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "저장";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDel
            // 
            this.btnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDel.Location = new System.Drawing.Point(596, 9);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(75, 34);
            this.btnDel.TabIndex = 5;
            this.btnDel.Text = "삭제";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnNew
            // 
            this.btnNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNew.Location = new System.Drawing.Point(515, 9);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 34);
            this.btnNew.TabIndex = 4;
            this.btnNew.Text = "신규";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuery.Location = new System.Drawing.Point(434, 9);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 34);
            this.btnQuery.TabIndex = 3;
            this.btnQuery.Text = "조회";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(252, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "시/도";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "선거종류";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cmbElecCatgr);
            this.panel2.Controls.Add(this.txtPollDist);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtAdultCnt);
            this.panel2.Controls.Add(this.txtPrecName);
            this.panel2.Controls.Add(this.txtHomeCnt);
            this.panel2.Controls.Add(this.txtPrecOrd);
            this.panel2.Controls.Add(this.txtPrecID);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.txtPopCnt);
            this.panel2.Controls.Add(this.cmbCity);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lblTxt1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(849, 124);
            this.panel2.TabIndex = 1;
            // 
            // cmbElecCatgr
            // 
            this.cmbElecCatgr.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bsPrec, "ElecCatgr", true));
            this.cmbElecCatgr.DataSource = this.bsElecCatgr;
            this.cmbElecCatgr.DisplayMember = "ADesc";
            this.cmbElecCatgr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbElecCatgr.Enabled = false;
            this.cmbElecCatgr.FormattingEnabled = true;
            this.cmbElecCatgr.Location = new System.Drawing.Point(121, 40);
            this.cmbElecCatgr.Name = "cmbElecCatgr";
            this.cmbElecCatgr.Size = new System.Drawing.Size(160, 20);
            this.cmbElecCatgr.TabIndex = 21;
            this.cmbElecCatgr.ValueMember = "Code";
            // 
            // bsPrec
            // 
            this.bsPrec.AllowNew = true;
            this.bsPrec.DataMember = "Ele_TPrec";
            this.bsPrec.DataSource = this.elecDataSet;
            // 
            // bsElecCatgr
            // 
            this.bsElecCatgr.DataMember = "Ele_TCode";
            this.bsElecCatgr.DataSource = this.elecDataSet;
            // 
            // txtPollDist
            // 
            this.txtPollDist.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPrec, "PollDist", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "N0"));
            this.txtPollDist.Location = new System.Drawing.Point(672, 68);
            this.txtPollDist.MaxLength = 50;
            this.txtPollDist.Name = "txtPollDist";
            this.txtPollDist.Size = new System.Drawing.Size(160, 21);
            this.txtPollDist.TabIndex = 13;
            this.txtPollDist.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPollDist.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPollDist_KeyPress);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(566, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 21);
            this.label6.TabIndex = 20;
            this.label6.Text = "투표구수";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtAdultCnt
            // 
            this.txtAdultCnt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPrec, "AdultCnt", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "N0"));
            this.txtAdultCnt.Location = new System.Drawing.Point(672, 94);
            this.txtAdultCnt.MaxLength = 8;
            this.txtAdultCnt.Name = "txtAdultCnt";
            this.txtAdultCnt.Size = new System.Drawing.Size(160, 21);
            this.txtAdultCnt.TabIndex = 16;
            this.txtAdultCnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAdultCnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdultCnt_KeyPress);
            // 
            // txtPrecName
            // 
            this.txtPrecName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPrec, "PrecName", true));
            this.txtPrecName.Location = new System.Drawing.Point(672, 40);
            this.txtPrecName.MaxLength = 50;
            this.txtPrecName.Name = "txtPrecName";
            this.txtPrecName.Size = new System.Drawing.Size(160, 21);
            this.txtPrecName.TabIndex = 10;
            // 
            // txtHomeCnt
            // 
            this.txtHomeCnt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPrec, "HomeCnt", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "N0"));
            this.txtHomeCnt.Location = new System.Drawing.Point(397, 95);
            this.txtHomeCnt.MaxLength = 8;
            this.txtHomeCnt.Name = "txtHomeCnt";
            this.txtHomeCnt.Size = new System.Drawing.Size(160, 21);
            this.txtHomeCnt.TabIndex = 15;
            this.txtHomeCnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtHomeCnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHomeCnt_KeyPress);
            // 
            // txtPrecOrd
            // 
            this.txtPrecOrd.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPrec, "PrecOrd", true));
            this.txtPrecOrd.Location = new System.Drawing.Point(397, 69);
            this.txtPrecOrd.MaxLength = 3;
            this.txtPrecOrd.Name = "txtPrecOrd";
            this.txtPrecOrd.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtPrecOrd.Size = new System.Drawing.Size(160, 21);
            this.txtPrecOrd.TabIndex = 12;
            // 
            // txtPrecID
            // 
            this.txtPrecID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPrec, "PrecID", true));
            this.txtPrecID.Location = new System.Drawing.Point(397, 41);
            this.txtPrecID.MaxLength = 8;
            this.txtPrecID.Name = "txtPrecID";
            this.txtPrecID.Size = new System.Drawing.Size(160, 21);
            this.txtPrecID.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(566, 94);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 21);
            this.label12.TabIndex = 13;
            this.label12.Text = "20세이상주민수";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(566, 40);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 21);
            this.label13.TabIndex = 12;
            this.label13.Text = "선거구명";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPopCnt
            // 
            this.txtPopCnt.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPrec, "PopCnt", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "N0"));
            this.txtPopCnt.Location = new System.Drawing.Point(120, 95);
            this.txtPopCnt.MaxLength = 8;
            this.txtPopCnt.Name = "txtPopCnt";
            this.txtPopCnt.Size = new System.Drawing.Size(160, 21);
            this.txtPopCnt.TabIndex = 14;
            this.txtPopCnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPopCnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPopCnt_KeyPress);
            // 
            // cmbCity
            // 
            this.cmbCity.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bsPrec, "City", true));
            this.cmbCity.DataSource = this.bsCity;
            this.cmbCity.DisplayMember = "ADesc";
            this.cmbCity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCity.Enabled = false;
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Location = new System.Drawing.Point(121, 68);
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.Size = new System.Drawing.Size(160, 20);
            this.cmbCity.TabIndex = 11;
            this.cmbCity.ValueMember = "Code";
            // 
            // bsCity
            // 
            this.bsCity.DataMember = "Ele_TCode";
            this.bsCity.DataSource = this.elecDataSet;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(291, 95);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 21);
            this.label8.TabIndex = 8;
            this.label8.Text = "세대수";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(291, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 21);
            this.label9.TabIndex = 7;
            this.label9.Text = "정렬";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(291, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 21);
            this.label10.TabIndex = 6;
            this.label10.Text = "선거구코드";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(14, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "인구수";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(14, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "시/도";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(283, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "* 인구수/세대수/주민수 내용은 사용하지 않습니다.";
            // 
            // lblTxt1
            // 
            this.lblTxt1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTxt1.ForeColor = System.Drawing.Color.White;
            this.lblTxt1.Location = new System.Drawing.Point(14, 41);
            this.lblTxt1.Name = "lblTxt1";
            this.lblTxt1.Size = new System.Drawing.Size(100, 21);
            this.lblTxt1.TabIndex = 0;
            this.lblTxt1.Text = "선거종류";
            this.lblTxt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvPrec
            // 
            this.dgvPrec.AllowUserToAddRows = false;
            this.dgvPrec.AllowUserToDeleteRows = false;
            this.dgvPrec.AllowUserToResizeColumns = false;
            this.dgvPrec.AllowUserToResizeRows = false;
            this.dgvPrec.AutoGenerateColumns = false;
            this.dgvPrec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrec.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pCity,
            this.pElecCatgr,
            this.CatgrName,
            this.pPrecID,
            this.pPrecName,
            this.pPopCnt,
            this.pHomeCnt,
            this.pAdultCnt,
            this.pPollDist,
            this.pPrecOrd});
            this.dgvPrec.DataSource = this.bsPrec;
            this.dgvPrec.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPrec.Location = new System.Drawing.Point(0, 174);
            this.dgvPrec.MultiSelect = false;
            this.dgvPrec.Name = "dgvPrec";
            this.dgvPrec.ReadOnly = true;
            this.dgvPrec.RowHeadersVisible = false;
            this.dgvPrec.RowTemplate.Height = 23;
            this.dgvPrec.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrec.Size = new System.Drawing.Size(849, 330);
            this.dgvPrec.TabIndex = 2;
            this.dgvPrec.SelectionChanged += new System.EventHandler(this.dgvPrec_SelectionChanged);
            // 
            // pCity
            // 
            this.pCity.DataPropertyName = "City";
            this.pCity.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.pCity.HeaderText = "시/도";
            this.pCity.Name = "pCity";
            this.pCity.ReadOnly = true;
            this.pCity.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.pCity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.pCity.Visible = false;
            // 
            // pElecCatgr
            // 
            this.pElecCatgr.DataPropertyName = "ElecCatgr";
            this.pElecCatgr.HeaderText = "선거종류";
            this.pElecCatgr.Name = "pElecCatgr";
            this.pElecCatgr.ReadOnly = true;
            this.pElecCatgr.Visible = false;
            // 
            // CatgrName
            // 
            this.CatgrName.DataPropertyName = "CatgrName";
            this.CatgrName.HeaderText = "선거종류명";
            this.CatgrName.Name = "CatgrName";
            this.CatgrName.ReadOnly = true;
            this.CatgrName.Visible = false;
            // 
            // pPrecID
            // 
            this.pPrecID.DataPropertyName = "PrecID";
            this.pPrecID.HeaderText = "선거구ID";
            this.pPrecID.Name = "pPrecID";
            this.pPrecID.ReadOnly = true;
            this.pPrecID.Visible = false;
            // 
            // pPrecName
            // 
            this.pPrecName.DataPropertyName = "PrecName";
            this.pPrecName.HeaderText = "선거구명";
            this.pPrecName.MaxInputLength = 50;
            this.pPrecName.Name = "pPrecName";
            this.pPrecName.ReadOnly = true;
            this.pPrecName.Width = 160;
            // 
            // pPopCnt
            // 
            this.pPopCnt.DataPropertyName = "PopCnt";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N0";
            dataGridViewCellStyle1.NullValue = "0";
            this.pPopCnt.DefaultCellStyle = dataGridViewCellStyle1;
            this.pPopCnt.HeaderText = "인구수";
            this.pPopCnt.Name = "pPopCnt";
            this.pPopCnt.ReadOnly = true;
            this.pPopCnt.Width = 150;
            // 
            // pHomeCnt
            // 
            this.pHomeCnt.DataPropertyName = "HomeCnt";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N0";
            dataGridViewCellStyle2.NullValue = "0";
            this.pHomeCnt.DefaultCellStyle = dataGridViewCellStyle2;
            this.pHomeCnt.HeaderText = "세대수";
            this.pHomeCnt.Name = "pHomeCnt";
            this.pHomeCnt.ReadOnly = true;
            this.pHomeCnt.Width = 150;
            // 
            // pAdultCnt
            // 
            this.pAdultCnt.DataPropertyName = "AdultCnt";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N0";
            dataGridViewCellStyle3.NullValue = "0";
            this.pAdultCnt.DefaultCellStyle = dataGridViewCellStyle3;
            this.pAdultCnt.HeaderText = "20세이상";
            this.pAdultCnt.Name = "pAdultCnt";
            this.pAdultCnt.ReadOnly = true;
            this.pAdultCnt.Width = 140;
            // 
            // pPollDist
            // 
            this.pPollDist.DataPropertyName = "PollDist";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = "0";
            this.pPollDist.DefaultCellStyle = dataGridViewCellStyle4;
            this.pPollDist.HeaderText = "투표구수";
            this.pPollDist.Name = "pPollDist";
            this.pPollDist.ReadOnly = true;
            this.pPollDist.Width = 150;
            // 
            // pPrecOrd
            // 
            this.pPrecOrd.DataPropertyName = "PrecOrd";
            this.pPrecOrd.HeaderText = "선거구순서";
            this.pPrecOrd.Name = "pPrecOrd";
            this.pPrecOrd.ReadOnly = true;
            this.pPrecOrd.Width = 90;
            // 
            // contextMenu
            // 
            this.contextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmQuery,
            this.toolStripSeparator1,
            this.tsmNew,
            this.tsmDel,
            this.tsmSave,
            this.toolStripSeparator2,
            this.tsmExit});
            this.contextMenu.Name = "contextMenu";
            this.contextMenu.Size = new System.Drawing.Size(157, 148);
            // 
            // tsmQuery
            // 
            this.tsmQuery.Name = "tsmQuery";
            this.tsmQuery.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.tsmQuery.Size = new System.Drawing.Size(156, 22);
            this.tsmQuery.Text = "조회";
            this.tsmQuery.Click += new System.EventHandler(this.tsmQuery_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(153, 6);
            // 
            // tsmNew
            // 
            this.tsmNew.Name = "tsmNew";
            this.tsmNew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.tsmNew.Size = new System.Drawing.Size(156, 22);
            this.tsmNew.Text = "신규(&F)";
            this.tsmNew.Click += new System.EventHandler(this.tsmNew_Click);
            // 
            // tsmDel
            // 
            this.tsmDel.Name = "tsmDel";
            this.tsmDel.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D)));
            this.tsmDel.Size = new System.Drawing.Size(156, 22);
            this.tsmDel.Text = "삭제(&D)";
            this.tsmDel.Click += new System.EventHandler(this.tsmDel_Click);
            // 
            // tsmSave
            // 
            this.tsmSave.Name = "tsmSave";
            this.tsmSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.tsmSave.Size = new System.Drawing.Size(156, 22);
            this.tsmSave.Text = "저장(&S)";
            this.tsmSave.Click += new System.EventHandler(this.tsmSave_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(153, 6);
            // 
            // tsmExit
            // 
            this.tsmExit.Name = "tsmExit";
            this.tsmExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.tsmExit.Size = new System.Drawing.Size(156, 22);
            this.tsmExit.Text = "종료(&X)";
            this.tsmExit.Click += new System.EventHandler(this.tsmExit_Click);
            // 
            // taCode
            // 
            this.taCode.ClearBeforeFill = true;
            // 
            // taPrec
            // 
            this.taPrec.ClearBeforeFill = true;
            // 
            // frmPrec
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 504);
            this.ContextMenuStrip = this.contextMenu;
            this.Controls.Add(this.dgvPrec);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmPrec";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "선거구관리";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bsCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsElecCatgr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrec)).EndInit();
            this.contextMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvPrec;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private DB.ElecDataSet elecDataSet;
        private DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter taCode;
        private System.Windows.Forms.BindingSource bsCode;
        private System.Windows.Forms.ComboBox cbCity;
        private System.Windows.Forms.BindingSource bsPrec;
        private DB.ElecDataSetTableAdapters.Ele_TPrecTableAdapter taPrec;
        private System.Windows.Forms.Label lblTxt1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbCity;
        private System.Windows.Forms.TextBox txtPopCnt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtPrecID;
        private System.Windows.Forms.TextBox txtAdultCnt;
        private System.Windows.Forms.TextBox txtPrecName;
        private System.Windows.Forms.TextBox txtHomeCnt;
        private System.Windows.Forms.TextBox txtPrecOrd;
        
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPollDist;
        internal System.Windows.Forms.ComboBox cbElecCatgr;
        private System.Windows.Forms.BindingSource bsCity;
        private System.Windows.Forms.ComboBox cmbElecCatgr;
        private System.Windows.Forms.BindingSource bsElecCatgr;
        private System.Windows.Forms.ContextMenuStrip contextMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmNew;
        private System.Windows.Forms.ToolStripMenuItem tsmDel;
        private System.Windows.Forms.ToolStripMenuItem tsmSave;
        private System.Windows.Forms.ToolStripMenuItem tsmQuery;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem tsmExit;
        private System.Windows.Forms.DataGridViewComboBoxColumn pCity;
        private System.Windows.Forms.DataGridViewTextBoxColumn pElecCatgr;
        private System.Windows.Forms.DataGridViewTextBoxColumn CatgrName;
        private System.Windows.Forms.DataGridViewTextBoxColumn pPrecID;
        private System.Windows.Forms.DataGridViewTextBoxColumn pPrecName;
        private System.Windows.Forms.DataGridViewTextBoxColumn pPopCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn pHomeCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn pAdultCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn pPollDist;
        private System.Windows.Forms.DataGridViewTextBoxColumn pPrecOrd;
    }
}