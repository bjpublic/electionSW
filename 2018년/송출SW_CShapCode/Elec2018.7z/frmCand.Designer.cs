﻿namespace Election
{
    partial class frmCand
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCand));
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmb2 = new System.Windows.Forms.ComboBox();
            this.bsElec = new System.Windows.Forms.BindingSource(this.components);
            this.elecDataSet = new Election.DB.ElecDataSet();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.cmb3 = new System.Windows.Forms.ComboBox();
            this.bsPrec = new System.Windows.Forms.BindingSource(this.components);
            this.cmb1 = new System.Windows.Forms.ComboBox();
            this.bsCity = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.bsCode = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmbPrec = new System.Windows.Forms.ComboBox();
            this.bsCand = new System.Windows.Forms.BindingSource(this.components);
            this.bsPrecView = new System.Windows.Forms.BindingSource(this.components);
            this.cmbElec = new System.Windows.Forms.ComboBox();
            this.bsElecView = new System.Windows.Forms.BindingSource(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtChgYMD = new System.Windows.Forms.TextBox();
            this.txtKorName = new System.Windows.Forms.TextBox();
            this.cmbRegGbn = new System.Windows.Forms.ComboBox();
            this.bsRegGubn = new System.Windows.Forms.BindingSource(this.components);
            this.cmbPartyCode = new System.Windows.Forms.ComboBox();
            this.bsParty = new System.Windows.Forms.BindingSource(this.components);
            this.txtCareer1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtChgResn = new System.Windows.Forms.TextBox();
            this.txtCareer4 = new System.Windows.Forms.TextBox();
            this.txtCareer3 = new System.Windows.Forms.TextBox();
            this.txtCareer2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtOrdNo = new System.Windows.Forms.TextBox();
            this.lblTxt1 = new System.Windows.Forms.Label();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnDelAll = new System.Windows.Forms.Button();
            this.btnFileSave = new System.Windows.Forms.Button();
            this.dgvCand = new System.Windows.Forms.DataGridView();
            this.elecCatgrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.bsPrecList = new System.Windows.Forms.BindingSource(this.components);
            this.cOrdNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.korNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chaNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partyCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.socialNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addr1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addr2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.schCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradYMDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jobCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.career1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.career2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.career3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.career4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.regGbnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.elecCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.candCntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.regYMDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chgYMDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chgResnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmQuery = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmNew = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmDel = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmDelAll = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmSave = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmExit = new System.Windows.Forms.ToolStripMenuItem();
            this.taCode = new Election.DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter();
            this.taPrec = new Election.DB.ElecDataSetTableAdapters.Ele_TPrecTableAdapter();
            this.taCand = new Election.DB.ElecDataSetTableAdapters.Ele_TCandTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsElec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCode)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsCand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsElecView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsRegGubn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsParty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecList)).BeginInit();
            this.contextMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cmb2);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.cmb3);
            this.panel1.Controls.Add(this.cmb1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnDel);
            this.panel1.Controls.Add(this.btnNew);
            this.panel1.Controls.Add(this.btnQuery);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(849, 42);
            this.panel1.TabIndex = 3;
            // 
            // cmb2
            // 
            this.cmb2.DataSource = this.bsElec;
            this.cmb2.DisplayMember = "ADesc";
            this.cmb2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb2.FormattingEnabled = true;
            this.cmb2.Location = new System.Drawing.Point(63, 11);
            this.cmb2.Name = "cmb2";
            this.cmb2.Size = new System.Drawing.Size(100, 20);
            this.cmb2.TabIndex = 1;
            this.cmb2.ValueMember = "Code";
            // 
            // bsElec
            // 
            this.bsElec.AllowNew = true;
            this.bsElec.DataMember = "Ele_TCode";
            this.bsElec.DataSource = this.elecDataSet;
            this.bsElec.CurrentChanged += new System.EventHandler(this.bsElec_CurrentChanged);
            // 
            // elecDataSet
            // 
            this.elecDataSet.DataSetName = "ElecDataSet";
            this.elecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Location = new System.Drawing.Point(765, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 34);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "종료";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(684, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 34);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "저장";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cmb3
            // 
            this.cmb3.DataSource = this.bsPrec;
            this.cmb3.DisplayMember = "PrecName";
            this.cmb3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb3.FormattingEnabled = true;
            this.cmb3.Location = new System.Drawing.Point(333, 11);
            this.cmb3.Name = "cmb3";
            this.cmb3.Size = new System.Drawing.Size(100, 20);
            this.cmb3.TabIndex = 3;
            this.cmb3.ValueMember = "PrecID";
            // 
            // bsPrec
            // 
            this.bsPrec.AllowNew = true;
            this.bsPrec.DataMember = "Ele_TPrec";
            this.bsPrec.DataSource = this.elecDataSet;
            // 
            // cmb1
            // 
            this.cmb1.DataSource = this.bsCity;
            this.cmb1.DisplayMember = "ADesc";
            this.cmb1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb1.FormattingEnabled = true;
            this.cmb1.Location = new System.Drawing.Point(213, 11);
            this.cmb1.Name = "cmb1";
            this.cmb1.Size = new System.Drawing.Size(70, 20);
            this.cmb1.TabIndex = 2;
            this.cmb1.ValueMember = "Code";
            // 
            // bsCity
            // 
            this.bsCity.AllowNew = true;
            this.bsCity.DataMember = "Ele_TCode";
            this.bsCity.DataSource = this.elecDataSet;
            this.bsCity.CurrentChanged += new System.EventHandler(this.bsCity_CurrentChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(172, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "시/도";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(286, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "선거구";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDel
            // 
            this.btnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDel.Location = new System.Drawing.Point(603, 5);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(75, 34);
            this.btnDel.TabIndex = 6;
            this.btnDel.Text = "삭제";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnNew
            // 
            this.btnNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNew.Location = new System.Drawing.Point(522, 5);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 34);
            this.btnNew.TabIndex = 5;
            this.btnNew.Text = "신규";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuery.Location = new System.Drawing.Point(441, 5);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 34);
            this.btnQuery.TabIndex = 4;
            this.btnQuery.Text = "조회";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "선거종류";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bsCode
            // 
            this.bsCode.AllowNew = true;
            this.bsCode.DataMember = "Ele_TCode";
            this.bsCode.DataSource = this.elecDataSet;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cmbPrec);
            this.panel2.Controls.Add(this.cmbElec);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtChgYMD);
            this.panel2.Controls.Add(this.txtKorName);
            this.panel2.Controls.Add(this.cmbRegGbn);
            this.panel2.Controls.Add(this.cmbPartyCode);
            this.panel2.Controls.Add(this.txtCareer1);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtChgResn);
            this.panel2.Controls.Add(this.txtCareer4);
            this.panel2.Controls.Add(this.txtCareer3);
            this.panel2.Controls.Add(this.txtCareer2);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.txtOrdNo);
            this.panel2.Controls.Add(this.lblTxt1);
            this.panel2.Controls.Add(this.btnOpen);
            this.panel2.Controls.Add(this.btnDelAll);
            this.panel2.Controls.Add(this.btnFileSave);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 42);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(849, 161);
            this.panel2.TabIndex = 6;
            // 
            // cmbPrec
            // 
            this.cmbPrec.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bsCand, "PrecID", true));
            this.cmbPrec.DataSource = this.bsPrecView;
            this.cmbPrec.DisplayMember = "PrecName";
            this.cmbPrec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPrec.Enabled = false;
            this.cmbPrec.FormattingEnabled = true;
            this.cmbPrec.Location = new System.Drawing.Point(123, 49);
            this.cmbPrec.Name = "cmbPrec";
            this.cmbPrec.Size = new System.Drawing.Size(160, 20);
            this.cmbPrec.TabIndex = 42;
            this.cmbPrec.ValueMember = "PrecID";
            // 
            // bsCand
            // 
            this.bsCand.AllowNew = true;
            this.bsCand.DataMember = "Ele_TCand";
            this.bsCand.DataSource = this.elecDataSet;
            // 
            // bsPrecView
            // 
            this.bsPrecView.AllowNew = true;
            this.bsPrecView.DataMember = "Ele_TPrec";
            this.bsPrecView.DataSource = this.elecDataSet;
            // 
            // cmbElec
            // 
            this.cmbElec.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bsCand, "ElecCatgr", true));
            this.cmbElec.DataSource = this.bsElecView;
            this.cmbElec.DisplayMember = "ADesc";
            this.cmbElec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbElec.Enabled = false;
            this.cmbElec.FormattingEnabled = true;
            this.cmbElec.Location = new System.Drawing.Point(123, 21);
            this.cmbElec.MaxLength = 2;
            this.cmbElec.Name = "cmbElec";
            this.cmbElec.Size = new System.Drawing.Size(160, 20);
            this.cmbElec.TabIndex = 41;
            this.cmbElec.ValueMember = "Code";
            // 
            // bsElecView
            // 
            this.bsElecView.AllowNew = true;
            this.bsElecView.DataMember = "Ele_TCode";
            this.bsElecView.DataSource = this.elecDataSet;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(15, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 21);
            this.label8.TabIndex = 40;
            this.label8.Text = "선거구";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(15, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 21);
            this.label7.TabIndex = 39;
            this.label7.Text = "선거종류";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtChgYMD
            // 
            this.txtChgYMD.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsCand, "ChgYMD", true));
            this.txtChgYMD.Location = new System.Drawing.Point(673, 105);
            this.txtChgYMD.MaxLength = 8;
            this.txtChgYMD.Name = "txtChgYMD";
            this.txtChgYMD.Size = new System.Drawing.Size(160, 21);
            this.txtChgYMD.TabIndex = 20;
            this.txtChgYMD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtChgYMD_KeyPress);
            // 
            // txtKorName
            // 
            this.txtKorName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsCand, "KorName", true));
            this.txtKorName.Location = new System.Drawing.Point(122, 105);
            this.txtKorName.MaxLength = 14;
            this.txtKorName.Name = "txtKorName";
            this.txtKorName.Size = new System.Drawing.Size(160, 21);
            this.txtKorName.TabIndex = 13;
            // 
            // cmbRegGbn
            // 
            this.cmbRegGbn.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bsCand, "RegGbn", true));
            this.cmbRegGbn.DataSource = this.bsRegGubn;
            this.cmbRegGbn.DisplayMember = "ADesc";
            this.cmbRegGbn.FormattingEnabled = true;
            this.cmbRegGbn.Location = new System.Drawing.Point(673, 78);
            this.cmbRegGbn.Name = "cmbRegGbn";
            this.cmbRegGbn.Size = new System.Drawing.Size(160, 20);
            this.cmbRegGbn.TabIndex = 19;
            this.cmbRegGbn.ValueMember = "Code";
            // 
            // bsRegGubn
            // 
            this.bsRegGubn.AllowNew = true;
            this.bsRegGubn.DataMember = "Ele_TCode";
            this.bsRegGubn.DataSource = this.elecDataSet;
            // 
            // cmbPartyCode
            // 
            this.cmbPartyCode.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bsCand, "PartyCode", true));
            this.cmbPartyCode.DataSource = this.bsParty;
            this.cmbPartyCode.DisplayMember = "ADesc";
            this.cmbPartyCode.FormattingEnabled = true;
            this.cmbPartyCode.Location = new System.Drawing.Point(121, 132);
            this.cmbPartyCode.Name = "cmbPartyCode";
            this.cmbPartyCode.Size = new System.Drawing.Size(160, 20);
            this.cmbPartyCode.TabIndex = 14;
            this.cmbPartyCode.ValueMember = "Code";
            // 
            // bsParty
            // 
            this.bsParty.AllowNew = true;
            this.bsParty.DataMember = "Ele_TCode";
            this.bsParty.DataSource = this.elecDataSet;
            // 
            // txtCareer1
            // 
            this.txtCareer1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsCand, "Career1", true));
            this.txtCareer1.Location = new System.Drawing.Point(398, 51);
            this.txtCareer1.MaxLength = 25;
            this.txtCareer1.Name = "txtCareer1";
            this.txtCareer1.Size = new System.Drawing.Size(160, 21);
            this.txtCareer1.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(567, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 21);
            this.label6.TabIndex = 38;
            this.label6.Text = "사퇴일자";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtChgResn
            // 
            this.txtChgResn.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsCand, "ChgResn", true));
            this.txtChgResn.Location = new System.Drawing.Point(673, 132);
            this.txtChgResn.MaxLength = 50;
            this.txtChgResn.Name = "txtChgResn";
            this.txtChgResn.Size = new System.Drawing.Size(160, 21);
            this.txtChgResn.TabIndex = 21;
            // 
            // txtCareer4
            // 
            this.txtCareer4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsCand, "Career4", true));
            this.txtCareer4.Location = new System.Drawing.Point(398, 132);
            this.txtCareer4.MaxLength = 25;
            this.txtCareer4.Name = "txtCareer4";
            this.txtCareer4.Size = new System.Drawing.Size(160, 21);
            this.txtCareer4.TabIndex = 18;
            // 
            // txtCareer3
            // 
            this.txtCareer3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsCand, "Career3", true));
            this.txtCareer3.Location = new System.Drawing.Point(398, 105);
            this.txtCareer3.MaxLength = 25;
            this.txtCareer3.Name = "txtCareer3";
            this.txtCareer3.Size = new System.Drawing.Size(160, 21);
            this.txtCareer3.TabIndex = 17;
            // 
            // txtCareer2
            // 
            this.txtCareer2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsCand, "Career2", true));
            this.txtCareer2.Location = new System.Drawing.Point(398, 78);
            this.txtCareer2.MaxLength = 25;
            this.txtCareer2.Name = "txtCareer2";
            this.txtCareer2.Size = new System.Drawing.Size(160, 21);
            this.txtCareer2.TabIndex = 16;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(567, 132);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 21);
            this.label12.TabIndex = 33;
            this.label12.Text = "사퇴사유";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(567, 78);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 21);
            this.label13.TabIndex = 31;
            this.label13.Text = "사퇴여부";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(292, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 100);
            this.label10.TabIndex = 24;
            this.label10.Text = "경력";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(15, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 21);
            this.label5.TabIndex = 23;
            this.label5.Text = "정당";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(15, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 21);
            this.label4.TabIndex = 22;
            this.label4.Text = "성명";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOrdNo
            // 
            this.txtOrdNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsCand, "OrdNo", true));
            this.txtOrdNo.Location = new System.Drawing.Point(122, 78);
            this.txtOrdNo.MaxLength = 2;
            this.txtOrdNo.Name = "txtOrdNo";
            this.txtOrdNo.Size = new System.Drawing.Size(160, 21);
            this.txtOrdNo.TabIndex = 12;
            // 
            // lblTxt1
            // 
            this.lblTxt1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTxt1.ForeColor = System.Drawing.Color.White;
            this.lblTxt1.Location = new System.Drawing.Point(15, 78);
            this.lblTxt1.Name = "lblTxt1";
            this.lblTxt1.Size = new System.Drawing.Size(100, 21);
            this.lblTxt1.TabIndex = 21;
            this.lblTxt1.Text = "기호";
            this.lblTxt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnOpen
            // 
            this.btnOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOpen.Location = new System.Drawing.Point(684, -1);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(156, 34);
            this.btnOpen.TabIndex = 11;
            this.btnOpen.Text = "불러오기";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnDelAll
            // 
            this.btnDelAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelAll.Location = new System.Drawing.Point(603, -1);
            this.btnDelAll.Name = "btnDelAll";
            this.btnDelAll.Size = new System.Drawing.Size(75, 34);
            this.btnDelAll.TabIndex = 10;
            this.btnDelAll.Text = "전체삭제";
            this.btnDelAll.UseVisualStyleBackColor = true;
            this.btnDelAll.Click += new System.EventHandler(this.btnDelAll_Click);
            // 
            // btnFileSave
            // 
            this.btnFileSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFileSave.Location = new System.Drawing.Point(441, -1);
            this.btnFileSave.Name = "btnFileSave";
            this.btnFileSave.Size = new System.Drawing.Size(156, 34);
            this.btnFileSave.TabIndex = 9;
            this.btnFileSave.Text = "파일로 저장";
            this.btnFileSave.UseVisualStyleBackColor = true;
            this.btnFileSave.Click += new System.EventHandler(this.btnFileSave_Click);
            // 
            // dgvCand
            // 
            this.dgvCand.AllowUserToAddRows = false;
            this.dgvCand.AllowUserToDeleteRows = false;
            this.dgvCand.AllowUserToResizeRows = false;
            this.dgvCand.AutoGenerateColumns = false;
            this.dgvCand.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCand.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.elecCatgrDataGridViewTextBoxColumn,
            this.precIDDataGridViewTextBoxColumn,
            this.cOrdNo,
            this.korNameDataGridViewTextBoxColumn,
            this.chaNameDataGridViewTextBoxColumn,
            this.partyCodeDataGridViewTextBoxColumn,
            this.socialNoDataGridViewTextBoxColumn,
            this.addr1DataGridViewTextBoxColumn,
            this.telDataGridViewTextBoxColumn,
            this.addr2DataGridViewTextBoxColumn,
            this.schCodeDataGridViewTextBoxColumn,
            this.gradYMDDataGridViewTextBoxColumn,
            this.jobCodeDataGridViewTextBoxColumn,
            this.career1DataGridViewTextBoxColumn,
            this.career2DataGridViewTextBoxColumn,
            this.career3DataGridViewTextBoxColumn,
            this.career4DataGridViewTextBoxColumn,
            this.regGbnDataGridViewTextBoxColumn,
            this.elecCntDataGridViewTextBoxColumn,
            this.candCntDataGridViewTextBoxColumn,
            this.regYMDDataGridViewTextBoxColumn,
            this.chgYMDDataGridViewTextBoxColumn,
            this.chgResnDataGridViewTextBoxColumn});
            this.dgvCand.ContextMenuStrip = this.contextMenu;
            this.dgvCand.DataSource = this.bsCand;
            this.dgvCand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCand.Location = new System.Drawing.Point(0, 203);
            this.dgvCand.MultiSelect = false;
            this.dgvCand.Name = "dgvCand";
            this.dgvCand.ReadOnly = true;
            this.dgvCand.RowHeadersVisible = false;
            this.dgvCand.RowTemplate.Height = 23;
            this.dgvCand.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCand.Size = new System.Drawing.Size(849, 301);
            this.dgvCand.TabIndex = 23;
            this.dgvCand.SelectionChanged += new System.EventHandler(this.dgvCand_SelectionChanged);
            // 
            // elecCatgrDataGridViewTextBoxColumn
            // 
            this.elecCatgrDataGridViewTextBoxColumn.DataPropertyName = "ElecCatgr";
            this.elecCatgrDataGridViewTextBoxColumn.HeaderText = "선거종류";
            this.elecCatgrDataGridViewTextBoxColumn.MaxInputLength = 2;
            this.elecCatgrDataGridViewTextBoxColumn.Name = "elecCatgrDataGridViewTextBoxColumn";
            this.elecCatgrDataGridViewTextBoxColumn.ReadOnly = true;
            this.elecCatgrDataGridViewTextBoxColumn.Visible = false;
            // 
            // precIDDataGridViewTextBoxColumn
            // 
            this.precIDDataGridViewTextBoxColumn.DataPropertyName = "PrecID";
            this.precIDDataGridViewTextBoxColumn.DataSource = this.bsPrecList;
            this.precIDDataGridViewTextBoxColumn.DisplayMember = "PrecName";
            this.precIDDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.precIDDataGridViewTextBoxColumn.HeaderText = "선거구명";
            this.precIDDataGridViewTextBoxColumn.Name = "precIDDataGridViewTextBoxColumn";
            this.precIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.precIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.precIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.precIDDataGridViewTextBoxColumn.ValueMember = "PrecID";
            this.precIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // bsPrecList
            // 
            this.bsPrecList.AllowNew = true;
            this.bsPrecList.DataMember = "Ele_TPrec";
            this.bsPrecList.DataSource = this.elecDataSet;
            // 
            // cOrdNo
            // 
            this.cOrdNo.DataPropertyName = "OrdNo";
            this.cOrdNo.HeaderText = "기호";
            this.cOrdNo.Name = "cOrdNo";
            this.cOrdNo.ReadOnly = true;
            // 
            // korNameDataGridViewTextBoxColumn
            // 
            this.korNameDataGridViewTextBoxColumn.DataPropertyName = "KorName";
            this.korNameDataGridViewTextBoxColumn.HeaderText = "성명";
            this.korNameDataGridViewTextBoxColumn.Name = "korNameDataGridViewTextBoxColumn";
            this.korNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // chaNameDataGridViewTextBoxColumn
            // 
            this.chaNameDataGridViewTextBoxColumn.DataPropertyName = "ChaName";
            this.chaNameDataGridViewTextBoxColumn.HeaderText = "한자성명";
            this.chaNameDataGridViewTextBoxColumn.Name = "chaNameDataGridViewTextBoxColumn";
            this.chaNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.chaNameDataGridViewTextBoxColumn.Visible = false;
            // 
            // partyCodeDataGridViewTextBoxColumn
            // 
            this.partyCodeDataGridViewTextBoxColumn.DataPropertyName = "PartyCode";
            this.partyCodeDataGridViewTextBoxColumn.DataSource = this.bsParty;
            this.partyCodeDataGridViewTextBoxColumn.DisplayMember = "ADesc";
            this.partyCodeDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.partyCodeDataGridViewTextBoxColumn.HeaderText = "정당";
            this.partyCodeDataGridViewTextBoxColumn.Name = "partyCodeDataGridViewTextBoxColumn";
            this.partyCodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.partyCodeDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.partyCodeDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.partyCodeDataGridViewTextBoxColumn.ValueMember = "Code";
            this.partyCodeDataGridViewTextBoxColumn.Width = 150;
            // 
            // socialNoDataGridViewTextBoxColumn
            // 
            this.socialNoDataGridViewTextBoxColumn.DataPropertyName = "SocialNo";
            this.socialNoDataGridViewTextBoxColumn.HeaderText = "SocialNo";
            this.socialNoDataGridViewTextBoxColumn.Name = "socialNoDataGridViewTextBoxColumn";
            this.socialNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.socialNoDataGridViewTextBoxColumn.Visible = false;
            // 
            // addr1DataGridViewTextBoxColumn
            // 
            this.addr1DataGridViewTextBoxColumn.DataPropertyName = "Addr1";
            this.addr1DataGridViewTextBoxColumn.HeaderText = "Addr1";
            this.addr1DataGridViewTextBoxColumn.Name = "addr1DataGridViewTextBoxColumn";
            this.addr1DataGridViewTextBoxColumn.ReadOnly = true;
            this.addr1DataGridViewTextBoxColumn.Visible = false;
            // 
            // telDataGridViewTextBoxColumn
            // 
            this.telDataGridViewTextBoxColumn.DataPropertyName = "Tel";
            this.telDataGridViewTextBoxColumn.HeaderText = "Tel";
            this.telDataGridViewTextBoxColumn.Name = "telDataGridViewTextBoxColumn";
            this.telDataGridViewTextBoxColumn.ReadOnly = true;
            this.telDataGridViewTextBoxColumn.Visible = false;
            // 
            // addr2DataGridViewTextBoxColumn
            // 
            this.addr2DataGridViewTextBoxColumn.DataPropertyName = "Addr2";
            this.addr2DataGridViewTextBoxColumn.HeaderText = "Addr2";
            this.addr2DataGridViewTextBoxColumn.Name = "addr2DataGridViewTextBoxColumn";
            this.addr2DataGridViewTextBoxColumn.ReadOnly = true;
            this.addr2DataGridViewTextBoxColumn.Visible = false;
            // 
            // schCodeDataGridViewTextBoxColumn
            // 
            this.schCodeDataGridViewTextBoxColumn.DataPropertyName = "SchCode";
            this.schCodeDataGridViewTextBoxColumn.HeaderText = "SchCode";
            this.schCodeDataGridViewTextBoxColumn.Name = "schCodeDataGridViewTextBoxColumn";
            this.schCodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.schCodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // gradYMDDataGridViewTextBoxColumn
            // 
            this.gradYMDDataGridViewTextBoxColumn.DataPropertyName = "GradYMD";
            this.gradYMDDataGridViewTextBoxColumn.HeaderText = "GradYMD";
            this.gradYMDDataGridViewTextBoxColumn.Name = "gradYMDDataGridViewTextBoxColumn";
            this.gradYMDDataGridViewTextBoxColumn.ReadOnly = true;
            this.gradYMDDataGridViewTextBoxColumn.Visible = false;
            // 
            // jobCodeDataGridViewTextBoxColumn
            // 
            this.jobCodeDataGridViewTextBoxColumn.DataPropertyName = "JobCode";
            this.jobCodeDataGridViewTextBoxColumn.HeaderText = "JobCode";
            this.jobCodeDataGridViewTextBoxColumn.Name = "jobCodeDataGridViewTextBoxColumn";
            this.jobCodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.jobCodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // career1DataGridViewTextBoxColumn
            // 
            this.career1DataGridViewTextBoxColumn.DataPropertyName = "Career1";
            this.career1DataGridViewTextBoxColumn.HeaderText = "경력";
            this.career1DataGridViewTextBoxColumn.Name = "career1DataGridViewTextBoxColumn";
            this.career1DataGridViewTextBoxColumn.ReadOnly = true;
            this.career1DataGridViewTextBoxColumn.Width = 240;
            // 
            // career2DataGridViewTextBoxColumn
            // 
            this.career2DataGridViewTextBoxColumn.DataPropertyName = "Career2";
            this.career2DataGridViewTextBoxColumn.HeaderText = "경력2";
            this.career2DataGridViewTextBoxColumn.Name = "career2DataGridViewTextBoxColumn";
            this.career2DataGridViewTextBoxColumn.ReadOnly = true;
            this.career2DataGridViewTextBoxColumn.Visible = false;
            // 
            // career3DataGridViewTextBoxColumn
            // 
            this.career3DataGridViewTextBoxColumn.DataPropertyName = "Career3";
            this.career3DataGridViewTextBoxColumn.HeaderText = "경력3";
            this.career3DataGridViewTextBoxColumn.Name = "career3DataGridViewTextBoxColumn";
            this.career3DataGridViewTextBoxColumn.ReadOnly = true;
            this.career3DataGridViewTextBoxColumn.Visible = false;
            // 
            // career4DataGridViewTextBoxColumn
            // 
            this.career4DataGridViewTextBoxColumn.DataPropertyName = "Career4";
            this.career4DataGridViewTextBoxColumn.HeaderText = "경력4";
            this.career4DataGridViewTextBoxColumn.Name = "career4DataGridViewTextBoxColumn";
            this.career4DataGridViewTextBoxColumn.ReadOnly = true;
            this.career4DataGridViewTextBoxColumn.Visible = false;
            // 
            // regGbnDataGridViewTextBoxColumn
            // 
            this.regGbnDataGridViewTextBoxColumn.DataPropertyName = "RegGbn";
            this.regGbnDataGridViewTextBoxColumn.DataSource = this.bsRegGubn;
            this.regGbnDataGridViewTextBoxColumn.DisplayMember = "ADesc";
            this.regGbnDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.regGbnDataGridViewTextBoxColumn.HeaderText = "등록구분";
            this.regGbnDataGridViewTextBoxColumn.Name = "regGbnDataGridViewTextBoxColumn";
            this.regGbnDataGridViewTextBoxColumn.ReadOnly = true;
            this.regGbnDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.regGbnDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.regGbnDataGridViewTextBoxColumn.ValueMember = "Code";
            // 
            // elecCntDataGridViewTextBoxColumn
            // 
            this.elecCntDataGridViewTextBoxColumn.DataPropertyName = "ElecCnt";
            this.elecCntDataGridViewTextBoxColumn.HeaderText = "당선횟수";
            this.elecCntDataGridViewTextBoxColumn.Name = "elecCntDataGridViewTextBoxColumn";
            this.elecCntDataGridViewTextBoxColumn.ReadOnly = true;
            this.elecCntDataGridViewTextBoxColumn.Visible = false;
            // 
            // candCntDataGridViewTextBoxColumn
            // 
            this.candCntDataGridViewTextBoxColumn.DataPropertyName = "CandCnt";
            this.candCntDataGridViewTextBoxColumn.HeaderText = "입후보횟수";
            this.candCntDataGridViewTextBoxColumn.Name = "candCntDataGridViewTextBoxColumn";
            this.candCntDataGridViewTextBoxColumn.ReadOnly = true;
            this.candCntDataGridViewTextBoxColumn.Visible = false;
            // 
            // regYMDDataGridViewTextBoxColumn
            // 
            this.regYMDDataGridViewTextBoxColumn.DataPropertyName = "RegYMD";
            this.regYMDDataGridViewTextBoxColumn.HeaderText = "등록일";
            this.regYMDDataGridViewTextBoxColumn.Name = "regYMDDataGridViewTextBoxColumn";
            this.regYMDDataGridViewTextBoxColumn.ReadOnly = true;
            this.regYMDDataGridViewTextBoxColumn.Visible = false;
            // 
            // chgYMDDataGridViewTextBoxColumn
            // 
            this.chgYMDDataGridViewTextBoxColumn.DataPropertyName = "ChgYMD";
            dataGridViewCellStyle1.Format = "####-##-##";
            dataGridViewCellStyle1.NullValue = null;
            this.chgYMDDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.chgYMDDataGridViewTextBoxColumn.HeaderText = "등록변경일";
            this.chgYMDDataGridViewTextBoxColumn.Name = "chgYMDDataGridViewTextBoxColumn";
            this.chgYMDDataGridViewTextBoxColumn.ReadOnly = true;
            this.chgYMDDataGridViewTextBoxColumn.Visible = false;
            // 
            // chgResnDataGridViewTextBoxColumn
            // 
            this.chgResnDataGridViewTextBoxColumn.DataPropertyName = "ChgResn";
            this.chgResnDataGridViewTextBoxColumn.HeaderText = "변경사유";
            this.chgResnDataGridViewTextBoxColumn.Name = "chgResnDataGridViewTextBoxColumn";
            this.chgResnDataGridViewTextBoxColumn.ReadOnly = true;
            this.chgResnDataGridViewTextBoxColumn.Visible = false;
            // 
            // contextMenu
            // 
            this.contextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmQuery,
            this.toolStripSeparator3,
            this.tsmNew,
            this.tsmDel,
            this.tsmDelAll,
            this.tsmSave,
            this.toolStripSeparator2,
            this.tsmFileSave,
            this.tsmOpen,
            this.toolStripSeparator1,
            this.tsmExit});
            this.contextMenu.Name = "contextMenu";
            this.contextMenu.Size = new System.Drawing.Size(157, 198);
            // 
            // tsmQuery
            // 
            this.tsmQuery.Name = "tsmQuery";
            this.tsmQuery.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.tsmQuery.Size = new System.Drawing.Size(156, 22);
            this.tsmQuery.Text = "조회";
            this.tsmQuery.Click += new System.EventHandler(this.tsmQuery_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(153, 6);
            // 
            // tsmNew
            // 
            this.tsmNew.Name = "tsmNew";
            this.tsmNew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.tsmNew.Size = new System.Drawing.Size(156, 22);
            this.tsmNew.Text = "신규(&F)";
            this.tsmNew.Click += new System.EventHandler(this.tsmNew_Click);
            // 
            // tsmDel
            // 
            this.tsmDel.Name = "tsmDel";
            this.tsmDel.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D)));
            this.tsmDel.Size = new System.Drawing.Size(156, 22);
            this.tsmDel.Text = "삭제(&D)";
            this.tsmDel.Click += new System.EventHandler(this.tsmDel_Click);
            // 
            // tsmDelAll
            // 
            this.tsmDelAll.Name = "tsmDelAll";
            this.tsmDelAll.Size = new System.Drawing.Size(156, 22);
            this.tsmDelAll.Text = "전체삭제";
            this.tsmDelAll.Click += new System.EventHandler(this.tsmDelAll_Click);
            // 
            // tsmSave
            // 
            this.tsmSave.Name = "tsmSave";
            this.tsmSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.tsmSave.Size = new System.Drawing.Size(156, 22);
            this.tsmSave.Text = "저장(&S)";
            this.tsmSave.Click += new System.EventHandler(this.tsmSave_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(153, 6);
            // 
            // tsmFileSave
            // 
            this.tsmFileSave.Name = "tsmFileSave";
            this.tsmFileSave.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.tsmFileSave.Size = new System.Drawing.Size(156, 22);
            this.tsmFileSave.Text = "파일로 저장";
            this.tsmFileSave.Click += new System.EventHandler(this.tsmFileSave_Click);
            // 
            // tsmOpen
            // 
            this.tsmOpen.Name = "tsmOpen";
            this.tsmOpen.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.tsmOpen.Size = new System.Drawing.Size(156, 22);
            this.tsmOpen.Text = "불러오기";
            this.tsmOpen.Click += new System.EventHandler(this.tsmOpen_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(153, 6);
            // 
            // tsmExit
            // 
            this.tsmExit.Name = "tsmExit";
            this.tsmExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.tsmExit.Size = new System.Drawing.Size(156, 22);
            this.tsmExit.Text = "종료(&X)";
            this.tsmExit.Click += new System.EventHandler(this.tsmExit_Click);
            // 
            // taCode
            // 
            this.taCode.ClearBeforeFill = true;
            // 
            // taPrec
            // 
            this.taPrec.ClearBeforeFill = true;
            // 
            // taCand
            // 
            this.taCand.ClearBeforeFill = true;
            // 
            // frmCand
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 504);
            this.ContextMenuStrip = this.contextMenu;
            this.Controls.Add(this.dgvCand);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCand";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "후보관리";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsElec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCode)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsCand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsElecView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsRegGubn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsParty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPrecList)).EndInit();
            this.contextMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvCand;
        private System.Windows.Forms.ComboBox cmb1;
        private DB.ElecDataSet elecDataSet;
        private DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter taCode;
        private System.Windows.Forms.ComboBox cmb2;
        private System.Windows.Forms.ComboBox cmb3;
        private System.Windows.Forms.BindingSource bsPrec;
        private DB.ElecDataSetTableAdapters.Ele_TPrecTableAdapter taPrec;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnDelAll;
        private System.Windows.Forms.Button btnFileSave;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtChgResn;
        private System.Windows.Forms.TextBox txtCareer4;
        private System.Windows.Forms.TextBox txtCareer3;
        private System.Windows.Forms.TextBox txtCareer2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtOrdNo;
        private System.Windows.Forms.Label lblTxt1;
        private System.Windows.Forms.ComboBox cmbPartyCode;
        private System.Windows.Forms.TextBox txtCareer1;
        private System.Windows.Forms.ComboBox cmbRegGbn;
        private System.Windows.Forms.TextBox txtKorName;
        private System.Windows.Forms.BindingSource bsCand;
        private DB.ElecDataSetTableAdapters.Ele_TCandTableAdapter taCand;
        private System.Windows.Forms.TextBox txtChgYMD;
        private System.Windows.Forms.BindingSource bsParty;
        private System.Windows.Forms.BindingSource bsRegGubn;
        private System.Windows.Forms.BindingSource bsCity;
        private System.Windows.Forms.BindingSource bsElec;
        private System.Windows.Forms.ContextMenuStrip contextMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmNew;
        private System.Windows.Forms.ToolStripMenuItem tsmDel;
        private System.Windows.Forms.ToolStripMenuItem tsmSave;
        private System.Windows.Forms.ToolStripMenuItem tsmDelAll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem tsmFileSave;
        private System.Windows.Forms.ToolStripMenuItem tsmOpen;
        private System.Windows.Forms.ToolStripMenuItem tsmQuery;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tsmExit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbPrec;
        private System.Windows.Forms.BindingSource bsElecView;
        private System.Windows.Forms.BindingSource bsPrecView;
        private System.Windows.Forms.ComboBox cmbElec;
        private System.Windows.Forms.BindingSource bsCode;
        private System.Windows.Forms.BindingSource bsPrecList;
        private System.Windows.Forms.DataGridViewTextBoxColumn elecCatgrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn precIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOrdNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn korNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn chaNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn partyCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn socialNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addr1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addr2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn schCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradYMDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jobCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn career1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn career2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn career3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn career4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn regGbnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn elecCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn candCntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn regYMDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn chgYMDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn chgResnDataGridViewTextBoxColumn;
    }
}