﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Election
{
    class Prec
    {
        private string precId = "";
        private string precName = "";

        public string PrecId
        {
            get { return precId;}
            set { precId = value; }
        }

        public string PrecName
        {
            get { return precName; }
            set { precName = value; }
        }
        
    }
}
