﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Deployment.Application;
using System.Data.OleDb;
using System.IO;
using IniFile;

namespace Election
{
    class Global
    {
        /// <summary>
        ///     버젼
        /// </summary>
        public static string Version
        {
            get 
            {
                //어플리케이션 개발버전을 구함
                string ver = Application.ProductVersion;
                //인터넷 배포일경우에는 배포버전으로 대체
                if(ApplicationDeployment.IsNetworkDeployed)
                    ver = ApplicationDeployment.CurrentDeployment.CurrentVersion.ToString();
                return ver;
            }
        }

        //프로그램 타이틀
        public static string Title = "6.13 지방선거 개표방송 시스템";

        /// <summary>
        ///     ini 전체 파일명
        ///     기본 : C:\Users\사용자명\AppData\Local\KNN\Election.ini
        /// </summary>
        private static string IniFileName = DataPath + "\\" + ExeName + ".INI";

        public static TIniFile IniFile
        {
            get 
            {
                //실행파일이 있는 폴더(인터넷 배포시 랜덤)
                string sourceFilePath = Path.Combine(StartupPath, ExeName + ".ini");
                //초기정보폴더
                string destFilePath = IniFileName;
                //기본 : C:\Users\사용자명\AppData\Local\KNN\Election.ini 에 파일이 없으면 실행폴더의 ini를 복사해옴
                if (!File.Exists(destFilePath))
                {
                    File.Copy(sourceFilePath, destFilePath);
                }

                return new TIniFile(IniFileName); 
            }
        }

        /// <summary>
        ///     실행파일의 full path
        /// </summary>
        public static string ExecutablePath
        {
            get { return Application.ExecutablePath; }
        }

        /// <summary>
        ///     실행파일의 folder path
        /// </summary>
        public static string StartupPath
        {
            get { return Application.StartupPath; }
        }

        /// <summary>
        ///     실행파일의 초기정보 저장 folder path
        /// </summary>
        public static string DataPath
        {
            get 
            {
                //기본 : C:\Users\사용자명\AppData\Local
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

                //기본 : C:\Users\사용자명\AppData\Local\KNN
                //프로그램 초기화값(ex: ini file)을 저장하는 폴더
                string userFilePath = Path.Combine(localAppData, "KNN");

                //해당 폴더가 없으면, 생성
                if (!Directory.Exists(userFilePath))
                    Directory.CreateDirectory(userFilePath);

                return userFilePath;
            }
        }

        /// <summary>
        ///     확장자없는 실행파일명
        /// </summary>
        public static string ExeName
        {
            get
            {
                string name = ExeNameNExt;
                int n = name.LastIndexOf(".");
                return name.Substring(0, n);
            }
        }

        /// <summary>
        ///     확장자있는 실행파일명
        /// </summary>
        public static string ExeNameNExt
        {
            get
            {
                string path = ExecutablePath;
                int n = path.LastIndexOf(@"\");
                return path.Substring(n + 1);
            }
        }

        //로긴시 선택한 방송사 ID
        private static string _CompID = "";
        public static string CompID
        {
            get 
            { 
                if(_CompID == "") _CompID = IniFile.GetString("Election", "CompID");
                return _CompID;
            }
            set 
            {
                //방송사가 지정되면, 해당 방송사의 DB id 및 연결문자열등 초기값 설정
                //방송사 ID
                _CompID = value;
                //DB ID
                _DbID = IniFile.GetString(CompID, "DbID");
                //DB 커넥트스트링
                _DbConnectionString = IniFile.GetString(_DbID, "ConnectionString");
                //개표방송시스템을 실행하는 해당 단말명 (여러대 실행할 수 있음)
                _SystemName = IniFile.GetString(CompID, "SystemName");
                //토네이도 IP
                _TornadoIP = IniFile.GetString(CompID, "TornadoIP");
                //토네이도 포트
                _TornadoPort = IniFile.GetString(CompID, "TornadoPORT");
                //토네이도 Scene 패스
                _TornadoScenePath = IniFile.GetString(CompID, "ScenePath");
                //ini에 방송사ID 저장
                IniFile.SetString("Election", "CompID", value); 
            }
        }

        //로긴한 방송사의 Select Like String
        //방송사마다 사용하는 선거구, Scene등 다르게 설정할 수 있게 방송사별 포지션 코드로 DB에서 쿼리하게 하기 위함
        //ex) 순서가 부산,울산,대구라면 부산은 첫위치가 Y이면 사용이란 의미(ele_tcode catgr = '001')
        //  1번 선거구 YNN
        //  2번 선거구 NYN
        //  3번 선거구 NNY
        //  4번 선거구 YYY
        //  sql query시  like 'Y__'이면 부산꺼만, '_Y_'이면 울산꺼만 쿼리할 수 있음
        public static string CompLikeString = "";
        
        //로긴시 선택한 DB ID
        private static string _DbID = "";
        public static string DbID
        {
            get 
            {
                if (_DbID == "") _DbID = IniFile.GetString(CompID, "DbID");
                return _DbID;
            }
            set 
            {
                _DbID = value;
                _DbConnectionString = IniFile.GetString(_DbID, "ConnectionString");
                IniFile.SetString(CompID, "DbID", value); 
            }
        }

        //로긴시 선택한 DB ID의 접속문자열
        private static string _DbConnectionString = "";
        public static string DbConnectionString
        {
            get 
            {
                if (_DbConnectionString == "") _DbConnectionString = IniFile.GetString(DbID, "ConnectionString");
                return _DbConnectionString;
            }
        }

        //개표방송시스템을 실행시키는 워크스테이션 ID
        private static string _SystemName = "";
        public static string SystemName
        { 
            get 
            {
                if (_SystemName == "") _SystemName = IniFile.GetString(CompID, "SystemName");
                return _SystemName;
            } 
            set 
            {
                _SystemName = value;
                IniFile.SetString(CompID, "SystemName", value); 
            }
        }

        //토네이도 IP
        private static string _TornadoIP = "";
        public static string TornadoIP
        { 
            get 
            {
                if (_TornadoIP == "") _TornadoIP = IniFile.GetString(CompID, "TornadoIP");
                return _TornadoIP;
            }
            set 
            {
                _TornadoIP = value;
                IniFile.SetString(CompID, "TornadoIP", value); 
            }
        }

        //토네이도 포트
        private static string _TornadoPort = "";
        public static string TornadoPort
        {
            get 
            {
                if (_TornadoPort == "") _TornadoPort = IniFile.GetString(CompID, "TornadoPORT");
                return _TornadoPort;
            }
            set 
            {
                _TornadoPort = value; 
                IniFile.SetString(CompID, "TornadoPORT", value);
            }
        }

        //토네이도 장면경로
        private static string _TornadoScenePath = "";
        public static string TornadoScenePath
        {
            get 
            {
                if (_TornadoScenePath == "") _TornadoScenePath = IniFile.GetString(CompID, "ScenePath");
                return _TornadoScenePath;
            }
            set 
            { 
                _TornadoScenePath = value;
                IniFile.SetString(CompID, "ScenePath", value); 
            }
        }
    }
}
