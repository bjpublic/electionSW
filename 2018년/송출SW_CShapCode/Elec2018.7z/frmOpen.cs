﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Election
{
    public partial class frmOpen : Form
    {
        bool FIng = true;   //조회중

        public frmOpen()
        {
            InitializeComponent();
        }
        private void btnQuery_Click(object sender, EventArgs e)
        {
            FIng = true;

            this.taPrecSBS.FillByCompID(this.openDataSet.Ele_TPrecSBS, Global.CompID);

            //카운터용 변수
            int Tot2 = 0;   //광역총수
            int Tot3 = 0;   //교육총수
            int Tot4 = 0;   //기초총수
            int TotT = 0;   //합계총수
            int Cnt2 = 0;   //광역당선수
            int Cnt3 = 0;   //교육당선수
            int Cnt4 = 0;   //기초당선수
            int CntT = 0;   //합계당선수

            for (int i = 0; i < bsPrecSBS.Count; i++)
            {
                bsPrecSBS.Position = i;
                DataRowView row = (DataRowView)bsPrecSBS.Current;
                string catgr = row["ElecCatgr"].ToString().Trim();
                string elec  = row["ElecGbn"].ToString().Trim();
                bool belec = elec == "60" || elec == "80" || elec == "90" ? true : false;
                switch(catgr)
                {
                    case "02":
                        Tot2++;
                        if (belec) Cnt2++;
                        break;
                    case "03":
                        Tot3++;
                        if (belec) Cnt3++;
                        break;
                    case "04":
                        Tot4++;
                        if (belec) Cnt4++;
                        break;
                }

                TotT++;
                if (belec) CntT++;
            }
            //표시
            lbCnt2.Text = Cnt2.ToString() + "/" + Tot2.ToString();
            lbCnt3.Text = Cnt3.ToString() + "/" + Tot3.ToString();
            lbCnt4.Text = Cnt4.ToString() + "/" + Tot4.ToString();
            lbCntT.Text = CntT.ToString() + "/" + TotT.ToString();
            bsPrecSBS.MoveFirst();
            FIng = false;
        }

        private void dgvPrec_SelectionChanged(object sender, EventArgs e)
        {
            if (bsPrecSBS.Count == 0) return;
            if (FIng) return;

            DataRowView row = (DataRowView)bsPrecSBS.Current;
            string catgr = row["ElecCatgr"].ToString().Trim();
            string precid = row["PrecID"].ToString().Trim();
            this.taCandSBS.Fill(this.openDataSet.Ele_TCandSBS, catgr, precid);
        }
    }
}
