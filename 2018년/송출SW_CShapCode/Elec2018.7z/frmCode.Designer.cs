﻿namespace Election
{
    partial class frmCode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCode));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.gdvCatgr = new System.Windows.Forms.DataGridView();
            this.cCatgr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cADesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bDescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resv1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resv2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resv3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resv4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resv5DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsCatgr = new System.Windows.Forms.BindingSource(this.components);
            this.elecDataSet = new Election.DB.ElecDataSet();
            this.dgvCode = new System.Windows.Forms.DataGridView();
            this.dCatgr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dADesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsCode = new System.Windows.Forms.BindingSource(this.components);
            this.contextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmQuery = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmNew = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmDel = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmSave = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmExit = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.taCatgr = new Election.DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter();
            this.taCode = new Election.DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gdvCatgr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCatgr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCode)).BeginInit();
            this.contextMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.btnNew);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.btnDel);
            this.panel1.Controls.Add(this.btnQuery);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(849, 51);
            this.panel1.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Location = new System.Drawing.Point(754, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 34);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "종료";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnNew
            // 
            this.btnNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNew.Location = new System.Drawing.Point(511, 5);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 34);
            this.btnNew.TabIndex = 3;
            this.btnNew.Text = "신규";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(673, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 34);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "저장";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDel
            // 
            this.btnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDel.Location = new System.Drawing.Point(592, 5);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(75, 34);
            this.btnDel.TabIndex = 1;
            this.btnDel.Text = "삭제";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuery.Location = new System.Drawing.Point(430, 5);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 34);
            this.btnQuery.TabIndex = 0;
            this.btnQuery.Text = "조회";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // gdvCatgr
            // 
            this.gdvCatgr.AllowUserToAddRows = false;
            this.gdvCatgr.AllowUserToDeleteRows = false;
            this.gdvCatgr.AllowUserToResizeColumns = false;
            this.gdvCatgr.AllowUserToResizeRows = false;
            this.gdvCatgr.AutoGenerateColumns = false;
            this.gdvCatgr.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gdvCatgr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdvCatgr.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cCatgr,
            this.cCode,
            this.cADesc,
            this.bDescDataGridViewTextBoxColumn,
            this.resv1DataGridViewTextBoxColumn,
            this.resv2DataGridViewTextBoxColumn,
            this.resv3DataGridViewTextBoxColumn,
            this.resv4DataGridViewTextBoxColumn,
            this.resv5DataGridViewTextBoxColumn,
            this.ordDataGridViewTextBoxColumn});
            this.gdvCatgr.DataSource = this.bsCatgr;
            this.gdvCatgr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gdvCatgr.Location = new System.Drawing.Point(0, 0);
            this.gdvCatgr.MultiSelect = false;
            this.gdvCatgr.Name = "gdvCatgr";
            this.gdvCatgr.ReadOnly = true;
            this.gdvCatgr.RowHeadersVisible = false;
            this.gdvCatgr.RowTemplate.Height = 23;
            this.gdvCatgr.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gdvCatgr.Size = new System.Drawing.Size(265, 453);
            this.gdvCatgr.TabIndex = 3;
            this.gdvCatgr.VirtualMode = true;
            this.gdvCatgr.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gdvCatgr_CellFormatting);
            this.gdvCatgr.SelectionChanged += new System.EventHandler(this.gdvCatgr_SelectionChanged);
            // 
            // cCatgr
            // 
            this.cCatgr.DataPropertyName = "Catgr";
            this.cCatgr.HeaderText = "카테고리";
            this.cCatgr.Name = "cCatgr";
            this.cCatgr.ReadOnly = true;
            this.cCatgr.Visible = false;
            // 
            // cCode
            // 
            this.cCode.DataPropertyName = "Code";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.cCode.DefaultCellStyle = dataGridViewCellStyle1;
            this.cCode.HeaderText = "코드";
            this.cCode.Name = "cCode";
            this.cCode.ReadOnly = true;
            this.cCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.cCode.Width = 61;
            // 
            // cADesc
            // 
            this.cADesc.DataPropertyName = "ADesc";
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.cADesc.DefaultCellStyle = dataGridViewCellStyle2;
            this.cADesc.HeaderText = "설명";
            this.cADesc.MinimumWidth = 200;
            this.cADesc.Name = "cADesc";
            this.cADesc.ReadOnly = true;
            this.cADesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.cADesc.Width = 200;
            // 
            // bDescDataGridViewTextBoxColumn
            // 
            this.bDescDataGridViewTextBoxColumn.DataPropertyName = "BDesc";
            this.bDescDataGridViewTextBoxColumn.HeaderText = "BDesc";
            this.bDescDataGridViewTextBoxColumn.Name = "bDescDataGridViewTextBoxColumn";
            this.bDescDataGridViewTextBoxColumn.ReadOnly = true;
            this.bDescDataGridViewTextBoxColumn.Visible = false;
            // 
            // resv1DataGridViewTextBoxColumn
            // 
            this.resv1DataGridViewTextBoxColumn.DataPropertyName = "Resv1";
            this.resv1DataGridViewTextBoxColumn.HeaderText = "Resv1";
            this.resv1DataGridViewTextBoxColumn.Name = "resv1DataGridViewTextBoxColumn";
            this.resv1DataGridViewTextBoxColumn.ReadOnly = true;
            this.resv1DataGridViewTextBoxColumn.Visible = false;
            // 
            // resv2DataGridViewTextBoxColumn
            // 
            this.resv2DataGridViewTextBoxColumn.DataPropertyName = "Resv2";
            this.resv2DataGridViewTextBoxColumn.HeaderText = "Resv2";
            this.resv2DataGridViewTextBoxColumn.Name = "resv2DataGridViewTextBoxColumn";
            this.resv2DataGridViewTextBoxColumn.ReadOnly = true;
            this.resv2DataGridViewTextBoxColumn.Visible = false;
            // 
            // resv3DataGridViewTextBoxColumn
            // 
            this.resv3DataGridViewTextBoxColumn.DataPropertyName = "Resv3";
            this.resv3DataGridViewTextBoxColumn.HeaderText = "Resv3";
            this.resv3DataGridViewTextBoxColumn.Name = "resv3DataGridViewTextBoxColumn";
            this.resv3DataGridViewTextBoxColumn.ReadOnly = true;
            this.resv3DataGridViewTextBoxColumn.Visible = false;
            // 
            // resv4DataGridViewTextBoxColumn
            // 
            this.resv4DataGridViewTextBoxColumn.DataPropertyName = "Resv4";
            this.resv4DataGridViewTextBoxColumn.HeaderText = "Resv4";
            this.resv4DataGridViewTextBoxColumn.Name = "resv4DataGridViewTextBoxColumn";
            this.resv4DataGridViewTextBoxColumn.ReadOnly = true;
            this.resv4DataGridViewTextBoxColumn.Visible = false;
            // 
            // resv5DataGridViewTextBoxColumn
            // 
            this.resv5DataGridViewTextBoxColumn.DataPropertyName = "Resv5";
            this.resv5DataGridViewTextBoxColumn.HeaderText = "Resv5";
            this.resv5DataGridViewTextBoxColumn.Name = "resv5DataGridViewTextBoxColumn";
            this.resv5DataGridViewTextBoxColumn.ReadOnly = true;
            this.resv5DataGridViewTextBoxColumn.Visible = false;
            // 
            // ordDataGridViewTextBoxColumn
            // 
            this.ordDataGridViewTextBoxColumn.DataPropertyName = "Ord";
            this.ordDataGridViewTextBoxColumn.HeaderText = "Ord";
            this.ordDataGridViewTextBoxColumn.Name = "ordDataGridViewTextBoxColumn";
            this.ordDataGridViewTextBoxColumn.ReadOnly = true;
            this.ordDataGridViewTextBoxColumn.Visible = false;
            // 
            // bsCatgr
            // 
            this.bsCatgr.AllowNew = true;
            this.bsCatgr.DataMember = "Ele_TCode";
            this.bsCatgr.DataSource = this.elecDataSet;
            // 
            // elecDataSet
            // 
            this.elecDataSet.DataSetName = "ElecDataSet";
            this.elecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dgvCode
            // 
            this.dgvCode.AllowUserToAddRows = false;
            this.dgvCode.AllowUserToOrderColumns = true;
            this.dgvCode.AutoGenerateColumns = false;
            this.dgvCode.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCode.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dCatgr,
            this.dCode,
            this.dADesc,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dCnt});
            this.dgvCode.DataSource = this.bsCode;
            this.dgvCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCode.Location = new System.Drawing.Point(0, 0);
            this.dgvCode.MultiSelect = false;
            this.dgvCode.Name = "dgvCode";
            this.dgvCode.RowTemplate.Height = 23;
            this.dgvCode.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCode.Size = new System.Drawing.Size(580, 453);
            this.dgvCode.TabIndex = 4;
            this.dgvCode.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvCode_CellFormatting);
            // 
            // dCatgr
            // 
            this.dCatgr.DataPropertyName = "Catgr";
            this.dCatgr.HeaderText = "카테고리";
            this.dCatgr.MaxInputLength = 3;
            this.dCatgr.Name = "dCatgr";
            this.dCatgr.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dCatgr.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dCatgr.Visible = false;
            this.dCatgr.Width = 69;
            // 
            // dCode
            // 
            this.dCode.DataPropertyName = "Code";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dCode.DefaultCellStyle = dataGridViewCellStyle3;
            this.dCode.HeaderText = "코드";
            this.dCode.MaxInputLength = 3;
            this.dCode.Name = "dCode";
            this.dCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dADesc
            // 
            this.dADesc.DataPropertyName = "ADesc";
            this.dADesc.HeaderText = "설명";
            this.dADesc.Name = "dADesc";
            this.dADesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dADesc.Width = 200;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "BDesc";
            this.dataGridViewTextBoxColumn14.HeaderText = "부연설명";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Resv1";
            this.dataGridViewTextBoxColumn15.HeaderText = "예약1";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Resv2";
            this.dataGridViewTextBoxColumn16.HeaderText = "예약2";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Resv3";
            this.dataGridViewTextBoxColumn17.HeaderText = "예약3";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Resv4";
            this.dataGridViewTextBoxColumn18.HeaderText = "예약4";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Resv5";
            this.dataGridViewTextBoxColumn19.HeaderText = "예약5";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Ord";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn20.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn20.HeaderText = "정렬";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dCnt
            // 
            this.dCnt.DataPropertyName = "CCnt";
            this.dCnt.HeaderText = "CCnt";
            this.dCnt.Name = "dCnt";
            this.dCnt.ReadOnly = true;
            this.dCnt.Visible = false;
            // 
            // bsCode
            // 
            this.bsCode.AllowNew = true;
            this.bsCode.DataMember = "Ele_TCode";
            this.bsCode.DataSource = this.elecDataSet;
            // 
            // contextMenu
            // 
            this.contextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmQuery,
            this.toolStripSeparator1,
            this.tsmNew,
            this.tsmDel,
            this.tsmSave,
            this.toolStripSeparator2,
            this.tsmExit});
            this.contextMenu.Name = "contextMenu";
            this.contextMenu.Size = new System.Drawing.Size(157, 148);
            // 
            // tsmQuery
            // 
            this.tsmQuery.Name = "tsmQuery";
            this.tsmQuery.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.tsmQuery.Size = new System.Drawing.Size(156, 22);
            this.tsmQuery.Text = "조회";
            this.tsmQuery.Click += new System.EventHandler(this.tsmQuery_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(153, 6);
            // 
            // tsmNew
            // 
            this.tsmNew.Name = "tsmNew";
            this.tsmNew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.tsmNew.Size = new System.Drawing.Size(156, 22);
            this.tsmNew.Text = "신규(&F)";
            this.tsmNew.Click += new System.EventHandler(this.tsmNew_Click);
            // 
            // tsmDel
            // 
            this.tsmDel.Name = "tsmDel";
            this.tsmDel.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D)));
            this.tsmDel.Size = new System.Drawing.Size(156, 22);
            this.tsmDel.Text = "삭제(&D)";
            this.tsmDel.Click += new System.EventHandler(this.tsmDel_Click);
            // 
            // tsmSave
            // 
            this.tsmSave.Name = "tsmSave";
            this.tsmSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.tsmSave.Size = new System.Drawing.Size(156, 22);
            this.tsmSave.Text = "저장(&S)";
            this.tsmSave.Click += new System.EventHandler(this.tsmSave_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(153, 6);
            // 
            // tsmExit
            // 
            this.tsmExit.Name = "tsmExit";
            this.tsmExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.tsmExit.Size = new System.Drawing.Size(156, 22);
            this.tsmExit.Text = "종료(&X)";
            this.tsmExit.Click += new System.EventHandler(this.tsmExit_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 51);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.gdvCatgr);
            this.splitContainer1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dgvCode);
            this.splitContainer1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer1.Size = new System.Drawing.Size(849, 453);
            this.splitContainer1.SplitterDistance = 265;
            this.splitContainer1.TabIndex = 5;
            // 
            // taCatgr
            // 
            this.taCatgr.ClearBeforeFill = true;
            // 
            // taCode
            // 
            this.taCode.ClearBeforeFill = true;
            // 
            // frmCode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 504);
            this.ContextMenuStrip = this.contextMenu;
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "코드관리";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gdvCatgr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCatgr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsCode)).EndInit();
            this.contextMenu.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnQuery;
        private DB.ElecDataSet elecDataSet;
        private DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter taCatgr;
        private System.Windows.Forms.DataGridView gdvCatgr;
        private DB.ElecDataSetTableAdapters.Ele_TCodeTableAdapter taCode;
        private System.Windows.Forms.DataGridView dgvCode;
        private System.Windows.Forms.BindingSource bsCode;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn cCatgr;
        private System.Windows.Forms.DataGridViewTextBoxColumn cCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn cADesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn bDescDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resv1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resv2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resv3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resv4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resv5DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ordDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bsCatgr;
        private System.Windows.Forms.ContextMenuStrip contextMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmNew;
        private System.Windows.Forms.ToolStripMenuItem tsmDel;
        private System.Windows.Forms.ToolStripMenuItem tsmSave;
        private System.Windows.Forms.ToolStripMenuItem tsmQuery;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem tsmExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dCatgr;
        private System.Windows.Forms.DataGridViewTextBoxColumn dCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn dADesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dCnt;
    }
}