﻿namespace Election.DB {
    
    
    public partial class ElecDataSet {
        partial class Ele_TPrecDataTable
        {
        }
    
        partial class Ele_TCandDataTable
        {
        }
    
        partial class DataTable1DataTable
        {
            
        }

        partial class Ele_TCodeDataTable
        {
            
        }
    }
}

namespace Election.DB.ElecDataSetTableAdapters {
    partial class Ele_TCandSBSTableAdapter
    {
    }

    partial class Ele_TCandTableAdapter
    {
    }

    partial class Ele_TQsheetTableAdapter
    {
        
    }


    public partial class Ele_TCodeTableAdapter
    {
        
    }
}
