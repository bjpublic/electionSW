﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Election
{
    public partial class frmCand : Form
    {
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb1; //시도
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb2; //선거종류                       
        private DB.ElecDataSet.Ele_TPrecDataTable dtCmb3; //선거구
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb4; //정당
        private DB.ElecDataSet.Ele_TCodeDataTable dtCmb5; //사퇴여부


        private DB.ElecDataSet.Ele_TCandDataTable dtCand;

        
        


        private Boolean isNew = false;
        private Boolean isSearch = false;

        public frmCand()
        {
            InitializeComponent();

            Init();
        }
        private void Init()
        {
            dtCmb1 = this.taCode.GetDataByCompLikeStr("600", Global.CompLikeString);
            bsCity.DataSource = dtCmb1;

            dtCmb2 = this.taCode.GetDataByCompLikeStr("010", Global.CompLikeString);
            bsElec.DataSource = dtCmb2;

            //정당
            dtCmb4 = this.taCode.GetData("100");
            bsParty.DataSource = dtCmb4;

            //사퇴여부
            dtCmb5 = this.taCode.GetData("500");
            bsRegGubn.DataSource = dtCmb5;


            //dtCand = new DB.ElecDataSet.Ele_TCandDataTable();

            setControl();
        }

        

      

       
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "후보목록|*.csv";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    bsPrecList.DataSource = dtCmb3;
                    //TransferCSVToTable(this.dtCand, ofd.FileName);
                    TransferCSVToTable(elecDataSet.Ele_TCand, ofd.FileName);

                    setElecPrec();
                    setControl();

                    //taCand.Update(dtCand);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("오류 : " + ex.Message);
                }
            }
        }

        private void btnFileSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "후보목록(*.csv)|*.csv";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();

                //컬럼헤드는 생략
                //IEnumerable<string> colNames = dtCand.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
                IEnumerable<string> colNames = elecDataSet.Ele_TCand.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
                
                sb.AppendLine(string.Join("\t", colNames));
                foreach (DataRow row in elecDataSet.Ele_TCand.Rows)
                {
                    
                    IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                    sb.AppendLine(string.Join("\t", fields));
                }

                System.IO.File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.Default);
            }
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            isNew = false;
            isSearch = true;
            //조회조건 설정
            string catgr = cmb2.SelectedValue.ToString();
            string prec = cmb3.SelectedValue.ToString();

            if (catgr != "" && prec != "")
            {

                bsPrecList.DataSource = dtCmb3;

                //dtCand = this.taCand.GetData(catgr, prec);
                //bsCand.DataSource = dtCand;

                taCand.Fill(elecDataSet.Ele_TCand, catgr, prec);

                setElecPrec();
                setControl();
            }
        }


        private void btnNew_Click(object sender, EventArgs e)
        {
            isNew = true;

            MessageBox.Show(cmb2.SelectedValue.ToString() + "," + cmb3.SelectedValue.ToString().Trim());
            bsPrecList.DataSource = dtCmb3;
            elecDataSet.Ele_TCand.AddEle_TCandRow(cmb2.SelectedValue.ToString(), cmb3.SelectedValue.ToString().Trim(), "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 0, 0, "", "", "");
            //bsCand.MoveLast();
            //elecDataSet.Ele_TCand.AddEle_TCandRow("", )
            //DataRowView drv = (DataRowView)bsCand.AddNew();

            
            //drv["ElecCatgr"] = cmb2.SelectedValue.ToString().Trim();
            //drv["PrecID"] = cmb3.SelectedValue.ToString().Trim();

            

            setElecPrec();
            setControl();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(cmbElec.SelectedValue.ToString().Length + ",");
            isNew = false;
            try
            {
                if (isSearch)
                {
                    bsCand.EndEdit();
                    //taCand.Update(dtCand);
                    taCand.Update(elecDataSet.Ele_TCand);
                        
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            setControl();
        }


        private void dgvCand_SelectionChanged(object sender, EventArgs e)
        {
            isNew = false;


        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            isNew = false;
            if (bsCand.Count > 0)
            {
                if (MessageBox.Show("삭제 하시겠습니까?", "삭제", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    bsCand.RemoveCurrent();
                    //bsCand.MoveNext();
                }
            }
            setControl();
        }

        private void btnDelAll_Click(object sender, EventArgs e)
        {
            isNew = false;

            if (bsCand.Count > 0)
            {

                for (int i = bsCand.Count - 1; i >= 0 ; i--)
                {
                    bsCand.RemoveAt(i);
                    //bsCand.EndEdit();
                }
                
            }
            setControl();
        }

        private void bsElec_CurrentChanged(object sender, EventArgs e)
        {
            
            if (cmb1.SelectedValue != null && cmb2.SelectedValue != null)
            {
                getPrec(cmb1.SelectedValue.ToString().Trim(), cmb2.SelectedValue.ToString().Trim());
            }

            
        }

        private void bsCity_CurrentChanged(object sender, EventArgs e)
        {
            if (cmb1.SelectedValue != null && cmb2.SelectedValue != null)
            {
                getPrec(cmb1.SelectedValue.ToString().Trim(), cmb2.SelectedValue.ToString().Trim());
            }
        }


        private void getPrec(string strCity, string strPrec)
        {
            dtCmb3 = this.taPrec.GetData(strPrec, strCity);
            bsPrec.DataSource = dtCmb3;


        }

        public void TransferCSVToTable(DataTable dt, string filePath)
        {
            
            //dt.Clear();           

            string[] csvRows = System.IO.File.ReadAllLines(filePath,Encoding.Default);
            string[] fields = null;
            int i = 0;
            foreach (string csvRow in csvRows)
            {
                //MessageBox.Show(csvRow);
                fields = csvRow.Split('\t');
                if (i > 0)
                {
                    DataRow row = dt.NewRow();
                    row.ItemArray = fields;
                    dt.Rows.Add(row);
                }
                i++;
            }

            bsCand.DataSource = dt;
        }

        private void setElecPrec()
        {
            
            bsPrecView.DataSource = dtCmb3;//선거구


            bsElecView.DataSource = bsElec.DataSource;
        }

        public void setControl()
        {


            if (bsCand.Count == 0)
            {
                this.btnDel.Enabled = false;
                this.btnDelAll.Enabled = false;
                this.btnFileSave.Enabled = false;


                this.tsmDel.Enabled = false;
                this.tsmDelAll.Enabled = false;
                this.tsmFileSave.Enabled = false;

            }
            else
            {
                this.btnDel.Enabled = true;
                this.btnDelAll.Enabled = true;
                this.btnFileSave.Enabled = true;

                this.tsmDel.Enabled = true;
                this.tsmDelAll.Enabled = true;
                this.tsmFileSave.Enabled = true;

            }

        }

        private void txtChgYMD_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtKeyPress(sender, e);
        }

        private void txtKeyPress(object sender, KeyPressEventArgs e)
        {
            int keyCode = (int)e.KeyChar;  // 46: Point  
            if ((keyCode < 48 || keyCode > 57) && keyCode != 8 && keyCode != 46)
            {
                e.Handled = true;
            }

        }

        private void tsmNew_Click(object sender, EventArgs e)
        {
            this.btnNew_Click(sender, e);
        }

        private void tsmDel_Click(object sender, EventArgs e)
        {
            this.btnDel_Click(sender, e);
        }

        private void tsmSave_Click(object sender, EventArgs e)
        {
            this.btnSave_Click(sender, e);
        }

        private void tsmQuery_Click(object sender, EventArgs e)
        {
            this.btnQuery_Click(sender, e);
        }

        private void tsmOpen_Click(object sender, EventArgs e)
        {
            this.btnOpen_Click(sender, e);
        }

        private void tsmFileSave_Click(object sender, EventArgs e)
        {
            this.btnFileSave_Click(sender, e);
        }

        private void tsmExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tsmDelAll_Click(object sender, EventArgs e)
        {
            this.btnDelAll_Click(sender, e);
        }



    }
}
