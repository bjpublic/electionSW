﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Election
{
    class Global
    {
        public static string version = "r1";

        /// <summary>
        ///     실행파일의 full path
        /// </summary>
        public static string ExecutablePath
        {
            get { return Application.ExecutablePath; }
        }

        /// <summary>
        ///     실행파일의 folder path
        /// </summary>
        public static string StartupPath
        {
            get { return Application.StartupPath; }
        }

        /// <summary>
        ///     실행파일의 folder path
        /// </summary>
        public static string ExeName
        {
            get 
            {
                int n = ExecutablePath.LastIndexOf(@"\");
                return ExecutablePath.Substring(n + 1); 
            }
        }

    }
}
