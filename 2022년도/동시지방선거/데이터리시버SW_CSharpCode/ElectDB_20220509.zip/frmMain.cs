﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using IBM.Data.DB2;

namespace ElectDB
{
    public partial class frmMain : Form
    {
        #region 내부사용변수 설정

        #endregion

        #region 생성자
        public frmMain()
        {
            InitializeComponent();

            //init 파일 설정
            MyInit();

        }
        #endregion

        #region 초기화
        public void MyInit()
        {
            //version, title
            this.Text = Global.Title + " (Version " + Global.Version + ")";
            //FMainForm = this;

            setExec();
            //setFtpInfo();
            //setHttpInfo();
            //setUpload();
            setDBConnect();
            setLog();
        }

        //실행 탭페이지 콘트롤 초기화
        private void setExec()
        {
            //자동/수동여부 라디오버튼 설정
            //this.rdoAuto.Checked = Global.IniFile.GetString("EXEC", "AUTO").Equals("1");

            //자동시 지연시간
            this.txtTime.Text = Global.IniFile.GetString("EXEC", "TIME");

            //로고레벨
            this.cbLog.SelectedIndex = Convert.ToInt32(Global.IniFile.GetString("EXEC", "LOG"));

            //DB2쿼리 여부
            //this.chkDB2.Checked = Global.IniFile.GetString("EXEC", "DB2Query").Equals("1");

            //DB업데이트 여부
            this.chkDBUP.Checked = Global.IniFile.GetString("EXEC", "DbUpdate").Equals("1");
        }

        //FTP탭페이지 콘트롤 초기화
        private void setFtp()
        { 
            //
        }

        //HTTP 탭페이지 콘트롤 초기화
        private void setHttp()
        {
            //
        }

        //Upload 탭페이지 콘트롤 초기화
        private void setUpload()
        {
            //
        }

        //DB연결정보 탭페이지 콘트롤 초기화
        private void setDBConnect()
        {
            //SBS DB2서버 연결 문자열
            this.txtDB2ConnectionString.Text = Global.IniFile.GetString("DB", "DB2ConnectionString");

            //개표방송 시스템 DB 연결문자열
            this.txtConnectionString.Text = Global.IniFile.GetString("DB", "ConnectionString");


            //투개표 데이터를 수신할 시도체크여부
            // 서울 = 11,  부산 = 26, 울산 = 31, 전남 = 46
            // 전체를 사용할 필요가 없으면 울산만 받거나 
            // 부산, 울산만 선택해서 골라 받을수도 있다. 

            string sd = Global.IniFile.GetString("DB", "SD");
            this.chkSD11.Checked = sd.IndexOf("11") > -1;
            this.chkSD26.Checked = sd.IndexOf("26") > -1;
            this.chkSD27.Checked = sd.IndexOf("27") > -1;
            this.chkSD28.Checked = sd.IndexOf("28") > -1;
            this.chkSD29.Checked = sd.IndexOf("29") > -1;
            this.chkSD30.Checked = sd.IndexOf("30") > -1;
            this.chkSD31.Checked = sd.IndexOf("31") > -1;
            this.chkSD41.Checked = sd.IndexOf("41") > -1;
            this.chkSD42.Checked = sd.IndexOf("42") > -1;
            this.chkSD43.Checked = sd.IndexOf("43") > -1;
            this.chkSD44.Checked = sd.IndexOf("44") > -1;
            this.chkSD45.Checked = sd.IndexOf("45") > -1;
            this.chkSD46.Checked = sd.IndexOf("46") > -1;
            this.chkSD47.Checked = sd.IndexOf("47") > -1;
            this.chkSD48.Checked = sd.IndexOf("48") > -1;
            this.chkSD49.Checked = sd.IndexOf("49") > -1;
            this.chkSD51.Checked = sd.IndexOf("51") > -1;
        }

        //로그 탭페이지 콘트롤 초기화
        private void setLog()
        {
            //LOG 최대라인수
            this.txtMaxLine.Text = Global.IniFile.GetString("LOG", "MAXLINE");
        }
        #endregion

        #region 각종 작동함수

        //로그추가 함수
        public void addMsg(int lvl, string head, string msg)
        {
            CheckForIllegalCrossThreadCalls = false;
            try
            {
                //로그레벨이 허용레벨이면
                if (cbLog.SelectedIndex >= lvl)
                {
                    //최대 허용 로그 라인수
                    int maxline = Convert.ToInt32(txtMaxLine.Text);
                    //로그가 최대 허용라인보다 많으면
                    if (lstLog.Items.Count >= maxline)
                    {
                        //첫줄 로그 라인 삭제
                        lstLog.Items.RemoveAt(0);
                    }

                    //로그 문자열 생성
                    // [2018-06-02 오후 11:03:30] +4 울산 북구처럼 로그창에 표시한다 
                    string strLog = "[" + DateTime.Now + "] " + head + msg;

                  

                    //로그 추가
                    lstLog.Items.Add(strLog);
                    //현재 라인을 마지막줄로 이동
                    lstLog.SelectedIndex = lstLog.Items.Count - 1;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //처리 프로세스
        private void execute()
        {
            //현재 커서모양 대기커서로 변경
            Cursor.Current = Cursors.WaitCursor;

            //처리로그
            addMsg(1, "실행", "시작---------------------------------------");
            //타이머 정지
            timerAuto.Stop();
            //실행버튼 비활성화
            this.btnExec.Enabled = false;

            //FTP Download, Http DownLoad, FTP Upload등 프로세스 생략

            //DB Update
            if (this.chkDBUP.Checked)
            {
                processDB2(false);
                //SBS DB2 개표자료 처리

            }

            //처리완료후 실행버튼 재활성
            btnExec.Enabled = true;
            //자동이면 인터발 설정후 타이머 작동
            if (this.rdoAuto.Checked)
            {
                int interval = int.Parse(this.txtTime.Text.ToString()) * 1000;
                this.timerAuto.Interval = interval;
                this.timerAuto.Start();
            }
            addMsg(1, "실행", "종료---------------------------------------");
            //현재 커서모양 기본커서로 변경
            Cursor.Current = Cursors.Default;
        }

        //SBS DB2 개표자료 처리
        private void processDB2(bool bindGrid = false)
        {
            //내부변수
            DB2Connection db2;
            DB2Command cmd;

            try
            {
                //연결준비
                db2 = new DB2Connection(txtDB2ConnectionString.Text);

                //db2 쿼리문자열
                cmd = new DB2Command();
                cmd.CommandText = "select * from Ele.TB_VOTE2022 where vt_kind in ('1','2','3','4') and vt_gubun='S' order by vt_kind, vt_suncode for fetch only";
                cmd.Connection = db2;
                cmd.CommandTimeout = 60;

                //연결
                db2.Open();
                //연결 성공시 로그
                addMsg(1, "SBS DB : ", "연결");

                //결과조회
                DB2DataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                DataTable dt = new DataTable();
                dt.Load(dr);

                //그리드에 표출?
                dgvVOTE2018.DataSource = bindGrid ? dt : null;

                //그리드 표출 없으면 개표데이터 업데이트
                if (!bindGrid) updateDB(dt);

                //종료
                db2.Close();
                addMsg(1, "SBS DB : ", "종료");
            }
            catch (Exception e)
            {
                //연결오류발생시 출력(오류는 로그레벨1)
                addMsg(1, "SBS DB : ", e.Message);
            }
        }

         //SBS DB2자료를 MS-SQL서버(개표DB)로 업데이트

        private void updateDB(DataTable table)
        {
            try
            {
                //개표DB열기
                SqlConnection db = new SqlConnection(this.txtConnectionString.Text.ToString().Trim());
                db.Open();
                addMsg(1, "개표 DB : ", "연결");

                for (var i = 0; i < table.Rows.Count; i++)
                {
                    updateRow(db, table.Rows[i]);
                }
                db.Close();
                addMsg(1, "개표 DB : ", "종료");
            }
            catch (Exception e)
            {
                //연결오류발생시 출력(오류는 로그레벨1)
                addMsg(1, "개표 DB : ", e.Message);
            }
        }

        private void updateRow(SqlConnection db, DataRow row)
        {
            //SBS 데이타 시도코드 분리
            string localCode = row["VT_SUNCODE"].ToString().Substring(0, 2);

            //시도 체크된 데이터만 업로드
            string chkLocal = "";
            if (this.chkSD11.Checked) chkLocal += this.chkSD11.Tag.ToString() + ",";
            if (this.chkSD26.Checked) chkLocal += this.chkSD26.Tag.ToString() + ",";
            if (this.chkSD27.Checked) chkLocal += this.chkSD27.Tag.ToString() + ",";
            if (this.chkSD28.Checked) chkLocal += this.chkSD28.Tag.ToString() + ",";
            if (this.chkSD29.Checked) chkLocal += this.chkSD29.Tag.ToString() + ",";
            if (this.chkSD30.Checked) chkLocal += this.chkSD30.Tag.ToString() + ",";
            if (this.chkSD31.Checked) chkLocal += this.chkSD31.Tag.ToString() + ",";
            if (this.chkSD41.Checked) chkLocal += this.chkSD41.Tag.ToString() + ",";
            if (this.chkSD42.Checked) chkLocal += this.chkSD42.Tag.ToString() + ",";
            if (this.chkSD43.Checked) chkLocal += this.chkSD43.Tag.ToString() + ",";
            if (this.chkSD44.Checked) chkLocal += this.chkSD44.Tag.ToString() + ",";
            if (this.chkSD45.Checked) chkLocal += this.chkSD45.Tag.ToString() + ",";
            if (this.chkSD46.Checked) chkLocal += this.chkSD46.Tag.ToString() + ",";
            if (this.chkSD47.Checked) chkLocal += this.chkSD47.Tag.ToString() + ",";
            if (this.chkSD48.Checked) chkLocal += this.chkSD48.Tag.ToString() + ",";
            if (this.chkSD49.Checked) chkLocal += this.chkSD49.Tag.ToString() + ",";
            if (this.chkSD51.Checked) chkLocal += this.chkSD51.Tag.ToString();

            if (chkLocal.IndexOf(localCode) > -1)
            {
                updatePrec(db, row);
            }
        }

        private void updatePrec(SqlConnection db, DataRow row)
        {
            //선거구분 1, 2, 3, 4
            string elecCatgr = row["VT_KIND"].ToString().PadLeft(2, '0');

            //선거구 개표자료 MS-SQL서버의 ELE_TPRECSBS으로 업데이트
                        string sql = "";
            sql += "UPDATE ELE_TPRECSBS SET";
            sql += " eleccnt = " + int.Parse(row["VT_YOOCNT"].ToString());
            sql += ", pollcnt = " + int.Parse(row["VT_TOOCNT"].ToString());
            sql += ", pollrate = '" + row["VT_TOORATE"].ToString() + "'";
            sql += ", pollyn = '" + (row["VT_TOOEND"].ToString() == "1" ? "Y" : "N") + "'";
            sql += ", opencnt = " + int.Parse(row["VT_OPENCNT"].ToString());
            sql += ", openrate = '" + row["VT_OPENRATE"].ToString() + "'";
            sql += ", openyn = '" + (row["VT_OPENEND"].ToString() == "1" ? "Y" : "N") + "'";
            sql += ", fstno = '" + row["VT_RANK01"].ToString() + "'";
            sql += ", elecgbn = '" + row["VT_DEGREE"].ToString() + "'";
            sql += " where eleccatgr = '" + elecCatgr + "'";
            sql += " and precid = '" + row["VT_SUNCODE"].ToString().Trim() + "'";

            //선거구 개표자료 업데이트 실행
            var msg = row["VT_KIND"].ToString().Trim() + " " + row["VT_SIDONAME"].ToString().Trim() + " " + row["VT_GUNAME"].ToString().Trim();
            try
            {
                SqlCommand cmd = new SqlCommand(sql, db);
                cmd.ExecuteNonQuery();
                addMsg(2, "+ ", msg);

                //후보정보 업데이트
                updateCand(db, row);
            }
            catch (Exception e)
            {
                addMsg(2, "+ ", msg + " : " + e.Message);
            }

        }

        private void updateCand(SqlConnection db, DataRow row)
        {
            //SBS 한선거구에 16명씩 후보정보가 넘어옴 

            const int HUBO_CNT = 16;
            //선거종류 1, 2, 3, 4
            string elecCatgr = row["VT_KIND"].ToString().PadLeft(2, '0');
            // 01, 02, 03, 04로 변경 

            //선거구ID
            string precid = row["VT_SUNCODE"].ToString().Trim();
            //해당 선거구의 후보자 리스트를 가져옴
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = db;
            var sql = "select ordno from ele_tcandsbs where eleccatgr = '" + elecCatgr + "' and precid = '" + precid + "'";
            cmd.CommandText = sql;
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            //후보기호리스트
            string chkCand = "";
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                chkCand += dt.Rows[i]["ORDNO"].ToString() + ",";
            }

            for (int i = 1; i < HUBO_CNT; i++)
            {
                var no = i.ToString().PadLeft(2, '0');
                if (chkCand.IndexOf(no) < 0) continue;

                sql = "UPDATE ELE_TCANDSBS SET";
                sql += " VOTESCNT = "+ int.Parse(row["VT_DUKPCNT" + no].ToString());
                sql += ", VOTESRATE = '" + row["VT_DUKPRATE" + no].ToString() + "'";
                sql += ", RANK = " + int.Parse(row["VT_DUKPRANK" + no].ToString());
                sql += " WHERE ELECCATGR = '"+ elecCatgr +"'";
                sql += " AND PRECID = '" + row["VT_SUNCODE"].ToString() + "'";
                sql += " AND ORDNO = '"+ no +"'";
                try
                {
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                    addMsg(3, "@ ", no +" 완료");
                }
                catch (Exception e)
                {
                    addMsg(3, "@ ", no + " : " + e.Message);
                }
            }
        }
        #endregion

        #region 콘트롤 이벤트 처리
        //자동타이머 틱 이벤트
        private void timerAuto_Tick(object sender, EventArgs e)
        {
            this.timerAuto.Stop();
            this.execute();
        }

        #region 실행탭 이벤트 처리
        //자동/수동 : 자동체크박스 변경
        private void rdoAuto_CheckedChanged(object sender, EventArgs e)
        {
            //Global.IniFile.SetString("EXEC", "AUTO", rdoAuto.Checked ? "1" : "0");
        }

        //자동/수동 : 수동체크박스 변경
        private void rdoManual_CheckedChanged(object sender, EventArgs e)
        {
            //Global.IniFile.SetString("EXEC", "AUTO", rdoAuto.Checked ? "0" : "1");
            //타이머 종료
            if (rdoManual.Checked) timerAuto.Stop();
        }

        //지연시간 초수변경
        private void txtTime_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("EXEC", "TIME", this.txtTime.Text.ToString().Trim());
        }

        //로그레벨 변경
        private void cbLog_SelectedIndexChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("EXEC", "LOG", this.cbLog.SelectedIndex.ToString());
        }


        //DB2 Query 변경
        private void chkDB2_CheckedChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("EXEC", "Db2Query", this.chkDB2.Checked ? "1" : "0");
        }

        //DB Update 변경
        private void chkDBUP_CheckedChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("EXEC", "DbUpdate", this.chkDBUP.Checked ? "1" : "0");
        }

        //실행폴더 버튼클릭
        private void btnExecFolder_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", Global.StartupPath);
        }

        //INI폴더 버튼클릭
        private void btnINI_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", Global.DataPath);
        }

        //실행 버튼클릭
        private void btnExec_Click(object sender, EventArgs e)
        {
            this.execute();
        }
        #endregion

        #region 미리보기 탭페이지
        //미리보기 버튼클릭
        private void btnPreview_Click(object sender, EventArgs e)
        {
            //this.taVOTE2018.Fill(this.sbsDataSet.TB_VOTE2018);
            processDB2(true);
        }

        #endregion

        #region DB연결정보 탭페이지
        //DB2 연결문자열 변경
        private void txtDB2ConnectionString_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("DB", "DB2ConnectionString", this.txtDB2ConnectionString.Text.ToString().Trim());
        }

        //개표DB(MS-SQL서버) 연결문자열 변경

        private void txtConnectionString_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("DB", "ConnectionString", this.txtConnectionString.Text.ToString().Trim());
        }

        //전체선택 변경
        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAll.Checked)
            {
                this.chkSD11.Checked = true; this.chkSD26.Checked = true;
                this.chkSD27.Checked = true; this.chkSD28.Checked = true;
                this.chkSD29.Checked = true; this.chkSD30.Checked = true;
                this.chkSD31.Checked = true; this.chkSD41.Checked = true;
                this.chkSD42.Checked = true; this.chkSD43.Checked = true;
                this.chkSD44.Checked = true; this.chkSD45.Checked = true;
                this.chkSD46.Checked = true; this.chkSD47.Checked = true;
                this.chkSD48.Checked = true; this.chkSD49.Checked = true;
                this.chkSD51.Checked = true;
            }
            else
            {
                this.chkSD11.Checked = false; this.chkSD26.Checked = false;
                this.chkSD27.Checked = false; this.chkSD28.Checked = false;
                this.chkSD29.Checked = false; this.chkSD30.Checked = false;
                this.chkSD31.Checked = false; this.chkSD41.Checked = false;
                this.chkSD42.Checked = false; this.chkSD43.Checked = false;
                this.chkSD44.Checked = false; this.chkSD45.Checked = false;
                this.chkSD46.Checked = false; this.chkSD47.Checked = false;
                this.chkSD48.Checked = false; this.chkSD49.Checked = false;
                this.chkSD51.Checked = false;
            }
        }

        //각 시도선택 변경
        private void chkSido_CheckedChanged(object sender, EventArgs e)
        {
            string sd = "";

            if (this.chkSD11.Checked) sd += this.chkSD11.Tag.ToString() + ",";
            if (this.chkSD26.Checked) sd += this.chkSD26.Tag.ToString() + ",";
            if (this.chkSD27.Checked) sd += this.chkSD27.Tag.ToString() + ",";
            if (this.chkSD28.Checked) sd += this.chkSD28.Tag.ToString() + ",";
            if (this.chkSD29.Checked) sd += this.chkSD29.Tag.ToString() + ",";
            if (this.chkSD30.Checked) sd += this.chkSD30.Tag.ToString() + ",";
            if (this.chkSD31.Checked) sd += this.chkSD31.Tag.ToString() + ",";
            if (this.chkSD41.Checked) sd += this.chkSD41.Tag.ToString() + ",";
            if (this.chkSD42.Checked) sd += this.chkSD42.Tag.ToString() + ",";
            if (this.chkSD43.Checked) sd += this.chkSD43.Tag.ToString() + ",";
            if (this.chkSD44.Checked) sd += this.chkSD44.Tag.ToString() + ",";
            if (this.chkSD45.Checked) sd += this.chkSD45.Tag.ToString() + ",";
            if (this.chkSD46.Checked) sd += this.chkSD46.Tag.ToString() + ",";
            if (this.chkSD47.Checked) sd += this.chkSD47.Tag.ToString() + ",";
            if (this.chkSD48.Checked) sd += this.chkSD48.Tag.ToString() + ",";
            if (this.chkSD49.Checked) sd += this.chkSD49.Tag.ToString() + ",";
            if (this.chkSD51.Checked) sd += this.chkSD51.Tag.ToString();

            Global.IniFile.SetString("DB", "SD", sd);
        }

        #endregion

        #region 로그 탭페이지
        //총 라인수 변경
        private void txtMaxLine_TextChanged(object sender, EventArgs e)
        {
            Global.IniFile.SetString("LOG", "MAXLINE", this.txtMaxLine.Text.ToString().Trim());
        }

        //로그지우기 버튼클릭
        private void btnLogClear_Click(object sender, EventArgs e)
        {
            while (lstLog.Items.Count > 0)
            {
                lstLog.Items.RemoveAt(0);
            }
        }

        #endregion

        #endregion

        private void dgvVOTE2018_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
