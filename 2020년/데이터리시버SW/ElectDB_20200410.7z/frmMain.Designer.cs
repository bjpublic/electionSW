﻿namespace ElectDB
{
    partial class frmMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpExec = new System.Windows.Forms.TabPage();
            this.btnINI = new System.Windows.Forms.Button();
            this.btnExecFolder = new System.Windows.Forms.Button();
            this.btnExec = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkDB2 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.chkDBUP = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbLog = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.rdoManual = new System.Windows.Forms.RadioButton();
            this.rdoAuto = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tpPreview = new System.Windows.Forms.TabPage();
            this.dgvVOTE2018 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPreview = new System.Windows.Forms.Button();
            this.tpDb = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.chkSD51 = new System.Windows.Forms.CheckBox();
            this.chkSD49 = new System.Windows.Forms.CheckBox();
            this.chkSD48 = new System.Windows.Forms.CheckBox();
            this.chkSD47 = new System.Windows.Forms.CheckBox();
            this.chkSD46 = new System.Windows.Forms.CheckBox();
            this.chkSD45 = new System.Windows.Forms.CheckBox();
            this.chkSD44 = new System.Windows.Forms.CheckBox();
            this.chkSD43 = new System.Windows.Forms.CheckBox();
            this.chkSD42 = new System.Windows.Forms.CheckBox();
            this.chkSD41 = new System.Windows.Forms.CheckBox();
            this.chkSD31 = new System.Windows.Forms.CheckBox();
            this.chkSD30 = new System.Windows.Forms.CheckBox();
            this.chkSD29 = new System.Windows.Forms.CheckBox();
            this.chkSD28 = new System.Windows.Forms.CheckBox();
            this.chkSD27 = new System.Windows.Forms.CheckBox();
            this.chkSD26 = new System.Windows.Forms.CheckBox();
            this.chkSD11 = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtConnectionString = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtDB2ConnectionString = new System.Windows.Forms.TextBox();
            this.tpLog = new System.Windows.Forms.TabPage();
            this.lstLog = new System.Windows.Forms.ListBox();
            this.btnLogClear = new System.Windows.Forms.Button();
            this.txtMaxLine = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.timerAuto = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tpExec.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tpPreview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVOTE2018)).BeginInit();
            this.panel1.SuspendLayout();
            this.tpDb.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tpLog.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpExec);
            this.tabControl1.Controls.Add(this.tpPreview);
            this.tabControl1.Controls.Add(this.tpDb);
            this.tabControl1.Controls.Add(this.tpLog);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(529, 471);
            this.tabControl1.TabIndex = 2;
            // 
            // tpExec
            // 
            this.tpExec.Controls.Add(this.btnINI);
            this.tpExec.Controls.Add(this.btnExecFolder);
            this.tpExec.Controls.Add(this.btnExec);
            this.tpExec.Controls.Add(this.groupBox2);
            this.tpExec.Controls.Add(this.groupBox1);
            this.tpExec.Location = new System.Drawing.Point(4, 22);
            this.tpExec.Name = "tpExec";
            this.tpExec.Padding = new System.Windows.Forms.Padding(3);
            this.tpExec.Size = new System.Drawing.Size(521, 445);
            this.tpExec.TabIndex = 1;
            this.tpExec.Text = "실행";
            this.tpExec.UseVisualStyleBackColor = true;
            // 
            // btnINI
            // 
            this.btnINI.Location = new System.Drawing.Point(122, 341);
            this.btnINI.Name = "btnINI";
            this.btnINI.Size = new System.Drawing.Size(88, 79);
            this.btnINI.TabIndex = 15;
            this.btnINI.Text = "INI폴더";
            this.btnINI.UseVisualStyleBackColor = true;
            this.btnINI.Click += new System.EventHandler(this.btnINI_Click);
            // 
            // btnExecFolder
            // 
            this.btnExecFolder.Location = new System.Drawing.Point(27, 341);
            this.btnExecFolder.Name = "btnExecFolder";
            this.btnExecFolder.Size = new System.Drawing.Size(88, 79);
            this.btnExecFolder.TabIndex = 14;
            this.btnExecFolder.Text = "실행폴더";
            this.btnExecFolder.UseVisualStyleBackColor = true;
            this.btnExecFolder.Click += new System.EventHandler(this.btnExecFolder_Click);
            // 
            // btnExec
            // 
            this.btnExec.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExec.Location = new System.Drawing.Point(216, 341);
            this.btnExec.Name = "btnExec";
            this.btnExec.Size = new System.Drawing.Size(284, 79);
            this.btnExec.TabIndex = 13;
            this.btnExec.Tag = "0";
            this.btnExec.Text = "실행";
            this.btnExec.UseVisualStyleBackColor = true;
            this.btnExec.Click += new System.EventHandler(this.btnExec_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.chkDB2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.chkDBUP);
            this.groupBox2.Location = new System.Drawing.Point(27, 203);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(473, 107);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "실행";
            // 
            // chkDB2
            // 
            this.chkDB2.AutoSize = true;
            this.chkDB2.Checked = true;
            this.chkDB2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDB2.Enabled = false;
            this.chkDB2.Location = new System.Drawing.Point(72, 34);
            this.chkDB2.Name = "chkDB2";
            this.chkDB2.Size = new System.Drawing.Size(84, 16);
            this.chkDB2.TabIndex = 6;
            this.chkDB2.Text = "DB2 Query";
            this.chkDB2.UseVisualStyleBackColor = true;
            this.chkDB2.CheckedChanged += new System.EventHandler(this.chkDB2_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 12);
            this.label7.TabIndex = 5;
            this.label7.Text = "실행 :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 12);
            this.label6.TabIndex = 4;
            this.label6.Text = "수신 :";
            // 
            // chkDBUP
            // 
            this.chkDBUP.AutoSize = true;
            this.chkDBUP.Location = new System.Drawing.Point(72, 71);
            this.chkDBUP.Name = "chkDBUP";
            this.chkDBUP.Size = new System.Drawing.Size(83, 16);
            this.chkDBUP.TabIndex = 3;
            this.chkDBUP.Text = "DB Update";
            this.chkDBUP.UseVisualStyleBackColor = true;
            this.chkDBUP.CheckedChanged += new System.EventHandler(this.chkDBUP_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbLog);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtTime);
            this.groupBox1.Controls.Add(this.rdoManual);
            this.groupBox1.Controls.Add(this.rdoAuto);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(27, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(473, 163);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "작동";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(193, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "(레벨 0는 로그 무출력)";
            // 
            // cbLog
            // 
            this.cbLog.FormattingEnabled = true;
            this.cbLog.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cbLog.Location = new System.Drawing.Point(140, 112);
            this.cbLog.Name = "cbLog";
            this.cbLog.Size = new System.Drawing.Size(47, 20);
            this.cbLog.TabIndex = 7;
            this.cbLog.SelectedIndexChanged += new System.EventHandler(this.cbLog_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(187, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(231, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "초 (실행종료 후 다음 실행까지 대기 시간)";
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(140, 75);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(35, 21);
            this.txtTime.TabIndex = 5;
            this.txtTime.TextChanged += new System.EventHandler(this.txtTime_TextChanged);
            // 
            // rdoManual
            // 
            this.rdoManual.AutoSize = true;
            this.rdoManual.Checked = true;
            this.rdoManual.Location = new System.Drawing.Point(201, 40);
            this.rdoManual.Name = "rdoManual";
            this.rdoManual.Size = new System.Drawing.Size(47, 16);
            this.rdoManual.TabIndex = 4;
            this.rdoManual.TabStop = true;
            this.rdoManual.Text = "수동";
            this.rdoManual.UseVisualStyleBackColor = true;
            this.rdoManual.CheckedChanged += new System.EventHandler(this.rdoManual_CheckedChanged);
            // 
            // rdoAuto
            // 
            this.rdoAuto.AutoSize = true;
            this.rdoAuto.Location = new System.Drawing.Point(140, 40);
            this.rdoAuto.Name = "rdoAuto";
            this.rdoAuto.Size = new System.Drawing.Size(47, 16);
            this.rdoAuto.TabIndex = 3;
            this.rdoAuto.Text = "자동";
            this.rdoAuto.UseVisualStyleBackColor = true;
            this.rdoAuto.CheckedChanged += new System.EventHandler(this.rdoAuto_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "로그레벨 :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "지연시간 :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "자동/수동 :";
            // 
            // tpPreview
            // 
            this.tpPreview.Controls.Add(this.dgvVOTE2018);
            this.tpPreview.Controls.Add(this.panel1);
            this.tpPreview.Location = new System.Drawing.Point(4, 22);
            this.tpPreview.Name = "tpPreview";
            this.tpPreview.Padding = new System.Windows.Forms.Padding(3);
            this.tpPreview.Size = new System.Drawing.Size(521, 445);
            this.tpPreview.TabIndex = 0;
            this.tpPreview.Text = "미리보기";
            this.tpPreview.UseVisualStyleBackColor = true;
            // 
            // dgvVOTE2018
            // 
            this.dgvVOTE2018.AllowUserToAddRows = false;
            this.dgvVOTE2018.AllowUserToDeleteRows = false;
            this.dgvVOTE2018.AllowUserToResizeRows = false;
            this.dgvVOTE2018.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVOTE2018.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvVOTE2018.Location = new System.Drawing.Point(3, 38);
            this.dgvVOTE2018.MultiSelect = false;
            this.dgvVOTE2018.Name = "dgvVOTE2018";
            this.dgvVOTE2018.ReadOnly = true;
            this.dgvVOTE2018.RowTemplate.Height = 23;
            this.dgvVOTE2018.Size = new System.Drawing.Size(515, 404);
            this.dgvVOTE2018.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnPreview);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(515, 35);
            this.panel1.TabIndex = 3;
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.Location = new System.Drawing.Point(417, 5);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(93, 24);
            this.btnPreview.TabIndex = 0;
            this.btnPreview.Text = "미리보기";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // tpDb
            // 
            this.tpDb.Controls.Add(this.groupBox3);
            this.tpDb.Controls.Add(this.groupBox8);
            this.tpDb.Location = new System.Drawing.Point(4, 22);
            this.tpDb.Name = "tpDb";
            this.tpDb.Size = new System.Drawing.Size(521, 445);
            this.tpDb.TabIndex = 3;
            this.tpDb.Text = "DB연결정보";
            this.tpDb.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.chkAll);
            this.groupBox3.Controls.Add(this.chkSD51);
            this.groupBox3.Controls.Add(this.chkSD49);
            this.groupBox3.Controls.Add(this.chkSD48);
            this.groupBox3.Controls.Add(this.chkSD47);
            this.groupBox3.Controls.Add(this.chkSD46);
            this.groupBox3.Controls.Add(this.chkSD45);
            this.groupBox3.Controls.Add(this.chkSD44);
            this.groupBox3.Controls.Add(this.chkSD43);
            this.groupBox3.Controls.Add(this.chkSD42);
            this.groupBox3.Controls.Add(this.chkSD41);
            this.groupBox3.Controls.Add(this.chkSD31);
            this.groupBox3.Controls.Add(this.chkSD30);
            this.groupBox3.Controls.Add(this.chkSD29);
            this.groupBox3.Controls.Add(this.chkSD28);
            this.groupBox3.Controls.Add(this.chkSD27);
            this.groupBox3.Controls.Add(this.chkSD26);
            this.groupBox3.Controls.Add(this.chkSD11);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.txtConnectionString);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Location = new System.Drawing.Point(8, 172);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(505, 237);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "개표 DB";
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Location = new System.Drawing.Point(75, 124);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(72, 16);
            this.chkAll.TabIndex = 42;
            this.chkAll.Text = "전체선택";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // chkSD51
            // 
            this.chkSD51.AutoSize = true;
            this.chkSD51.Location = new System.Drawing.Point(128, 189);
            this.chkSD51.Name = "chkSD51";
            this.chkSD51.Size = new System.Drawing.Size(48, 16);
            this.chkSD51.TabIndex = 41;
            this.chkSD51.Tag = "51";
            this.chkSD51.Text = "세종";
            this.chkSD51.UseVisualStyleBackColor = true;
            this.chkSD51.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD49
            // 
            this.chkSD49.AutoSize = true;
            this.chkSD49.Location = new System.Drawing.Point(75, 189);
            this.chkSD49.Name = "chkSD49";
            this.chkSD49.Size = new System.Drawing.Size(48, 16);
            this.chkSD49.TabIndex = 40;
            this.chkSD49.Tag = "49";
            this.chkSD49.Text = "제주";
            this.chkSD49.UseVisualStyleBackColor = true;
            this.chkSD49.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD48
            // 
            this.chkSD48.AutoSize = true;
            this.chkSD48.Location = new System.Drawing.Point(22, 189);
            this.chkSD48.Name = "chkSD48";
            this.chkSD48.Size = new System.Drawing.Size(48, 16);
            this.chkSD48.TabIndex = 39;
            this.chkSD48.Tag = "48";
            this.chkSD48.Text = "경남";
            this.chkSD48.UseVisualStyleBackColor = true;
            this.chkSD48.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD47
            // 
            this.chkSD47.AutoSize = true;
            this.chkSD47.Location = new System.Drawing.Point(340, 167);
            this.chkSD47.Name = "chkSD47";
            this.chkSD47.Size = new System.Drawing.Size(48, 16);
            this.chkSD47.TabIndex = 38;
            this.chkSD47.Tag = "47";
            this.chkSD47.Text = "경북";
            this.chkSD47.UseVisualStyleBackColor = true;
            this.chkSD47.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD46
            // 
            this.chkSD46.AutoSize = true;
            this.chkSD46.Location = new System.Drawing.Point(287, 167);
            this.chkSD46.Name = "chkSD46";
            this.chkSD46.Size = new System.Drawing.Size(48, 16);
            this.chkSD46.TabIndex = 37;
            this.chkSD46.Tag = "46";
            this.chkSD46.Text = "전남";
            this.chkSD46.UseVisualStyleBackColor = true;
            this.chkSD46.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD45
            // 
            this.chkSD45.AutoSize = true;
            this.chkSD45.Location = new System.Drawing.Point(234, 167);
            this.chkSD45.Name = "chkSD45";
            this.chkSD45.Size = new System.Drawing.Size(48, 16);
            this.chkSD45.TabIndex = 36;
            this.chkSD45.Tag = "45";
            this.chkSD45.Text = "전북";
            this.chkSD45.UseVisualStyleBackColor = true;
            this.chkSD45.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD44
            // 
            this.chkSD44.AutoSize = true;
            this.chkSD44.Location = new System.Drawing.Point(181, 167);
            this.chkSD44.Name = "chkSD44";
            this.chkSD44.Size = new System.Drawing.Size(48, 16);
            this.chkSD44.TabIndex = 35;
            this.chkSD44.Tag = "44";
            this.chkSD44.Text = "충남";
            this.chkSD44.UseVisualStyleBackColor = true;
            this.chkSD44.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD43
            // 
            this.chkSD43.AutoSize = true;
            this.chkSD43.Location = new System.Drawing.Point(128, 167);
            this.chkSD43.Name = "chkSD43";
            this.chkSD43.Size = new System.Drawing.Size(48, 16);
            this.chkSD43.TabIndex = 34;
            this.chkSD43.Tag = "43";
            this.chkSD43.Text = "충북";
            this.chkSD43.UseVisualStyleBackColor = true;
            this.chkSD43.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD42
            // 
            this.chkSD42.AutoSize = true;
            this.chkSD42.Location = new System.Drawing.Point(75, 167);
            this.chkSD42.Name = "chkSD42";
            this.chkSD42.Size = new System.Drawing.Size(48, 16);
            this.chkSD42.TabIndex = 33;
            this.chkSD42.Tag = "42";
            this.chkSD42.Text = "강원";
            this.chkSD42.UseVisualStyleBackColor = true;
            this.chkSD42.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD41
            // 
            this.chkSD41.AutoSize = true;
            this.chkSD41.Location = new System.Drawing.Point(22, 167);
            this.chkSD41.Name = "chkSD41";
            this.chkSD41.Size = new System.Drawing.Size(48, 16);
            this.chkSD41.TabIndex = 32;
            this.chkSD41.Tag = "41";
            this.chkSD41.Text = "경기";
            this.chkSD41.UseVisualStyleBackColor = true;
            this.chkSD41.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD31
            // 
            this.chkSD31.AutoSize = true;
            this.chkSD31.Location = new System.Drawing.Point(340, 145);
            this.chkSD31.Name = "chkSD31";
            this.chkSD31.Size = new System.Drawing.Size(48, 16);
            this.chkSD31.TabIndex = 31;
            this.chkSD31.Tag = "31";
            this.chkSD31.Text = "울산";
            this.chkSD31.UseVisualStyleBackColor = true;
            this.chkSD31.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD30
            // 
            this.chkSD30.AutoSize = true;
            this.chkSD30.Location = new System.Drawing.Point(287, 145);
            this.chkSD30.Name = "chkSD30";
            this.chkSD30.Size = new System.Drawing.Size(48, 16);
            this.chkSD30.TabIndex = 30;
            this.chkSD30.Tag = "30";
            this.chkSD30.Text = "대전";
            this.chkSD30.UseVisualStyleBackColor = true;
            this.chkSD30.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD29
            // 
            this.chkSD29.AutoSize = true;
            this.chkSD29.Location = new System.Drawing.Point(234, 145);
            this.chkSD29.Name = "chkSD29";
            this.chkSD29.Size = new System.Drawing.Size(48, 16);
            this.chkSD29.TabIndex = 29;
            this.chkSD29.Tag = "29";
            this.chkSD29.Text = "광주";
            this.chkSD29.UseVisualStyleBackColor = true;
            this.chkSD29.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD28
            // 
            this.chkSD28.AutoSize = true;
            this.chkSD28.Location = new System.Drawing.Point(181, 145);
            this.chkSD28.Name = "chkSD28";
            this.chkSD28.Size = new System.Drawing.Size(48, 16);
            this.chkSD28.TabIndex = 28;
            this.chkSD28.Tag = "28";
            this.chkSD28.Text = "인천";
            this.chkSD28.UseVisualStyleBackColor = true;
            this.chkSD28.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD27
            // 
            this.chkSD27.AutoSize = true;
            this.chkSD27.Location = new System.Drawing.Point(128, 145);
            this.chkSD27.Name = "chkSD27";
            this.chkSD27.Size = new System.Drawing.Size(48, 16);
            this.chkSD27.TabIndex = 27;
            this.chkSD27.Tag = "27";
            this.chkSD27.Text = "대구";
            this.chkSD27.UseVisualStyleBackColor = true;
            this.chkSD27.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD26
            // 
            this.chkSD26.AutoSize = true;
            this.chkSD26.Location = new System.Drawing.Point(75, 145);
            this.chkSD26.Name = "chkSD26";
            this.chkSD26.Size = new System.Drawing.Size(48, 16);
            this.chkSD26.TabIndex = 26;
            this.chkSD26.Tag = "26";
            this.chkSD26.Text = "부산";
            this.chkSD26.UseVisualStyleBackColor = true;
            this.chkSD26.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // chkSD11
            // 
            this.chkSD11.AutoSize = true;
            this.chkSD11.Location = new System.Drawing.Point(22, 145);
            this.chkSD11.Name = "chkSD11";
            this.chkSD11.Size = new System.Drawing.Size(48, 16);
            this.chkSD11.TabIndex = 25;
            this.chkSD11.Tag = "11";
            this.chkSD11.Text = "서울";
            this.chkSD11.UseVisualStyleBackColor = true;
            this.chkSD11.CheckedChanged += new System.EventHandler(this.chkSido_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(20, 125);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 24;
            this.label19.Text = "시도선택";
            // 
            // txtConnectionString
            // 
            this.txtConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtConnectionString.Location = new System.Drawing.Point(19, 64);
            this.txtConnectionString.Name = "txtConnectionString";
            this.txtConnectionString.Size = new System.Drawing.Size(480, 21);
            this.txtConnectionString.TabIndex = 23;
            this.txtConnectionString.TextChanged += new System.EventHandler(this.txtConnectionString_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(17, 34);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 22;
            this.label14.Text = "연결문자열";
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.txtDB2ConnectionString);
            this.groupBox8.Location = new System.Drawing.Point(8, 28);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(505, 114);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "DB2 Data Source";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(17, 35);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 6;
            this.label16.Text = "연결문자열";
            // 
            // txtDB2ConnectionString
            // 
            this.txtDB2ConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDB2ConnectionString.Location = new System.Drawing.Point(19, 66);
            this.txtDB2ConnectionString.Name = "txtDB2ConnectionString";
            this.txtDB2ConnectionString.Size = new System.Drawing.Size(480, 21);
            this.txtDB2ConnectionString.TabIndex = 3;
            this.txtDB2ConnectionString.TextChanged += new System.EventHandler(this.txtDB2ConnectionString_TextChanged);
            // 
            // tpLog
            // 
            this.tpLog.Controls.Add(this.lstLog);
            this.tpLog.Controls.Add(this.btnLogClear);
            this.tpLog.Controls.Add(this.txtMaxLine);
            this.tpLog.Controls.Add(this.label15);
            this.tpLog.Location = new System.Drawing.Point(4, 22);
            this.tpLog.Name = "tpLog";
            this.tpLog.Size = new System.Drawing.Size(521, 445);
            this.tpLog.TabIndex = 2;
            this.tpLog.Text = "로그";
            this.tpLog.UseVisualStyleBackColor = true;
            // 
            // lstLog
            // 
            this.lstLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstLog.BackColor = System.Drawing.Color.Black;
            this.lstLog.ForeColor = System.Drawing.Color.White;
            this.lstLog.FormattingEnabled = true;
            this.lstLog.HorizontalScrollbar = true;
            this.lstLog.ItemHeight = 12;
            this.lstLog.Location = new System.Drawing.Point(8, 34);
            this.lstLog.Name = "lstLog";
            this.lstLog.Size = new System.Drawing.Size(505, 400);
            this.lstLog.TabIndex = 6;
            // 
            // btnLogClear
            // 
            this.btnLogClear.Location = new System.Drawing.Point(407, 7);
            this.btnLogClear.Name = "btnLogClear";
            this.btnLogClear.Size = new System.Drawing.Size(98, 23);
            this.btnLogClear.TabIndex = 5;
            this.btnLogClear.Text = "로그 지우기";
            this.btnLogClear.UseVisualStyleBackColor = true;
            this.btnLogClear.Click += new System.EventHandler(this.btnLogClear_Click);
            // 
            // txtMaxLine
            // 
            this.txtMaxLine.Location = new System.Drawing.Point(145, 10);
            this.txtMaxLine.Name = "txtMaxLine";
            this.txtMaxLine.Size = new System.Drawing.Size(100, 21);
            this.txtMaxLine.TabIndex = 4;
            this.txtMaxLine.TextChanged += new System.EventHandler(this.txtMaxLine_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(60, 14);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 3;
            this.label15.Text = "총 라인수 :";
            // 
            // timerAuto
            // 
            this.timerAuto.Tick += new System.EventHandler(this.timerAuto_Tick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 471);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tpExec.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tpPreview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVOTE2018)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tpDb.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tpLog.ResumeLayout(false);
            this.tpLog.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpExec;
        private System.Windows.Forms.TabPage tpPreview;
        private System.Windows.Forms.DataGridView dgvVOTE2018;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.TabPage tpLog;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbLog;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.RadioButton rdoManual;
        private System.Windows.Forms.RadioButton rdoAuto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkDBUP;
        private System.Windows.Forms.Button btnINI;
        private System.Windows.Forms.Button btnExecFolder;
        private System.Windows.Forms.Button btnExec;
        private System.Windows.Forms.TabPage tpDb;
        private System.Windows.Forms.CheckBox chkDB2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Timer timerAuto;
        private System.Windows.Forms.Button btnLogClear;
        private System.Windows.Forms.TextBox txtMaxLine;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListBox lstLog;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox chkAll;
        private System.Windows.Forms.CheckBox chkSD51;
        private System.Windows.Forms.CheckBox chkSD49;
        private System.Windows.Forms.CheckBox chkSD48;
        private System.Windows.Forms.CheckBox chkSD47;
        private System.Windows.Forms.CheckBox chkSD46;
        private System.Windows.Forms.CheckBox chkSD45;
        private System.Windows.Forms.CheckBox chkSD44;
        private System.Windows.Forms.CheckBox chkSD43;
        private System.Windows.Forms.CheckBox chkSD42;
        private System.Windows.Forms.CheckBox chkSD41;
        private System.Windows.Forms.CheckBox chkSD31;
        private System.Windows.Forms.CheckBox chkSD30;
        private System.Windows.Forms.CheckBox chkSD29;
        private System.Windows.Forms.CheckBox chkSD28;
        private System.Windows.Forms.CheckBox chkSD27;
        private System.Windows.Forms.CheckBox chkSD26;
        private System.Windows.Forms.CheckBox chkSD11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtConnectionString;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtDB2ConnectionString;


    }
}

