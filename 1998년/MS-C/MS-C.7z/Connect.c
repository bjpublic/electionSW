#include "Main.h"

LRESULT CALLBACK OracleConnectDlg( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	ORACLE_ENV	EnvTemp ;

	switch (message) 
	{
		case WM_INITDIALOG :
			SetDlgItemText( hDlg, IDC_USER, OracleEnv.DBLogid);
			SetDlgItemText( hDlg, IDC_PASSWORD, OracleEnv.DBPass);
			SetDlgItemText( hDlg, IDC_CONNECT, OracleEnv.DBServer);
			return (TRUE);

		case WM_COMMAND :
			if ( LOWORD(wParam) == IDOK)
			{
				GetDlgItemText( hDlg, IDC_USER, EnvTemp.DBLogid, sizeof(EnvTemp.DBLogid)); 
				GetDlgItemText( hDlg, IDC_PASSWORD, EnvTemp.DBPass, sizeof(EnvTemp.DBPass));
				GetDlgItemText( hDlg, IDC_CONNECT, EnvTemp.DBServer, sizeof(EnvTemp.DBServer));
				if (OracleLogon(hDlg, EnvTemp.DBLogid, EnvTemp.DBPass,
									  EnvTemp.DBServer) == FALSE)
				{
					MessageBox(hDlg, "DB Connection Error", "Error", MB_OK);
					return (TRUE);
				}
				lstrcpy(OracleEnv.DBLogid, EnvTemp.DBLogid);
				lstrcpy(OracleEnv.DBPass, EnvTemp.DBPass);
				lstrcpy(OracleEnv.DBServer, EnvTemp.DBServer);
				OracleEnvFileWrite( hDlg ) ;
				EndDialog(hDlg, TRUE);
				return (TRUE);
			}
			if ( LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, FALSE);
				return (TRUE);
			}
			break;
	}

	return (FALSE);
}
