#include "Main.h" 
#include "Rtx32.h" 

#define			TOTAL_HEIGHT		 85				// ??????????? ???????????
#define			GERERANG_HEIGHT		 85				// ???????????? ???????????

static	void	InitProc			( void ) ;
static	void	StockOnAirProc		( HWND ) ;
static	void	StockDollarDisp		( HWND ) ;
static	void	StockTotalDisp		( void ) ;
static	void	StockTimeDisp		( void ) ;
static	void	StockCostDisp		( int, int, BOOL ) ;

static	BYTE	szRxtCommBuf[20][150] ;
static	double	dTimeTotal[STOCK_DIFMAX] ;
static	double	dTimeGererang[STOCK_DIFMAX] ;
static	double	dOneDotValue[2], dYValue[2][3] ;				// ????? Y?? ??
static	int		nYpos[STOCK_DIFMAX] ;

LRESULT CALLBACK StockOnAir(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	double		dValue ;
	BYTE		szGetText[15] ;

	switch (message) 
	{
		case WM_INITDIALOG :
			SetWindowText(GetDlgItem(hDlg, IDC_DATE), DBSysDate ) ;
			SetWindowText(GetDlgItem(hDlg, IDC_USA), LeftSpaceTrim(&szDollarBuf[0][0])) ;
			SetWindowText(GetDlgItem(hDlg, IDC_USA_UPDN), LeftSpaceTrim(&szDollarBuf[1][0])) ;
			SetWindowText(GetDlgItem(hDlg, IDC_JAPAN), LeftSpaceTrim(&szDollarBuf[2][0])) ;
			SetWindowText(GetDlgItem(hDlg, IDC_JAPAN_UPDN), LeftSpaceTrim(&szDollarBuf[3][0])) ;

			InitProc() ;
			fnEditProc = (WNDPROC)SetWindowLong( GetDlgItem(hDlg, IDC_USA), GWL_WNDPROC, (LPARAM) EditProc ) ;
			fnEditProc = (WNDPROC)SetWindowLong( GetDlgItem(hDlg, IDC_JAPAN), GWL_WNDPROC, (LPARAM) EditProc ) ;
			fnEditProc = (WNDPROC)SetWindowLong( GetDlgItem(hDlg, IDC_USA_UPDN), GWL_WNDPROC, (LPARAM) EditProc ) ;
			fnEditProc = (WNDPROC)SetWindowLong( GetDlgItem(hDlg, IDC_JAPAN_UPDN), GWL_WNDPROC, (LPARAM) EditProc ) ;
			return (TRUE);

		case WM_COMMAND :
			if ( LOWORD(wParam) == IDC_USA || LOWORD(wParam) == IDC_JAPAN ||
				 LOWORD(wParam) == IDC_USA_UPDN || LOWORD(wParam) == IDC_JAPAN_UPDN )
			{
				switch( HIWORD(wParam) )
				{
					case EN_KILLFOCUS :
						GetWindowText(GetDlgItem(hDlg, LOWORD(wParam)), &szGetText[0], 14) ;
						dValue = atof( &szGetText[0] ) ;
						sprintf(&szGetText[0], "%9.2f", dValue ) ;
						SetWindowText( GetDlgItem(hDlg, LOWORD(wParam)), LeftSpaceTrim(&szGetText[0]) ) ;
						break ;
				}
				return (TRUE);
			}

			if ( LOWORD(wParam) == ID_ONAIR)
			{
				StockOnAirProc( hDlg ) ;
				EndDialog(hDlg, FALSE);
				return (TRUE);
			}

			if ( LOWORD(wParam) == ID_CLOSE)
			{
				EndDialog(hDlg, FALSE);
				return (TRUE);
			}
			return (TRUE);
	}
	return (FALSE);
}


static void InitProc (void)
{
	int		i ;

//	BYTE		Data[4][11] ;		/* TOTAL_MIN,TOTAL_MAX,TOTAL,COUNT	*/

	for( i = 0; i < nDifTotalCount; i++)
	{
		dTimeTotal[i] = atof(&StockDif[i].Data[2][0]) ;
		dTimeGererang[i] = atof(&StockDif[i].Data[3][0]) ;
	}
	dYValue[0][0] = atof( &StockDif[0].Data[1][0] ) ;
	dYValue[0][2] = atof( &StockDif[0].Data[0][0] ) ;
	dYValue[0][1] = (double)((dYValue[0][0] + dYValue[0][2]) / 2) ;
	dOneDotValue[0] = (double)(TOTAL_HEIGHT / (dYValue[0][0] - dYValue[0][2])) ;

	GetMaxDoubleValue( &dTimeGererang[0], nDifTotalCount, &dYValue[1][0] ) ;
	GetMinDoubleValue( &dTimeGererang[0], nDifTotalCount, &dYValue[1][2] ) ;
	dYValue[1][1] = (double)((dYValue[1][0] + dYValue[1][2]) / 2) ;
	dOneDotValue[1] = (double)(GERERANG_HEIGHT / (dYValue[1][0] - dYValue[1][2])) ;

	for( i = 0; i < nDifTotalCount; i++)
	{
		nYpos[i] = 35 + (int)((dTimeTotal[i] - dYValue[0][2]) * dOneDotValue[0]) ;
	}

	RTX(RTX_STRING, "reset clear clearscreen") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "/P_RIGHT { /A 3 array def A astore 0 get A 2 get stringwidth pop sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_LEFT { pop moveto } def") ;
	RTX(RTX_STRING, "/F_VALUE1 { 1.0 1.0 0.0 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY?????) cvn findfont 60 scalefont 2 shadowfont 90 fontwidth 4 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_VALUE2 { 0.99610 0.99610 0.99610 160 setrgbpalette 0.00000 0.00000 0.00000 163 setrgbpalette 0.00000 0.00000 0.00000 166 setrgbpalette 160 selectpalette (HY??????????B) cvn findfont 32 scalefont 0 shadowfont 100 fontwidth 3 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_DOLLAR1 { 0.99610 0.91797 0.02735 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 120 scalefont 1 shadowfont 38 fontwidth 5 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_DOLLAR2 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 48 scalefont 0 shadowfont 47 fontwidth 4 edgefont setfont } def") ;

	RTX(RTX_STRING, "(snap) effect board1 seteffectframebuffer (c:/ubc/stock/Stockimage/dollar.tga) layer seteffectlayer showeffect") ;
}

static void StockOnAirProc( HWND hDlg )
{
	int		i ;

	StockDollarDisp( hDlg ) ;
	RTX(RTX_STRING, "3000 wait") ;

	StockTotalDisp( ) ;
	RTX(RTX_STRING, "3000 wait") ;

	StockTimeDisp( ) ;
	RTX(RTX_STRING, "3000 wait") ;

	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "/P_RIGHT { /A 3 array def A astore 0 get A 2 get stringwidth pop sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_LEFT { pop moveto } def") ;
	RTX(RTX_STRING, "/F_FONT1 { 0.99610 0.99610 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 30 scalefont 0 shadowfont 80 fontwidth 2 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_FONT2 { 0.99610 0.99610 0.99610 120 setrgbpalette 0.00000 0.00000 0.00000 123 setrgbpalette 0.00000 0.00000 0.00000 126 setrgbpalette 120 selectpalette (HY??????????M) cvn findfont 28 scalefont 0 shadowfont 90 fontwidth 2 edgefont setfont } def") ;

// ?????? 6??????? ????
	RTX(RTX_STRING, "/F_FONT11 { 0.99610 0.99610 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 28 scalefont 0 shadowfont 80 fontwidth 2 edgefont setfont } def") ;
// ????? (9,999,999), ???? (999,999)  ????? ???? 
	RTX(RTX_STRING, "/F_FONT22 { 0.99610 0.99610 0.99610 120 setrgbpalette 0.00000 0.00000 0.00000 123 setrgbpalette 0.00000 0.00000 0.00000 126 setrgbpalette 120 selectpalette (HY??????????M) cvn findfont 28 scalefont 0 shadowfont 80 fontwidth 2 edgefont setfont } def") ;

	i = 0 ;
	while(i < nCostTotalCount)
	{
		if( (i + 7) > nCostTotalCount ) StockCostDisp( i, nCostTotalCount, TRUE) ;
		else							StockCostDisp( i, i + 7, FALSE ) ;
		i += 7 ;
	}
}

static void StockDollarDisp( HWND hDlg )
{
	double		dValue ;

	GetWindowText(GetDlgItem(hDlg, IDC_USA), &szDollarBuf[0][0], 10) ;
	GetWindowText(GetDlgItem(hDlg, IDC_USA_UPDN), &szDollarBuf[1][0], 10) ;
	GetWindowText(GetDlgItem(hDlg, IDC_JAPAN), &szDollarBuf[2][0], 10) ;
	GetWindowText(GetDlgItem(hDlg, IDC_JAPAN_UPDN), &szDollarBuf[3][0], 10) ;

	RTX(RTX_STRING, "(snap) effect board1 seteffectframebuffer (c:/ubc/stock/Stockimage/dollar.tga) layer seteffectlayer showeffect") ;

//	RTX(RTX_STRING, "/W_FRAMEBUFFER0 board0 340 280 320 70 windowframebuffer def") ;
//	RTX(RTX_STRING, "/W_LAYER0 FULL_LAYER 340 280 320 70 windowlayer def") ;
//	RTX(RTX_STRING, "W_LAYER0 setlayer") ;
//	RTX(RTX_STRING, "W_LAYER0 clearlayer") ;
//	sprintf( &szRxtCommBuf[0][0], "F_VALUE1 120 17 (%s) P_CENTER (%s) show", &szDollarBuf[0][0], &szDollarBuf[0][0] ) ;
//	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
//	RTX(RTX_STRING, "/EF_DISP0 (push) effect (left) seteffectdir W_FRAMEBUFFER0 seteffectframebuffer W_LAYER0 seteffectlayer 250 seteffectduration seteffectasync def") ;

//	RTX(RTX_STRING, "/W_FRAMEBUFFER2 board0 340 130 320 70 windowframebuffer def") ;
//	RTX(RTX_STRING, "/W_LAYER2 FULL_LAYER 340 130 320 70 windowlayer def") ;
//	RTX(RTX_STRING, "W_LAYER2 setlayer") ;
//	RTX(RTX_STRING, "W_LAYER2 clearlayer") ;
//	sprintf( &szRxtCommBuf[0][0], "F_VALUE1 120 17 (%s) P_CENTER (%s) show", &szDollarBuf[2][0], &szDollarBuf[2][0] ) ;
//	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
//	RTX(RTX_STRING, "/EF_DISP2 (push) effect (left) seteffectdir W_FRAMEBUFFER2 seteffectframebuffer W_LAYER2 seteffectlayer 250 seteffectduration def") ;

	RTX(RTX_STRING, "/W_FRAMEBUFFER0 board0 310 260 220 130 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER0 FULL_LAYER 310 260 220 130 windowlayer def") ;
	RTX(RTX_STRING, "W_LAYER0 setlayer") ;
	RTX(RTX_STRING, "W_LAYER0 clearlayer") ;
	sprintf( &szRxtCommBuf[0][0], "F_DOLLAR1 210 20 (%s) P_RIGHT (%s) show", &szDollarBuf[0][0], &szDollarBuf[0][0] ) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, "/EF_DISP0 (push) effect (right) seteffectdir W_FRAMEBUFFER0 seteffectframebuffer W_LAYER0 seteffectlayer 250 seteffectduration seteffectasync def") ;

	dValue = atof(&szDollarBuf[1][0]) ;
	RTX(RTX_STRING, "/W_FRAMEBUFFER1 board0  531 287 140 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER1 FULL_LAYER  531 287 140 55 windowlayer def") ;
	RTX(RTX_STRING, "W_LAYER1 setlayer") ;
	RTX(RTX_STRING, "W_LAYER1 clearlayer") ;
	if( dValue > 0.0 )
		RTX(RTX_STRING, "98 10 moveto (C:/Ubc/Stock/StockImage/d_up.tga) layer show") ;
	else
	{
		if(dValue != 0.0)
		{
			RTX(RTX_STRING, "98 10 moveto (C:/Ubc/Stock/StockImage/d_down.tga) layer show") ;
		}
	}
	sprintf( &szRxtCommBuf[0][0], "F_DOLLAR2 88 10 (%s) P_RIGHT (%s) show", &szDollarBuf[1][0], &szDollarBuf[1][0] ) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;

	RTX(RTX_STRING, "/EF_DISP1 (push) effect (left) seteffectdir W_FRAMEBUFFER1 seteffectframebuffer W_LAYER1 seteffectlayer 250 seteffectduration def") ;


/*
	dValue = atof(&szDollarBuf[1][0]) ;
	RTX(RTX_STRING, "/W_FRAMEBUFFER11 board0 631 292 35 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER11 FULL_LAYER 631 292 35 55 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER11 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER11 clearlayer") ;
	if( dValue > 0.0 )
		RTX(RTX_STRING, "0 0 moveto (C:/Ubc/Stock/StockImage/d_up.tga) layer W_LAYER11 resize show") ;
	else
		RTX(RTX_STRING, "0 0 moveto (C:/Ubc/Stock/StockImage/d_down.tga) layer W_LAYER11 resize show") ;
	RTX(RTX_STRING, "/EF_DISP11 (snap) effect (up) seteffectdir W_FRAMEBUFFER11 seteffectframebuffer W_LAYER11 seteffectlayer 200 seteffectduration seteffectasync def") ;
*/

	dValue = atof(&szDollarBuf[3][0]) ;
	RTX(RTX_STRING, "/W_FRAMEBUFFER2 board0 310 118 220 130 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER2 FULL_LAYER 310 118 220 130 windowlayer def") ;
	RTX(RTX_STRING, "W_LAYER2 setlayer") ;
	RTX(RTX_STRING, "W_LAYER2 clearlayer") ;
	sprintf( &szRxtCommBuf[0][0], "F_DOLLAR1 210 20 (%s) P_RIGHT (%s) show", &szDollarBuf[2][0], &szDollarBuf[2][0] ) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, "/EF_DISP2 (push) effect (right) seteffectdir W_FRAMEBUFFER2 seteffectframebuffer W_LAYER2 seteffectlayer 250 seteffectduration seteffectasync def") ;

	RTX(RTX_STRING, "/W_FRAMEBUFFER3 board0 531 147 140 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER3 FULL_LAYER 531 147 140 55 windowlayer def") ;
	RTX(RTX_STRING, "W_LAYER3 setlayer") ;
	RTX(RTX_STRING, "W_LAYER3 clearlayer") ;
	if( dValue > 0.0 )
		RTX(RTX_STRING, "98 10 moveto (C:/Ubc/Stock/StockImage/d_up.tga) layer show") ;
	else
	{
		if(dValue != 0.0)
		{
			RTX(RTX_STRING, "98 10 moveto (C:/Ubc/Stock/StockImage/d_down.tga) layer show") ;
		}
	}
	sprintf( &szRxtCommBuf[0][0], "F_DOLLAR2 88 10 (%s) P_RIGHT (%s) show", &szDollarBuf[3][0], &szDollarBuf[3][0] ) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
 	RTX(RTX_STRING, "/EF_DISP3 (push) effect (left) seteffectdir W_FRAMEBUFFER3 seteffectframebuffer W_LAYER3 seteffectlayer 250 seteffectduration def") ;

	RTX(RTX_STRING, "EF_DISP0 showeffect") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;
	RTX(RTX_STRING, "EF_DISP2 showeffect") ;
	RTX(RTX_STRING, "EF_DISP3 showeffect") ;

/*
	dValue = atof(&szDollarBuf[3][0]) ;
	RTX(RTX_STRING, "/W_FRAMEBUFFER33 board0  631 147 35 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER33 FULL_LAYER  631 147 35 55 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER33 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER33 clearlayer") ;
	if( dValue > 0.0 )
		RTX(RTX_STRING, "0 0 moveto (C:/Ubc/Stock/StockImage/d_up.tga) layer W_LAYER33 resize show") ;
	else
	{
		if(dValue != 0.0)
		{
			RTX(RTX_STRING, "0 0 moveto (C:/Ubc/Stock/StockImage/d_down.tga) layer W_LAYER33 resize show") ;
		}
	}
	RTX(RTX_STRING, "/EF_DISP33 (snap) effect (up) seteffectdir W_FRAMEBUFFER33 seteffectframebuffer W_LAYER33 seteffectlayer seteffectasync def") ;
	RTX(RTX_STRING, "EF_DISP0 showeffect") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;

	RTX(RTX_STRING, "EF_DISP2 showeffect") ;
	RTX(RTX_STRING, "EF_DISP3 showeffect") ;

	dValue = atof(&szDollarBuf[1][0]) ;
	if(dValue != 0.00) RTX(RTX_STRING, "EF_DISP11 showeffect") ;
	dValue = atof(&szDollarBuf[3][0]) ;
	if(dValue != 0.0) RTX(RTX_STRING, "EF_DISP33 showeffect") ;
*/
}

static void StockTotalDisp( void )
{

	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "/P_RIGHT { /A 3 array def A astore 0 get A 2 get stringwidth pop sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_LEFT { pop moveto } def") ;
	RTX(RTX_STRING, "/F_FONT1 { 0.99610 0.99610 0.50000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 50 scalefont 0 shadowfont 90 fontwidth 3 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_FONT2 { 0.99610 0.99610 0.50000 120 setrgbpalette 0.00000 0.00000 0.00000 123 setrgbpalette 0.00000 0.00000 0.00000 126 setrgbpalette 120 selectpalette (HY????????M) cvn findfont 50 scalefont 0 shadowfont 90 fontwidth 3 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_FONT3 { 0.99610 0.99610 0.99610 130 setrgbpalette 0.00000 0.00000 0.00000 133 setrgbpalette 0.00000 0.00000 0.00000 136 setrgbpalette 130 selectpalette (HY????????M) cvn findfont 30 scalefont 0 shadowfont 90 fontwidth 3 edgefont setfont } def") ;

	sprintf( &szRxtCommBuf[0][0], "F_FONT1 98 20 (%s) P_CENTER (%s) show",
					&StockTotal.Data[0][0], &StockTotal.Data[0][0] ) ;
	sprintf( &szRxtCommBuf[1][0], "F_FONT2 230 13 (%s) P_RIGHT (%s) show",
					&StockTotal.Data[1][0], &StockTotal.Data[1][0] ) ;
	sprintf( &szRxtCommBuf[2][0], "F_FONT2 230 13 (%s) P_RIGHT (%s) show",
					&StockTotal.Data[2][0], &StockTotal.Data[2][0] ) ;

	if(atof(&StockTotal.Data[3][0]) > 0.0)
	{
		strcpy(&szRxtCommBuf[3][0], "0 0 moveto (C:/Ubc/Stock/StockImage/up_arrow.tga) layer show") ;
		strcpy(&szRxtCommBuf[4][0], "/EF_DISP3 (push) effect (up) seteffectdir W_FRAMEBUF3 seteffectframebuffer W_LAYER3 seteffectlayer 400 seteffectduration def") ;
	}
	else
	{
		strcpy(&szRxtCommBuf[3][0], "0 0 moveto (C:/Ubc/Stock/StockImage/down_arrow.tga) layer show") ;
		strcpy(&szRxtCommBuf[4][0], "/EF_DISP3 (push) effect (down) seteffectdir W_FRAMEBUF3 seteffectframebuffer W_LAYER3 seteffectlayer 400 seteffectduration def") ;
	}
	sprintf( &szRxtCommBuf[5][0], "F_FONT3 50 10 (%s) P_CENTER (%s) show",
					&StockTotal.Data[3][0], &StockTotal.Data[3][0] ) ;

	RTX(RTX_STRING, "/W_FRAMEBUF0 board0 342 275 195 75 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER0 FULL_LAYER 342 275 195 75 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER0 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER0 clearlayer") ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, "/EF_DISP0 (push) effect (left) seteffectdir W_FRAMEBUF0 seteffectframebuffer W_LAYER0 seteffectlayer 300 seteffectduration seteffectasync def") ;

	RTX(RTX_STRING, "/W_FRAMEBUF1 board0 263 157 327 62 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER1 FULL_LAYER 263 157 327 62 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER1 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER1 clearlayer") ;
	RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
	RTX(RTX_STRING, "F_FONT3 240 15 (???) P_LEFT (???) show") ;
	RTX(RTX_STRING, "/EF_DISP1 (push) effect (left) seteffectdir W_FRAMEBUF1 seteffectframebuffer W_LAYER1 seteffectlayer 300 seteffectduration seteffectasync def") ;

	RTX(RTX_STRING, "/W_FRAMEBUF2 board0 264 59 328 61 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER2 FULL_LAYER 264 59 328 61 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER2 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER2 clearlayer") ;
	RTX(RTX_STRING, &szRxtCommBuf[2][0]) ;
	RTX(RTX_STRING, "F_FONT3 240 15 (????) P_LEFT (????) show") ;
	RTX(RTX_STRING, "/EF_DISP2 (push) effect (left) seteffectdir W_FRAMEBUF2 seteffectframebuffer W_LAYER2 seteffectlayer 300 seteffectduration def") ;

	RTX(RTX_STRING, "/W_FRAMEBUF3 board0 538 266 109 124 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER3 FULL_LAYER 538 266 109 124 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER3 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER3 clearlayer") ;
	RTX(RTX_STRING, &szRxtCommBuf[3][0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[4][0]) ;

	RTX(RTX_STRING, "/W_FRAMEBUF4 board0 537 226 109 40 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER4 FULL_LAYER 537 226 109 40 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER4 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER4 clearlayer") ;
	RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
	RTX(RTX_STRING, "/EF_DISP4 (push) effect (up) seteffectdir W_FRAMEBUF4 seteffectframebuffer W_LAYER4 seteffectlayer 100 seteffectduration def") ;

/*
	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/StockImage/stock1.tga) layer seteffectlayer") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;
	RTX(RTX_STRING, "200 wait") ;
*/

	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/StockImage/stock1.tga) layer setlayer def") ;
	RTX(RTX_STRING, "/STOCK (wipe) effect (right) seteffectdir 500 seteffectduration seteffectasync def") ;

	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/StockImage/stock1.tga) layer seteffectlayer") ;
	RTX(RTX_STRING, "STOCK showeffect") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;

	
	RTX(RTX_STRING, "EF_DISP0 showeffect") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;
	RTX(RTX_STRING, "EF_DISP2 showeffect") ;
	RTX(RTX_STRING, "EF_DISP3 showeffect") ;
	RTX(RTX_STRING, "EF_DISP4 showeffect") ;
}

static void StockTimeDisp( void )
{
	int		i, j, nHeight, x1, y1, x2, y2 ;
	int		xCharYpos[3] = { 110, 70, 30 } ;
//	int		xPos[11] = { 175, 216, 255, 296, 338, 381, 421, 462, 503, 546, 588 } ;
	int		xPos[11] = { 175, 216, 257, 298, 339, 380, 421, 462, 503, 544, 585} ;


	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "/P_RIGHT { /A 3 array def A astore 0 get A 2 get stringwidth pop sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_LEFT { pop moveto } def") ;
	RTX(RTX_STRING, "/F_DEFAULT { 0.99610 0.99610 0.99610 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (HY??????????B) cvn findfont 10 scalefont 1 shadowfont 100 fontwidth 1 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_FONT1 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 20 scalefont 1 shadowfont 90 fontwidth 1 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_FONT2 { 0.99610 0.99610 0.50000 120 setrgbpalette 0.00000 0.00000 0.00000 123 setrgbpalette 0.00000 0.00000 0.00000 126 setrgbpalette 120 selectpalette (HY????????M) cvn findfont 50 scalefont 0 shadowfont 90 fontwidth 3 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_FONT3 { 0.99610 0.99610 0.99610 130 setrgbpalette 0.00000 0.00000 0.00000 133 setrgbpalette 0.00000 0.00000 0.00000 136 setrgbpalette 130 selectpalette (HY????????M) cvn findfont 30 scalefont 0 shadowfont 90 fontwidth 3 edgefont setfont } def") ;

// ???????
	RTX(RTX_STRING, "/W_FRAMEBUF0 board0 63 225 91 145 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER0 FULL_LAYER 63 225 91 145 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER0 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER0 clearlayer") ;
	for( i = 0; i < 3; i++)
	{
		sprintf(&szRxtCommBuf[0][0], "F_FONT1 80 %d (%5.0f) P_RIGHT (%5.0f) show", xCharYpos[i], dYValue[0][i], dYValue[0][i]) ;
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	}
	RTX(RTX_STRING, "/EF_DISP0 (snap) effect (up) seteffectdir W_FRAMEBUF0 seteffectframebuffer W_LAYER0 seteffectlayer seteffectasync def") ;


	RTX(RTX_STRING, "/W_FRAMEBUF1 board0 63 62 91 145 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER1 FULL_LAYER 63 62 91 145 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER1 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER1 clearlayer") ;
	for( i = 0; i < 3; i++)
	{
		sprintf(&szRxtCommBuf[0][0], "F_FONT1 80 %d (%8.0f) P_RIGHT (%8.0f) show", xCharYpos[i], dYValue[1][i], dYValue[1][i]) ;
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	}
	RTX(RTX_STRING, "/EF_DISP1 (snap) effect (down) seteffectdir W_FRAMEBUF1 seteffectframebuffer W_LAYER1 seteffectlayer seteffectasync def") ;

	RTX(RTX_STRING, "/W_FRAMEBUF2 board0 157 31 483 35 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER2 FULL_LAYER 157 31 483 35 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER2 setlayer") ;
 	RTX(RTX_STRING, "W_LAYER2 clearlayer") ;
	RTX(RTX_STRING, "F_FONT1 2 10 (  10      11      ??       2       3       ??) P_LEFT (  10      11      ??       2       3       ??) show") ;
	RTX(RTX_STRING, "/EF_DISP2 (snap) effect (down) seteffectdir W_FRAMEBUF2 seteffectframebuffer W_LAYER2 seteffectlayer def") ;

// ??????????? ?????
	RTX(RTX_STRING, "70 selectpalette 1 setlinewidth") ;
	RTX(RTX_STRING, "/W_FRAMEBUF00 board0 157 230 482 134 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER00 FULL_LAYER 157 230 482 134 windowlayer def") ;
	RTX(RTX_STRING, "W_LAYER00 setlayer") ;
	RTX(RTX_STRING, "W_LAYER00 clearlayer") ;

	x1 = xPos[0] - 157 + 15;
	y1 = nYpos[0] + 1;
	sprintf(&szRxtCommBuf[0][0], "%d %d moveto", x1, y1) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, "polygonstart") ;
	for( i = 1; i < 11; i++)
	{
		x2 = xPos[i] - 157 + 15 ;
	 	y2 = nYpos[i] + 1;
		sprintf(&szRxtCommBuf[0][0], "%d %d lineto", x2, y2) ;
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	}
	for( i = 10; i > 0; i--)
	{
		x2 = xPos[i] - 157 + 15 ;
	 	y2 = nYpos[i] - 1;
		sprintf(&szRxtCommBuf[0][0], "%d %d lineto", x2, y2) ;
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	}
	RTX(RTX_STRING, "polygonend") ;
	RTX(RTX_STRING, "/EF_DISP00 (wipe) effect (right) seteffectdir W_FRAMEBUF00 seteffectframebuffer W_LAYER00 seteffectlayer def") ;
/*
	x1 = xPos[0] - 157 + 15;
	y1 = nYpos[0] + 1;
	for( i = 1; i < 11; i++)
	{
		x2 = xPos[i] - 157 + 15 ;
	 	y2 = nYpos[i] ;
		if(y1 == y2)
		{
//			sprintf(&szRxtCommBuf[0][0], "%d %d moveto %d %d rect", x1, y1, x2, y2) ;
//			sprintf(&szRxtCommBuf[1][0], "%d %d moveto %d %d rect", x1, y1+1, x2, y2+1) ;
			sprintf(&szRxtCommBuf[0][0], "%d %d moveto %d %d rect", x1, y1-4, x2 - x1, 4) ;
			RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		}
		else
		{
//			RTX(RTX_STRING, "1 setlinewidth") ;
			sprintf(&szRxtCommBuf[0][0], "%d %d moveto %d %d lineto", x1, y1, x2, y2) ;
			sprintf(&szRxtCommBuf[1][0], "%d %d moveto %d %d lineto", x1, y1+1, x2, y2+1) ;
			sprintf(&szRxtCommBuf[2][0], "%d %d moveto %d %d lineto", x1, y1-1, x2, y2-1) ;
			RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[2][0]) ;
		}
		x1 = x2 ;
		y1 = y2 ;
	}
	RTX(RTX_STRING, "/EF_DISP00 (wipe) effect (right) seteffectdir W_FRAMEBUF00 seteffectframebuffer W_LAYER00 seteffectlayer def") ;
*/

// ????? ?????
	for( i = 0; i < 11; i++)
	{
		nHeight = 35 + (int)((dTimeGererang[i] - dYValue[1][2]) * dOneDotValue[1]) ;
 		sprintf(&szRxtCommBuf[0][0], "/W_FRAMEBUF1%d board0 %d 65 31 %d windowframebuffer def", i, xPos[i], nHeight) ;
		sprintf(&szRxtCommBuf[1][0], "/W_LAYER1%d FULL_LAYER %d 65 31 %d windowlayer def", i, xPos[i], nHeight) ;
		sprintf(&szRxtCommBuf[2][0], "W_LAYER1%d setlayer", i) ;
		sprintf(&szRxtCommBuf[3][0], "W_LAYER1%d clearlayer", i) ;
		sprintf(&szRxtCommBuf[4][0], "0 0 moveto (C:/Ubc/Stock/StockImage/v_bar.tga) layer W_LAYER1%d resize show", i) ;
		sprintf(&szRxtCommBuf[5][0], "/EF_DISP1%d (push) effect (up) seteffectdir W_FRAMEBUF1%d seteffectframebuffer W_LAYER1%d seteffectlayer 200 seteffectduration seteffectasync def", i, i, i) ;
		for(j = 0; j < 6; j++)
		{
			RTX(RTX_STRING, &szRxtCommBuf[j][0]) ;
		}
	}
/*
	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/StockImage/stock2.tga) layer seteffectlayer") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;
	RTX(RTX_STRING, "200 wait") ;
*/

	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/StockImage/stock2.tga) layer setlayer def") ;
	RTX(RTX_STRING, "/STOCK (wipe) effect (right) seteffectdir 500 seteffectduration seteffectasync def") ;

	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/StockImage/stock2.tga) layer seteffectlayer") ;
	RTX(RTX_STRING, "STOCK showeffect") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;

	RTX(RTX_STRING, "EF_DISP0 showeffect") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;
	RTX(RTX_STRING, "EF_DISP2 showeffect") ;
	RTX(RTX_STRING, "EF_DISP00 showeffect") ;
	for( i = 0; i < 11; i++)
	{
		sprintf(&szRxtCommBuf[0][0], "EF_DISP1%d showeffect", i) ;
		RTX(RTX_STRING, &szRxtCommBuf[0][0]);
	}
}

static void StockCostDisp( int nStart, int nEnd, BOOL bEndFlag )
{
	int		i, j ;
	int		yPos[7] = { 322, 275, 228, 181, 134, 87, 40 } ;

	for(i = nStart; i < nEnd; i++)
	{
		j = i - nStart ;
		sprintf(&szRxtCommBuf[0][0], "/W_FRAMEBUF0%d board0 63 %d 148 45 windowframebuffer def", j, yPos[j]) ;
		sprintf(&szRxtCommBuf[1][0], "/W_LAYER0%d FULL_LAYER 63 %d 148 45 windowlayer def", j, yPos[j]) ;
		sprintf(&szRxtCommBuf[2][0], "W_LAYER0%d setlayer", j) ;
		sprintf(&szRxtCommBuf[3][0], "W_LAYER0%d clearlayer", j) ;

		if( strlen(&StockCost[i].Data[0][0]) >= 12 )
			sprintf(&szRxtCommBuf[4][0], "F_FONT11 73 11 (%s) P_CENTER (%s) show", &StockCost[i].Data[0][0], &StockCost[i].Data[0][0]) ;
		else
			sprintf(&szRxtCommBuf[4][0], "F_FONT1 73 11 (%s) P_CENTER (%s) show", &StockCost[i].Data[0][0], &StockCost[i].Data[0][0]) ;

		sprintf(&szRxtCommBuf[5][0], "/EF_DISP0%d (push) effect (right) seteffectdir W_FRAMEBUF0%d seteffectframebuffer W_LAYER0%d seteffectlayer 140 seteffectduration def", j, j, j) ;

		sprintf(&szRxtCommBuf[6][0], "/W_FRAMEBUF1%d board0 213 %d 448 45 windowframebuffer def", j, yPos[j]) ;
		sprintf(&szRxtCommBuf[7][0], "/W_LAYER1%d FULL_LAYER 213 %d 448 45 windowlayer def", j, yPos[j]) ;
	 	sprintf(&szRxtCommBuf[8][0], "W_LAYER1%d setlayer", j) ;
	 	sprintf(&szRxtCommBuf[9][0], "W_LAYER1%d clearlayer", j) ; 
		sprintf(&szRxtCommBuf[10][0], "F_FONT2 132 11 (%s) P_RIGHT (%s) show", FormatNumberStr(&StockCost[i].Data[1][0]), FormatNumberStr(&StockCost[i].Data[1][0])) ;
		if( atof(&StockCost[i].Data[2][0]) > 999,999 )
			sprintf(&szRxtCommBuf[11][0], "F_FONT22 286 11 (%s) P_RIGHT (%s) show", FormatNumberStr(&StockCost[i].Data[2][0]), FormatNumberStr(&StockCost[i].Data[2][0])) ;
		else
			sprintf(&szRxtCommBuf[11][0], "F_FONT2 286 11 (%s) P_RIGHT (%s) show", FormatNumberStr(&StockCost[i].Data[2][0]), FormatNumberStr(&StockCost[i].Data[2][0])) ;

		if( atof(&StockCost[i].Data[3][0]) > 9,999,999 )
			sprintf(&szRxtCommBuf[12][0], "F_FONT2 435 11 (%s) P_RIGHT (%s) show", FormatNumberStr(&StockCost[i].Data[3][0]), FormatNumberStr(&StockCost[i].Data[3][0])) ;
		else
			sprintf(&szRxtCommBuf[12][0], "F_FONT2 435 11 (%s) P_RIGHT (%s) show", FormatNumberStr(&StockCost[i].Data[3][0]), FormatNumberStr(&StockCost[i].Data[3][0])) ;
		sprintf(&szRxtCommBuf[13][0], "/EF_DISP1%d (push) effect (down) seteffectdir W_FRAMEBUF1%d seteffectframebuffer W_LAYER1%d seteffectlayer 70 seteffectduration def", j, j, j) ;

		sprintf(&szRxtCommBuf[14][0], "/W_FRAMEBUF2%d board0 363 %d 24 45 windowframebuffer def", j, yPos[j]) ;
		sprintf(&szRxtCommBuf[15][0], "/W_LAYER2%d FULL_LAYER 363 %d 24 45 windowlayer def", j, yPos[j]) ;
	 	sprintf(&szRxtCommBuf[16][0], "W_LAYER2%d setlayer", j) ;
	 	sprintf(&szRxtCommBuf[17][0], "W_LAYER2%d clearlayer", j) ; 

		switch (atoi(&StockCost[i].Data[4][0])) 
		{
			case 1 :
				strcpy(&szRxtCommBuf[18][0], "0 0 moveto (C:/Ubc/Stock/StockImage/p_up.tga) layer show");
				break ;
			case 2 :
				strcpy(&szRxtCommBuf[18][0], "0 0 moveto (C:/Ubc/Stock/StockImage/p_triup.tga) layer show");
				break ;
			case 3 :
				strcpy(&szRxtCommBuf[18][0], "0 0 moveto (C:/Ubc/Stock/StockImage/p_tridown.tga) layer show");
				break ;
			case 4 :
				strcpy(&szRxtCommBuf[18][0], "0 0 moveto (C:/Ubc/Stock/StockImage/p_down.tga) layer show");
				break ;
			default :
				strcpy(&szRxtCommBuf[18][0], "");
				break ;
		}
		sprintf(&szRxtCommBuf[19][0], "/EF_DISP2%d (snap) effect (down) seteffectdir W_FRAMEBUF2%d seteffectframebuffer W_LAYER2%d seteffectlayer 10 seteffectduration def", j, j, j) ;
		for(j = 0; j < 20; j++)
		{
			RTX(RTX_STRING, &szRxtCommBuf[j][0]) ;
		}
	}

	if(nStart == 0)
	{
		RTX(RTX_STRING, "board0 setframebuffer") ;
		RTX(RTX_STRING, "(C:/Ubc/Stock/StockImage/stock4.tga) layer setlayer def") ;
		RTX(RTX_STRING, "/STOCK (wipe) effect (right) seteffectdir 500 seteffectduration seteffectasync def") ;

		RTX(RTX_STRING, "(snap) effect") ;
		RTX(RTX_STRING, "board1 seteffectframebuffer") ;
		RTX(RTX_STRING, "(C:/Ubc/Stock/StockImage/stock4.tga) layer seteffectlayer") ;
		RTX(RTX_STRING, "STOCK showeffect") ;
		RTX(RTX_STRING, "showeffect") ;
		RTX(RTX_STRING, "clearscreen") ;
	}
	else
	{
		RTX(RTX_STRING, "clearscreen") ;
		if(bEndFlag)
		{
			RTX(RTX_STRING, "/W_FRAMEBUF_H board0 1 38 720 95 windowframebuffer def") ;
			RTX(RTX_STRING, "/W_LAYER_H FULL_LAYER 1 38 720 95 windowlayer def") ;
			RTX(RTX_STRING, "W_LAYER_H setlayer") ;
			RTX(RTX_STRING, "W_LAYER_H clearlayer") ;
			RTX(RTX_STRING, "0 0 moveto (C:/Ubc/Stock/StockImage/hyundai.tga) layer W_LAYER_H resize show") ;
			RTX(RTX_STRING, "/EF_DISP_H (snap) effect (down) seteffectdir W_FRAMEBUF_H seteffectframebuffer W_LAYER_H seteffectlayer def") ;
			RTX(RTX_STRING, "EF_DISP_H showeffect") ;
		}
		RTX(RTX_STRING, "200 wait") ;
	}

	for(i = nStart; i < nEnd; i++)
	{
		j = i - nStart ;
		sprintf(&szRxtCommBuf[0][0], "EF_DISP0%d showeffect", j) ;
		sprintf(&szRxtCommBuf[1][0], "EF_DISP1%d showeffect", j) ;
		sprintf(&szRxtCommBuf[2][0], "EF_DISP2%d showeffect", j) ;
		RTX(RTX_STRING, &szRxtCommBuf[0][0]);
		RTX(RTX_STRING, &szRxtCommBuf[1][0]);
		RTX(RTX_STRING, &szRxtCommBuf[2][0]);
	}
	RTX(RTX_STRING, "1500 wait") ;
}
