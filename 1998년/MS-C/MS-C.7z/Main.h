#include <windows.h>  
#include <windowsx.h>
#include <commctrl.h> 
#include <commdlg.h> 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

#include "TypeDef.h"
#include "Protype.h"
#include "Resource.h" 

// For Oracle
#include <ociapr.h>

#define	CLASSNAME		"RTX-ONAIR"
#define	APPNAME			"99/9/28 ??????? ????"
#define	APPMENUNAME		"MENU_MAIN"

#define	LDA				(struct cda_def *)&lda
#define	SEL_CURS		(struct cda_def *)&sel_curs
#define	DML_CURS		(struct cda_def *)&dml_curs
#define EOS '\0'
#define EOL '\n'
#define NULLTERM		5		/* Oracle datatype for Null-terminated string	*/
#define ROWID			11		/* Oracle datatype for a rowid					*/
#define NO_MORE_DATA	1403	/* Oracle error code for no more data to select	*/
#define COLS_MAX_DATA	15
#define ROWS_MAX_DATA	20

#define ELECT_MAXDATA	5

extern	HINSTANCE			ghInst ;
extern	HWND				ghWndMain ;

									/* Screen?????? ????		*/
extern	int					gnCxScreen ;
extern	int					gnCyScreen ;
extern	WNDPROC				fnEditProc ;

extern	BYTE				DBSysDate[] ;
extern	BYTE				szApplicationPath[MAX_PATH] ;

									/* For Oracle				*/
extern	struct	cda_def		lda ;
extern	struct	cda_def		sel_curs ;
extern	struct	cda_def		dml_curs ;
extern	ORACLE_SESSION		ORAsession ;
extern	ORACLE_ENV			OracleEnv ;
extern	VOTE_ENV			VoteEnv ;


									/* For Weather				*/
extern	ELECT_DATA1			ElectData1[ELECT_MAXDATA] ;
extern	ELECT_DISPDATA		ElectDispData[ELECT_MAXDATA] ;
extern	int					nReadedCount ;
extern	double				nVoteOpenRate ;
extern	BYTE				szVoteOpenRate[] ;