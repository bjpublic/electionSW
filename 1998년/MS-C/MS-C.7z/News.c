#include "Main.h" 
#include "Rtx32.h" 

static	void	InitProc		( HWND ) ;
static	void	VoteResultDisp	( HWND ) ;
static	void	NewsDisp1		( int ) ;
static	void	NewsDisp2		( void ) ;
static	void	NewsDisp3		( void ) ;
static	void	StadbyDisp		( void ) ;
static	void	RtxCommInit		( void ) ;

static	int		nLoopCount, nFlag ;
BYTE			szRxtCommBuf[10][151] ;

LRESULT CALLBACK NewsOnAir(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
		case WM_INITDIALOG :
			nFlag = 0;
			SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE), "??????? ???" ) ;
			SetWindowText( GetDlgItem(hDlg, IDC_VOTE1), &VoteEnv.Vote99[0][0] ) ;
			SetWindowText( GetDlgItem(hDlg, IDC_VOTE2), &VoteEnv.Vote99[1][0] ) ;
			SetWindowText( GetDlgItem(hDlg, IDC_VOTE3), &VoteEnv.VoteRate[1][0] ) ;
			SetDlgItemInt( hDlg, IDC_COUNT, 1, FALSE) ;
			InitProc( hDlg ) ;
			StadbyDisp() ;
			return (TRUE);

		case WM_COMMAND :
			if ( LOWORD(wParam) == ID_ONAIR)
			{
				SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE), "??????" ) ;
				VoteResultDisp( hDlg ) ;
				return (TRUE);
			}

			if ( LOWORD(wParam) == ID_CLOSE)
			{
				EndDialog(hDlg, FALSE);
				return (TRUE);
			}
			return (TRUE);
	}
	return (FALSE);
}

static void VoteResultDisp( HWND hDlg )
{
	int		i;

	nLoopCount = GetDlgItemInt( hDlg, IDC_COUNT, NULL, FALSE) ;
	SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE), "??????" ) ;
	for(i = 0; i < nLoopCount; i++)
	{
		if(nFlag > 0)
		{
			if(i > 0) RTX(RTX_STRING, "10000 wait");
			NewsDisp1( i ) ;
		} else {
			NewsDisp1(-1);
			nFlag = 1;
		}

		SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE3), "DB Reading..." ) ;
		if( !DBSelectElectData( hDlg, 0 ) ) return ;
		if( !DBSelectElectData( hDlg, 1 ) ) return ;
		SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE3), "DB Reading success" ) ;
		InitProc( hDlg ) ;
		RTX(RTX_STRING, "5000 wait");
		NewsDisp3( ) ;

		SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE3), "DB Reading..." ) ;
		if( !DBSelectElectData( hDlg, 0 ) ) return ;
		if( !DBSelectElectData( hDlg, 1 ) ) return ;
		SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE3), "DB Reading success" ) ;
		InitProc( hDlg ) ;
		RTX(RTX_STRING, "5000 wait");
		NewsDisp2( ) ;
	}
	SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE3), "Display End " ) ;
}

// ????? ????
static void NewsDisp1( int nType )
{
	BYTE	szTemp[100] ;
	int		j, k, nVal, len, nStart;
	int		xPos[9] = { 584, 574, 554, 532, 289, 273, 257, 241, 225} ;

	if(nType > -1)
	{
		RTX(RTX_STRING, "reset clear");
		RtxCommInit();
		RTX(RTX_STRING, "/F_FRAME board1 def");
		RTX(RTX_STRING, "/LY_FULL board1 size layer def");
		RTX(RTX_STRING, "(snap) effect");
		RTX(RTX_STRING, "F_FRAME seteffectframebuffer");
		RTX(RTX_STRING, "F_FRAME size layer seteffectlayer");
		RTX(RTX_STRING, "showeffect");

		RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
		RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
 		RTX(RTX_STRING, "WLY_BACKIMG setlayer");
 		RTX(RTX_STRING, "WLY_BACKIMG clearlayer ");
		RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/1back.tga) layer show");
/*
		strcpy(&szTemp[0], FormatNumberStr(&VoteEnv.Vote99[1][0]));
		sprintf(&szRxtCommBuf[0][0], "F_VALUE3 410 27 (%s) P_RIGHT (%s) show F_COUNT 412 27 moveto (??) show", &szTemp[0], &szTemp[0]) ;
		strcpy(&szTemp[0], FormatNumberStr(&VoteEnv.Vote99[0][0]));
		sprintf(&szRxtCommBuf[1][0], "F_VALUE4  410 65 (%s) P_RIGHT (%s) show F_COUNT 412 65 moveto (??) show", &szTemp[0], &szTemp[0]) ;

		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
*/
		RTX(RTX_STRING, "F_PER1 608 42 moveto (%) show") ;
		RTX(RTX_STRING, "(push) effect (left) seteffectdir WF_BACKIMG seteffectframebuffer WLY_BACKIMG seteffectlayer 1000 seteffectduration showeffect");
	}

	RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
 	RTX(RTX_STRING, "WLY_BACKIMG setlayer");
	RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/1back.tga) layer show");

	strcpy(&szTemp[0], FormatNumberStr(&VoteEnv.Vote99[1][0]));
	sprintf(&szRxtCommBuf[0][0], "F_VALUE3 410 27 (%s) P_RIGHT (%s) show F_COUNT 412 27 moveto (??) show", &szTemp[0], &szTemp[0]) ;
	strcpy(&szTemp[0], FormatNumberStr(&VoteEnv.Vote99[0][0]));
	sprintf(&szRxtCommBuf[1][0], "F_VALUE4  410 65 (%s) P_RIGHT (%s) show F_COUNT 412 65 moveto (??) show", &szTemp[0], &szTemp[0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
	RTX(RTX_STRING, "F_PER1 608 42 moveto (%) show") ;
	RTX(RTX_STRING, "(wipe) effect (right) seteffectdir WF_BACKIMG seteffectframebuffer WLY_BACKIMG seteffectlayer 1000 seteffectduration showeffect");


//	sprintf(&szRxtCommBuf[2][0], "F_VALUE2  605 42 (%s) P_RIGHT (%s) show F_PER1 608 42 moveto (%s) show", &VoteEnv.VoteRate[1][0], &VoteEnv.VoteRate[1][0], "%") ;
//	RTX(RTX_STRING, &szRxtCommBuf[2][0]) ;
	len = strlen(&VoteEnv.VoteRate[1][0]) - 1;
	for(j = len; j >= 0; j--)
	{
		szTemp[0] = VoteEnv.VoteRate[1][j];
		szTemp[1] = 0x00;
		nVal = atoi(szTemp);
		if(szTemp[0] == '.')
		{
			RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
			RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
			RTX(RTX_STRING, "WLY_BACKIMG setlayer");
			RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/1back.tga) layer show");
//			RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/blank.tga) 3 setlogo") ;

			sprintf(&szRxtCommBuf[5][0], "/WF_NUMBER board0 %d 58 10 38 windowframebuffer def", xPos[len - j]) ;
			sprintf(&szRxtCommBuf[6][0], "/WLY_NUMBER LY_FULL %d 58 10 38 windowlayer def", xPos[len - j]) ;
			RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[6][0]) ;
			RTX(RTX_STRING, "WLY_NUMBER setlayer");
//			RTX(RTX_STRING, "0 0 moveto 10 38 3 resize logorect");
			RTX(RTX_STRING, "F_VALUE2 3 5 (.) P_LEFT (.) show") ;
			RTX(RTX_STRING, "(snap) effect (up) seteffectdir WF_NUMBER seteffectframebuffer WLY_NUMBER seteffectlayer 0 seteffectduration showeffect");
		} else {
			if(nVal > 0) nStart = 1 ;
			else		 nStart = 0 ;
			sprintf(&szRxtCommBuf[5][0], "/WF_NUMBER board0 %d 58 22 38 windowframebuffer def", xPos[len - j]) ;
			sprintf(&szRxtCommBuf[6][0], "/WLY_NUMBER LY_FULL %d 58 22 38 windowlayer def", xPos[len - j]) ;
			for(k = nStart; k <= nVal; k++)
			{
				RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
				RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
				RTX(RTX_STRING, "WLY_BACKIMG setlayer");
				RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/1back.tga) layer show");
//				RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/blank.tga) 3 setlogo") ;

				RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
				RTX(RTX_STRING, &szRxtCommBuf[6][0]) ;
				RTX(RTX_STRING, "WLY_NUMBER setlayer");
//				RTX(RTX_STRING, "0 0 moveto 22 38 3 resize logorect");
				sprintf(&szRxtCommBuf[7][0], "F_VALUE2 1 5 (%d) P_LEFT (%d) show", k, k) ;
				RTX(RTX_STRING, &szRxtCommBuf[7][0]) ;
				RTX(RTX_STRING, "(snap) effect (up) seteffectdir WF_NUMBER seteffectframebuffer WLY_NUMBER seteffectlayer 0 seteffectduration showeffect");
			}
		}
	}
}


static void NewsDisp2( void )
{
	double	dPyoCha ;
	int		i, j, k, nVal, len, len1, nStart;
//	int		xPos[9] = { 345, 328, 311, 302, 285, 268, 251, 234, 217} ;
//	int		xPos[9] = { 345, 330, 314, 307, 291, 275, 259, 243, 227} ;
	int		xPos[9] =  { 345, 330, 315, 308, 293, 278, 263, 248, 233} ;
	int		xxPos[9] = { 560, 545, 530, 523, 508, 493, 478, 463, 448} ;
	BYTE	szTemp[50], szPyocha[50] ;

	RTX(RTX_STRING, "reset clear");
	RtxCommInit();
	RTX(RTX_STRING, "/F_FRAME board1 def");
	RTX(RTX_STRING, "/LY_FULL board1 size layer def");
	RTX(RTX_STRING, "(snap) effect");
	RTX(RTX_STRING, "F_FRAME seteffectframebuffer");
	RTX(RTX_STRING, "F_FRAME size layer seteffectlayer");
	RTX(RTX_STRING, "showeffect");

	sprintf(&szRxtCommBuf[0][0], "board0 setframebuffer (C:/ubc/????/img/2%s_l.tga) 1 setlogo", &ElectDispData[0].Data[5][0]) ;
	sprintf(&szRxtCommBuf[1][0], "board0 setframebuffer (C:/ubc/????/img/2%s_s.tga) 2 setlogo", &ElectDispData[1].Data[5][0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

	RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
 	RTX(RTX_STRING, "WLY_BACKIMG setlayer");
 	RTX(RTX_STRING, "WLY_BACKIMG clearlayer ");
	RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/2back.tga) layer show");
//	sprintf(&szRxtCommBuf[0][0], "F_RATE0 120 13 (%s) P_RIGHT (%s) show", &szVoteOpenRate[0], &szVoteOpenRate[0]) ;
//	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, "(push) effect (left) seteffectdir WF_BACKIMG seteffectframebuffer WLY_BACKIMG seteffectlayer 1000 seteffectduration showeffect");

// ????
// ???+L,S.TGA
	RTX(RTX_STRING, "/WF_LPHO1 board0  193 42 170 83 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_LPHO1 LY_FULL 193 42 170 83 windowlayer def");
	RTX(RTX_STRING, "WLY_LPHO1 setlayer");
	RTX(RTX_STRING, "0 0 moveto 170 83 1 logorect");
	RTX(RTX_STRING, "(wipe) effect (horizontal-gate) seteffectdir WF_LPHO1 seteffectframebuffer WLY_LPHO1 seteffectlayer 500 seteffectduration seteffectasync showeffect");

	RTX(RTX_STRING, "/WF_LPHO2 board0  491 42 169 83 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_LPHO2 LY_FULL 491 42 169 83 windowlayer def");
	RTX(RTX_STRING, "WLY_LPHO2 setlayer");
	RTX(RTX_STRING, "0 0 moveto 169 83 2 logorect");
	RTX(RTX_STRING, "(wipe) effect (horizontal-gate) seteffectdir WF_LPHO2 seteffectframebuffer WLY_LPHO2 seteffectlayer 500 seteffectduration seteffectasync showeffect");

// ?????
//	RTX(RTX_STRING, "0 0 moveto LY_GAPYOIMG show");
	RTX(RTX_STRING, "/WF_GAPYO board0   51 44 95 31 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_GAPYO LY_FULL 51 44 95 31 windowlayer def");
 	RTX(RTX_STRING, "WLY_GAPYO setlayer");
	sprintf(&szRxtCommBuf[0][0], "F_RATE0 75 7 (%s) P_RIGHT (%s) show", &szVoteOpenRate[0], &szVoteOpenRate[0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, "(snap) effect (left) seteffectdir WF_GAPYO seteffectframebuffer WLY_GAPYO seteffectlayer 300 seteffectduration showeffect");

	RTX(RTX_STRING, "700 wait");
// ??
    if(strlen(&ElectDispData[0].Data[6][0]) > 0)
	{
		RTX(RTX_STRING, "/WF_MARK board0  163 50 42 54 windowframebuffer def");
		RTX(RTX_STRING, "/WLY_MARK LY_FULL 163 50 42 54 windowlayer def");
//		RTX(RTX_STRING, "/LY_MARKIMG (C:/ubc/????/img/?�r.tga) layer def");
		sprintf(&szRxtCommBuf[0][0], "/LY_MARKIMG (C:/ubc/????/img/%s.tga) layer def", &ElectDispData[0].Data[6][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, "WLY_MARK setlayer");
		RTX(RTX_STRING, "0 0 moveto LY_MARKIMG show");
		RTX(RTX_STRING, "(fade) effect (box-open) seteffectdir WF_MARK seteffectframebuffer WLY_MARK seteffectlayer 500 seteffectduration seteffectasync showeffect");
	}

// TEST ?????
	len = strlen(&ElectDispData[0].Data[7][0]) - 1;
	len1 = strlen(&ElectDispData[0].Data[7][0]) - 1;
	for(j = len; j >= 0; j--)
	{
// 1???? (1???? 9?????? ??????
		szTemp[0] = ElectDispData[0].Data[7][j];
		szTemp[1] = 0x00;
		nVal = atoi(szTemp);
/*
		for(k = 1; k < 10; k++)
		{
			RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
			RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
			RTX(RTX_STRING, "WLY_BACKIMG setlayer");
			RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/2back.tga) layer show");
			RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/blank.tga) 3 setlogo") ;

			RTX(RTX_STRING, "/WF_NUMBER board0  355 80 25 30 windowframebuffer def");
			RTX(RTX_STRING, "/WLY_NUMBER LY_FULL 355 80 25 30 windowlayer def");
			RTX(RTX_STRING, "WLY_NUMBER setlayer");
			RTX(RTX_STRING, "0 0 moveto 25 30 3 resize logorect");
			sprintf(&szRxtCommBuf[5][0], "F_VALUE1 3 4 (%d) P_LEFT (%d) show", k, k) ;
			RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
			RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_NUMBER seteffectframebuffer WLY_NUMBER seteffectlayer 1 seteffectduration showeffect");
		}
*/
// 0???? ??????? Display
		if(szTemp[0] == ',')
		{
			RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
			RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
			RTX(RTX_STRING, "WLY_BACKIMG setlayer");
			RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/2back.tga) layer show");
			RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/blank.tga) 3 setlogo") ;

			sprintf(&szRxtCommBuf[5][0], "/WF_NUMBER board0 %d 80 8 30 windowframebuffer def", xPos[len - j]) ;
			sprintf(&szRxtCommBuf[6][0], "/WLY_NUMBER LY_FULL %d 80 8 30 windowlayer def", xPos[len - j]) ;
			RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[6][0]) ;
			RTX(RTX_STRING, "WLY_NUMBER setlayer");
			RTX(RTX_STRING, "0 0 moveto 8 30 3 resize logorect");
			RTX(RTX_STRING, "F_VALUE1 2 5 (,) P_LEFT (,) show") ;
			RTX(RTX_STRING, "(snap) effect (up) seteffectdir WF_NUMBER seteffectframebuffer WLY_NUMBER seteffectlayer 0 seteffectduration showeffect");
		} else {
			if(nVal > 0) nStart = 1 ;
			else		 nStart = 0 ;
			sprintf(&szRxtCommBuf[5][0], "/WF_NUMBER board0 %d 80 16 30 windowframebuffer def", xPos[len - j]) ;
			sprintf(&szRxtCommBuf[6][0], "/WLY_NUMBER LY_FULL %d 80 16 30 windowlayer def", xPos[len - j]) ;
			for(k = nStart; k <= nVal; k++)
			{
				RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
				RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
				RTX(RTX_STRING, "WLY_BACKIMG setlayer");
				RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/2back.tga) layer show");
				RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/blank.tga) 3 setlogo") ;

				RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
				RTX(RTX_STRING, &szRxtCommBuf[6][0]) ;
				RTX(RTX_STRING, "WLY_NUMBER setlayer");
				RTX(RTX_STRING, "0 0 moveto 16 30 3 resize logorect");
				sprintf(&szRxtCommBuf[7][0], "F_VALUE1 2 5 (%d) P_LEFT (%d) show", k, k) ;
				RTX(RTX_STRING, &szRxtCommBuf[7][0]) ;
				RTX(RTX_STRING, "(snap) effect (up) seteffectdir WF_NUMBER seteffectframebuffer WLY_NUMBER seteffectlayer 0 seteffectduration showeffect");
			}
		}
	}

// 2????
	len = strlen(&ElectDispData[1].Data[7][0]) - 1;
	for(j = len; j >= 0; j--)
	{
		szTemp[0] = ElectDispData[1].Data[7][j];
		szTemp[1] = 0x00;
		nVal = atoi(szTemp);
		if(szTemp[0] == ',')
		{
			RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
			RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
			RTX(RTX_STRING, "WLY_BACKIMG setlayer");
			RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/2back.tga) layer show");
			RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/blank.tga) 3 setlogo") ;

			sprintf(&szRxtCommBuf[5][0], "/WF_NUMBER board0 %d 80 8 30 windowframebuffer def", xxPos[len - j]) ;
			sprintf(&szRxtCommBuf[6][0], "/WLY_NUMBER LY_FULL %d 80 8 30 windowlayer def", xxPos[len - j]) ;
			RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[6][0]) ;
			RTX(RTX_STRING, "WLY_NUMBER setlayer");
			RTX(RTX_STRING, "0 0 moveto 8 30 3 resize logorect");
			RTX(RTX_STRING, "F_VALUE1 2 5 (,) P_LEFT (,) show") ;
			RTX(RTX_STRING, "(snap) effect (up) seteffectdir WF_NUMBER seteffectframebuffer WLY_NUMBER seteffectlayer 0 seteffectduration showeffect");
		} else {
			if(nVal > 0) nStart = 1 ;
			else		 nStart = 0 ;
			sprintf(&szRxtCommBuf[5][0], "/WF_NUMBER board0 %d 80 16 30 windowframebuffer def", xxPos[len - j]) ;
			sprintf(&szRxtCommBuf[6][0], "/WLY_NUMBER LY_FULL %d 80 16 30 windowlayer def", xxPos[len - j]) ;
			for(k = nStart; k <= nVal; k++)
			{
				RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
				RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
				RTX(RTX_STRING, "WLY_BACKIMG setlayer");
				RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/2back.tga) layer show");
				RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/blank.tga) 3 setlogo") ;

				RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
				RTX(RTX_STRING, &szRxtCommBuf[6][0]) ;
				RTX(RTX_STRING, "WLY_NUMBER setlayer");
				RTX(RTX_STRING, "0 0 moveto 16 30 3 resize logorect");
				sprintf(&szRxtCommBuf[7][0], "F_VALUE1 2 5 (%d) P_LEFT (%d) show", k, k) ;
				RTX(RTX_STRING, &szRxtCommBuf[7][0]) ;
				RTX(RTX_STRING, "(snap) effect (up) seteffectdir WF_NUMBER seteffectframebuffer WLY_NUMBER seteffectlayer 0 seteffectduration showeffect");
			}
		}
	}

// ???
	dPyoCha = ElectDispData[0].val - ElectDispData[1].val ;
	sprintf(szTemp, "%.0f", dPyoCha);
    strcpy( &szPyocha[0], FormatNumberStr(&szTemp[0]) ) ;

	RTX(RTX_STRING, "/WF_PYOCHA board0  381 44 90 29 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_PYOCHA LY_FULL 381 44 90 29 windowlayer def");
	RTX(RTX_STRING, "WLY_PYOCHA setlayer");
//	RTX(RTX_STRING, "0 0 moveto LY_LDUPIMG show");
	sprintf(&szRxtCommBuf[4][0], "F_VALUE8 47 6 (%s) P_CENTER (%s) show", &szPyocha[0], &szPyocha[0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[4][0]) ;
	RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_PYOCHA seteffectframebuffer WLY_PYOCHA seteffectlayer 500 seteffectduration showeffect");
return;
// TEST END


// ???
	dPyoCha = ElectDispData[0].val - ElectDispData[1].val ;
	sprintf(szTemp, "%.0f", dPyoCha);
    strcpy( &szPyocha[0], FormatNumberStr(&szTemp[0]) ) ;
// ?????
	sprintf(&szRxtCommBuf[0][0], "F_VALUE1 50 6 (%s) P_CENTER (%s) show", &ElectDispData[0].Data[7][0], &ElectDispData[0].Data[7][0]) ;
	sprintf(&szRxtCommBuf[1][0], "F_VALUE1 50 6 (%s) P_CENTER (%s) show", &ElectDispData[1].Data[7][0], &ElectDispData[1].Data[7][0]) ;
// ?????
	sprintf(&szRxtCommBuf[2][0], "F_VALUE1 50 6 (%s) P_CENTER (%s) show", &ElectDispData[0].Data[10][0], &ElectDispData[0].Data[10][0]) ;
	sprintf(&szRxtCommBuf[3][0], "F_VALUE1 50 6 (%s) P_CENTER (%s) show", &ElectDispData[1].Data[10][0], &ElectDispData[1].Data[10][0]) ;
	sprintf(&szRxtCommBuf[4][0], "F_VALUE8 47 6 (%s) P_CENTER (%s) show", &szPyocha[0], &szPyocha[0]) ;

// ?????
	RTX(RTX_STRING, "/WF_LDUP board0  270 80 100 29 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_LDUP LY_FULL 270 80 100 29 windowlayer def");
	RTX(RTX_STRING, "/LY_LDUPIMG (C:/ubc/????/img/2ldu.tga) layer def");

	RTX(RTX_STRING, "/WF_SDUP board0  485 80 100 29 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_SDUP LY_FULL 485 80 100 29 windowlayer def");
	RTX(RTX_STRING, "/LY_SDUPIMG (C:/ubc/????/img/2sdu.tga) layer def");

	RTX(RTX_STRING, "/WF_PYOCHA board0  380 44 90 29 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_PYOCHA LY_FULL 380 44 90 29 windowlayer def");

	for( i = 0; i < 1; i++)
	{
		if(i > 0) RTX(RTX_STRING, "5000 wait");
		RTX(RTX_STRING, "WLY_LDUP setlayer");
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_LDUP seteffectframebuffer WLY_LDUP seteffectlayer 500 seteffectduration seteffectasync showeffect");
		RTX(RTX_STRING, "WLY_SDUP setlayer");
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_SDUP seteffectframebuffer WLY_SDUP seteffectlayer 500 seteffectduration showeffect");
		if(i == 0)
		{
			RTX(RTX_STRING, "WLY_PYOCHA setlayer");
//	RTX(RTX_STRING, "0 0 moveto LY_LDUPIMG show");
			RTX(RTX_STRING, &szRxtCommBuf[4][0]) ;
			RTX(RTX_STRING, "(snap) effect (up) seteffectdir WF_PYOCHA seteffectframebuffer WLY_PYOCHA seteffectlayer 500 seteffectduration seteffectasync showeffect");
		}

		RTX(RTX_STRING, "5000 wait");

		RTX(RTX_STRING, "WLY_LDUP setlayer WLY_LDUP clearlayer");
		RTX(RTX_STRING, "0 0 moveto LY_LDUPIMG show");
		RTX(RTX_STRING, &szRxtCommBuf[2][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_LDUP seteffectframebuffer WLY_LDUP seteffectlayer 500 seteffectduration seteffectasync showeffect");
		RTX(RTX_STRING, "WLY_SDUP setlayer WLY_SDUP clearlayer");
		RTX(RTX_STRING, "0 0 moveto LY_SDUPIMG show");
		RTX(RTX_STRING, &szRxtCommBuf[3][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_SDUP seteffectframebuffer WLY_SDUP seteffectlayer 500 seteffectduration showeffect");
	}
//	RTX(RTX_STRING, "0 0 moveto LY_GAPYOIMG show");
//	RTX(RTX_STRING, "/WF_GAPYO board0   41 44 79 29 windowframebuffer def");
//	RTX(RTX_STRING, "/WLY_GAPYO LY_FULL 41 44 79 29 windowlayer def");
// 	RTX(RTX_STRING, "WLY_GAPYO setlayer");
// 	RTX(RTX_STRING, "WLY_GAPYO clearlayer ");
//	RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/2gpy.tga) layer show");
//	sprintf(&szRxtCommBuf[0][0], "F_RATE0 73 5 (%s) P_RIGHT (%s) show", &szVoteOpenRate[0], &szVoteOpenRate[0]) ;
//	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
//	RTX(RTX_STRING, "(snap) effect (left) seteffectdir WF_GAPYO seteffectframebuffer WLY_GAPYO seteffectlayer 300 seteffectduration showeffect");

// ?????
//	RTX(RTX_STRING, "/LY_BARIMG (C:/ubc/????/img/2bar.tga) layer def");
//	nBarLen1 = atoi(&ElectDispData[0].Data[10][0]);
//	nBarLen2 = atoi(&ElectDispData[1].Data[10][0]);
//	nWidth1 = (int)(nBarLen1 * 0.8);
//	nWidth2 = (int)(nBarLen2 * 0.8);
//	sprintf(&szRxtCommBuf[0][0], "/WF_LBAR board0  346 40 %d 19 windowframebuffer def", nWidth1) ;
//	sprintf(&szRxtCommBuf[1][0], "/WLY_LBAR LY_FULL 346 40 %d 19 windowlayer def", nWidth1) ;
//	sprintf(&szRxtCommBuf[2][0], "/WF_SBAR board0  %d 77 %d 19 windowframebuffer def", 480 - nWidth2, nWidth2) ;
//	sprintf(&szRxtCommBuf[3][0], "/WLY_SBAR LY_FULL %d 76 %d 19 windowlayer def", 480 - nWidth2, nWidth2) ;
//	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
//	RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
//	RTX(RTX_STRING, &szRxtCommBuf[2][0]) ;
//	RTX(RTX_STRING, &szRxtCommBuf[3][0]) ;
//	RTX(RTX_STRING, "WLY_LBAR setlayer WLY_LBAR clearlayer");
//	RTX(RTX_STRING, "0 0 moveto LY_BARIMG show");
//	RTX(RTX_STRING, "(wipe) effect (right) seteffectdir WF_LBAR seteffectframebuffer WLY_LBAR seteffectlayer 500 seteffectduration seteffectasync showeffect");
//	RTX(RTX_STRING, "WLY_SBAR setlayer WLY_SBAR clearlayer");
//	RTX(RTX_STRING, "0 0 moveto LY_BARIMG show");
//	RTX(RTX_STRING, "(wipe) effect (left) seteffectdir WF_SBAR seteffectframebuffer WLY_SBAR seteffectlayer 500 seteffectduration showeffect");
}

static void NewsDisp3( void )
{
	int		i;

	RTX(RTX_STRING, "reset clear");
	RtxCommInit();
	RTX(RTX_STRING, "/F_FRAME board1 def");
	RTX(RTX_STRING, "/LY_FULL board1 size layer def");
	RTX(RTX_STRING, "(snap) effect");
	RTX(RTX_STRING, "F_FRAME seteffectframebuffer");
	RTX(RTX_STRING, "F_FRAME size layer seteffectlayer");
	RTX(RTX_STRING, "showeffect");

	sprintf(&szRxtCommBuf[0][0], "board0 setframebuffer (C:/ubc/????/img/3%s.tga) 1 setlogo", &ElectDispData[0].Data[5][0]) ;
	sprintf(&szRxtCommBuf[1][0], "board0 setframebuffer (C:/ubc/????/img/3%s.tga) 2 setlogo", &ElectDispData[1].Data[5][0]) ;
	sprintf(&szRxtCommBuf[2][0], "board0 setframebuffer (C:/ubc/????/img/3%s.tga) 3 setlogo", &ElectDispData[2].Data[5][0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[2][0]) ;
	RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/3bar1.tga) 4 setlogo");
	RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/3bar2.tga) 5 setlogo");
	RTX(RTX_STRING, "board0 setframebuffer (C:/ubc/????/img/3bar3.tga) 6 setlogo");

	RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
 	RTX(RTX_STRING, "WLY_BACKIMG setlayer");
 	RTX(RTX_STRING, "WLY_BACKIMG clearlayer ");
	RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/3back.tga) layer show");
	RTX(RTX_STRING, "(push) effect (left) seteffectdir WF_BACKIMG seteffectframebuffer WLY_BACKIMG seteffectlayer 1000 seteffectduration showeffect");

	RTX(RTX_STRING, "/WF_LPHO1 board0  172 42 112 83 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_LPHO1 LY_FULL 172 42 112 83 windowlayer def");
	RTX(RTX_STRING, "WLY_LPHO1 setlayer");
	RTX(RTX_STRING, "0 0 moveto 112 83 1 logorect");
	RTX(RTX_STRING, "(wipe) effect (horizontal-gate) seteffectdir WF_LPHO1 seteffectframebuffer WLY_LPHO1 seteffectlayer 700 seteffectduration seteffectasync showeffect");
	RTX(RTX_STRING, "/WF_ORDER1 board0  282 42 46 33 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_ORDER1 LY_FULL 282 42 46 33 windowlayer def");
	RTX(RTX_STRING, "WLY_ORDER1 setlayer");
	RTX(RTX_STRING, "0 0 moveto 46 33 4 logorect");
	RTX(RTX_STRING, "(wipe) effect (horizontal-gate) seteffectdir WF_ORDER1 seteffectframebuffer WLY_ORDER1 seteffectlayer 700 seteffectduration seteffectasync showeffect");

	RTX(RTX_STRING, "/WF_LPHO2 board0  342 42 112 83 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_LPHO2 LY_FULL 342 42 112 83 windowlayer def");
	RTX(RTX_STRING, "WLY_LPHO2 setlayer");
	RTX(RTX_STRING, "0 0 moveto 112 83 2 logorect");
	RTX(RTX_STRING, "(wipe) effect (horizontal-gate) seteffectdir WF_LPHO2 seteffectframebuffer WLY_LPHO2 seteffectlayer 700 seteffectduration seteffectasync showeffect");
	RTX(RTX_STRING, "/WF_ORDER2 board0  452 42 46 33 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_ORDER2 LY_FULL 452 42 46 33 windowlayer def");
	RTX(RTX_STRING, "WLY_ORDER2 setlayer");
	RTX(RTX_STRING, "0 0 moveto 46 33 5 logorect");
	RTX(RTX_STRING, "(wipe) effect (horizontal-gate) seteffectdir WF_ORDER2 seteffectframebuffer WLY_ORDER2 seteffectlayer 700 seteffectduration seteffectasync showeffect");

	RTX(RTX_STRING, "/WF_LPHO3 board0  513 42 112 83 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_LPHO3 LY_FULL 513 42 112 83 windowlayer def");
	RTX(RTX_STRING, "WLY_LPHO3 setlayer");
	RTX(RTX_STRING, "0 0 moveto 112 83 3 logorect");
	RTX(RTX_STRING, "(wipe) effect (horizontal-gate) seteffectdir WF_LPHO3 seteffectframebuffer WLY_LPHO3 seteffectlayer 700 seteffectduration seteffectasync showeffect");
	RTX(RTX_STRING, "/WF_ORDER3 board0  623 42 46 33 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_ORDER3 LY_FULL 623 42 46 33 windowlayer def");
	RTX(RTX_STRING, "WLY_ORDER3 setlayer");
	RTX(RTX_STRING, "0 0 moveto 46 33 6 logorect");
	RTX(RTX_STRING, "(wipe) effect (horizontal-gate) seteffectdir WF_ORDER3 seteffectframebuffer WLY_ORDER3 seteffectlayer 700 seteffectduration showeffect");

// ?????
	RTX(RTX_STRING, "0 0 moveto LY_GAPYOIMG show");
	RTX(RTX_STRING, "/WF_GAPYO board0   51 44 95 31 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_GAPYO LY_FULL 51 44 95 31 windowlayer def");
 	RTX(RTX_STRING, "WLY_GAPYO setlayer");
	sprintf(&szRxtCommBuf[0][0], "F_RATE0 75 7 (%s) P_RIGHT (%s) show", &szVoteOpenRate[0], &szVoteOpenRate[0]) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, "(snap) effect (left) seteffectdir WF_GAPYO seteffectframebuffer WLY_GAPYO seteffectlayer 300 seteffectduration showeffect");

	RTX(RTX_STRING, "700 wait");

// ??
    if(strlen(&ElectDispData[0].Data[6][0]) > 0)
	{
		RTX(RTX_STRING, "/WF_MARK board0  143 50 42 54 windowframebuffer def");
		RTX(RTX_STRING, "/WLY_MARK LY_FULL 143 50 42 54 windowlayer def");
		sprintf(&szRxtCommBuf[0][0], "/LY_MARKIMG (C:/ubc/????/img/%s.tga) layer def", &ElectDispData[0].Data[6][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, "WLY_MARK setlayer");
		RTX(RTX_STRING, "0 0 moveto LY_MARKIMG show");
		RTX(RTX_STRING, "(wipe) effect (box-open) seteffectdir WF_MARK seteffectframebuffer WLY_MARK seteffectlayer 500 seteffectduration seteffectasync showeffect");
	}
// ?????,?????
	RTX(RTX_STRING, "/WF_DUP1 board0  243 79 95 29 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_DUP1 LY_FULL 243 79 95 29 windowlayer def");
	RTX(RTX_STRING, "/LY_DUP1IMG (C:/ubc/????/img/3dup1.tga) layer def");
//	RTX(RTX_STRING, "/WF_DUP2 board0  413 79 95 29 windowframebuffer def");
//	RTX(RTX_STRING, "/WLY_DUP2 LY_FULL 413 79 95 29 windowlayer def");
	RTX(RTX_STRING, "/WF_DUP2 board0  415 79 95 29 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_DUP2 LY_FULL 415 79 95 29 windowlayer def");
	RTX(RTX_STRING, "/LY_DUP2IMG (C:/ubc/????/img/3dup2.tga) layer def");
	RTX(RTX_STRING, "/WF_DUP3 board0  588 79 95 29 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_DUP3 LY_FULL 588 79 95 29 windowlayer def");
	RTX(RTX_STRING, "/LY_DUP3IMG (C:/ubc/????/img/3dup3.tga) layer def");

// ?????
	sprintf(&szRxtCommBuf[0][0], "F_VALUE7 45 5 (%s) P_CENTER (%s) show", &ElectDispData[0].Data[7][0], &ElectDispData[0].Data[7][0]) ;
	sprintf(&szRxtCommBuf[1][0], "F_VALUE7 45 5 (%s) P_CENTER (%s) show", &ElectDispData[1].Data[7][0], &ElectDispData[1].Data[7][0]) ;
	sprintf(&szRxtCommBuf[2][0], "F_VALUE7 45 5 (%s) P_CENTER (%s) show", &ElectDispData[2].Data[7][0], &ElectDispData[2].Data[7][0]) ;
// ?????
	sprintf(&szRxtCommBuf[3][0], "F_VALUE7 45 5 (%s) P_CENTER (%s) show", &ElectDispData[0].Data[10][0], &ElectDispData[0].Data[10][0]) ;
	sprintf(&szRxtCommBuf[4][0], "F_VALUE7 45 5 (%s) P_CENTER (%s) show", &ElectDispData[1].Data[10][0], &ElectDispData[1].Data[10][0]) ;
	sprintf(&szRxtCommBuf[5][0], "F_VALUE7 45 5 (%s) P_CENTER (%s) show", &ElectDispData[2].Data[10][0], &ElectDispData[2].Data[10][0]) ;

	for(i = 0; i < 1; i++)
	{
		if(i > 0) RTX(RTX_STRING, "10000 wait");

		RTX(RTX_STRING, "WLY_DUP1 setlayer WLY_DUP1 clearlayer");
		RTX(RTX_STRING, "0 0 moveto LY_DUP1IMG show");
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_DUP1 seteffectframebuffer WLY_DUP1 seteffectlayer 500 seteffectduration seteffectasync showeffect");

		RTX(RTX_STRING, "WLY_DUP2 setlayer WLY_DUP2 clearlayer");
		RTX(RTX_STRING, "0 0 moveto LY_DUP2IMG show");
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_DUP2 seteffectframebuffer WLY_DUP2 seteffectlayer 500 seteffectduration seteffectasync showeffect");

		RTX(RTX_STRING, "WLY_DUP3 setlayer WLY_DUP3 clearlayer");
		RTX(RTX_STRING, "0 0 moveto LY_DUP3IMG show");
		RTX(RTX_STRING, &szRxtCommBuf[2][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_DUP3 seteffectframebuffer WLY_DUP3 seteffectlayer 500 seteffectduration seteffectasync showeffect");

		RTX(RTX_STRING, "10000 wait");

		RTX(RTX_STRING, "WLY_DUP1 setlayer WLY_DUP1 clearlayer");
		RTX(RTX_STRING, "0 0 moveto LY_DUP1IMG show");
		RTX(RTX_STRING, &szRxtCommBuf[3][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_DUP1 seteffectframebuffer WLY_DUP1 seteffectlayer 500 seteffectduration seteffectasync showeffect");

		RTX(RTX_STRING, "WLY_DUP2 setlayer WLY_DUP2 clearlayer");
		RTX(RTX_STRING, "0 0 moveto LY_DUP2IMG show");
		RTX(RTX_STRING, &szRxtCommBuf[4][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_DUP2 seteffectframebuffer WLY_DUP2 seteffectlayer 500 seteffectduration seteffectasync showeffect");

		RTX(RTX_STRING, "WLY_DUP3 setlayer WLY_DUP3 clearlayer");
		RTX(RTX_STRING, "0 0 moveto LY_DUP3IMG show");
		RTX(RTX_STRING, &szRxtCommBuf[5][0]) ;
		RTX(RTX_STRING, "(push) effect (up) seteffectdir WF_DUP3 seteffectframebuffer WLY_DUP3 seteffectlayer 500 seteffectduration seteffectasync showeffect");
	}
}

static void	RtxCommInit( void )
{
	RTX(RTX_STRING, "/P_RIGHT  { /A 3 array def A astore 0 get A 2 get stringwidth pop sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_LEFT { pop moveto } def") ;
	RTX(RTX_STRING, "/P_NEXTPOS  { /A 3 array def A astore 0 get A 2 get stringwidth pop add A 1 get moveto } def") ;

	RTX(RTX_STRING, "/F_VALUE1 { 0.99610 0.99610 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 25 scalefont 0 shadowfont 80 fontwidth 2 edgefont setfont } def");
//	RTX(RTX_STRING, "/F_VALUE2 { 0.00000 0.00000 0.00000 110 setrgbpalette 0.99610 0.99610 0.99610 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 38 scalefont 0 shadowfont 85 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_VALUE2 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 38 scalefont 0 shadowfont 85 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_VALUE3 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 25 scalefont 0 shadowfont 85 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_VALUE4 { 0.00000 0.00000 0.00000 110 setrgbpalette 0.99610 0.99610 0.99610 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 25 scalefont 0 shadowfont 85 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_VALUE6 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 25 scalefont 0 shadowfont 80 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_VALUE7 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 25 scalefont 0 shadowfont 70 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_VALUE8 { 0.00000 0.00000 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 25 scalefont 0 shadowfont 70 fontwidth 0 edgefont setfont } def");

	RTX(RTX_STRING, "/F_RATE0 { 0.00000 0.00000 0.00000 110 setrgbpalette 0.99610 0.99610 0.99610 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????B) cvn findfont 24 scalefont 0 shadowfont 70 fontwidth 2 edgefont setfont } def");

	RTX(RTX_STRING, "/F_PYO { 0.00000 0.00000 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 20 scalefont 0 shadowfont 60 fontwidth 0 edgefont setfont } def");

	RTX(RTX_STRING, "/F_COUNT { 0.00000 0.00000 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 20 scalefont 0 shadowfont 70 fontwidth 0 edgefont setfont } def");
	RTX(RTX_STRING, "/F_PYO1 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 15 scalefont 0 shadowfont 60 fontwidth 2 edgefont setfont } def");
//	RTX(RTX_STRING, "/F_PER1 { 0.00000 0.00000 0.00000 110 setrgbpalette 0.99610 0.99610 0.99610 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 20 scalefont 0 shadowfont 70 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_PER1 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 20 scalefont 0 shadowfont 70 fontwidth 0 edgefont setfont } def");
}

static void StadbyDisp( void )
{
	RTX(RTX_STRING, "reset clear");
	RtxCommInit();
	RTX(RTX_STRING, "/F_FRAME board1 def");
	RTX(RTX_STRING, "/LY_FULL board1 size layer def");
	RTX(RTX_STRING, "(snap) effect");
	RTX(RTX_STRING, "F_FRAME seteffectframebuffer");
	RTX(RTX_STRING, "F_FRAME size layer seteffectlayer");
	RTX(RTX_STRING, "showeffect");

	RTX(RTX_STRING, "/WF_BACKIMG board0   0 22 720 115 windowframebuffer def");
	RTX(RTX_STRING, "/WLY_BACKIMG LY_FULL 0 22 720 115 windowlayer def");
 	RTX(RTX_STRING, "WLY_BACKIMG setlayer");
 	RTX(RTX_STRING, "WLY_BACKIMG clearlayer ");
	RTX(RTX_STRING, "0 0 moveto (C:/ubc/????/img/1back.tga) layer show");
	RTX(RTX_STRING, "(fade) effect (left) seteffectdir WF_BACKIMG seteffectframebuffer WLY_BACKIMG seteffectlayer 0 seteffectduration showeffect");
}


static void InitProc (HWND hDlg)
{
	int			i ;
	BYTE		Data[5][300] ;		/* TOTAL_MIN,TOTAL_MAX,TOTAL,COUNT	*/

	for( i = 0; i < nReadedCount; i++)
	{
		strcpy(&Data[i][0], &ElectData1[i].Data[4][0]) ;
		strcat(&Data[i][0], &ElectData1[i].Data[5][0]) ;
		strcat(&Data[i][0], &ElectData1[i].Data[8][0]) ;
		strcat(&Data[i][0], &ElectData1[i].Data[6][0]) ;
		strcat(&Data[i][0], &ElectData1[i].Data[7][0]) ;
		strcat(&Data[i][0], &ElectData1[i].Data[10][0]) ;
	}
	SetWindowText( GetDlgItem(hDlg, IDC_RESULT1), &Data[0][0] ) ;
	SetWindowText( GetDlgItem(hDlg, IDC_RESULT2), &Data[1][0] ) ;
	SetWindowText( GetDlgItem(hDlg, IDC_RESULT3), &Data[2][0] ) ;

	if(nReadedCount > 0)
	{
		SetWindowText( GetDlgItem(hDlg, IDC_SGGNAME), &ElectDispData[0].Data[1][0] ) ;
		SetWindowText( GetDlgItem(hDlg, IDC_TOTALUSER), &ElectDispData[0].Data[2][0] ) ;
		SetWindowText( GetDlgItem(hDlg, IDC_ENDFLAG), &ElectDispData[0].Data[3][0] ) ;
		SetWindowText( GetDlgItem(hDlg, IDC_DUPYU1), &ElectDispData[0].Data[9][0] ) ;
	}
	SetWindowText( GetDlgItem(hDlg, IDC_OPENVOTE), &szVoteOpenRate[0] ) ;
}
