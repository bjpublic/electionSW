#include "Main.h" 

BOOL InitFindWindow( void )
{
	HWND		hFindWin ;

	hFindWin = FindWindow( CLASSNAME, APPNAME ) ;
	if( hFindWin == NULL) return TRUE ;

	SetForegroundWindow( hFindWin ) ;
	ShowWindow( hFindWin, SW_SHOW ) ; 
	return FALSE ;
}

BOOL GlobalVarInitProc( void )
{
	gnCxScreen = GetSystemMetrics(SM_CXSCREEN) ;
	gnCyScreen = GetSystemMetrics(SM_CYSCREEN) ;
	ORAsession.connected = FALSE ;

	memset(szApplicationPath, 0x00, sizeof(szApplicationPath)) ;
	lstrcpy(szApplicationPath, "C:\\UBC\\????") ;

	return TRUE ;
}

BOOL OracleEnvFileRead ( HWND hWnd )
{
	FILE		*file ;
	BYTE		szTemp[MAX_PATH] ;

	lstrcpy(szTemp, szApplicationPath) ;
	lstrcat(szTemp, "\\ELECT.ENV") ;

	memset(&OracleEnv, 0x00, sizeof(OracleEnv)) ;
	if (NULL == (file = fopen (szTemp, "rb"))) return FALSE ;

	if(sizeof(OracleEnv) != (int)fread (&OracleEnv, 1, sizeof(OracleEnv), file))
	{
		fclose (file) ;
		return FALSE ;
	}
	fclose (file) ;

	return TRUE ;
}

BOOL OracleEnvFileWrite ( HWND hWnd )
{
	FILE		*file ;
	BYTE		szTemp[MAX_PATH] ;

	lstrcpy(szTemp, szApplicationPath) ;
	lstrcat(szTemp, "\\ELECT.ENV") ;

	if (NULL == (file = fopen (szTemp, "wb")))
	{
		MessageBox( hWnd, "File Create", "Error", MB_OK | MB_ICONSTOP);
		return FALSE ;
	}

	if(sizeof(OracleEnv) != (int)fwrite (&OracleEnv, 1, sizeof(OracleEnv), file))
	{
		fclose (file) ;
		MessageBox( hWnd, "File Write", "Error", MB_OK | MB_ICONSTOP);
		return FALSE ;
	}

	fclose (file) ;

	return TRUE ;
}

BOOL VoteEnvFileRead ( HWND hWnd )
{
	FILE		*file ;
	BYTE		szTemp[MAX_PATH] ;

	lstrcpy(szTemp, szApplicationPath) ;
	lstrcat(szTemp, "\\VOTE.ENV") ;

	memset(&VoteEnv, 0x00, sizeof(VoteEnv)) ;
	if (NULL == (file = fopen (szTemp, "rb"))) return FALSE ;

	if(sizeof(VoteEnv) != (int)fread (&VoteEnv, 1, sizeof(VoteEnv), file))
	{
		fclose (file) ;
		return FALSE ;
	}
	fclose (file) ;

	return TRUE ;
}

BOOL VoteEnvFileWrite ( HWND hWnd )
{
	FILE		*file ;
	BYTE		szTemp[MAX_PATH] ;

	lstrcpy(szTemp, szApplicationPath) ;
	lstrcat(szTemp, "\\VOTE.ENV") ;

	if (NULL == (file = fopen (szTemp, "wb")))
	{
		MessageBox( hWnd, "File Create", "Error", MB_OK | MB_ICONSTOP);
		return FALSE ;
	}

	if(sizeof(VoteEnv) != (int)fwrite (&VoteEnv, 1, sizeof(VoteEnv), file))
	{
		fclose (file) ;
		MessageBox( hWnd, "File Write", "Error", MB_OK | MB_ICONSTOP);
		return FALSE ;
	}

	fclose (file) ;

	return TRUE ;
}
