#include "Main.h"
#include <ociapr.h>

BOOL DBSelectIpsiData( HWND hWnd, int nType )
{
	int		i, nCount, nCols ;
	short	ind_temp[COLS_MAX_DATA];
	char	select_temp[COLS_MAX_DATA][41] ;
	BYTE	SqlCom[200] ;

	switch( nType )
	{
		case 1 :			// ���и� SELECT
			nCols = 2 ;
//			memset(&StockTotal, 0x00, sizeof(STOCK_TOTAL)) ;
			strcpy( SqlCom, "SELECT RPAD(U_NAME, 24, ' '),U_CODE FROM IPSI_UNIVERSITY" ) ;
			strcat( SqlCom, " WHERE ONAIR = '1'" ) ;
			strcat( SqlCom, " ORDER BY SORT" ) ;
			break ;

		case 2 :			// ���к� ���� ��Ȳ SELECT
			nCols = 6 ;
			strcpy( SqlCom, "SELECT a.S_NAME,b.C_COL,b.C_SUP,b.C_RATE,b.C_TIME,b.C_FLAG" ) ;
			strcat( SqlCom, " FROM IPSI_COLLECTION a,IPSI_RATE b WHERE a.U_CODE = b.U_CODE" ) ;
			strcat( SqlCom, " AND a.S_CODE=b.S_CODE AND a.U_CODE = '" ) ;
			strcat( SqlCom, szIpsiUniCode ) ;
			strcat( SqlCom, "' AND b.C_GUBUN = '" ) ;
			strcat( SqlCom, szIpsiGubun ) ;
			strcat( SqlCom, "' ORDER BY a.C_SORT" ) ;
			break ;
	}

						/* open a cursor for the select from REPT_MST	*/
	if (oopen(SEL_CURS, LDA, (char *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

								/* parse cursor						*/
								/* parse the INSERT SQL statement	*/
	if (osql3(SEL_CURS, (char *)&SqlCom[0], -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

	for( i = 0; i < nCols; i++ )
	{
		if (odefin(SEL_CURS, i + 1, (char *)&select_temp[i][0], 30, NULLTERM, -1,
					(short *)&ind_temp[i], (char *)0, -1, -1, (short *)0, (short *)0))
		{
			OracleErrorCode(hWnd, SEL_CURS);
			return FALSE ;
		}
	}
	if (oexec(SEL_CURS))	/* execute the query to get a new active set	*/
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}


	nCount = 0 ;
	switch( nType )
	{
		case 1 :			// ���и� SELECT
			while( nCount < IPSI_UNI_MAX )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}

				for( i = 0; i < nCols; i++ )
				{
					strcpy( &IpsiUniversity[nCount].Data[i][0], &select_temp[i][0] ) ;
				}
				nCount++ ;
			}
			nUniTotalCount = nCount;
			break ;

		case 2 :			// ���к� ���� ��Ȳ SELECT
			while( nCount < IPSI_COL_MAX )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}

				for( i = 0; i < nCols; i++ )
				{
					strcpy( &IpsiRate[nCount].Data[i][0], &select_temp[i][0] ) ;
				}
				nCount++ ;
			}
			nRateTotalCount = nCount;
			break ;

	}

	if (oclose(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}
	return TRUE ;
}
