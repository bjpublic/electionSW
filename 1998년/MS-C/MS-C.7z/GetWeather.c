#include "Main.h"
#include <ociapr.h>

BOOL DBSelectWeatherData( HWND hWnd, int nType )
{
	int		i, nCount, nCols ;
	short	ind_temp[COLS_MAX_DATA];
	char	select_temp[COLS_MAX_DATA][21] ;
	BYTE	SqlCom[100] ;

	switch( nType )
	{
		case 0 :						/* �����̵�, ���/�泲 ����		*/
			nCols = 6 ;
			memset(&WeatherArea, 0x00, sizeof(WEATHER_AREA) * AREA_MAXDATA) ;
			strcpy( SqlCom, "SELECT NO,LOW,HIGH,IMAGE,IMAGE1,MOVING FROM AREA_WEATHER" ) ;
			strcat( SqlCom, " ORDER BY NO" ) ;
			break ;

		case 1 :						/*�ػ� ����			*/
			nCols = 5 ;
			memset(&WeatherSea, 0x00, sizeof(WEATHER_SEA) * SEA_MAXDATA) ;
			strcpy( SqlCom, "SELECT NO,LOW,HIGH,IMAGE,IMAGE1 FROM SEA_WEATHER" ) ;
			strcat( SqlCom, " ORDER BY NO" ) ;
			break ;

		case 2 :						/* ���� ����					*/
			nCols = 5 ;
			memset(&WeatherTArea, 0x00, sizeof(WEATHER_TAREA) * TAREA_MAXDATA) ;
			strcpy( SqlCom, "SELECT NO,LOW,HIGH,IMAGE,IMAGE1 FROM TAREA_WEATHER" ) ;
			strcat( SqlCom, " ORDER BY NO" ) ;
			break ;

		case 3 :						/* �ְ� ����				*/
			nCols = 6 ;
			memset(&WeatherWeek, 0x00, sizeof(WEATHER_WEEK) * WEEK_MAXDATA) ;
			strcpy( SqlCom, "SELECT NO,DAY,DAYTITLE,IMAGE,IMAGE1,CHK FROM WEEK_WEATHER" ) ;
			strcat( SqlCom, " ORDER BY NO" ) ;
			break ;
	}

						/* open a cursor for the select from REPT_MST	*/
	if (oopen(SEL_CURS, LDA, (char *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

								/* parse cursor						*/
								/* parse the INSERT SQL statement	*/
	if (osql3(SEL_CURS, (char *)&SqlCom[0], -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

	for( i = 0; i < nCols; i++ )
	{
		if (odefin(SEL_CURS, i + 1, (char *)&select_temp[i][0], 30, NULLTERM, -1,
					(short *)&ind_temp[i], (char *)0, -1, -1, (short *)0, (short *)0))
		{
			OracleErrorCode(hWnd, SEL_CURS);
			return FALSE ;
		}
	}
	if (oexec(SEL_CURS))	/* execute the query to get a new active set	*/
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

	nCount = 0 ;
	switch( nType )
	{
		case 0 :						/*�����̵�, ���/�泲 ����	*/
			while( nCount < AREA_MAXDATA )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}
//ZeroMemory()
				for( i = 0; i < nCols; i++ )
				{
					strcpy( &WeatherArea[nCount].Data[i][0], &select_temp[i][0] ) ;
				}
				strcpy( &WeatherArea[nCount].DispData[0], &select_temp[1][0] ) ;
				if( select_temp[2][0] != 0x00 )
				{
					strcat( &WeatherArea[nCount].DispData[0], " ?? " ) ;
					strcat( &WeatherArea[nCount].DispData[0], &select_temp[2][0] ) ;
				}

				nCount++ ;
			}
			break ;

		case 1 :						/*�ػ� ����			*/
			while( nCount < SEA_MAXDATA )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}
				for( i = 0; i < nCols; i++ )
				{
					strcpy( &WeatherSea[nCount].Data[i][0], &select_temp[i][0] ) ;
				}
				strcpy( &WeatherSea[nCount].DispData[0], &select_temp[1][0] ) ;
				if( select_temp[2][0] != 0x00 )
				{
					strcat( &WeatherSea[nCount].DispData[0], " ?? " ) ;
					strcat( &WeatherSea[nCount].DispData[0], &select_temp[2][0] ) ;
				}

				nCount++ ;
			}
			break ;

		case 2 :						/*���� ����				*/
			while( nCount < TAREA_MAXDATA )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}
				for( i = 0; i < nCols; i++ )
				{
					strcpy( &WeatherTArea[nCount].Data[i][0], &select_temp[i][0] ) ;
				}
				strcpy( &WeatherTArea[nCount].DispData[0], &select_temp[1][0] ) ;
				if( select_temp[2][0] != 0x00 )
				{
					strcat( &WeatherTArea[nCount].DispData[0], " ?? " ) ;
					strcat( &WeatherTArea[nCount].DispData[0], &select_temp[2][0] ) ;
				}
				nCount++ ;
			}
			break ;

		case 3 :						/*�ְ� ����			*/
			while( nCount < WEEK_MAXDATA )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}
				for( i = 0; i < nCols; i++ )
				{
					strcpy( &WeatherWeek[nCount].Data[i][0], &select_temp[i][0] ) ;
				}
				nCount++ ;
			}
			break ;
	}

	if (oclose(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}
	return TRUE ;
}
