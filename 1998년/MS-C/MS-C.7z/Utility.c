#include "Main.h" 

LRESULT CALLBACK EditProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	MSG			msgTemp ;
	DWORD		dwStart, dwEnd ;

	switch( uMsg )
	{
//		case WM_SETFOCUS :
//			GetWindowText(hWnd, &szGetText[0], 14) ;
//			break ;

		case WM_CHAR :
			SendMessage( hWnd, EM_GETSEL, (WPARAM)&dwStart, (LPARAM)&dwEnd ) ;
			if( (wParam == 0x2b || wParam == 0x2d) && (int)dwStart != 0)
			{											// + - Keyó��
				GetMessage (&msgTemp, NULL, 0, 0) ;
				MessageBeep(0xFFFFFFFF);
				return 0 ;
			}
			if( wParam == 0x2e && (int)dwStart == 0)
			{											// .ó��
				GetMessage (&msgTemp, NULL, 0, 0) ;
				MessageBeep(0xFFFFFFFF);
				return 0 ;
			}

			if( (wParam >= 0x30 && wParam <= 0x39) || wParam == VK_BACK ||
				wParam == 0x2b || wParam == 0x2d || wParam == 0x2e )
			{
				break ;
			}
			GetMessage (&msgTemp, NULL, 0, 0) ;
			MessageBeep(0xFFFFFFFF);
//sprintf(&aaa[0], "Value=> %d, %x", (int)dwStart, (int)wParam) ;
//MessageBox( hWnd, aaa, "Error", MB_OK | MB_ICONSTOP );
			return 0 ;

/*
		case WM_KEYDOWN :
			if( wParam == VK_ESCAPE )
			{
				SetWindowText( hWnd, szGetText ) ;
			}
			break ;
*/
	}
	return CallWindowProc ( fnEditProc, hWnd, uMsg, wParam, lParam ) ;
}

int SpaceTrim( LPSTR Source )
{
	int		i, iLen ;

	iLen = strlen(Source) ;
	for(i = 0; i < iLen; i++)
	{
		if(*(Source + i) != ' ') break;
	}
	if(i)
	{
		memmove(Source, (Source + i), (iLen - i) );
		*(Source + (iLen - i)) = 0x00;
	}

	iLen = strlen(Source) - 1;
	for(i = iLen; i >= 0; i--)
	{
		if(*(Source + i) != ' ')
		{
			*(Source + i + 1) = 0x00;
			break;
		}
	}
	iLen = strlen(Source) ;
	return iLen ;
}

char *LeftSpaceTrim( LPSTR Source )
{
	int				i, iLen ;
	static BYTE		szReturnBuf[300];

	iLen = strlen(Source) ;
	for(i = 0; i < iLen; i++)
	{
		if(*(Source + i) != ' ') 
		{
			strcpy(szReturnBuf, (Source + i)) ;
			break;
		}
	}
	return szReturnBuf ;
}

char *RightSpaceTrim( LPSTR Source )
{
	int				i, iLen ;
	static BYTE		szReturnBuf[300];

	iLen = strlen(Source) - 1;
	for(i = iLen; i = 0; i--)
	{
		if(*(Source + i) != ' ') break ;
	}
	memset(szReturnBuf, 0x00, sizeof(szReturnBuf));
	if(i > 0) memcpy(szReturnBuf, Source, i) ;

	return szReturnBuf ;
}


char *FormatNumberLong(long val)
{
	BYTE			buf[100];
	static BYTE		buf2[100];
	int				len, n, i, j;

	sprintf(buf, "%d", val);
	len = strlen(buf);
	n = 3 - (len % 3);
	for (i = j = 0; i < len; i++)
	{
		buf2[j++] = buf[i];
		if ((++n % 3) == 0 && i != len-1) buf2[j++] = ',';
	}
	buf2[j] = '\0';

	return buf2;
}

char *FormatNumberStr(PSTR bzStr)
{
	static char	buf2[100];
	int			len, n, i, j;

	len = strlen(bzStr);
	if(len < 4) {
		strcpy(buf2, bzStr);
		return buf2;
	}
	n = 3 - (len % 3);
	for (i = j = 0; i < len; i++)
	{
		buf2[j++] = *(bzStr + i);
		if ((++n % 3) == 0 && i != len-1) buf2[j++] = ',';
	}
	buf2[j] = '\0';

	return buf2;
}

long GetMinValue(long *lArray, int element_num)
{
	int		i;
	long	min;

	min = abs(lArray[0]);
	for(i = 1; i < element_num; i++)
	{
		if(min > lArray[i]) min = lArray[i];
	}
	return min;
}

long GetMaxValue(long *lArray, int element_num)
{
	int		i ;
	long	max;

	max = abs(lArray[0]);
	for(i = 1; i < element_num; i++)
	{
		if(max < lArray[i]) max = lArray[i];
	}
	return max;
}

void GetMinDoubleValue(double *dArray, int element_num, double *ret_val)
{
    int i;
    double min, tmin;

    if(dArray[0] < 0.00) min = dArray[0] * (-1.0);
    else                 min = dArray[0];
    for(i = 1; i < element_num; i++)
    {
        if(dArray[i] < 0.00) tmin = dArray[i] * (-1.0);
        else                 tmin = dArray[i];
        if(min > tmin) min = tmin;
    }

    *ret_val = min;
}

void GetMaxDoubleValue(double *dArray, int element_num, double *ret_val)
{
    int i;
    double max, tmax;

    if(dArray[0] < 0.00) max = dArray[0] * (-1.0);
    else                 max = dArray[0];
    for(i = 1; i < element_num; i++)
    {
        if(dArray[i] < 0.00) tmax = dArray[i] * (-1.0);
        else                 tmax = dArray[i];
        if(max < tmax) max = tmax;
    }
    *ret_val = max;
}

char *LeftSpaceInsert( LPSTR Source, int nTotalLen )
{
	int				iLen ;
	static BYTE		szReturnBuf[300];

	iLen = nTotalLen - strlen(Source);
	if(iLen <= 0 || nTotalLen > 300) {
		strcpy(&szReturnBuf[0], Source);
	} else {
		memset(&szReturnBuf[0], 0x20, iLen);
		strcpy(&szReturnBuf[iLen], Source);
		szReturnBuf[nTotalLen] = 0x00;
	}
	return szReturnBuf ;
}

char *RightSpaceInsert( LPSTR Source, int nTotalLen )
{
	int				iLen ;
	static BYTE		szReturnBuf[300];

	if(nTotalLen > 300) {
		szReturnBuf[0] = 0x00;
	} else {
		iLen = strlen(Source);
		strcpy(&szReturnBuf[0], Source);
		memset(&szReturnBuf[iLen], 0x20, nTotalLen - iLen);
		szReturnBuf[nTotalLen] = 0x00;
	}
	return szReturnBuf ;
}
