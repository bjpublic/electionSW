#include "Main.h"
#include <ociapr.h>

BOOL DBSelectIpsiData( HWND hWnd, HWND hListBox, HWND hListTime, LPSTR SqlCom, int nType, int nCols )
{
	int		i ;
	LONG	lTotal1, lTotal2 ;
	short	ind_temp[COLS_MAX_DATA];
	char	select_temp[COLS_MAX_DATA][21] ;
	BYTE	sFullSpaceData[63] ;

						/* open a cursor for the select from REPT_MST	*/
	if (oopen(SEL_CURS, LDA, (char  *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

								/* parse cursor						*/
								/* parse the INSERT SQL statement	*/
	if (osql3(SEL_CURS, (char  *)SqlCom, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}
	for( i = 0; i < nCols; i++ )
	{
		if (odefin(SEL_CURS, i + 1, (char *)&select_temp[i][0], 30, NULLTERM, -1,
					(short *)&ind_temp[i], (char *)0, -1, -1, (short *)0, (short *)0))
		{
			OracleErrorCode(hWnd, SEL_CURS);
			return FALSE ;
		}
	}
	if (oexec(SEL_CURS))	/* execute the query to get a new active set	*/
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

	switch( nType )
	{
		case 0 :
			lTotal1 = 0L;
			lTotal2 = 0L;

			SetWindowText(hListTime, "") ;
			while(1)
			{
				if (ofetch(SEL_CURS)) break ;

				memset(sFullSpaceData, 0x20, sizeof(sFullSpaceData)) ;
				strncpy( sFullSpaceData, &select_temp[0][0], strlen(&select_temp[0][0]) );
				strncpy( &sFullSpaceData[1], &select_temp[1][0], strlen(&select_temp[1][0]) );
				strncpy( &sFullSpaceData[21], &select_temp[2][0], strlen(&select_temp[2][0]) );
				strncpy( &sFullSpaceData[29], &select_temp[3][0], strlen(&select_temp[3][0]) );
				strncpy( &sFullSpaceData[38], &select_temp[4][0], strlen(&select_temp[4][0]) );
				sFullSpaceData[38 + strlen(&select_temp[4][0])] = 0x00 ;
				SendMessage(hListBox, LB_ADDSTRING, 0, (LPARAM)sFullSpaceData);
				SetWindowText(hListTime, &select_temp[5][0]) ;
				lTotal1 += atol(&select_temp[2][0]);
				lTotal2 += atol(&select_temp[3][0]);
			}
			if( lTotal1 > 0)
			{
				wsprintf(sFullSpaceData, "%d", lTotal1) ;
				SetWindowText(GetDlgItem(hWnd, IDC_TOTAL1),sFullSpaceData) ;
				wsprintf(sFullSpaceData, "%d", lTotal2) ;
				SetWindowText(GetDlgItem(hWnd, IDC_TOTAL2), sFullSpaceData) ;

				sprintf(sFullSpaceData, "%7.2f", (float)((float)lTotal2 / (float)lTotal1)) ;
				SetWindowText(GetDlgItem(hWnd, IDC_TOTALRATE), sFullSpaceData) ;
			} else {
				SetWindowText(GetDlgItem(hWnd, IDC_TOTAL1)," ") ;
				SetWindowText(GetDlgItem(hWnd, IDC_TOTAL2), " ") ;
				SetWindowText(GetDlgItem(hWnd, IDC_TOTALRATE), " ") ;
			}

			break ;

		case 11 :					// Combo Box?? ???��? + PRIMARY Key Display
			while(1)
			{
				if (ofetch(SEL_CURS)) break ;
				memset(sFullSpaceData, 0x20, sizeof(sFullSpaceData)) ;
				strncpy( sFullSpaceData, &select_temp[0][0], strlen(&select_temp[0][0]) );
				strncpy( &sFullSpaceData[25], &select_temp[1][0], strlen(&select_temp[1][0]) );
				sFullSpaceData[25 + strlen(&select_temp[1][0])] = 0x00 ;
				SendMessage(hListBox, CB_ADDSTRING, 0, (LPARAM)sFullSpaceData);
			}
			break ;
	}

	if (oclose(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}
	return TRUE ;
}


BOOL DBGetSysdate( HWND hWnd, PSTR pstrSysBuf )
{
	SHORT	ind_sys_date ;
	BYTE	sys_date[15] ;
	BYTE	*QrySysdate = "SELECT TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') FROM DUAL" ;

	pstrSysBuf[0] = 0x00;
						/* open a cursor for the select from REPT_MST	*/
	if (oopen(SEL_CURS, LDA, (char  *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE;
	}

						/* parse cursor									*/
	if (osql3(SEL_CURS, (char  *)QrySysdate, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE;
	}

						/* Define output buffers for the all fields		*/
						/* in the select list of our query				*/
	if (odefin(SEL_CURS, 1, (char  *)sys_date, sizeof(sys_date),
							NULLTERM, -1, (short  *)&ind_sys_date,
							(char  *)0, -1, -1, (short  *)0, (short  *)0))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE;
	}

						/* execute the query to get a new active set	*/
	if (oexec(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE;
	}

	if (ofetch(SEL_CURS))
	{
		if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
		return  FALSE;
	}

	if (oclose(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}
	lstrcpy(pstrSysBuf, sys_date) ;

	return TRUE;
}

