
typedef  struct					/* ORACLE Connect Information		*/
{
	BOOL	connected;			/* Is there a current connection?	*/
	BOOL	opened;				/* Is the cursor open?				*/
	BOOL	nomore;				/* Have we fetched all the rows?	*/
} ORACLE_SESSION ;

typedef  struct
{
	BYTE		DBLogid[10] ;			/* DB Login User ID			*/
	BYTE		DBPass[10] ;			/* DB Login Password		*/
	BYTE		DBServer[20] ;			/* Server Name				*/
} ORACLE_ENV ;

typedef  struct
{
	BYTE		Vote98[2][15] ;				/* ???????, ??????		*/
	BYTE		Vote99[2][15] ;				/* ???????, ??????		*/
	BYTE		VoteRate[2][15] ;		/* 98,99					*/		
} VOTE_ENV ;


typedef  struct
{
	BYTE		Data[11][21] ;			/* SELECT DATA 			*/
} ELECT_DATA1 ;

typedef  struct
{
	BYTE		Data[11][21] ;		/* SELECT DATA 			*/
	long		val ;
} ELECT_DISPDATA ;

