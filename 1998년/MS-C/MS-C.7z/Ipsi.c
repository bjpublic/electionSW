#include "Main.h" 
#include "Rtx32.h" 


static	void	InitProc			( HWND ) ;
static	void	UniversityDelProc	( HWND ) ;
static	void	OnAirProc			( HWND ) ;
static	void	OnAirStopProc		( HWND ) ;
static	void	GetCollectionProc	( HWND ) ;
static	void	OnAirSendProc		( HWND ) ;
static	void	GetColForUniv		( HWND ) ;
static	void	GetColForUnivClick	( HWND ) ;

static	void	IpsiRTXInitProc		( void ) ;
static	int		IpsiRTXSendProc		( void ) ;
static	void	IpsiRTXClearProc	( HWND, int ) ;
static	void	PreOnAirSendProc	( HWND ) ;

/*
static	void	StockOnAirProc		( HWND ) ;
static	void	StockDollarDisp		( HWND ) ;
static	void	StockTotalDisp		( void ) ;
static	void	StockTimeDisp		( void ) ;
static	void	StockCostDisp		( int, int, BOOL ) ;

static	BYTE	szRxtCommBuf[20][150] ;
static	double	dTimeTotal[STOCK_DIFMAX] ;
static	double	dTimeGererang[STOCK_DIFMAX] ;
static	double	dOneDotValue[2], dYValue[2][3] ;				// ????? Y?? ??
static	int		nYpos[STOCK_DIFMAX] ;
*/
int				nPreUniPos, nCurUniPos, nColRateDBpos, nColDispNum, nEF_DISPnum ;
BYTE			szRxtCommBuf[10][150] ;

LRESULT CALLBACK IpsiOnAir(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
		case WM_INITDIALOG :
			nPreUniPos = -1 ;
			nCurUniPos = -1 ;
			nColDispNum = 0 ;
			nEF_DISPnum = -1 ;
			nColRateDBpos = -1 ;
			SetDlgItemInt( hDlg, IDC_DISPNUM, 7, FALSE ); 
			InitProc( hDlg ) ;
			return (TRUE);

		case WM_COMMAND :
			if ( LOWORD(wParam) == IDC_SEND)
			{
				OnAirSendProc( hDlg ) ;
				return (TRUE);
			}

			if ( LOWORD(wParam) == IDC_LIST1 )
			{
				GetColForUnivClick( hDlg ) ;
				IpsiRTXClearProc(hDlg, 1);
				return (TRUE);
			}
			
			if ( LOWORD(wParam) == IDC_IPSIDEL )
			{
				UniversityDelProc( hDlg ) ;
				return (TRUE);
			}

			if ( LOWORD(wParam) == IDC_STOP)
			{
				OnAirStopProc( hDlg ) ;
				return (TRUE);
			}

			if ( LOWORD(wParam) == ID_ONAIR)
			{
				OnAirProc( hDlg ) ;
// KIM
				PreOnAirSendProc( hDlg ) ;
				return (TRUE);
			}

			if ( LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, FALSE);
				return (TRUE);
			}
			return (TRUE);
	}
	return (FALSE);
}

static void UniversityDelProc (HWND hDlg)
{
	int		i ;

	i = SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_GETCURSEL, 0, 0L);
	if(i != LB_ERR) SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_DELETESTRING, i, 0L);
}

static void InitProc (HWND hDlg)
{
	int		i ;

	BYTE		Data[100] ;		/* TOTAL_MIN,TOTAL_MAX,TOTAL,COUNT	*/

	for( i = 0; i < nUniTotalCount; i++)
	{
		memset(Data, 0x00, sizeof(Data)) ;
		strcpy(Data, &IpsiUniversity[i].Data[0][0]) ;
		strcat(Data, &IpsiUniversity[i].Data[1][0]) ;
		SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_ADDSTRING, 0, (LPARAM)(LPCSTR)Data);
	}
	SendMessage ( GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)(LPCSTR)"???");
	SendMessage ( GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)(LPCSTR)"????");
	SendMessage ( GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)(LPCSTR)"????");
	SendMessage ( GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)(LPCSTR)"???");
	SendMessage ( GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)(LPCSTR)"????");

	SendMessage ( GetDlgItem(hDlg, IDC_COMBO1), CB_SETCURSEL, 0, 0L);
	memset(szIpsiGubun, 0x00, sizeof(szIpsiGubun)) ;
	sprintf(szIpsiGubun, "%d", 1) ;

	IpsiRTXInitProc( ) ;
}


static void OnAirProc ( HWND hDlg )
{
	int		i ;

	nColDispNum = GetDlgItemInt( hDlg, IDC_DISPNUM, FALSE, FALSE ); 
	if(nColDispNum < 1) return ;

	i = SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_GETCURSEL, 0, 0L );
	if(i == LB_ERR) nCurUniPos = 0 ;

	i = SendMessage ( GetDlgItem(hDlg, IDC_COMBO1), CB_GETCURSEL, 0, 0L );
	if(i == LB_ERR) i = 0 ;

	SendMessage ( GetDlgItem(hDlg, IDC_COMBO1), CB_SETCURSEL, i, 0L );
	i++;
	memset(szIpsiGubun, 0x00, sizeof(szIpsiGubun)) ;
	sprintf(szIpsiGubun, "%d", i) ;

	EnableWindow( GetDlgItem(hDlg, IDC_COMBO1), FALSE ) ;
	EnableWindow( GetDlgItem(hDlg, IDC_DISPNUM), FALSE ) ;

	EnableWindow( GetDlgItem(hDlg, ID_ONAIR), FALSE ) ;
	EnableWindow( GetDlgItem(hDlg, IDCANCEL), FALSE ) ;
	EnableWindow( GetDlgItem(hDlg, IDC_IPSIDEL), FALSE ) ;

	EnableWindow( GetDlgItem(hDlg, IDC_SEND), TRUE ) ;
	EnableWindow( GetDlgItem(hDlg, IDC_STOP), TRUE ) ;
	SetFocus( GetDlgItem(hDlg, IDC_SEND) ) ;

//	IpsiRTXClearProc(hDlg, 0) ;
	GetColForUniv( hDlg ) ;
	IpsiRTXClearProc(hDlg, 1) ;
}

static void OnAirStopProc ( HWND hDlg )
{
	EnableWindow( GetDlgItem(hDlg, IDC_COMBO1), TRUE ) ;
	EnableWindow( GetDlgItem(hDlg, IDC_DISPNUM), TRUE ) ;

	EnableWindow( GetDlgItem(hDlg, ID_ONAIR), TRUE ) ;
	EnableWindow( GetDlgItem(hDlg, IDCANCEL), TRUE ) ;
	EnableWindow( GetDlgItem(hDlg, IDC_IPSIDEL), TRUE ) ;

	EnableWindow( GetDlgItem(hDlg, IDC_SEND), FALSE ) ;
	EnableWindow( GetDlgItem(hDlg, IDC_STOP), FALSE ) ;
}

static void GetCollectionProc ( HWND hDlg )
{
	int			i, j ;
	BYTE		szUniName[31], szBuffer[200] ;

	SendMessage ( GetDlgItem(hDlg, IDC_LIST2), LB_RESETCONTENT, 0, 0L);
	for( i = 0; i < nRateTotalCount; i++)
	{
		memset(szBuffer, 0x00, sizeof(szBuffer)) ;
		strcpy(szBuffer, &IpsiRate[i].Data[0][0]) ;
		for( j = 1; j < 6; j++)
		{
			strcat(szBuffer, ",") ;
			strcat(szBuffer, &IpsiRate[i].Data[j][0]) ;
		}
		SendMessage ( GetDlgItem(hDlg, IDC_LIST2), LB_ADDSTRING, 0, (LPARAM)(LPCSTR)szBuffer );
	}

	SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_GETTEXT, nCurUniPos, (LPARAM)(LPCSTR)szBuffer );
	memset(szUniName, 0x00, sizeof(szUniName)) ;
	memcpy(szUniName, &szBuffer[0], 24) ;
	SetWindowText(GetDlgItem(hDlg, IDC_UNIV1), szUniName ) ;

	memset(szBuffer, 0x00, sizeof(szBuffer)) ;
	strcpy(szBuffer, &IpsiRate[0].Data[4][0]) ;
	SetWindowText(GetDlgItem(hDlg, IDC_TIME1), szBuffer ) ;

	nColRateDBpos = 0 ;
}

static void PreOnAirSendProc ( HWND hDlg )
{
	int		nTotal ;

	nTotal = SendMessage ( GetDlgItem(hDlg, IDC_LIST2), LB_GETCOUNT, 0, 0L );
	if(nCurUniPos == -1 || nColDispNum < 1 || nTotal < 1) return ;

	nEF_DISPnum = IpsiRTXSendProc( ) ;
}


static void OnAirSendProc ( HWND hDlg )
{
	int			i, nTotal ;
	BYTE		szTimeBuffer[50], szBuffer[200] ;

	nTotal = SendMessage ( GetDlgItem(hDlg, IDC_LIST2), LB_GETCOUNT, 0, 0L );
	if(nCurUniPos == -1 || nColDispNum < 1 || nTotal < 1) return ;

	if(nPreUniPos != nCurUniPos) RTX(RTX_STRING, "EF_CLEAR1 showeffect") ;
	RTX(RTX_STRING, "EF_DISP-0 showeffect") ;
	nPreUniPos = nCurUniPos ;

/*
	nEF_DISPnum = IpsiRTXSendProc( ) ;
	for( i = 0; i < nEF_DISPnum; i++)
	{
		sprintf(&szRxtCommBuf[i][0], "EF_DISP%d showeffect", i) ;
		RTX(RTX_STRING, &szRxtCommBuf[i][0]) ;
	}
*/
//	nEF_DISPnum = IpsiRTXSendProc( ) ;
//	RTX(RTX_STRING, "EF_DISP-0 showeffect") ;

	SendMessage ( GetDlgItem(hDlg, IDC_LIST3), LB_RESETCONTENT, 0, 0L);
	for( i = 0; i < nColDispNum; i++)
	{
		memset(szBuffer, 0x00, sizeof(szBuffer)) ;
		SendMessage ( GetDlgItem(hDlg, IDC_LIST2), LB_GETTEXT, 0, (LPARAM)(LPCSTR)szBuffer );
		if(szBuffer[0] == 0x00) break ;
		SendMessage ( GetDlgItem(hDlg, IDC_LIST3), LB_ADDSTRING, 0, (LPARAM)(LPCSTR)szBuffer );
		SendMessage ( GetDlgItem(hDlg, IDC_LIST2), LB_DELETESTRING, 0, 0L );
	}
	memset(szBuffer, 0x00, sizeof(szBuffer)) ;
	GetWindowText( GetDlgItem(hDlg, IDC_UNIV1), szBuffer, 25) ;
	SetWindowText(GetDlgItem(hDlg, IDC_UNIV2), szBuffer ) ;
	memset(szTimeBuffer, 0x00, sizeof(szTimeBuffer)) ;
	GetWindowText( GetDlgItem(hDlg, IDC_TIME1), szTimeBuffer, 25) ;
	SetWindowText(GetDlgItem(hDlg, IDC_TIME2), szTimeBuffer ) ;

	nColRateDBpos += nColDispNum ;

	nTotal = SendMessage ( GetDlgItem(hDlg, IDC_LIST2), LB_GETCOUNT, 0, 0L );
	if(nTotal < 1)
	{
		nCurUniPos++ ;
		GetColForUniv( hDlg ) ;
	}
//	IpsiRTXClearProc(hDlg, 0);
// KIM

	if(nPreUniPos != nCurUniPos) IpsiRTXClearProc(hDlg, 1);
	nEF_DISPnum = IpsiRTXSendProc( ) ;
//	IpsiRTXClearProc(hDlg, 1);
}

static void GetColForUniv( HWND hDlg )
{
	int			nTotal ;
	BYTE		szBuffer[100] ;

	if(nCurUniPos == -1)  return;
	nTotal = SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_GETCOUNT, 0, 0L );
	while(nCurUniPos < nTotal)
	{
		SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_SETCURSEL, nCurUniPos, 0L );

		SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_GETTEXT, nCurUniPos, (LPARAM)(LPCSTR)szBuffer );
		memset(szIpsiUniCode, 0x00, sizeof(szIpsiUniCode)) ;
		strcpy(szIpsiUniCode, &szBuffer[24]) ;

		if( !DBSelectIpsiData( hDlg, 2 ) ) return;

		if(nRateTotalCount > 0)
		{
			GetCollectionProc ( hDlg ) ;
			break ;
		}
		nCurUniPos++;
	}
}

static void GetColForUnivClick( HWND hDlg )
{
	int			i ;
	BYTE		szUniName[31], szBuffer[100] ;

	i = SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_GETCURSEL, 0, 0L);
	if(i == LB_ERR)  return;

	nCurUniPos = i ;
	SendMessage ( GetDlgItem(hDlg, IDC_LIST1), LB_GETTEXT, i, (LPARAM)(LPCSTR)szBuffer );
//	memset(szUniName, 0x00, sizeof(szUniName)) ;
//	memcpy(szUniName, &szBuffer[0], 24) ;
//	SetWindowText(GetDlgItem(hDlg, IDC_UNIV1), szUniName ) ;

	memset(szIpsiUniCode, 0x00, sizeof(szIpsiUniCode)) ;
	strcpy(szIpsiUniCode, &szBuffer[24]) ;

	SendMessage ( GetDlgItem(hDlg, IDC_LIST2), LB_RESETCONTENT, 0, 0L);
	if( !DBSelectIpsiData( hDlg, 2 ) ) return;

	if(nRateTotalCount > 0)
	{
		GetCollectionProc ( hDlg ) ;
		nCurUniPos = i ;
	}
}

static void IpsiRTXInitProc( void )
{
	RTX(RTX_STRING, "reset clear clearscreen") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "board0 setframebuffer") ;

	RTX(RTX_STRING, "/P_RIGHT { /A 3 array def A astore 0 get A 2 get stringwidth pop sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/P_LEFT { pop moveto } def") ;
	RTX(RTX_STRING, "/F_VALUE1 { 0.99610 0.99610 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 35 scalefont 1 shadowfont 75 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_VALUE2 { 0.99610 0.99610 0.99610 160 setrgbpalette 0.00000 0.00000 0.00000 163 setrgbpalette 0.00000 0.00000 0.00000 166 setrgbpalette 160 selectpalette (HY??????????M) cvn findfont 35 scalefont 0 shadowfont 75 fontwidth 3 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_VALUE3 { 0.99610 0.50000 0.00000 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (HY??????????M) cvn findfont 35 scalefont 1 shadowfont 75 fontwidth 1 edgefont setfont } def");
	RTX(RTX_STRING, "/F_VALUE_11 { 0.99610 0.99610 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 35 scalefont 1 shadowfont 70 fontwidth 2 edgefont setfont } def");


	RTX(RTX_STRING, "/F_UNIV { 0.99610 0.99610 0.99610 160 setrgbpalette 0.00000 0.00000 0.00000 163 setrgbpalette 0.00000 0.00000 0.00000 166 setrgbpalette 160 selectpalette (HY??????????M) cvn findfont 38 scalefont 1 shadowfont 80 fontwidth 2 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_TIME1 { 0.99610 0.99610 0.99610 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (??-?????R) cvn findfont 32 scalefont 0 shadowfont 75 fontwidth 2 edgefont setfont } def");
//HY?��???
	RTX(RTX_STRING, "/F_TIME2 { 0.99610 0.50000 0.50000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 30 scalefont 1 shadowfont 65 fontwidth 1 edgefont setfont } def");

	RTX(RTX_STRING, "/F_TITLE1 { 0.99610 0.99610 0.99610 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (HY?��???) cvn findfont 32 scalefont 0 shadowfont 72 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_TITLE2 { 0.63282 0.99610 0.63282 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 35 scalefont 0 shadowfont 85 fontwidth 2 edgefont setfont } def");

	RTX(RTX_STRING, "/F_DONG { 0.63282 0.99610 0.63282 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY??????????M) cvn findfont 35 scalefont 0 shadowfont 75 fontwidth 2 edgefont setfont } def");

	RTX(RTX_STRING, "/F_MAX_VALUE_11 { 0.46485 0.99610 0.99610 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (HY??????????M) cvn findfont 35 scalefont 1 shadowfont 70 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_MAX_VALUE1 { 0.46485 0.99610 0.99610 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (HY??????????M) cvn findfont 35 scalefont 1 shadowfont 75 fontwidth 2 edgefont setfont } def");
	RTX(RTX_STRING, "/F_MAX_VALUE2 { 0.46485 0.99610 0.99610 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (HY??????????M) cvn findfont 35 scalefont 0 shadowfont 75 fontwidth 3 edgefont setfont } def") ;


//	RTX(RTX_STRING, "/F_VALUE3 { 0.99610 0.99610 0.99610 160 setrgbpalette 0.00000 0.00000 0.00000 163 setrgbpalette 0.00000 0.00000 0.00000 166 setrgbpalette 160 selectpalette (HY??????) cvn findfont 38 scalefont 1 shadowfont 80 fontwidth 2 edgefont setfont } def") ;
//	RTX(RTX_STRING, "/F_UNIV { 0.99610 0.99610 0.99610 160 setrgbpalette 0.00000 0.00000 0.00000 163 setrgbpalette 0.00000 0.00000 0.00000 166 setrgbpalette 160 selectpalette (HY??????????M) cvn findfont 38 scalefont 1 shadowfont 80 fontwidth 2 edgefont setfont } def") ;
//	RTX(RTX_STRING, "/F_UNIV  { 0.61329 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY?????) cvn findfont 35 scalefont 1 shadowfont 80 fontwidth 1 edgefont setfont } def");

	RTX(RTX_STRING, "(snap) effect board1 seteffectframebuffer (c:/ubc/stock/IpsiImage/IpsiMain.tga) layer seteffectlayer showeffect") ;

	RTX(RTX_STRING, "/W_FRAMEBUF1 board0 25 350 130 95 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER1 FULL_LAYER 25 350 130 95 windowlayer def") ;
 	RTX(RTX_STRING, "W_LAYER1 setlayer") ; 
 	RTX(RTX_STRING, "W_LAYER1 clearlayer") ; 
	RTX(RTX_STRING, "F_TITLE1 120 55 (`99????) P_RIGHT (`99????) show") ;
	RTX(RTX_STRING, "F_TITLE2 105 10 (????) P_RIGHT (????) show") ;
	RTX(RTX_STRING, "/EF_DISP1 (snap) effect (up) seteffectdir W_FRAMEBUF1 seteffectframebuffer W_LAYER1 seteffectlayer seteffectasync def") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;
}

/*
static int IpsiRTXSendProc( void )
{
	int			i, j, k, xPos, nDispMaxPos ;
	int			yPos[11] = { 347, 295, 243, 191, 142, 92, 42, 0, 0, 0, 0} ;

	j = 0 ;
	i = nColRateDBpos ;
	nDispMaxPos = nColRateDBpos + nColDispNum ;
	while(i < nRateTotalCount && i < nDispMaxPos)
	{
		sprintf(&szRxtCommBuf[0][0], "/W_FRAMEBUF%d board0 160 %d 489 40 windowframebuffer def", j, yPos[j]) ;
		sprintf(&szRxtCommBuf[1][0], "/W_LAYER%d FULL_LAYER 160 %d 489 40 windowlayer def", j, yPos[j]) ;
		sprintf(&szRxtCommBuf[2][0], "W_LAYER%d setlayer", j) ;
		sprintf(&szRxtCommBuf[3][0], "W_LAYER%d clearlayer", j) ;
		if(strlen(&IpsiRate[i].Data[0][0]) > 11) xPos = 1 ;
		else									 xPos = 10 ;

		if(atoi(&IpsiRate[i].Data[1][0]) > atoi(&IpsiRate[i].Data[2][0]))
		{
			if(strlen(&IpsiRate[i].Data[0][0]) > 13)
			{
				sprintf(&szRxtCommBuf[4][0], "F_VALUE_11 %d 10 (%s) P_LEFT (%s) show", xPos, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
			} else {
				sprintf(&szRxtCommBuf[4][0], "F_VALUE1 %d 10 (%s) P_LEFT (%s) show", xPos, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
			}
			sprintf(&szRxtCommBuf[5][0], "F_VALUE2 250 10 (%s) P_RIGHT (%s) show", &IpsiRate[i].Data[1][0], &IpsiRate[i].Data[1][0]) ;
			sprintf(&szRxtCommBuf[6][0], "F_VALUE2 360 10 (%s) P_RIGHT (%s) show", &IpsiRate[i].Data[2][0], &IpsiRate[i].Data[2][0]) ;
			sprintf(&szRxtCommBuf[7][0], "F_VALUE3 470 10 (???) P_RIGHT (???) show") ;
		} else {
			if(IpsiRate[i].Data[5][0] == '1' )
			{
				if(strlen(&IpsiRate[i].Data[0][0]) > 13)
				{
					sprintf(&szRxtCommBuf[4][0], "F_MAX_VALUE_11 %d 10 (%s) P_LEFT (%s) show", xPos, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
				} else {
					sprintf(&szRxtCommBuf[4][0], "F_MAX_VALUE1 %d 10 (%s) P_LEFT (%s) show", xPos, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
				}
				sprintf(&szRxtCommBuf[5][0], "F_MAX_VALUE2 250 10 (%s) P_RIGHT (%s) show", &IpsiRate[i].Data[1][0], &IpsiRate[i].Data[1][0]) ;
				sprintf(&szRxtCommBuf[6][0], "F_MAX_VALUE2 360 10 (%s) P_RIGHT (%s) show", &IpsiRate[i].Data[2][0], &IpsiRate[i].Data[2][0]) ;
				sprintf(&szRxtCommBuf[7][0], "F_MAX_VALUE2 470 10 (%s) P_RIGHT (%s) show", &IpsiRate[i].Data[3][0], &IpsiRate[i].Data[3][0]) ;
			} else {
				if(strlen(&IpsiRate[i].Data[0][0]) > 13)
				{
					sprintf(&szRxtCommBuf[4][0], "F_VALUE_11 %d 10 (%s) P_LEFT (%s) show", xPos, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
				} else {
					sprintf(&szRxtCommBuf[4][0], "F_VALUE1 %d 10 (%s) P_LEFT (%s) show", xPos, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
				}
				sprintf(&szRxtCommBuf[5][0], "F_VALUE2 250 10 (%s) P_RIGHT (%s) show", &IpsiRate[i].Data[1][0], &IpsiRate[i].Data[1][0]) ;
				sprintf(&szRxtCommBuf[6][0], "F_VALUE2 360 10 (%s) P_RIGHT (%s) show", &IpsiRate[i].Data[2][0], &IpsiRate[i].Data[2][0]) ;
				sprintf(&szRxtCommBuf[7][0], "F_VALUE2 470 10 (%s) P_RIGHT (%s) show", &IpsiRate[i].Data[3][0], &IpsiRate[i].Data[3][0]) ;
			}
		}
		sprintf(&szRxtCommBuf[8][0], "/EF_DISP%d (push) effect (down) seteffectdir W_FRAMEBUF%d seteffectframebuffer W_LAYER%d seteffectlayer 100 seteffectduration def", j, j, j) ;

		for(k = 0; k < 9; k++) { RTX(RTX_STRING, &szRxtCommBuf[k][0]) ; }

		i++;
		j++;
	}

	return j ;
}
*/

static int IpsiRTXSendProc( void )
{
	int			i, j, k, m, xPos, nDispMaxPos ;
	int			yPos[11] = { 347, 295, 243, 191, 142, 92, 42, 0, 0, 0, 0} ;

//	sprintf(&szRxtCommBuf[0][0], "/W_FRAMEBUF%d board0 160 %d 489 40 windowframebuffer def", j, yPos[j]) ;
//	sprintf(&szRxtCommBuf[1][0], "/W_LAYER%d FULL_LAYER 160 %d 489 40 windowlayer def", j, yPos[j]) ;
//	sprintf(&szRxtCommBuf[2][0], "W_LAYER%d setlayer", j) ;
//	sprintf(&szRxtCommBuf[3][0], "W_LAYER%d clearlayer", j) ;
	RTX(RTX_STRING, "/W_FRAMEBUF-0 board0 160 30 489 390 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_LAYER-0 FULL_LAYER 160 30 489 390 windowlayer def") ;
	RTX(RTX_STRING, "W_LAYER-0 setlayer") ;
	RTX(RTX_STRING, "W_LAYER-0 clearlayer") ;

	j = 0 ;
	i = nColRateDBpos ;
	nDispMaxPos = nColRateDBpos + nColDispNum ;
	while(i < nRateTotalCount && i < nDispMaxPos)
	{
		m = yPos[j] - 22;
		if(strlen(&IpsiRate[i].Data[0][0]) > 11) xPos = 1 ;
		else									 xPos = 10 ;

		if(atoi(&IpsiRate[i].Data[1][0]) > atoi(&IpsiRate[i].Data[2][0]))
		{
			if(strlen(&IpsiRate[i].Data[0][0]) > 13)
			{
				sprintf(&szRxtCommBuf[0][0], "F_VALUE_11 %d %d (%s) P_LEFT (%s) show", xPos, m, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
			} else {
				sprintf(&szRxtCommBuf[0][0], "F_VALUE1 %d %d (%s) P_LEFT (%s) show", xPos, m, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
			}
			sprintf(&szRxtCommBuf[1][0], "F_VALUE2 250 %d (%s) P_RIGHT (%s) show", m, &IpsiRate[i].Data[1][0], &IpsiRate[i].Data[1][0]) ;
			sprintf(&szRxtCommBuf[2][0], "F_VALUE2 360 %d (%s) P_RIGHT (%s) show", m, &IpsiRate[i].Data[2][0], &IpsiRate[i].Data[2][0]) ;
			sprintf(&szRxtCommBuf[3][0], "F_VALUE3 470 %d (???) P_RIGHT (???) show", m) ;
		} else {
			if(IpsiRate[i].Data[5][0] == '1' )
			{
				if(strlen(&IpsiRate[i].Data[0][0]) > 13)
				{
					sprintf(&szRxtCommBuf[0][0], "F_MAX_VALUE_11 %d %d (%s) P_LEFT (%s) show", xPos, m, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
				} else {
					sprintf(&szRxtCommBuf[0][0], "F_MAX_VALUE1 %d %d (%s) P_LEFT (%s) show", xPos, m, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
				}
				sprintf(&szRxtCommBuf[1][0], "F_MAX_VALUE2 250 %d (%s) P_RIGHT (%s) show", m, &IpsiRate[i].Data[1][0], &IpsiRate[i].Data[1][0]) ;
				sprintf(&szRxtCommBuf[2][0], "F_MAX_VALUE2 360 %d (%s) P_RIGHT (%s) show", m, &IpsiRate[i].Data[2][0], &IpsiRate[i].Data[2][0]) ;
				sprintf(&szRxtCommBuf[3][0], "F_MAX_VALUE2 470 %d (%s) P_RIGHT (%s) show", m, &IpsiRate[i].Data[3][0], &IpsiRate[i].Data[3][0]) ;
			} else {
				if(strlen(&IpsiRate[i].Data[0][0]) > 13)
				{
					sprintf(&szRxtCommBuf[0][0], "F_VALUE_11 %d %d (%s) P_LEFT (%s) show", xPos, m, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
				} else {
					sprintf(&szRxtCommBuf[0][0], "F_VALUE1 %d %d (%s) P_LEFT (%s) show", xPos, m, &IpsiRate[i].Data[0][0], &IpsiRate[i].Data[0][0]) ;
				}
				sprintf(&szRxtCommBuf[1][0], "F_VALUE2 250 %d (%s) P_RIGHT (%s) show", m, &IpsiRate[i].Data[1][0], &IpsiRate[i].Data[1][0]) ;
				sprintf(&szRxtCommBuf[2][0], "F_VALUE2 360 %d (%s) P_RIGHT (%s) show", m, &IpsiRate[i].Data[2][0], &IpsiRate[i].Data[2][0]) ;
				sprintf(&szRxtCommBuf[3][0], "F_VALUE2 470 %d (%s) P_RIGHT (%s) show", m, &IpsiRate[i].Data[3][0], &IpsiRate[i].Data[3][0]) ;
			}
		}
//		sprintf(&szRxtCommBuf[8][0], "/EF_DISP%d (push) effect (down) seteffectdir W_FRAMEBUF%d seteffectframebuffer W_LAYER%d seteffectlayer 100 seteffectduration def", j, j, j) ;

		for(k = 0; k < 4; k++) { RTX(RTX_STRING, &szRxtCommBuf[k][0]) ; }

		i++;
		j++;
	}
//	sprintf(&szRxtCommBuf[8][0], "/EF_DISP%d (push) effect (down) seteffectdir W_FRAMEBUF%d seteffectframebuffer W_LAYER%d seteffectlayer 100 seteffectduration def", j, j, j) ;
//RTX(RTX_STRING, "W_LAYER-0 clearlayer") ;
	RTX(RTX_STRING, "/EF_DISP-0 (wipe) effect (down) seteffectdir W_FRAMEBUF-0 seteffectframebuffer W_LAYER-0 seteffectlayer 500 seteffectduration def") ;

	return j ;
}

static void IpsiRTXClearProc( HWND hDlg, int nType )
{
	int			i, nLen, nCharHeight ;
	BYTE		szTwoUniv[3], szTimeBuffer[50], szBuffer[200] ;

	switch (nType) 
	{
		case 0:
/*
			RTX(RTX_STRING, "/W_FRAMEBUF_A board0 160 10 489 390 windowframebuffer def") ;
			RTX(RTX_STRING, "/W_LAYER_A FULL_LAYER 160 10 489 390 windowlayer def") ;
			RTX(RTX_STRING, "W_LAYER_A setlayer") ;
			RTX(RTX_STRING, "W_LAYER_A clearlayer") ;
			RTX(RTX_STRING, "/EF_CLEAR0 (snap) effect W_FRAMEBUF_A seteffectframebuffer W_LAYER_A seteffectlayer def") ;
*/
			break ;

		case 1:
/*
RTX(RTX_STRING, "/W_FRAMEBUF_A board0 160 10 489 390 windowframebuffer def") ;
RTX(RTX_STRING, "/W_LAYER_A FULL_LAYER 160 10 489 390 windowlayer def") ;
RTX(RTX_STRING, "W_LAYER_A setlayer") ;
RTX(RTX_STRING, "W_LAYER_A clearlayer") ;
RTX(RTX_STRING, "/EF_CLEAR0 (snap) effect W_FRAMEBUF_A seteffectframebuffer W_LAYER_A seteffectlayer def") ;
*/
nEF_DISPnum = IpsiRTXSendProc( ) ;

			memset(szBuffer, 0x00, sizeof(szBuffer)) ;
			GetWindowText( GetDlgItem(hDlg, IDC_UNIV1), szBuffer, 30) ;
			memset(szTimeBuffer, 0x00, sizeof(szTimeBuffer)) ;
			GetWindowText( GetDlgItem(hDlg, IDC_TIME1), szTimeBuffer, 30) ;

			RTX(RTX_STRING, "/W_FRAMEBUF_A board0 42 41 90 265 windowframebuffer def") ;
			RTX(RTX_STRING, "/W_LAYER_A FULL_LAYER 42 41 90 265 windowlayer def") ;
			RTX(RTX_STRING, "W_LAYER_A setlayer") ;
			RTX(RTX_STRING, "W_LAYER_A clearlayer") ;

			nLen = SpaceTrim(&szBuffer[0]) ;
			if(nLen > 8) nCharHeight = 40 ;
			else if(nLen < 8)   nCharHeight = 55 ;
			else				nCharHeight = 50 ;

if(!memcmp(&szBuffer[0], "??????", 6))
{
	nCharHeight = 50 ;
	memset(szTwoUniv, 0x00, sizeof(szTwoUniv)) ;
//	memcpy(szTwoUniv, &szBuffer[(i * 2)], 2) ;
	sprintf(&szRxtCommBuf[0][0], "F_UNIV 35 %d (??) P_LEFT (??) show", 230) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	sprintf(&szRxtCommBuf[0][0], "F_UNIV 35 %d (??) P_LEFT (??) show", 230 - (1 * nCharHeight)) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	sprintf(&szRxtCommBuf[0][0], "F_UNIV 35 %d (??) P_LEFT (??) show", 230 - (2 * nCharHeight)) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	sprintf(&szRxtCommBuf[0][0], "F_DONG 27 %d (????) P_LEFT (????) show", 220 - (3 * nCharHeight)) ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;


	if(!memcmp(szTimeBuffer, "??", 2))
	{
		sprintf(&szRxtCommBuf[0][0], "F_TIME2 55 20 (%s) P_CENTER (%s) show", &szTimeBuffer[0], &szTimeBuffer[0]) ;
	} else {
		sprintf(&szRxtCommBuf[0][0], "F_TIME1 55 20 (%s) P_CENTER (%s) show", &szTimeBuffer[0], &szTimeBuffer[0]) ;
	}

	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
	RTX(RTX_STRING, "/EF_CLEAR1 (push) effect (right) seteffectdir W_FRAMEBUF_A seteffectframebuffer W_LAYER_A seteffectlayer 100 seteffectduration seteffectasync def") ;

	break ;
}
			for( i = 0; i < 5; i++)
			{
				if(szBuffer[(i * 2)] == 0x00) break ;
				memset(szTwoUniv, 0x00, sizeof(szTwoUniv)) ;
				memcpy(szTwoUniv, &szBuffer[(i * 2)], 2) ;
				sprintf(&szRxtCommBuf[0][0], "F_UNIV 35 %d (%s) P_LEFT (%s) show", 220 - (i * nCharHeight), &szTwoUniv[0], &szTwoUniv[0]) ;
				RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
			}
			if(!memcmp(szTimeBuffer, "??", 2))
			{
				sprintf(&szRxtCommBuf[0][0], "F_TIME2 55 20 (%s) P_CENTER (%s) show", &szTimeBuffer[0], &szTimeBuffer[0]) ;
			} else {
				sprintf(&szRxtCommBuf[0][0], "F_TIME1 55 20 (%s) P_CENTER (%s) show", &szTimeBuffer[0], &szTimeBuffer[0]) ;
			}
			RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
			RTX(RTX_STRING, "/EF_CLEAR1 (push) effect (right) seteffectdir W_FRAMEBUF_A seteffectframebuffer W_LAYER_A seteffectlayer 100 seteffectduration seteffectasync def") ;
			break ;
		default : return ;
	}


}