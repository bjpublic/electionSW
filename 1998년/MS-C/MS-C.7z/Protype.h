						/* In InitProc.c				*/
BOOL				InitFindWindow				( void ) ;
BOOL				GlobalVarInitProc			( void ) ;
BOOL				OracleEnvFileRead			( HWND ) ;
BOOL				OracleEnvFileWrite			( HWND ) ;
BOOL				VoteEnvFileRead			( HWND ) ;
BOOL				VoteEnvFileWrite			( HWND ) ;

						/* OraComm.c					*/
BOOL				OracleLogonProgress			( HWND, HINSTANCE, PSTR, PSTR, PSTR ) ;
BOOL				OracleLogon					( HWND, PSTR, PSTR, PSTR ) ;
BOOL				OracleDisconnect			( HWND ) ;
BOOL				OracleErrorCode				( HWND, struct cda_def *) ;
BOOL				DBGetSysdate				( HWND, PSTR ) ;

						/* RTXComm.c					*/
void				RTXInitReset				( void ) ;
void				RTXInitClear				( void ) ;

						/* Connect.c					*/
LRESULT CALLBACK	OracleConnectDlg			( HWND, UINT, WPARAM, LPARAM ) ;

						/* .c					*/
LRESULT CALLBACK	VotesuInpDlg			( HWND, UINT, WPARAM, LPARAM ) ;

						/* Utility.c					*/
LRESULT	CALLBACK	EditProc					( HWND, UINT, WPARAM, LPARAM ) ;
int					SpaceTrim					( LPSTR ) ;
char				*LeftSpaceTrim				( LPSTR ) ;
char				*RightSpaceTrim				( LPSTR ) ;
char				*FormatNumberLong			( long ) ;
char				*FormatNumberStr			( PSTR ) ;
long				GetMinValue					( long *, int ) ;
long				GetMaxValue					( long *, int ) ;
void				GetMinDoubleValue			( double *, int, double * ) ;
void				GetMaxDoubleValue			( double *, int, double * ) ;
char				*LeftSpaceInsert			( LPSTR, int ) ;
char				*RightSpaceInsert			( LPSTR, int ) ;

						/* In GetElect.c				*/
BOOL				DBSelectElectData			( HWND, int ) ;


LRESULT	CALLBACK	NewsOnAir					( HWND, UINT, WPARAM, LPARAM ) ;
