#include "Main.h"

LRESULT CALLBACK VotesuInpDlg( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	double		dVal, dVal1, dVal2 ;

	switch (message) 
	{
		case WM_INITDIALOG :
			VoteEnvFileRead ( hDlg ) ;
			SetDlgItemText( hDlg, IDC_EDIT1, &VoteEnv.Vote98[0][0]);
			SetDlgItemText( hDlg, IDC_EDIT3, &VoteEnv.Vote98[1][0]);
			SetDlgItemText( hDlg, IDC_EDIT2, &VoteEnv.Vote99[0][0]);
			SetDlgItemText( hDlg, IDC_EDIT4, &VoteEnv.Vote99[1][0]);
			return (TRUE);

		case WM_COMMAND :
			if ( LOWORD(wParam) == IDOK)
			{
				GetDlgItemText( hDlg, IDC_EDIT1, &VoteEnv.Vote98[0][0], 10); 
				GetDlgItemText( hDlg, IDC_EDIT3, &VoteEnv.Vote98[1][0], 10); 
				GetDlgItemText( hDlg, IDC_EDIT2, &VoteEnv.Vote99[0][0], 10); 
				GetDlgItemText( hDlg, IDC_EDIT4, &VoteEnv.Vote99[1][0], 10); 

				dVal1 = atof(&VoteEnv.Vote98[0][0]);
				dVal2 = atof(&VoteEnv.Vote98[1][0]);
				dVal = (dVal2 / dVal1)  * 100.0 ;
				sprintf(&VoteEnv.VoteRate[0][0], "%.1f", dVal) ;
				dVal1 = atof(&VoteEnv.Vote99[0][0]);
				dVal2 = atof(&VoteEnv.Vote99[1][0]);
				dVal = (dVal2 / dVal1) * 100.0 ;
				sprintf(&VoteEnv.VoteRate[1][0], "%.1f", dVal) ;
				VoteEnvFileWrite( hDlg ) ;
				EndDialog(hDlg, TRUE);
				return (TRUE);
			}
			if ( LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, FALSE);
				return (TRUE);
			}
			break;
	}
	return (FALSE);
}
