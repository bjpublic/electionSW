#include "Main.h"
#include <ociapr.h>

BOOL DBSelectElectData( HWND hWnd, int nType )
{
	int		i, nCount, nCols ;
	short	ind_temp[COLS_MAX_DATA];
	char	select_temp[COLS_MAX_DATA][41] ;
	BYTE	SqlCom[300] ;
	long	lVal[15] ;
	double	dVal ;

	switch( nType )
	{
		case 0 :			// ?????? SELECT
			nCols = 1 ;
			strcpy( SqlCom, "SELECT (DPTOTAL + INVALID) * 100.0 / NVOTE" ) ;
			strcat( SqlCom, " FROM VSGG WHERE SGGCODE = 5000" ) ;
			break ;

		case 1 :			// ?????? SELECT
			nCols = 11 ;
//			memset(&StockTotal, 0x00, sizeof(STOCK_TOTAL)) ;
			strcpy( SqlCom, "SELECT VSGG.SGGCODE,VSGG.SGGNAME,VSGG.NVOTE,VSGG.GPEND," ) ;
			strcat( SqlCom, "VDPH.WBJSEQ,VDPH.WBJNAME,VDPH.WBJSTAT,VDPH.DPCOUNT," ) ;
			strcat( SqlCom, "JD.JDNAME,VSGG.DPTOTAL," ) ;
			strcat( SqlCom, "DECODE(VSGG.DPTOTAL,0,0,round((100 * VDPH.DPCOUNT / VSGG.DPTOTAL), 1))");
			strcat( SqlCom, " FROM VDPH,JD,VSGG" ) ;
			strcat( SqlCom, " WHERE VSGG.SGGCODE = VDPH.SGGCODE and");
			strcat( SqlCom, " VDPH.JDCODE = JD.JDCODE and" ) ;
			strcat( SqlCom, " VSGG.SGGCODE = 5000 and VSGG.DPTOTAL > 0" ) ;
			strcat( SqlCom, " ORDER BY VSGG.SGGCODE, VDPH.DPCOUNT DESC, VDPH.WBJSEQ" ) ;
			break ;
	}

						/* open a cursor for the select from REPT_MST	*/
	if (oopen(SEL_CURS, LDA, (char *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

								/* parse cursor						*/
								/* parse the INSERT SQL statement	*/
	if (osql3(SEL_CURS, (char *)&SqlCom[0], -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

	for( i = 0; i < nCols; i++ )
	{
		if (odefin(SEL_CURS, i + 1, (char *)&select_temp[i][0], 30, NULLTERM, -1,
					(short *)&ind_temp[i], (char *)0, -1, -1, (short *)0, (short *)0))
		{
			OracleErrorCode(hWnd, SEL_CURS);
			return FALSE ;
		}
	}
	if (oexec(SEL_CURS))	/* execute the query to get a new active set	*/
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}


	nCount = 0 ;
	switch( nType )
	{
		case 0 :
			if (ofetch(SEL_CURS))
			{
				if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
				break ;
			}
			nVoteOpenRate = atof(&select_temp[0][0]);
			if(nVoteOpenRate > 99.999999) 
			{
				strcpy(&szVoteOpenRate[0], "???"); ;
			} else {
				sprintf(&szVoteOpenRate[0], "%.1f", nVoteOpenRate);
				strcat(&szVoteOpenRate[0], "%");
			}
//			strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &select_temp[i][0], 8 ) ) ;
//			strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
//			nVoteOpenRate ;
			break ;

		case 1 :
			while( nCount < ELECT_MAXDATA )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}

				for( i = 0; i < nCols; i++ )
				{
					switch( i )
					{
//						case 6 :		// ????
//							strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &select_temp[i][0], 8 ) ) ;
//							strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
//							break;
						case 4 :		// ???
							strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &select_temp[i][0], 5 ) ) ;
							strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
							break;
						case 5 :		// ????
							strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &select_temp[i][0], 10 ) ) ;
							strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
							break;
						case 8 :		// ????
							strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &select_temp[i][0], 12 ) ) ;
							strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
							break;
						case 10 :		// ?????
							dVal = atof(&select_temp[i][0]) ;
							sprintf(&select_temp[i][0], "%.1f", dVal);
							strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &select_temp[i][0], 12 ) ) ;
							strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
							strcat( &ElectData1[nCount].Data[i][0], "%");
							strcat( &ElectDispData[nCount].Data[i][0], "%");
							break;
						case 2 :		// ??????
						case 9 :		// ??????
							strcpy( &ElectDispData[nCount].Data[i][0], FormatNumberStr(&select_temp[i][0]) ) ;
							strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &ElectDispData[nCount].Data[i][0], 15 ) ) ;
							break;
						case 6 :
							strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &select_temp[i][0], 8 ) ) ;
							if(!strcmp(&select_temp[i][0], "???"))
							{
								strcpy( &ElectDispData[nCount].Data[i][0], "??" ) ;
							} else if(strcmp(&select_temp[i][0], "????") && strcmp(&select_temp[i][0], "????"))
							{
								strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
							} else {
								ElectDispData[nCount].Data[i][0] = 0x00 ;
							}
//							strcpy( &ElectData1[nCount].Data[i][0], &select_temp[i][0] ) ;
//							strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
							break;
						case 7 :		// ?????
							ElectDispData[nCount].val = atol(&select_temp[i][0]);
							strcpy( &ElectDispData[nCount].Data[i][0], FormatNumberStr(&select_temp[i][0]) ) ;
							strcpy( &ElectData1[nCount].Data[i][0], LeftSpaceInsert( &ElectDispData[nCount].Data[i][0], 15 ) ) ;
							break;

						default :
							strcpy( &ElectData1[nCount].Data[i][0], &select_temp[i][0] ) ;
							strcpy( &ElectDispData[nCount].Data[i][0], &select_temp[i][0] ) ;
							break;
					}
				}
				nCount++ ;
			}
			nReadedCount = nCount;
			break ;
	}

	if (oclose(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}
	return TRUE ;
}
