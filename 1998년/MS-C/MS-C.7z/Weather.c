#include "Main.h" 
#include "Rtx32.h" 

static	void	Weather1Disp		( void ) ;
static	void	Weather2Disp		( void ) ;
static	void	Weather3Disp		( void ) ;
static	void	Weather4Disp		( void ) ;
static	void	Weather5Disp		( void ) ;
static	void	Weather6Disp		( void ) ;

static	void	Weather1StandBy		( void ) ;
static	void	Weather2StandBy		( void ) ;
static	void	Weather3StandBy		( void ) ;
static	void	Weather4StandBy		( void ) ;
static	void	Weather5StandBy		( void ) ;
static	void	Weather6StandBy		( void ) ;

static	BYTE	szRxtCommBuf[10][150] ;
static	int		nDispNum, nMovingCount ;

LRESULT CALLBACK WeatherOnAir(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
//	RTX(RTX_STRING, "/F_VALUE1 { 1.0 1.0 0.0 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY�߰���) cvn findfont 60 scalefont 2 shadowfont 90 fontwidth 4 edgefont setfont } def") ;
//	RTX(RTX_STRING, "/F_VALUE2 { 0.99610 0.99610 0.99610 160 setrgbpalette 0.00000 0.00000 0.00000 163 setrgbpalette 0.00000 0.00000 0.00000 166 setrgbpalette 160 selectpalette (HY��������B) cvn findfont 32 scalefont 0 shadowfont 100 fontwidth 3 edgefont setfont } def") ;
	switch (message) 
	{
		case WM_INITDIALOG :
			SetWindowText(GetDlgItem(hDlg, IDC_DATE), DBSysDate ) ;
			SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE), "����غ� �Ϸ�" ) ;
			SetDlgItemInt( hDlg, IDC_COUNT, 5, FALSE) ;
			nDispNum = 1 ;
			Weather1StandBy( ) ;
			return (TRUE);

		case WM_COMMAND :
			if ( LOWORD(wParam) == ID_ONAIR)
			{
				switch (nDispNum)
				{
					case 1 :
						nMovingCount = GetDlgItemInt( hDlg, IDC_COUNT, NULL, FALSE) ;
						EnableWindow(GetDlgItem(hDlg, ID_CLOSE), FALSE) ;
						SetWindowText(GetDlgItem(hDlg, IDC_MESSAGE), "�����" ) ;
						Weather1Disp( ) ;
						Weather2StandBy( ) ;
						break ;
					case 2 :
						Weather2Disp( ) ;
						Weather4StandBy( ) ;
						break ;
					case 3 :
						Weather4Disp( ) ;
						Weather3StandBy( ) ;
						break ;
					case 4 :
						Weather3Disp( ) ;
						Weather5StandBy( ) ;
						break ;
					case 5 :
						Weather5Disp( ) ;
						Weather6StandBy( ) ;
						break ;
					case 6 :
						Weather6Disp( ) ;
						break ;
					default :
						EndDialog(hDlg, FALSE);
						return (TRUE);
						break ;
				}
				if( nDispNum == 6 ) EndDialog(hDlg, FALSE);
				else				nDispNum++;
				return (TRUE);
			}

			if ( LOWORD(wParam) == ID_CLOSE)
			{
				EndDialog(hDlg, FALSE);
				return (TRUE);
			}
			return (TRUE);
	}
	return (FALSE);
}


static void Weather1Disp( void )
{
	int		i ;
	BYTE	bzTempBuff[101] ;

//	nMovingCount = atoi(&WeatherArea[0].Data[5][0]) ;

	RTX(RTX_STRING, "showeffect") ;
	for( i = 1; i < nMovingCount; i++ )
	{
		sprintf( &bzTempBuff[0], "(C:/Ubc/Stock/WeatherImage/sky%d.tga) layer setlayer", i ) ;
		RTX(RTX_STRING, &bzTempBuff[0]) ;
		RTX(RTX_STRING, "(snap) effect (right) seteffectdir") ;
		RTX(RTX_STRING, "showeffect") ;
	 	RTX(RTX_STRING, "100 wait") ;
	}
	sprintf( &bzTempBuff[0], "(C:/Ubc/Stock/WeatherImage/sky%d.tga) layer setlayer", nMovingCount ) ;
	RTX(RTX_STRING, &bzTempBuff[0]) ;
	RTX(RTX_STRING, "(snap) effect (right) seteffectdir") ;
	RTX(RTX_STRING, "showeffect") ;

// KIM
/*
	sprintf( &bzTempBuff[0], "(C:/Ubc/Stock/WeatherImage/sky%d.tga) layer setlayer", nMovingCount + 1) ;
	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, &bzTempBuff[0]) ;
	RTX(RTX_STRING, "/WEATHER2 (tile) effect (box-open) seteffectdir 400 seteffectduration def") ;
*/
/*
	sprintf( &bzTempBuff[0], "(C:/Ubc/Stock/WeatherImage/sky%d.tga) layer setlayer", nMovingCount) ;
	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, &bzTempBuff[0]) ;
*/
}

static void Weather2Disp( void )
{
/*
	sprintf( &bzTempBuff[0], "(C:/Ubc/Stock/WeatherImage/sky%d.tga) layer setlayer", nMovingCount ) ;
	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, &bzTempBuff[0]) ;
	RTX(RTX_STRING, "showeffect") ;
*/

//	RTX(RTX_STRING, "WEATHER2 showeffect") ;
//	RTX(RTX_STRING, "showeffect") ;
//	RTX(RTX_STRING, "clearscreen") ;

//	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/low1.tga) layer setlayer") ;
//	RTX(RTX_STRING, "(wipe) effect (right) seteffectdir 700 seteffectduration showeffect") ;
//	RTX(RTX_STRING, "showeffect") ;

	RTX(RTX_STRING, "WEATHER2 showeffect") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;
}

static void Weather3Disp( void )
{
	int		i, j, nImageNo ;

	RTX(RTX_STRING, "WEATHER3 showeffect") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;

	RTX(RTX_STRING, "EF_DISP0 showeffect") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;

//	SeaMovingIcon
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING01 board0 455 345 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING02 board0 145 100 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD1 board0 535 345 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD2 board0 225 100 32 55 windowframebuffer def") ;

	for( i = 1; i <= SEA_MAXDATA; i++)
	{
		nImageNo = atoi(&WeatherSea[i - 1].Data[4][0]) + 1;
		sprintf(&szRxtCommBuf[0][0], "/ADDLAYER%d (C:/Ubc/Stock/WeatherImage/add%d.tga) layer def", i, nImageNo) ; 
		sprintf(&szRxtCommBuf[1][0], "/ADDDISP%d (push) effect (up) seteffectdir W_FRAMEBUF_ADD%d seteffectframebuffer ADDLAYER%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

		nImageNo = atoi(&WeatherSea[i - 1].Data[3][0]) + 1;
		sprintf(&szRxtCommBuf[0][0], "/MOVINGLAYER0%d (C:/Ubc/Stock/WeatherImage/micon%d0.tga) layer def", i, nImageNo) ; 
		sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 
		if(i == SEA_MAXDATA)
			sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration def", i, i, i) ; 
		else
			sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 

		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

	}

	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING1 board0 455 345 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING2 board0 145 100 71 55 windowframebuffer def") ;
	for( j = 1; j <= 3; j++)
	{
		for( i = 1; i <= SEA_MAXDATA; i++)
		{
			nImageNo = atoi(&WeatherSea[i - 1].Data[3][0]) + 1;
			sprintf(&szRxtCommBuf[0][0], "/MOVINGLAYER%d%d (C:/Ubc/Stock/WeatherImage/micon%d%d.tga) layer def", i, j, nImageNo, j - 1) ; 
			if(i == SEA_MAXDATA) 
				sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP%d%d (snap) effect W_FRAMEBUF_MOVING%d seteffectframebuffer MOVINGLAYER%d%d seteffectlayer def", i, j, i, i, j) ; 
			else
				sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP%d%d (snap) effect W_FRAMEBUF_MOVING%d seteffectframebuffer MOVINGLAYER%d%d seteffectlayer seteffectasync def", i, j, i, i, j) ; 
			RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
		}
	}

 	RTX(RTX_STRING, "ADDDISP1 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP2 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP01 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP02 showeffect") ;

	GetAsyncKeyState(VK_SPACE) ;		//	VK_SPACE
	while(1)
	{
	 	RTX(RTX_STRING, "MOVINGDISP11 showeffect  50 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP21 showeffect  50 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE

 		RTX(RTX_STRING, "MOVINGDISP12 showeffect  50 wait") ;
 		RTX(RTX_STRING, "MOVINGDISP22 showeffect  50 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE

 		RTX(RTX_STRING, "MOVINGDISP13 showeffect  50 wait") ;
 		RTX(RTX_STRING, "MOVINGDISP23 showeffect  50 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE
	}
}

static void Weather4Disp( void )
{
	int		i, j, nImageNo ;

	RTX(RTX_STRING, "WEATHER4 showeffect") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;

	RTX(RTX_STRING, "EF_DISP0 showeffect") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;
	RTX(RTX_STRING, "EF_DISP2 showeffect") ;
	RTX(RTX_STRING, "EF_DISP3 showeffect") ;
	RTX(RTX_STRING, "EF_DISP4 showeffect") ;

//	SeaMovingIcon
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING01 board0 253 395 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING02 board0 448 395 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING03 board0 68 245 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING04 board0 228 260 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING05 board0 403 275 71 55 windowframebuffer def") ;

	RTX(RTX_STRING, "/W_FRAMEBUF_ADD1 board0 333 395 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD2 board0 528 395 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD3 board0 148 245 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD4 board0 308 260 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD5 board0 483 275 32 55 windowframebuffer def") ;

	for( i = 1; i <= AREA_MAXDATA; i++)
	{
		nImageNo = atoi(&WeatherArea[i - 1].Data[4][0]) + 1;
		sprintf(&szRxtCommBuf[0][0], "/ADDLAYER%d (C:/Ubc/Stock/WeatherImage/add%d.tga) layer def", i, nImageNo) ; 
		sprintf(&szRxtCommBuf[1][0], "/ADDDISP%d (push) effect (up) seteffectdir W_FRAMEBUF_ADD%d seteffectframebuffer ADDLAYER%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

		nImageNo = atoi(&WeatherArea[i - 1].Data[3][0]) + 1;
		sprintf(&szRxtCommBuf[0][0], "/MOVINGLAYER0%d (C:/Ubc/Stock/WeatherImage/micon%d0.tga) layer def", i, nImageNo) ; 
		sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 
		if(i == AREA_MAXDATA)
			sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration def", i, i, i) ; 
		else
			sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 

		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

	}

	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING1 board0 253 395 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING2 board0 448 395 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING3 board0 68 245 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING4 board0 228 260 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING5 board0 403 275 71 55 windowframebuffer def") ;
	for( j = 1; j <= 3; j++)
	{
		for( i = 1; i <= AREA_MAXDATA; i++)
		{
			nImageNo = atoi(&WeatherArea[i - 1].Data[3][0]) + 1;
			sprintf(&szRxtCommBuf[0][0], "/MOVINGLAYER%d%d (C:/Ubc/Stock/WeatherImage/micon%d%d.tga) layer def", i, j, nImageNo, j - 1) ; 
			if(i == AREA_MAXDATA)
				sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP%d%d (snap) effect W_FRAMEBUF_MOVING%d seteffectframebuffer MOVINGLAYER%d%d seteffectlayer def", i, j, i, i, j) ; 
			else
				sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP%d%d (snap) effect W_FRAMEBUF_MOVING%d seteffectframebuffer MOVINGLAYER%d%d seteffectlayer seteffectasync def", i, j, i, i, j) ; 
			RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
		}
	}

 	RTX(RTX_STRING, "ADDDISP1 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP2 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP3 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP4 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP5 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP01 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP02 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP03 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP04 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP05 showeffect") ;

	GetAsyncKeyState(VK_SPACE) ;		//	VK_SPACE
	while(1)
	{
	 	RTX(RTX_STRING, "MOVINGDISP11 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP21 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP31 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP41 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP51 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE

	 	RTX(RTX_STRING, "MOVINGDISP12 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP22 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP32 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP42 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP52 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE

	 	RTX(RTX_STRING, "MOVINGDISP13 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP23 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP33 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP43 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP53 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE
	}
}

static void Weather5Disp( void )
{
	int		i, j, nImageNo ;

	RTX(RTX_STRING, "WEATHER5 showeffect") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;

	RTX(RTX_STRING, "EF_DISP0 showeffect") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;
	RTX(RTX_STRING, "EF_DISP2 showeffect") ;
	RTX(RTX_STRING, "EF_DISP3 showeffect") ;
	RTX(RTX_STRING, "EF_DISP4 showeffect") ;
	RTX(RTX_STRING, "EF_DISP5 showeffect") ;
	RTX(RTX_STRING, "EF_DISP6 showeffect") ;

//	SeaMovingIcon
//	int			xPos[6] = { 250, 440, 335, 435, 270, 470 } ;
//	int			yPos[6] = { 320, 337, 233, 206,  80, 101 } ;
//	int			xPos[6] = { 290, 480, 375, 475, 310, 510 } ;
//	int			yPos[6] = { 320, 337, 233, 206,  80, 101 } ;

	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING01 board0 313 375 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING02 board0 468 392 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING03 board0 378 287 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING04 board0 478 257 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING05 board0 308 137 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING06 board0 513 153 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING07 board0 105 113 71 55 windowframebuffer def") ;

	RTX(RTX_STRING, "/W_FRAMEBUF_ADD1 board0 385 375 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD2 board0 540 392 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD3 board0 450 287 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD4 board0 550 257 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD5 board0 380 137 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD6 board0 585 153 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD7 board0 187 113 32 55 windowframebuffer def") ;

	for( i = 1; i <= TAREA_MAXDATA; i++)
	{
		nImageNo = atoi(&WeatherTArea[i - 1].Data[4][0]) + 1;
		sprintf(&szRxtCommBuf[0][0], "/ADDLAYER%d (C:/Ubc/Stock/WeatherImage/add%d.tga) layer def", i, nImageNo) ; 
		sprintf(&szRxtCommBuf[1][0], "/ADDDISP%d (push) effect (up) seteffectdir W_FRAMEBUF_ADD%d seteffectframebuffer ADDLAYER%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

		nImageNo = atoi(&WeatherTArea[i - 1].Data[3][0]) + 1;
		sprintf(&szRxtCommBuf[0][0], "/MOVINGLAYER0%d (C:/Ubc/Stock/WeatherImage/micon%d0.tga) layer def", i, nImageNo) ; 
		sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 
		if(i == TAREA_MAXDATA)
			sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration def", i, i, i) ; 
		else
			sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 

		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

	}

/*
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING1 board0 273 375 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING2 board0 428 392 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING3 board0 338 287 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING4 board0 438 257 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING5 board0 268 137 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING6 board0 473 153 71 55 windowframebuffer def") ;
*/

	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING1 board0 313 375 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING2 board0 468 392 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING3 board0 378 287 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING4 board0 478 257 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING5 board0 308 137 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING6 board0 513 153 71 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING7 board0 105 113 71 55 windowframebuffer def") ;

	for( j = 1; j <= 3; j++)
	{
		for( i = 1; i <= TAREA_MAXDATA; i++)
		{
			nImageNo = atoi(&WeatherTArea[i - 1].Data[3][0]) + 1;
			sprintf(&szRxtCommBuf[0][0], "/MOVINGLAYER%d%d (C:/Ubc/Stock/WeatherImage/micon%d%d.tga) layer def", i, j, nImageNo, j - 1) ; 
			if(i == TAREA_MAXDATA)
				sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP%d%d (snap) effect W_FRAMEBUF_MOVING%d seteffectframebuffer MOVINGLAYER%d%d seteffectlayer def", i, j, i, i, j) ; 
			else
				sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP%d%d (snap) effect W_FRAMEBUF_MOVING%d seteffectframebuffer MOVINGLAYER%d%d seteffectlayer seteffectasync def", i, j, i, i, j) ; 
			RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
		}
	}

 	RTX(RTX_STRING, "ADDDISP1 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP2 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP3 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP4 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP5 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP6 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP7 showeffect") ;

 	RTX(RTX_STRING, "MOVINGDISP01 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP02 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP03 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP04 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP05 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP06 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP07 showeffect") ;

	GetAsyncKeyState(VK_SPACE) ;		//	VK_SPACE
	while(1)
	{
	 	RTX(RTX_STRING, "MOVINGDISP11 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP21 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP31 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP41 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP51 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP61 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP71 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE

	 	RTX(RTX_STRING, "MOVINGDISP12 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP22 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP32 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP42 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP52 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP62 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP72 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE

	 	RTX(RTX_STRING, "MOVINGDISP13 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP23 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP33 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP43 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP53 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP63 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP73 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE
	}
}

static void Weather6Disp( void )
{
	int		i, j, nImageNo ;

	RTX(RTX_STRING, "WEATHER6 showeffect") ;
	RTX(RTX_STRING, "showeffect") ;
	RTX(RTX_STRING, "clearscreen") ;

	RTX(RTX_STRING, "EF_DISP0 showeffect") ;
	RTX(RTX_STRING, "EF_DISP1 showeffect") ;
	RTX(RTX_STRING, "EF_DISP2 showeffect") ;
	RTX(RTX_STRING, "EF_DISP3 showeffect") ;
	RTX(RTX_STRING, "EF_DISP4 showeffect") ;

// KIMKIM
//	SeaMovingIcon

	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING01 board0 211 304 70 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING02 board0 211 245 70 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING03 board0 211 182 70 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING04 board0 211 124 70 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING05 board0 211 62 70 55 windowframebuffer def") ;

	RTX(RTX_STRING, "/W_FRAMEBUF_ADD1 board0 286 308 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD2 board0 286 248 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD3 board0 286 187 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD4 board0 286 127 32 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_ADD5 board0 286 67 32 55 windowframebuffer def") ;



  	for( i = 1; i <= WEEK_MAXDATA; i++)
	{
		nImageNo = atoi(&WeatherWeek[i - 1].Data[4][0]) + 1;
		sprintf(&szRxtCommBuf[0][0], "/ADDLAYER%d (C:/Ubc/Stock/WeatherImage/add%d.tga) layer def", i, nImageNo) ; 
		sprintf(&szRxtCommBuf[1][0], "/ADDDISP%d (push) effect (up) seteffectdir W_FRAMEBUF_ADD%d seteffectframebuffer ADDLAYER%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 
		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

		nImageNo = atoi(&WeatherWeek[i - 1].Data[3][0]) + 1;
		sprintf(&szRxtCommBuf[0][0], "/MOVINGLAYER0%d (C:/Ubc/Stock/WeatherImage/micon%d0.tga) layer def", i, nImageNo) ; 
		sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 
		if(i == WEEK_MAXDATA)
			sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration def", i, i, i) ; 
		else
			sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP0%d (push) effect (up) seteffectdir W_FRAMEBUF_MOVING0%d seteffectframebuffer MOVINGLAYER0%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ; 

		RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
		RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;

	}

	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING1 board0 211 304 70 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING2 board0 211 245 70 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING3 board0 211 182 70 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING4 board0 211 124 70 55 windowframebuffer def") ;
	RTX(RTX_STRING, "/W_FRAMEBUF_MOVING5 board0 211 62 70 55 windowframebuffer def") ;

	for( j = 1; j <= 3; j++)
	{
		for( i = 1; i <= WEEK_MAXDATA; i++)
		{
			nImageNo = atoi(&WeatherWeek[i - 1].Data[3][0]) + 1;
			sprintf(&szRxtCommBuf[0][0], "/MOVINGLAYER%d%d (C:/Ubc/Stock/WeatherImage/micon%d%d.tga) layer def", i, j, nImageNo, j - 1) ; 
			if(i == WEEK_MAXDATA)
				sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP%d%d (snap) effect W_FRAMEBUF_MOVING%d seteffectframebuffer MOVINGLAYER%d%d 100 seteffectduration seteffectlayer def", i, j, i, i, j) ; 
			else
				sprintf(&szRxtCommBuf[1][0], "/MOVINGDISP%d%d (snap) effect W_FRAMEBUF_MOVING%d seteffectframebuffer MOVINGLAYER%d%d seteffectlayer 100 seteffectduration seteffectasync def", i, j, i, i, j) ; 
			RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
			RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
		}
	}

 	RTX(RTX_STRING, "ADDDISP1 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP2 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP3 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP4 showeffect") ;
 	RTX(RTX_STRING, "ADDDISP5 showeffect") ;

 	RTX(RTX_STRING, "MOVINGDISP01 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP02 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP03 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP04 showeffect") ;
 	RTX(RTX_STRING, "MOVINGDISP05 showeffect") ;

	GetAsyncKeyState(VK_SPACE) ;		//	VK_SPACE
	while(1)
	{
	 	RTX(RTX_STRING, "MOVINGDISP11 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP21 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP31 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP41 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP51 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE

	 	RTX(RTX_STRING, "MOVINGDISP12 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP22 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP32 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP42 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP52 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE

	 	RTX(RTX_STRING, "MOVINGDISP13 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP23 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP33 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP43 showeffect  30 wait") ;
	 	RTX(RTX_STRING, "MOVINGDISP53 showeffect  30 wait") ;
		if(GetAsyncKeyState(VK_SPACE) != 0) break ;		//	VK_SPACE
	}
}

static void	Weather1StandBy( void )
{
	RTX(RTX_STRING, "reset clear clearscreen") ;
	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/sky1.tga) layer seteffectlayer") ;
	RTX(RTX_STRING, "showeffect") ;
//	RTX(RTX_STRING, "clear clearscreen") ;
}

static void	Weather2StandBy( void )
{
	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/low.tga) layer setlayer") ;
	RTX(RTX_STRING, "/WEATHER2 (wipe) effect (down) seteffectdir 700 seteffectduration def") ;

	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/low.tga) layer seteffectlayer") ;
}

static void	Weather3StandBy( void )
{
	int			i, j ;
	int			xPos[2] = { 466, 305 } ;
	int			yPos[2] = { 261,  56 } ;

	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "/P_LEFT { pop moveto } def") ;
	RTX(RTX_STRING, "/F_FONT1 { 0.99610 0.99610 0.99610 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (HY��������B) cvn findfont 30 scalefont 0 shadowfont 65 fontwidth 2 edgefont setfont } def") ;

	for( i = 0; i < SEA_MAXDATA; i++)
	{
		sprintf(&szRxtCommBuf[0][0], "/W_FRAMEBUF%d board0 %d %d 180 41 windowframebuffer def", i, xPos[i], yPos[i]) ;
		sprintf(&szRxtCommBuf[1][0], "/W_LAYER%d FULL_LAYER %d %d 180 41 windowlayer def", i, xPos[i], yPos[i]) ;
		sprintf(&szRxtCommBuf[2][0], "W_LAYER%d setlayer", i) ;
		sprintf(&szRxtCommBuf[3][0], "W_LAYER%d clearlayer", i) ;
		sprintf(&szRxtCommBuf[4][0], "F_FONT1 0 10 (%s ��) P_LEFT (%s ��) show",
					&WeatherSea[i].DispData[0], &WeatherSea[i].DispData[0]) ; 
		sprintf(&szRxtCommBuf[5][0], "/EF_DISP%d (push) effect (up) seteffectdir W_FRAMEBUF%d seteffectframebuffer W_LAYER%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ;
		for(j = 0; j < 6; j++)
		{
			RTX(RTX_STRING, &szRxtCommBuf[j][0]) ;
		}
	}

	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/weather3.tga) layer setlayer") ;
//	RTX(RTX_STRING, "/WEATHER3 (tile) effect (box-open) seteffectdir 400 seteffectduration seteffectasync def") ;
//	RTX(RTX_STRING, "/WEATHER3 (wipe) effect 1 seteffectsize (vertical-gate) seteffectdir 700 seteffectduration seteffectasync def") ;
//	RTX(RTX_STRING, "/WEATHER3 (wipe) effect (horizontal-close) seteffectdir 700 seteffectduration seteffectasync def") ;
//	RTX(RTX_STRING, "/WEATHER3 (wipe) effect (horizontal-open) seteffectdir 700 seteffectduration seteffectasync def") ;
//	RTX(RTX_STRING, "/WEATHER3 (tile) effect (up-left) seteffectdir 500 seteffectduration seteffectasync def") ;
//	RTX(RTX_STRING, "/WEATHER3 (tile) effect (diagonal-up-left) seteffectdir 500 seteffectduration seteffectasync def") ;

//	RTX(RTX_STRING, "/WEATHER3 (louvre) effect (horizontal-open) seteffectdir 700 seteffectduration seteffectasync def") ;
//	RTX(RTX_STRING, "/WEATHER3 (wipe) effect (horizontal-open) seteffectdir 700 seteffectduration seteffectasync def") ;
//	RTX(RTX_STRING, "/WEATHER3 (tile) effect (horizontal-open) seteffectdir 700 seteffectduration seteffectasync def") ;
	RTX(RTX_STRING, "/WEATHER3 (tile) effect (down-right) seteffectdir 400 seteffectduration seteffectasync def") ;

/*
	RTX(RTX_STRING, "/WEATHER3 (wipe) effect 4 seteffectsize (crosses) seteffectdir 1500 seteffectduration seteffectasync def") ;
	RTX(RTX_STRING, "/WEATHER3 (wipe) effect 4 seteffectsize (diamonds) seteffectdir 1500 seteffectduration seteffectasync def") ;
	RTX(RTX_STRING, "/WEATHER3 (wipe) effect 4 seteffectsize (snake-down) seteffectdir 1500 seteffectduration seteffectasync def") ;
	RTX(RTX_STRING, "/WEATHER3 (wipe) effect 4 seteffectsize (spiral-clockwise) seteffectdir 1500 seteffectduration seteffectasync def") ;
	RTX(RTX_STRING, "/WEATHER3 (wipe) effect 4 seteffectsize (spiral-counter-clockwise) seteffectdir def") ;
	RTX(RTX_STRING, "/WEATHER3 (wipe) effect 4 seteffectsize (stars) seteffectdir 1500 seteffectduration seteffectasync def") ;
*/

	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/weather3.tga) layer seteffectlayer") ;
}

static void	Weather4StandBy( void )
{
	int			i, j ;
	int			xPos[5] = { 234, 429,  59, 214, 394 } ;
	int			yPos[5] = { 327, 327, 172, 189, 202 } ;

	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/F_FONT2 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY��������B) cvn findfont 25 scalefont 0 shadowfont 85 fontwidth 3 edgefont setfont } def") ;

	for( i = 0; i < AREA_MAXDATA; i++)
	{
		sprintf(&szRxtCommBuf[0][0], "/W_FRAMEBUF%d board0 %d %d 120 40 windowframebuffer def", i, xPos[i], yPos[i]) ;
		sprintf(&szRxtCommBuf[1][0], "/W_LAYER%d FULL_LAYER %d %d 120 40 windowlayer def", i, xPos[i], yPos[i]) ;
		sprintf(&szRxtCommBuf[2][0], "W_LAYER%d setlayer", i) ;
		sprintf(&szRxtCommBuf[3][0], "W_LAYER%d clearlayer", i) ;
		sprintf(&szRxtCommBuf[4][0], "F_FONT2 60 12 (%s) P_CENTER (%s) show",
					&WeatherArea[i].DispData[0], &WeatherArea[i].DispData[0]) ; 
		sprintf(&szRxtCommBuf[5][0], "/EF_DISP%d (push) effect (up) seteffectdir W_FRAMEBUF%d seteffectframebuffer W_LAYER%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ;
		for(j = 0; j < 6; j++)
		{
			RTX(RTX_STRING, &szRxtCommBuf[j][0]) ;
		}
	}

	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/weather2.tga) layer setlayer") ;
//	RTX(RTX_STRING, "/WEATHER4 (tile) effect (box-open) seteffectdir 400 seteffectduration seteffectasync def") ;
	RTX(RTX_STRING, "/WEATHER4 (tile) effect (down-right) seteffectdir 400 seteffectduration seteffectasync def") ;

	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/weather2.tga) layer seteffectlayer") ;
}

static void	Weather5StandBy( void )
{
	int			i, j ;
//	int			xPos[6] = { 250, 440, 335, 435, 270, 470 } ;
//	int			yPos[6] = { 320, 337, 233, 206,  80, 101 } ;
	int			xPos[7] = { 290, 480, 375, 475, 310, 510, 110 } ;
	int			yPos[7] = { 320, 337, 233, 206,  80, 101,  52 } ;

	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
	RTX(RTX_STRING, "/F_FONT1 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY��������M) cvn findfont 21 scalefont 0 shadowfont 86 fontwidth 2 edgefont setfont } def") ;
	for( i = 0; i < TAREA_MAXDATA; i++)
	{
		sprintf(&szRxtCommBuf[0][0], "/W_FRAMEBUF%d board0 %d %d 87 30 windowframebuffer def", i, xPos[i], yPos[i]) ;
		sprintf(&szRxtCommBuf[1][0], "/W_LAYER%d FULL_LAYER %d %d 87 30 windowlayer def", i, xPos[i], yPos[i]) ;
		sprintf(&szRxtCommBuf[2][0], "W_LAYER%d setlayer", i) ;
		sprintf(&szRxtCommBuf[3][0], "W_LAYER%d clearlayer", i) ;
		sprintf(&szRxtCommBuf[4][0], "F_FONT1 43 5 (%s) P_CENTER (%s) show",
					&WeatherTArea[i].DispData[0], &WeatherTArea[i].DispData[0]) ; 
		sprintf(&szRxtCommBuf[5][0], "/EF_DISP%d (push) effect (up) seteffectdir W_FRAMEBUF%d seteffectframebuffer W_LAYER%d seteffectlayer 100 seteffectduration seteffectasync def", i, i, i) ;
		for(j = 0; j < 6; j++)
		{
			RTX(RTX_STRING, &szRxtCommBuf[j][0]) ;
		}
	}

	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/weather4.tga) layer setlayer def") ;
//	RTX(RTX_STRING, "/WEATHER5 (tile) effect (box-open) seteffectdir 400 seteffectduration seteffectasync def") ;
	RTX(RTX_STRING, "/WEATHER5 (tile) effect (down-right) seteffectdir 400 seteffectduration seteffectasync def") ;

	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, "(C:/Ubc/Stock/WeatherImage/weather4.tga) layer seteffectlayer") ;
}

static void	Weather6StandBy( void )
{
	int			i, j, nImageNo, nDay ;
	int			yPos[5] = { 305, 244, 185, 122, 62 } ;

	RTX(RTX_STRING, "reset") ;
	RTX(RTX_STRING, "/FULL_LAYER board1 size layer def") ;
	RTX(RTX_STRING, "/P_CENTER { /A 3 array def A astore 0 get A 2 get stringwidth pop 2 div sub A 1 get moveto } def") ;
//	RTX(RTX_STRING, "/F_FONT1 { 0.99610 0.99610 0.99610 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (HY��������M) cvn findfont 30 scalefont 2 shadowfont 100 fontwidth 1 edgefont setfont } def") ;
//	RTX(RTX_STRING, "/F_FONT2 { 0.99610 0.00000 0.00000 110 setrgbpalette 0.99610 0.99610 0.99610 113 setrgbpalette 0.99610 0.99610 0.99610 116 setrgbpalette 110 selectpalette (HY��������M) cvn findfont 30 scalefont 2 shadowfont 100 fontwidth 1 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_FONT1 { 0.00000 0.00000 0.00000 110 setrgbpalette 0.00000 0.00000 0.00000 113 setrgbpalette 0.00000 0.00000 0.00000 116 setrgbpalette 110 selectpalette (Times New Roman Bold) cvn findfont 35 scalefont 0 shadowfont 120 fontwidth 0 edgefont setfont } def") ;
	RTX(RTX_STRING, "/F_FONT2 { 0.83204 0.00000 0.00000 100 setrgbpalette 0.00000 0.00000 0.00000 103 setrgbpalette 0.00000 0.00000 0.00000 106 setrgbpalette 100 selectpalette (Times New Roman Bold) cvn findfont 35 scalefont 0 shadowfont 120 fontwidth 0 edgefont setfont } def") ;


	for( i = 0; i < WEEK_MAXDATA; i++)
	{
		nDay = atoi(&WeatherWeek[i].Data[1][0]) ;
		if(!strcmp(&WeatherWeek[i].Data[2][0], "��") || WeatherWeek[i].Data[5][0] == '1')
		{
			sprintf(&szRxtCommBuf[4][0], "F_FONT2 32 12 (%d) P_CENTER (%d) show", nDay, nDay) ; 
		}
		else
		{
			sprintf(&szRxtCommBuf[4][0], "F_FONT1 32 12 (%d) P_CENTER (%d) show", nDay, nDay) ; 
		}
		sprintf(&szRxtCommBuf[0][0], "/W_FRAMEBUF%d board0 78 %d 60 50 windowframebuffer def", i, yPos[i]) ;
		sprintf(&szRxtCommBuf[1][0], "/W_LAYER%d FULL_LAYER 78 %d 60 50 windowlayer def", i, yPos[i]) ;
		sprintf(&szRxtCommBuf[2][0], "W_LAYER%d setlayer", i) ;
		sprintf(&szRxtCommBuf[3][0], "W_LAYER%d clearlayer", i) ;
		sprintf(&szRxtCommBuf[5][0], "/EF_DISP%d (snap) effect (up) seteffectdir W_FRAMEBUF%d seteffectframebuffer W_LAYER%d seteffectlayer seteffectasync def", i, i, i) ;
		for(j = 0; j < 6; j++)
		{
			RTX(RTX_STRING, &szRxtCommBuf[j][0]) ;
		}
	}


	if(!strcmp(&WeatherWeek[0].Data[2][0], "��")) nImageNo = 7;
	else if(!strcmp(&WeatherWeek[0].Data[2][0], "��"))  nImageNo = 1;
	else if(!strcmp(&WeatherWeek[0].Data[2][0], "ȭ"))  nImageNo = 2;
	else if(!strcmp(&WeatherWeek[0].Data[2][0], "��"))  nImageNo = 3;
	else if(!strcmp(&WeatherWeek[0].Data[2][0], "��"))  nImageNo = 4;
	else if(!strcmp(&WeatherWeek[0].Data[2][0], "��"))  nImageNo = 5;
	else												nImageNo = 6;
	sprintf(&szRxtCommBuf[0][0], "(C:/Ubc/Stock/WeatherImage/week%d.tga) layer setlayer", nImageNo) ; 
	sprintf(&szRxtCommBuf[1][0], "(C:/Ubc/Stock/WeatherImage/week%d.tga) layer seteffectlayer", nImageNo) ; 

	RTX(RTX_STRING, "board0 setframebuffer") ;
	RTX(RTX_STRING, &szRxtCommBuf[0][0]) ;
//	RTX(RTX_STRING, "/WEATHER6 (tile) effect (box-open) seteffectdir 400 seteffectduration seteffectasync def") ;
	RTX(RTX_STRING, "/WEATHER6 (tile) effect (down-right) seteffectdir 400 seteffectduration seteffectasync def") ;

	RTX(RTX_STRING, "(snap) effect") ;
	RTX(RTX_STRING, "board1 seteffectframebuffer") ;
	RTX(RTX_STRING, &szRxtCommBuf[1][0]) ;
}
