#include "Main.h"
#include <ociapr.h>

static	void			SetDataTrim				( HWND, PSTR, int, int ) ;
static	BOOL			SetDataForInsert		( int ) ;

static char				sIdate[18] ;
static char				sUniName[21] ;
static char				sOnAir[2] ;
static char				sUniSort[4] ;
static char				sUsedFlg[2] ;
static char				sSysDate[15] ;

static short			ind_temp[10];

BOOL DBInsertIpsiData( HWND hWnd, HWND hListBox, int nType )
{
	BYTE	sFullData[63] ;
	int		i, nTotalRows ;
	BYTE	*UniversityName = "INSERT INTO IPSI_UNIVERSITY (IDATE,NAME,ONAIR,USED,SORT) \
								  VALUES (:sIdate,:sUniName,:sOnAir,:sUsedFlg,:sUniSort)" ;
	BYTE	*SubjectName = "INSERT INTO IPSI_SUBJECT (S_DATE,S_NAME) \
								  VALUES (:sIdate,:sUniName)" ;

	if(!DBGetSysdate( hWnd, sSysDate )) return FALSE;

	if (oopen(DML_CURS, LDA, (char  *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, DML_CURS);
		return FALSE ;
	}

	switch( nType )
	{
		case 1 :
			if (osql3(DML_CURS, (char  *)UniversityName, -1))
			{
				OracleErrorCode(hWnd, DML_CURS);
				return FALSE ;
			}

			nTotalRows = (int)SendMessage(hListBox, LB_GETCOUNT, 0, 0L);
			for(i = 0; i < nTotalRows; i++)
			{
				sFullData[0] = 0x00;
				SendMessage(hListBox, LB_GETTEXT, (UINT)i, (LPARAM)sFullData);
				SetDataTrim( hWnd, sFullData, i, nType ) ;
				SetDataForInsert( nType ) ;
				if (oexec(DML_CURS)) OracleErrorCode(hWnd, DML_CURS);
			}
			break ;

		case 2 :
			if (osql3(DML_CURS, (char  *)SubjectName, -1))
			{
				OracleErrorCode(hWnd, DML_CURS);
				return FALSE ;
			}

			nTotalRows = (int)SendMessage(hListBox, LB_GETCOUNT, 0, 0L);
			for(i = 0; i < nTotalRows; i++)
			{
				sFullData[0] = 0x00;
				SendMessage(hListBox, LB_GETTEXT, (UINT)i, (LPARAM)sFullData);
				SetDataTrim( hWnd, sFullData, i, nType ) ;
				SetDataForInsert( nType ) ;

				if (oexec(DML_CURS)) OracleErrorCode(hWnd, DML_CURS);
			}
			break ;

	}
							/* close the cursor					*/

	if (oclose(DML_CURS))
	{
		OracleErrorCode(hWnd, DML_CURS);
		return FALSE ;
	}

	if (ocom(LDA))
	{
		OracleErrorCode(hWnd, DML_CURS);
		return FALSE ;
	}

	return TRUE ;
}

static void SetDataTrim( HWND hWnd, PSTR pstrText, int nRow, int nType )
{
	BYTE	sFullSpaceData[63] ;

	switch( nType )
	{
		case 1 :
			memset(sFullSpaceData, 0x20, sizeof(sFullSpaceData)) ;
			strncpy( sFullSpaceData, pstrText, strlen(pstrText) );

			lstrcpyn(DataUniversity.Name, &sFullSpaceData[0], 21);
			lstrcpyn(DataUniversity.OnAir, &sFullSpaceData[26], 2);
			lstrcpyn(DataUniversity.Used, &sFullSpaceData[38], 2);
			sprintf(DataUniversity.Sort, "%03d", nRow);
			lstrcpyn(DataUniversity.Idate, &sFullSpaceData[43], 18);
			sFullSpaceData[62] = 0x00 ;

			SpaceTrim( DataUniversity.Name ) ;
			SpaceTrim( DataUniversity.OnAir ) ;
			SpaceTrim( DataUniversity.Used ) ;
			SpaceTrim( DataUniversity.Sort ) ;
			SpaceTrim( DataUniversity.Idate ) ;

			if(DataUniversity.Idate[0] == 0x00)
			{
				sprintf(DataUniversity.Idate, "%s%03d", sSysDate, nRow);
			}
			break;

		case 2 :
			memset(sFullSpaceData, 0x20, sizeof(sFullSpaceData)) ;
			strncpy( sFullSpaceData, pstrText, strlen(pstrText) );
			lstrcpyn(DataSubject.S_Name, &sFullSpaceData[0], 21);
			lstrcpyn(DataSubject.S_Date, &sFullSpaceData[26], 18);
			sFullSpaceData[44] = 0x00 ;

			SpaceTrim( DataSubject.S_Name ) ;
			SpaceTrim( DataSubject.S_Date ) ;

			if(DataSubject.S_Date[0] == 0x00)
			{
				sprintf(DataSubject.S_Date, "%s%03d", sSysDate, nRow);
			}
			break;

	}
}

static BOOL SetDataForInsert( int nType )
{
	switch( nType )
	{
		case 1 :
			if (obndrv(DML_CURS, (char  *)":sUniName", -1, (char *)DataUniversity.Name,
					sizeof(DataUniversity.Name), NULLTERM, -1, (short *)&ind_temp[0],
					(char  *)0, -1, -1))  return FALSE ;
			if (obndrv(DML_CURS, (char  *)":sOnAir", -1, (char *)DataUniversity.OnAir,
					sizeof(DataUniversity.OnAir), NULLTERM, -1, (short *)&ind_temp[1],
					(char  *)0, -1, -1))  return FALSE ;
			if (obndrv(DML_CURS, (char  *)":sUsedFlg", -1, (char *)DataUniversity.Used,
					sizeof(DataUniversity.Used), NULLTERM, -1, (short *)&ind_temp[2],
					(char  *)0, -1, -1))  return FALSE ;
			if (obndrv(DML_CURS, (char  *)":sUniSort", -1, (char *)DataUniversity.Sort,
					sizeof(DataUniversity.Sort), NULLTERM, -1, (short *)&ind_temp[3],
					(char  *)0, -1, -1))  return FALSE ;
			if (obndrv(DML_CURS, (char  *)":sIdate", -1, (char *)DataUniversity.Idate,
					sizeof(DataUniversity.Idate), NULLTERM, -1, (short *)&ind_temp[4],
					(char  *)0, -1, -1))  return FALSE ;
			break ;

		case 2 :
			if (obndrv(DML_CURS, (char  *)":sUniName", -1, (char *)DataSubject.S_Name,
					sizeof(DataSubject.S_Name), NULLTERM, -1, (short *)&ind_temp[0],
					(char  *)0, -1, -1))  return FALSE ;
			if (obndrv(DML_CURS, (char  *)":sIdate", -1, (char *)DataSubject.S_Date,
					sizeof(DataSubject.S_Date), NULLTERM, -1, (short *)&ind_temp[1],
					(char  *)0, -1, -1))  return FALSE ;
			break ;
	}

	return TRUE ;
}

