#include "Main.h" 
#include "GloVal.h" 
#include "Rtx32.h"

LRESULT	CALLBACK	WndProc						( HWND, UINT, WPARAM, LPARAM ) ;
BOOL				RegisterWin		( void ) ;

int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
					  LPTSTR lpCmdLine, int nCmdShow)
{
	MSG			msg ;

	ghInst = hInstance ;

	if( !InitFindWindow() ) return FALSE ;
	if( !GlobalVarInitProc( ) ) return FALSE ;

	memset(&VoteEnv, 0x00, sizeof(VoteEnv)) ;
/*
	if( !OracleEnvFileRead ( NULL ) )
	{
		if(!DialogBox( ghInst, "IDD_COMMCONFIG", NULL, (DLGPROC)OracleLoginSetup )) return( FALSE );
	}
*/

	if ( !RegisterWin() ) return( FALSE );
	if ( gnCxScreen < 800 ) {
		ghWndMain = CreateWindow( CLASSNAME, APPNAME,
							 WS_VISIBLE | WS_MINIMIZEBOX | WS_SYSMENU,
							 0, 0, gnCxScreen, gnCyScreen, NULL, NULL, hInstance, NULL);
	} else {
		ghWndMain = CreateWindow( CLASSNAME, APPNAME,
							 WS_VISIBLE | WS_MINIMIZEBOX | WS_SYSMENU,
							 (gnCxScreen - 800) / 2, (gnCyScreen - 600) / 2,
							 800, 572, NULL, NULL, hInstance, NULL);
	}

	if ( !ghWndMain )
	{
		MessageBeep(0xFFFFFFFF);
		MessageBox( ghWndMain, "Window?? Create?? ?? ???????.", "Error", MB_OK | MB_ICONSTOP );
		return( FALSE );
	}

	ShowWindow( ghWndMain, SW_SHOW ) ; 
	UpdateWindow( ghWndMain ) ;
	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage ( &msg ) ;
		DispatchMessage ( &msg ) ;
	}

	return( msg.wParam ) ; 
}

BOOL RegisterWin( void )
{
	WNDCLASS		wc;

	wc.style		 =  CS_SAVEBITS;
	wc.lpfnWndProc   = (WNDPROC)WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = sizeof( DWORD );
	wc.hInstance     = ghInst;
	wc.hIcon         = LoadIcon( ghInst, "MAIN" ); 
	wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName  = APPMENUNAME;
	wc.lpszClassName = CLASSNAME;

	if( !RegisterClass( &wc ) ) return FALSE;
	return TRUE;
}

LRESULT CALLBACK WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int			i ;
	HMENU		hmenuElect ;

	switch( uMsg )
	{
		case WM_CREATE :

			if( OracleEnvFileRead ( hWnd ) )
			{
				OracleLogonProgress ( hWnd, ghInst, OracleEnv.DBLogid, OracleEnv.DBPass, OracleEnv.DBServer ) ;
			}

			i = 0;
			while(i < 3 && ORAsession.connected == FALSE)
			{
				if(!DialogBox( ghInst, "IDD_ORACONNECT", hWnd, (DLGPROC)OracleConnectDlg) ) i = 3 ;
				i++;
			}
			if(ORAsession.connected == FALSE)
			{
				SendMessage ( hWnd, WM_CLOSE, 0, 0L);
				return 0 ;
			}
			hmenuElect = GetMenu( hWnd );
			EnableMenuItem(hmenuElect, IDM_CONNECT, MF_GRAYED);
			VoteEnvFileRead ( hWnd ) ;
			RTX(RTX_STRING, "reset clear clearscreen") ;
			break ;

		case WM_CLOSE :
			if(ORAsession.connected == TRUE)
			{
				OracleDisconnect( hWnd ) ;
			}
			break ;

		case WM_DESTROY :
			PostQuitMessage(0) ;
			return 0 ;

		case WM_COMMAND :
			switch( LOWORD(wParam) )				// Messages From Menu Control
			{
//				case IDM_BASEBALL :
//					DialogBox( ghInst, "IDD_BASEBALL", hWnd, (DLGPROC)BaseBallDlg );
//					break;

				case IDM_CONNECT:
					if(OracleLogon( hWnd, OracleEnv.DBLogid, OracleEnv.DBPass, OracleEnv.DBServer ))
					{
						hmenuElect = GetMenu( hWnd );
						EnableMenuItem(hmenuElect, IDM_CONNECT, MF_GRAYED);
						EnableMenuItem(hmenuElect, IDM_DISCONNECT, MF_ENABLED);
					}
					break;

				case IDM_DISCONNECT:
					if(OracleDisconnect( hWnd ))
					{
						hmenuElect = GetMenu( hWnd );
						EnableMenuItem(hmenuElect, IDM_DISCONNECT, MF_GRAYED);
						EnableMenuItem(hmenuElect, IDM_CONNECT, MF_ENABLED);
					}
					break;

				case IDM_NEWS :
					if( !DBSelectElectData( hWnd, 0 ) ) return 0 ;
					if( !DBSelectElectData( hWnd, 1 ) ) return 0 ;
					DialogBox( ghInst, "IDD_NEWS", hWnd, (DLGPROC)NewsOnAir );
					return 0 ;
				case IDM_VOTESU :
					DialogBox( ghInst, "IDD_VOTESU", hWnd, (DLGPROC)VotesuInpDlg );
					return 0 ;

				case IDM_EXIT :
					SendMessage ( hWnd, WM_CLOSE, 0, 0L);
					return 0 ;
			}
			break;

		default :
			break;
	}

	return( DefWindowProc( hWnd, uMsg, wParam, lParam ) );
}
