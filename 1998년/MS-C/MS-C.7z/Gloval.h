#if defined (WIN32)
	#define IS_WIN32 TRUE
#else
	#define IS_WIN32 FALSE
#endif

#define IS_NT      IS_WIN32 && (BOOL)(GetVersion() < 0x80000000)
#define IS_WIN32S  IS_WIN32 && (BOOL)(!(IS_NT) && (LOBYTE(LOWORD(GetVersion()))<4))
#define IS_WIN95   (BOOL)(!(IS_NT) && !(IS_WIN32S)) && IS_WIN32

#define ELECT_MAXDATA	5			/* ???? ???				*/

HINSTANCE			ghInst ;
HWND				ghWndMain ;

									/* Screen?????? ????		*/
int					gnCxScreen ;
int					gnCyScreen ;
WNDPROC				fnEditProc ;

BYTE				DBSysDate[11] ;
BYTE				szApplicationPath[MAX_PATH] ;
ORACLE_ENV			OracleEnv ;
VOTE_ENV			VoteEnv ;


									/* For Oracle									*/
									/* Cursor and LDA for communicating with ORACLE	*/
struct	cda_def		lda;			/* lda area										*/
struct	cda_def		sel_curs;		/* cursor for SELECT							*/
struct	cda_def		dml_curs;		/* cursor for DML...insert,update,delete		*/
ORACLE_SESSION		ORAsession ;	/* Structure to keep info on current session	*/


									/* 9/28????				*/
ELECT_DATA1			ElectData1[ELECT_MAXDATA] ;
ELECT_DISPDATA		ElectDispData[ELECT_MAXDATA] ;
int					nReadedCount ;
double				nVoteOpenRate ;
BYTE				szVoteOpenRate[10] ;