//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StockNT.rc
//
#define IDR_MAINMENU                    101
#define ID_ONAIR                        1000
#define IDC_USER                        1000
#define ID_CLOSE                        1001
#define IDC_PASSWORD                    1001
#define IDC_CONNECT                     1002
#define IDC_DATE                        1002
#define IDC_USA                         1003
#define IDC_JAPAN                       1004
#define IDC_USA_UPDN                    1005
#define IDC_JAPAN_UPDN                  1006
#define IDC_MESSAGE                     1010
#define IDC_MESSAGE3                    1011
#define IDC_COUNT                       1016
#define IDC_LIST1                       1018
#define IDC_PROGRESS                    1019
#define IDC_IPSIDEL                     1019
#define IDC_MESSAGE2                    1020
#define IDC_LIST2                       1020
#define IDC_MESSAGE1                    1021
#define IDC_LIST3                       1021
#define IDC_DISPNUM                     1022
#define IDC_STOP                        1023
#define IDC_SEND                        1024
#define IDC_COMBO1                      1025
#define IDC_UNIV1                       1026
#define IDC_UNIV2                       1027
#define IDC_TIME1                       1028
#define IDC_TIME2                       1029
#define IDC_TOTALUSER                   1031
#define IDC_ENDFLAG                     1032
#define IDC_DUPYU1                      1033
#define IDC_SGGNAME                     1034
#define IDC_EDIT1                       1035
#define IDC_EDIT2                       1036
#define IDC_EDIT3                       1037
#define IDC_EDIT4                       1038
#define IDC_VOTE1                       1039
#define IDC_VOTE2                       1040
#define IDC_VOTE3                       1041
#define IDC_OPENVOTE                    1042
#define IDC_RESULT1                     1043
#define IDC_RESULT2                     1044
#define IDC_RESULT3                     1045
#define IDM_CONNECT                     40001
#define IDM_DISCONNECT                  40002
#define IDM_STOCK                       40003
#define IDM_WEATHER                     40004
#define IDM_EXIT                        40005
#define IDM_IPSI                        40006
#define IDM_NEWS                        40007
#define IDM_VOTESU                      40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
