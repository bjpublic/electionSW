#include "Main.h"
#include <ociapr.h>

BOOL DBSelectStockData( HWND hWnd, int nType )
{
	int		i, nCount, nCols ;
	short	ind_temp[COLS_MAX_DATA];
	char	select_temp[COLS_MAX_DATA][41] ;
	BYTE	SqlCom[200] ;

	switch( nType )
	{
		case 0 :
			nCols = 1 ;
//			memset(&StockTotal, 0x00, sizeof(STOCK_TOTAL)) ;
			strcpy( SqlCom, "SELECT MAX(YMD) FROM STO_TOTAL" ) ;
			break ;

		case 1 :
			nCols = 4 ;
//			memset(&StockTotal, 0x00, sizeof(STOCK_TOTAL)) ;
			strcpy( SqlCom, "SELECT TOTAL,COUNT,AMOUNT,UPDN_TOT FROM STO_TOTAL" ) ;
			strcat( SqlCom, " WHERE YMD = '" ) ;
			strcat( SqlCom, DBSysDate ) ;
			strcat( SqlCom, "'" ) ;
			break ;
		case 2 :
			nCols = 4 ;
//			memset(&StockTotal, 0x00, sizeof(STOCK_TOTAL)) ;
			strcpy( SqlCom, "SELECT a.TOTAL_MIN,a.TOTAL_MAX,a.TOTAL,a.COUNT" ) ;
			strcat( SqlCom, " FROM STO_DIF a,STO_TIME b WHERE a.TIME_CD = b.TIME_CD" ) ;
			strcat( SqlCom, " AND b.FLAG = '1' AND a.YMD = '" ) ;
			strcat( SqlCom, DBSysDate ) ;
			strcat( SqlCom, "' ORDER BY b.SORT" ) ;
			break ;
		case 4 :
			nCols = 5 ;
//			ZeroMemorySet()
//			memset(&StockTotal, 0x00, sizeof(STOCK_TOTAL)) ;
			strcpy( SqlCom, "SELECT b.COMPANY_NAME,a.COST,a.UPDN_RATE,a.COUNT,a.UPDN_CD" ) ;
			strcat( SqlCom, " FROM STO_COST a,STO_COMP b WHERE a.COMPANY_CD = b.COMPANY_CD" ) ;
			strcat( SqlCom, " AND a.YMD = '" ) ;
			strcat( SqlCom, DBSysDate ) ;
			strcat( SqlCom, "' ORDER BY b.SORT" ) ;
			break ;
	}

						/* open a cursor for the select from REPT_MST	*/
	if (oopen(SEL_CURS, LDA, (char *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

								/* parse cursor						*/
								/* parse the INSERT SQL statement	*/
	if (osql3(SEL_CURS, (char *)&SqlCom[0], -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

	for( i = 0; i < nCols; i++ )
	{
		if (odefin(SEL_CURS, i + 1, (char *)&select_temp[i][0], 30, NULLTERM, -1,
					(short *)&ind_temp[i], (char *)0, -1, -1, (short *)0, (short *)0))
		{
			OracleErrorCode(hWnd, SEL_CURS);
			return FALSE ;
		}
	}
	if (oexec(SEL_CURS))	/* execute the query to get a new active set	*/
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}

	nCount = 0 ;
	switch( nType )
	{
		case 0 :					//������ �����ְ����� ������¥
			if (ofetch(SEL_CURS))
			{
				if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
				break ;
			}
			strcpy( &DBSysDate[0], &select_temp[0][0] ) ;
			break ;

		case 1 :					//������ �����ְ�����
			if (ofetch(SEL_CURS))
			{
				if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
				break ;
			}
			for( i = 0; i < nCols; i++ )
			{
				strcpy( &StockTotal.Data[i][0], &select_temp[i][0] ) ;
			}
			break ;

		case 2 :						// �ְ�����
			while( nCount < STOCK_DIFMAX )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}

				for( i = 0; i < nCols; i++ )
				{
					strcpy( &StockDif[nCount].Data[i][0], &select_temp[i][0] ) ;
				}
				nCount++ ;
			}
			nDifTotalCount = nCount;
			break ;

		case 4 :						//���� �ü�
			while( nCount < STOCK_COSTMAX )
			{
				if (ofetch(SEL_CURS))
				{
					if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
					break ;
				}

				for( i = 0; i < nCols; i++ )
				{
					strcpy( &StockCost[nCount].Data[i][0], &select_temp[i][0] ) ;
				}
				nCount++ ;
			}
			nCostTotalCount = nCount;
			break ;
	}

	if (oclose(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}
	return TRUE ;
}
