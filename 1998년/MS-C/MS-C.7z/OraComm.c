#include "Main.h"
#include <ociapr.h>

#define MAX_USERID                   20
#define MAX_PASSWORD                 20
#define MAX_CONNECT                  20

BOOL OracleLogonProgress( HWND hParentWnd, HINSTANCE hInst, PSTR pstrUser, PSTR pstrPass, PSTR pstrConnect )
{
	int		i, nProgressCount ;
	HWND	hWnd, hProgress ;
	BYTE	connstr[ MAX_USERID + MAX_CONNECT + 2 ];

	if (ORAsession.connected == TRUE) return TRUE;

	hWnd = CreateDialog( hInst, "IDD_PROGRESS", hParentWnd, (DLGPROC)NULL ) ;
	if( hWnd )
	{
		ShowWindow( hWnd, SW_SHOW ) ;
		SetDlgItemText( hWnd, IDC_MESSAGE1, "???? ????? ?????." );
		SetDlgItemText( hWnd, IDC_MESSAGE2, "?????????? ??????..." );
		SetFocus( GetDlgItem( hWnd, IDC_MESSAGE1 ) ) ;
		SetFocus( GetDlgItem( hWnd, IDC_MESSAGE2 ) ) ;
		hProgress = GetDlgItem( hWnd, IDC_PROGRESS ) ;
		SendMessage( hProgress, PBM_SETRANGE, 0, MAKELPARAM(0, 10) );
		SendMessage( hProgress, PBM_SETSTEP, 1, 0L );
		SendMessage( hProgress, PBM_STEPIT, 0, 0L );
		SendMessage( hProgress, PBM_STEPIT, 0, 0L );
		nProgressCount = 2 ;
	}

    while (ORAsession.connected == FALSE)
	{								/* Append host string to username.	*/
		strcpy(connstr, pstrUser);
		if (strlen(pstrConnect) != 0)
		{
			strcat(connstr, "@");
			strcat(connstr, pstrConnect);
		}
		if( hWnd )
		{
			SendMessage( hProgress, PBM_STEPIT, 0, 0L );
			SendMessage( hProgress, PBM_STEPIT, 0, 0L );
			nProgressCount += 2 ;
		}

									/* Call orlon() to do connect.		*/
        if (olon(LDA, (char  *)connstr, -1, pstrPass, -1, 0))
		{
			OracleErrorCode(hWnd, LDA);
			if (MessageBox(hWnd, "Login to ORACLE", "ORACLE", MB_RETRYCANCEL) != IDRETRY) break;
		} 
		else
		{
			nProgressCount += 2 ;
			ORAsession.connected = TRUE;
			SendMessage( hProgress, PBM_STEPIT, 0, 0L );
			SendMessage( hProgress, PBM_STEPIT, 0, 0L );
		}
	}
	if( hWnd )
	{
		for(i = nProgressCount; i < 10; i++)
		{
			SendMessage( hProgress, PBM_STEPIT, 0, 0L );
		}
	}
	DestroyWindow( hWnd );

	return( ORAsession.connected );
}

BOOL OracleLogon(HWND hWnd, PSTR pstrUser, PSTR pstrPass, PSTR pstrConnect)
{
									/* used to store userid@database */
	char	connstr[ MAX_USERID + MAX_CONNECT + 2 ];

	if (ORAsession.connected == TRUE) return TRUE;

    while (ORAsession.connected == FALSE)
	{								/* Append host string to username.	*/
		strcpy(connstr, pstrUser);
		if (strlen(pstrConnect) != 0)
		{
			strcat(connstr, "@");
			strcat(connstr, pstrConnect);
		}

									/* Call orlon() to do connect.		*/
        if (olon(LDA, (char  *)connstr, -1, pstrPass, -1, 0))
		{
			OracleErrorCode(hWnd, LDA);
			if (MessageBox(hWnd, "Login to ORACLE", "ORACLE", MB_RETRYCANCEL) != IDRETRY) break;
		} 
		else
		{
			ORAsession.connected = TRUE;
		}
	}

	return( ORAsession.connected );
}

BOOL OracleDisconnect(HWND hWnd)
{
	if( ORAsession.connected == FALSE ) return TRUE;

									/* Disconnect the current connection. */
	if( ologof(LDA) ) OracleErrorCode(hWnd, LDA);
    else			  ORAsession.connected = FALSE;

	return((ORAsession.connected == FALSE) ? TRUE : FALSE);
}

BOOL OracleErrorCode(HWND hWnd, struct cda_def *csrlda)
{
    char	buffer[ 133 ];			/* buffer to hold Oracle error message	*/

    if (csrlda->rc)
	{								/* if error code is set...				*/
									/* Get Oracle Error Message				*/
		oerhms(LDA, (sb2)csrlda->rc, (char  *)buffer, sizeof(buffer)-1);
		MessageBox(hWnd, buffer, "ORACLE Error", MB_OK);
		return FALSE;
	}

	return TRUE;
}

BOOL DBGetSysdate( HWND hWnd, PSTR pstrSysBuf )
{
	SHORT	ind_sys_date ;
	BYTE	sys_date[11] ;
	BYTE	*QrySysdate = "SELECT TO_CHAR(SYSDATE,'YYYY/MM/DD') FROM DUAL" ;

	pstrSysBuf[0] = 0x00;
						/* open a cursor for the select from REPT_MST	*/
	if (oopen(SEL_CURS, LDA, (char  *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE;
	}

						/* parse cursor									*/
	if (osql3(SEL_CURS, (char  *)QrySysdate, -1))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE;
	}

						/* Define output buffers for the all fields		*/
						/* in the select list of our query				*/
	if (odefin(SEL_CURS, 1, (char  *)sys_date, sizeof(sys_date),
							NULLTERM, -1, (short  *)&ind_sys_date,
							(char  *)0, -1, -1, (short  *)0, (short  *)0))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE;
	}

						/* execute the query to get a new active set	*/
	if (oexec(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE;
	}

	if (ofetch(SEL_CURS))
	{
		if ((SEL_CURS)->rc != NO_MORE_DATA) OracleErrorCode(hWnd, SEL_CURS);
		return  FALSE;
	}

	if (oclose(SEL_CURS))
	{
		OracleErrorCode(hWnd, SEL_CURS);
		return FALSE ;
	}
	lstrcpy(pstrSysBuf, sys_date) ;

	return TRUE;
}
