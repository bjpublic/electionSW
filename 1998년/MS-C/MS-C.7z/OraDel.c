#include "Main.h"
#include <ociapr.h>

BOOL DBDeleteProc( HWND hWnd, int nType )
{
	BYTE	SQLcommand[50] ;

	switch( nType )
	{
		case 1 :
			lstrcpy(SQLcommand, "DELETE FROM IPSI_UNIVERSITY") ;
			break ;
		case 2 :
			lstrcpy(SQLcommand, "DELETE FROM IPSI_SUBJECT") ;
			break ;
		case 3 :
			break ;
		case 4 :
			break ;
	}

						/* open a cursor for the select from	*/
	if (oopen(DML_CURS, LDA, (char  *)0, -1, -1, (char  *)0, -1))
	{
		OracleErrorCode(hWnd, DML_CURS);
		return FALSE;
	}

						/* parse cursor							*/
	if (osql3(DML_CURS, (char  *)SQLcommand, -1))
	{
		OracleErrorCode(hWnd, DML_CURS);
		return FALSE;
	}
	if (oexec(DML_CURS))
	{
		OracleErrorCode(hWnd, DML_CURS);
		return FALSE ;
	}

	if (oclose(DML_CURS))
	{
		OracleErrorCode(hWnd, DML_CURS);
		return FALSE ;
	}
	if (ocom(LDA))
	{
		OracleErrorCode(hWnd, DML_CURS);
		return FALSE ;
	}

	return TRUE ;
}
