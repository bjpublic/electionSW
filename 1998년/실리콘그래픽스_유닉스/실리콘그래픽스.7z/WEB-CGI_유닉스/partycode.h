typedef struct _PARTYCODE {
        char *code;
        char *party_name;
} PARTYNAME;

PARTYNAME party[9]={
	{ "01","한나라당"},
	{ "02","국민회의"},
	{ "03","자민련"},
	{ "04","국민신당"},
	{ "05","공화당"},
	{ "06","바른나라정치연합"},
	{ "07","통일한국당"},
	{ "08","노동당"},
	{ "99","무소속"},
};
