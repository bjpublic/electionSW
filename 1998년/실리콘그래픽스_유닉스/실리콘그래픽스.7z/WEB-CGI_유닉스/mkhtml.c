#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

#include "ginfo.h"
#include "hubotitle.h"
#include "htmlform.h"
#include "partycode.h"

extern ADVKYDC hubo1buf[MAX_HUBO1];
extern ADVKYDC hubo2buf[MAX_HUBO2];
extern HUBO hubo1[MAX_CITY][MAX_DATA];
extern HUBO hubo2[MAX_CITY][MAX_LOCAL][MAX_DATA];
extern ResultRecord ResultBuf1[MAX_HUBO1];
extern ResultRecord ResultBuf2[MAX_HUBO2];
extern ResultRecord FirstBuf;
extern getvotedRate(char *,int,char *);


void insertComma(int , char *);

void make_total_html(char *title)
{
    int i,j,k,idx;
    char tmp_total[9];
    FILE *fp;
    char *htmlname="./html/total.html";

    fp = fopen(htmlname,"w");
    
    fprintf(fp,header,title,title,ResultBuf1[0].adv_day,ResultBuf1[0].adv_hour,ResultBuf1[0].adv_min);

    for(i=0;i<MAX_HUBO1;i++){
       /*fprintf(fp,"<tr bgcolor=lightcyan><td>%s</td>",docode[i].name);*/
       for(j=0;j< ResultBuf1[i].candidate;j++) {
            fprintf(fp,"<td>%s</td><td>%s</td>\n",ResultBuf1[i].voted[j].name,ResultBuf1[i].voted[j].get_voted);
       }
       fprintf(fp,"</tr>\n");
    }
    fprintf(fp,footer);
    fclose(fp);
}

void make_hubo1_html()
{
    int i,j,idx;
    char tmp_total[9],tmp_rate[5];
    FILE *fp;
    char htmlname[50];


    for(i=0;i<MAX_CITY;i++){
       memset(htmlname,0x00,sizeof(htmlname));
       sprintf(htmlname,"./html/%s%s.html",ResultBuf1[i].g_code,ResultBuf1[i].l_code);
       fp = fopen(htmlname,"w");
       fprintf(fp,g_header,hubo1title[i].name,hubo1title[i].name,ResultBuf1[i].adv_day,ResultBuf1[i].adv_hour,ResultBuf1[i].adv_min);
       fprintf(fp,g_body1,ResultBuf1[i].NofVotePeople,ResultBuf1[i].nofVote,ResultBuf1[i].votedRate);
       fprintf(fp,g_body2,ResultBuf1[i].openRate);
       fprintf(fp,g_body3);
       for(j=0;j<ResultBuf1[i].candidate;j++) {
          fprintf(fp,"<td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s%%</td><td>%s</td></tr>\n",ResultBuf1[i].voted[j].rank,ResultBuf1[i].voted[j].name,ResultBuf1[i].voted[j].party_name,ResultBuf1[i].voted[j].get_voted,ResultBuf1[i].voted[j].gainRate,ResultBuf1[i].voted[j].votedGap);
       }
       fprintf(fp,g_footer);
       fclose(fp);
    }
}

void make_hubo2_html()
{
    int i,j,idx;
    char tmp_total[9],tmp_rate[5];
    FILE *fp;
    char htmlname[50];


    for(i=0;i<MAX_HUBO2;i++) {
       memset(htmlname,0x00,sizeof(htmlname));
       sprintf(htmlname,"./html/%s%s.html",ResultBuf2[i].g_code,ResultBuf2[i].l_code);
       fp = fopen(htmlname,"w");
       fprintf(fp,g_header,hubo2title[ResultBuf2[i].g_val-1][ResultBuf2[i].l_val-1].name,hubo2title[ResultBuf2[i].g_val-1][ResultBuf2[i].l_val-1].name,ResultBuf2[i].adv_day,ResultBuf2[i].adv_hour,ResultBuf2[i].adv_min);
       fprintf(fp,g_body1,ResultBuf2[i].NofVotePeople,ResultBuf2[i].nofVote,ResultBuf2[i].votedRate);
       fprintf(fp,g_body2,ResultBuf2[i].openRate);
       fprintf(fp,g_body3);
       for(j=0;j<ResultBuf2[i].candidate;j++) {
          fprintf(fp,"<td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",ResultBuf2[i].voted[j].rank,ResultBuf2[i].voted[j].name,ResultBuf2[i].voted[j].party_name,ResultBuf2[i].voted[j].get_voted,ResultBuf2[i].voted[j].gainRate,ResultBuf2[i].voted[j].votedGap);
       }
       fprintf(fp,g_footer);
       fclose(fp);
    }
}

void make_result_record()
{
   int i,j,k,idx,p_idx,g_val,l_val;

    for(i=0;i<MAX_HUBO1;i++) {
        ResultBuf1[i].g_val = hubo1buf[i].g_val;
        ResultBuf1[i].l_val = hubo1buf[i].l_val;
        memcpy(ResultBuf1[i].g_code,hubo1buf[i].g_code,2);
        ResultBuf1[i].g_code[2] = '\0';
        memcpy(ResultBuf1[i].l_code,hubo1buf[i].l_code,2);
        ResultBuf1[i].l_code[2] = '\0';
        memcpy(ResultBuf1[i].adv_day,hubo1buf[i].adv_day,2);
        ResultBuf1[i].adv_day[2] = '\0';
        memcpy(ResultBuf1[i].adv_hour,hubo1buf[i].adv_hour,2);
        ResultBuf1[i].adv_hour[2] = '\0';
        memcpy(ResultBuf1[i].adv_min,hubo1buf[i].adv_min,2);
        ResultBuf1[i].adv_min[2] = '\0';
        ResultBuf1[i].voteFlag = hubo1buf[i].voteFlag;
        ResultBuf1[i].openFlag = hubo1buf[i].openFlag;
        k = 0;
        for(j=0;j< MAX_DATA;j++) {
          idx = hubo1buf[i].rank[j].loc;
          if(hubo1[i][idx].name[0] != '\0') {
            k++; 
            memset(ResultBuf1[i].voted[j].name,0x00,11);
            memcpy(ResultBuf1[i].voted[j].name,hubo1[i][idx].name,10);
            memset(ResultBuf1[i].voted[j].party_name,0x00,sizeof(ResultBuf1[0].voted[0].party_name));
            p_idx = (hubo1[i][idx].party_code[1] - '0') -1;
            memcpy(ResultBuf1[i].voted[j].party_name,party[p_idx].party_name,strlen(party[p_idx].party_name));
            memset(ResultBuf1[i].voted[j].get_voted,0x00,11);
            insertComma(atoi(hubo1buf[i].voted[idx].get_voted),ResultBuf1[i].voted[j].get_voted);
            ResultBuf1[i].voted[j].rank = hubo1buf[i].rank[j].rank;
            getvotedRate(ResultBuf1[i].voted[j].gainRate,hubo1buf[i].hap,hubo1buf[i].voted[idx].get_voted);
            insertComma(atoi(hubo1buf[i].voted[hubo1buf[i].rank[0].loc].get_voted)-atoi(hubo1buf[i].voted[idx].get_voted),ResultBuf1[i].voted[j].votedGap);
            ResultBuf1[i].voted[j].status = hubo1buf[i].voted[idx].status;
          }
        }
        ResultBuf1[i].candidate = k;
        insertComma(atoi(hubo1buf[i].nofVote),ResultBuf1[i].nofVote);
        insertComma(atoi(hubo1buf[i].NofVotePeople),ResultBuf1[i].NofVotePeople);
        memset(ResultBuf1[i].votedRate,0x00,sizeof(ResultBuf1[0].votedRate));
        memcpy(ResultBuf1[i].votedRate,hubo1buf[i].votedRate,sizeof(hubo1buf[0].votedRate)-1);
        memset(ResultBuf1[i].openRate,0x00,sizeof(ResultBuf1[0].openRate));
        memcpy(ResultBuf1[i].openRate,hubo1buf[i].openRate,sizeof(hubo1buf[0].openRate)-1);
    }

    for(i=0;i<MAX_HUBO2;i++) {
        ResultBuf2[i].g_val = hubo2buf[i].g_val;
        ResultBuf2[i].l_val = hubo2buf[i].l_val;
        memcpy(ResultBuf2[i].g_code,hubo2buf[i].g_code,2);
        ResultBuf2[i].g_code[2] = '\0';
        memcpy(ResultBuf2[i].l_code,hubo2buf[i].l_code,2);
        ResultBuf2[i].l_code[2] = '\0';
        memcpy(ResultBuf2[i].adv_day,hubo2buf[i].adv_day,2);
        ResultBuf2[i].adv_day[2] = '\0';
        memcpy(ResultBuf2[i].adv_hour,hubo2buf[i].adv_hour,2);
        ResultBuf2[i].adv_hour[2] = '\0';
        memcpy(ResultBuf2[i].adv_min,hubo2buf[i].adv_min,2);
        ResultBuf2[i].adv_min[2] = '\0';
        ResultBuf2[i].voteFlag = hubo2buf[i].voteFlag;
        ResultBuf2[i].openFlag = hubo2buf[i].openFlag;
        k = 0;
        g_val = hubo2buf[i].g_val -1;
        l_val = hubo2buf[i].l_val -1;
        for(j=0;j< MAX_DATA;j++) {
          idx = hubo2buf[i].rank[j].loc;
          if(hubo2[g_val][l_val][idx].name[0] != '\0') {
            k++; 
            memset(ResultBuf2[i].voted[j].name,0x00,11);
            memcpy(ResultBuf2[i].voted[j].name,hubo2[g_val][l_val][idx].name,10);
            memset(ResultBuf2[i].voted[j].party_name,0x00,sizeof(ResultBuf2[0].voted[0].party_name));
            p_idx = (hubo2[g_val][l_val][idx].party_code[1] - '0') -1;
            memcpy(ResultBuf2[i].voted[j].party_name,party[p_idx].party_name,strlen(party[p_idx].party_name));
            memset(ResultBuf2[i].voted[j].get_voted,0x00,11);
            insertComma(atoi(hubo2buf[i].voted[idx].get_voted),ResultBuf2[i].voted[j].get_voted);
            ResultBuf2[i].voted[j].rank = hubo2buf[i].rank[j].rank;
            getvotedRate(ResultBuf2[i].voted[j].gainRate,hubo2buf[i].hap,hubo2buf[i].voted[idx].get_voted);
            insertComma(atoi(hubo2buf[i].voted[hubo2buf[i].rank[0].loc].get_voted)-atoi(hubo2buf[i].voted[idx].get_voted),ResultBuf2[i].voted[j].votedGap);
            ResultBuf2[i].voted[j].status = hubo2buf[i].voted[idx].status;
          }
        }
        ResultBuf2[i].candidate = k;
        insertComma(atoi(hubo2buf[i].nofVote),ResultBuf2[i].nofVote);
        insertComma(atoi(hubo2buf[i].NofVotePeople),ResultBuf2[i].NofVotePeople);
        memset(ResultBuf2[i].votedRate,0x00,sizeof(ResultBuf2[0].votedRate));
        memcpy(ResultBuf2[i].votedRate,hubo2buf[i].votedRate,sizeof(hubo2buf[0].votedRate)-1);
        memset(ResultBuf2[i].openRate,0x00,sizeof(ResultBuf2[0].openRate));
        memcpy(ResultBuf2[i].openRate,hubo2buf[i].openRate,sizeof(hubo2buf[0].openRate)-1);

    }

    k = 0;
    memset(FirstBuf.adv_day,0x00,3);
    memcpy(FirstBuf.adv_day,ResultBuf1[0].adv_day,2);
    memset(FirstBuf.adv_hour,0x00,3);
    memcpy(FirstBuf.adv_hour,ResultBuf1[0].adv_hour,2);
    memset(FirstBuf.adv_min,0x00,3);
    memcpy(FirstBuf.adv_min,ResultBuf1[0].adv_min,2);
    for(i=0;i<MAX_HUBO1;i++) {
      for(j=0;j< ResultBuf1[i].candidate;j++){
        if(ResultBuf1[i].voted[j].rank == 1) {
           memset(FirstBuf.voted[k].name,0x00,11);
           memcpy(FirstBuf.voted[k].name,ResultBuf1[i].voted[j].name,10);
	   memset(FirstBuf.voted[k].party_name,0x00,20);
           memcpy(FirstBuf.voted[k].party_name,ResultBuf1[i].voted[j].party_name,strlen(ResultBuf1[i].voted[j].party_name));
	   memset(FirstBuf.voted[k].get_voted,0x00,11);
           memcpy(FirstBuf.voted[k].get_voted,ResultBuf1[i].voted[j].get_voted,10);
	   memset(FirstBuf.voted[k].gainRate,0x00,7);
           memcpy(FirstBuf.voted[k].gainRate,ResultBuf1[i].voted[j].gainRate,6);
           FirstBuf.voted[k].status = ResultBuf1[i].voted[j].status;
	   FirstBuf.voted[k].guval = ResultBuf1[i].g_val;
	   k++;
	}
      }
    }  
    FirstBuf.candidate = k;
}

void insertComma(int val, char *tmpbuf)
{
        int i;
        char tmp[10+1];

        sprintf(tmp, "%8d", val);
        sprintf(tmpbuf, "%c%c,%c%c%c,%c%c%c", tmp[0], tmp[1], tmp[2], tmp[3],
                                              tmp[4], tmp[5], tmp[6], tmp[7]);

        for(i=0; i<10; i++) {
            if(tmpbuf[i] == ',')
                     tmpbuf[i] = ' ';
            else if(tmpbuf[i] != ' ')
                     break;
        }
}


