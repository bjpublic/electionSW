#define MAX_CITY 16 /* 전국 광역장수 */
#define MAX_HUBO1 16  /* 전국 광역단체장수 */
#define MAX_HUBO2 232  /* 전국 기초단체장수 */
#define MAX_LOCAL 35 /* 최대 기초 단체장수 지역수  */
#define KYDC_NO  4  /* 광역단체장 후보수 */
#define GCDC_NO  7  /* 기초단체장 후보수 */
#define KYYY_NO  8  /* 광역의원   후보수 */
#define GCYY_NO  8  /* 기초의원   후보수 */

#define MAX_DATA 8 /* 모든 데이타는 8명 기준 으로 한다 */


typedef struct _VOTED {
        char get_voted[8];
        char status;
} VOTED;
typedef struct _ADVVOTED {
        char get_voted[8+1];
        char status;
} ADVVOTED;

typedef struct _RANK {
	int rank;
        int loc;
} RANK;

 /* 광역단체장 */
typedef struct _KYDCINFO { 
	char g_code[2];		/* 선거구 시도(2)  */
	char l_code[2];		/* 선거구(2) */
	char upTime[6];		/* 입력시간 */
	char nofVote[8];	/* 투표자수 */
	char candidate ;        /* 후보자수 */
	VOTED  voted[MAX_DATA];	/* 후보별 득표수(8) + 구분코드(1)  */
	char ignore[8];		/* 무효표수 */
	char voteFlag;		/* 투표완료 여부 */
	char openFlag;		/* 개표완료 여부 */
	char newline;
} KYDCINFO;

typedef struct _ADVKYDC { 
        int  g_val;             /* 선거구시도지역  index */        
        int  l_val;             /* 선거구  index */        
	char g_code[2+1];	/* 선거구 시도(2)  */
	char l_code[2+1];	/* 선거구(2) */
	char adv_day[3];	/* 입력시간 */
	char adv_hour[3];	/* 입력시간 */
	char adv_min[3];	/* 입력시간 */
	int  candidate ;        /* 마지막 후보자 기호 */
        RANK  rank[MAX_DATA];    /* 후보자별 순위 */
	ADVVOTED voted[MAX_DATA];	/* 후보별 득표수(8) + 구분코드(1)  */
	char ignore[8+1];		/* 무효표수 */
	char voteFlag;		/* 투표완료 여부 */
	char openFlag;		/* 개표완료 여부 */
        char NofVotePeople[8+1];     /* 유권자수 */
	char nofVote[8+1];	/* 투표자수 */
	char votedRate[6];      /* 투표율 */
	char openRate[6];       /* 개표율 */ 
	int  hap;
} ADVKYDC;


typedef struct _OrderTmp {
    unsigned long value;
    int   loc;
    int   hubocode;
}  OrderTmp; 


typedef struct _HUBOLIST {
        char g_code[2];
        char l_code[2];
	char ge_code[4];
        char hubocode[2];
        char party_code[2];
        unsigned char name[10];
	char idx;
        char newline;
} HUBOLIST;

typedef struct _HUBO {
        char g_code[3];
        char l_code[3];
        char hubocode[3];
        char party_code[3];
        unsigned char name[11];
} HUBO;

typedef struct _NOVPEOPLE {
        unsigned int  novPeople;
} NOVPEOPLE;

typedef struct _VOTERECORD {
        char name[11];        /* 후보자 성명 */
	char party_name[20];  /* 정당이름 */
        char get_voted[11];   /* 득표수 */
	char gainRate[7];     /* 득표율 */
	char votedGap[11];    /* 득표차 */
        char status;          /* 당선,당선유력,... */
        int rank;
	int guval;
} VOTERECORD;

typedef struct _RESULTRECORD { 
        int  g_val;             /* 선거구시도지역  index */        
        int  l_val;             /* 선거구  index */        
	char g_code[3];	/* 선거구 시도(2)  */
	char l_code[3];	/* 선거구(2) */
	char adv_day[3];	/* 입력시간 */
	char adv_hour[3];	/* 입력시간 */
	char adv_min[3];	/* 입력시간 */
	int  candidate ;        /* 후보자 수 */
	VOTERECORD  voted[MAX_DATA * 5];  /* 후보별 득표정보 * 8명(최대) */
	char voteFlag;		/* 투표완료 여부 */
	char openFlag;		/* 개표완료 여부 */
        char NofVotePeople[11];     /* 유권자수 */
	char nofVote[11];	/* 투표자수 */
	char votedRate[7];      /* 투표율 */
	char openRate[7];       /* 개표율 */ 
} ResultRecord;
