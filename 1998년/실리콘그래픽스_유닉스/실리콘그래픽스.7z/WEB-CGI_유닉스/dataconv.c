#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include "ginfo.h"

extern ADVKYDC hubo1buf[MAX_HUBO1];
extern ADVKYDC hubo2buf[MAX_HUBO2];
extern HUBO hubo1[MAX_CITY][MAX_DATA];
extern HUBO hubo2[MAX_CITY][MAX_LOCAL][MAX_DATA];
extern int VotePeople1[MAX_CITY];
extern int VotePeople2[MAX_CITY][MAX_LOCAL];

extern void kydc_ranking(ADVKYDC *,int);
extern void gcdc_ranking(ADVKYDC *);
void  getvotedRate(char *,int ,char *);
void  getopenRate(char *,int ,char *);



void hubo_conv(HUBOLIST ghubo,int mode)
{
     int i,g_val,l_val,idx;

     g_val = (ghubo.g_code[0] - '0' ) * 10 + (ghubo.g_code[1] - '0');
     l_val = (ghubo.l_code[0] - '0' ) * 10 + (ghubo.l_code[1] - '0');
     idx =   (ghubo.hubocode[0] - '0') * 10 + ( ghubo.hubocode[1] - '0') -1;

   
     if(mode == 1){
        memcpy(hubo1[g_val-1][idx].g_code,ghubo.g_code,2);
        hubo1[g_val-1][idx].g_code[2]='\0';
        memcpy(hubo1[g_val-1][idx].l_code,ghubo.l_code,2);
        hubo1[g_val-1][idx].l_code[2]='\0';
        memcpy(hubo1[g_val-1][idx].hubocode,ghubo.hubocode,2);
        hubo1[g_val-1][idx].hubocode[2]='\0';
        memcpy(hubo1[g_val-1][idx].party_code,ghubo.party_code,2);
        hubo1[g_val-1][idx].party_code[2]='\0';
        memset(hubo1[g_val-1][idx].name,0x00,11);
        memcpy(hubo1[g_val-1][idx].name,ghubo.name,10);
     }
     else {
        memcpy(hubo2[g_val-1][l_val-1][idx].g_code,ghubo.g_code,2);
        hubo2[g_val-1][l_val-1][idx].g_code[2]='\0';
        memcpy(hubo2[g_val-1][l_val-1][idx].l_code,ghubo.l_code,2);
        hubo2[g_val-1][l_val-1][idx].l_code[2]='\0';
        memcpy(hubo2[g_val-1][l_val-1][idx].hubocode,ghubo.hubocode,2);
        hubo2[g_val-1][l_val-1][idx].hubocode[2]='\0';
        memcpy(hubo2[g_val-1][l_val-1][idx].party_code,ghubo.party_code,2);
        hubo2[g_val-1][l_val-1][idx].party_code[2]='\0';
        memset(hubo2[g_val-1][l_val-1][idx].name,0x00,11);
        memcpy(hubo2[g_val-1][l_val-1][idx].name,ghubo.name,10);
     }

}


void kydc_convInfo(KYDCINFO ginfo)
{
     int i,g_val,l_val,sub_val,tmp_val;
     char can_tmp[2];

     g_val = (ginfo.g_code[0] - '0' ) * 10 + (ginfo.g_code[1] - '0');
     l_val = (ginfo.l_code[0] - '0' ) * 10 + (ginfo.l_code[1] - '0');

     hubo1buf[g_val-1].g_val = g_val;
     hubo1buf[g_val-1].l_val = l_val;

     memcpy(hubo1buf[g_val-1].g_code,ginfo.g_code,2);
     hubo1buf[g_val-1].g_code[2]='\0';
     memcpy(hubo1buf[g_val-1].l_code,ginfo.l_code,2);
     hubo1buf[g_val-1].l_code[2]='\0';
    
     sprintf(hubo1buf[g_val-1].adv_day,"%c%c\0",ginfo.upTime[0],ginfo.upTime[1]);
     sprintf(hubo1buf[g_val-1].adv_hour,"%c%c\0",ginfo.upTime[2],ginfo.upTime[3]);
     sprintf(hubo1buf[g_val-1].adv_min,"%c%c\0",ginfo.upTime[4],ginfo.upTime[5]);

     memcpy(hubo1buf[g_val-1].nofVote,ginfo.nofVote,8);
     hubo1buf[g_val-1].nofVote[8]='\0';
     memcpy(hubo1buf[g_val-1].ignore,ginfo.ignore,8);
     hubo1buf[g_val-1].ignore[8]='\0';

     sprintf(can_tmp,"%c",ginfo.candidate);
     can_tmp[1]='\0';
     hubo1buf[g_val-1].candidate = atoi(can_tmp);
     
     sub_val = 0;
     tmp_val = 0;
     for(i=0;i<MAX_DATA;i++) {
        memcpy(hubo1buf[g_val-1].voted[i].get_voted,ginfo.voted[i].get_voted,8);
        hubo1buf[g_val-1].voted[i].get_voted[8] ='\0';
        hubo1buf[g_val-1].voted[i].status = ginfo.voted[i].status;
        tmp_val = atoi(hubo1buf[g_val-1].voted[i].get_voted);
        if(tmp_val > 0)
            sub_val = sub_val + tmp_val;
     }
     hubo1buf[g_val-1].voteFlag = ginfo.voteFlag;
     hubo1buf[g_val-1].openFlag  = ginfo.openFlag;
     memset(hubo1buf[g_val-1].NofVotePeople,0x00,sizeof(hubo1buf[0].NofVotePeople));
     sprintf(hubo1buf[g_val-1].NofVotePeople,"%8d",VotePeople1[g_val-1]);
     
     kydc_ranking(&hubo1buf[g_val-1],1);
     getvotedRate(hubo1buf[g_val-1].votedRate,VotePeople1[g_val-1],hubo1buf[g_val-1].nofVote);
     sub_val = sub_val + atoi(hubo1buf[g_val-1].ignore);
     hubo1buf[g_val-1].hap = sub_val;
     getopenRate(hubo1buf[g_val-1].openRate,sub_val,hubo1buf[g_val-1].nofVote);

}

void gcdc_convInfo(KYDCINFO ginfo,int idx)
{
     int i,g_val,l_val,sub_val,tmp_val;
     char can_tmp[2];

     g_val = (ginfo.g_code[0] - '0' ) * 10 + (ginfo.g_code[1] - '0');
     l_val = (ginfo.l_code[0] - '0' ) * 10 + (ginfo.l_code[1] - '0');

     hubo2buf[idx].g_val = g_val;
     hubo2buf[idx].l_val = l_val;

     memcpy(hubo2buf[idx].g_code,ginfo.g_code,2);
     hubo2buf[idx].g_code[2]='\0';
     memcpy(hubo2buf[idx].l_code,ginfo.l_code,2);
     hubo2buf[idx].l_code[2]='\0';
    
     sprintf(hubo2buf[idx].adv_day,"%c%c\0",ginfo.upTime[0],ginfo.upTime[1]);
     sprintf(hubo2buf[idx].adv_hour,"%c%c\0",ginfo.upTime[2],ginfo.upTime[3]);
     sprintf(hubo2buf[idx].adv_min,"%c%c\0",ginfo.upTime[4],ginfo.upTime[5]);

     memcpy(hubo2buf[idx].nofVote,ginfo.nofVote,8);
     hubo2buf[idx].nofVote[8]='\0';
     memcpy(hubo2buf[idx].ignore,ginfo.ignore,8);
     hubo2buf[idx].ignore[8]='\0';

     sprintf(can_tmp,"%c",ginfo.candidate);
     can_tmp[1]='\0';
     hubo2buf[idx].candidate = atoi(can_tmp);

     tmp_val = 0;
     sub_val = 0;

     for(i=0;i<MAX_DATA;i++) {
        memcpy(hubo2buf[idx].voted[i].get_voted,ginfo.voted[i].get_voted,8);
        hubo2buf[idx].voted[i].get_voted[8] ='\0';
        hubo2buf[idx].voted[i].status = ginfo.voted[i].status;
        tmp_val = atoi(hubo2buf[idx].voted[i].get_voted);
        if(tmp_val > 0)
            sub_val = sub_val + tmp_val;
        
     }
     hubo2buf[idx].voteFlag = ginfo.voteFlag;
     hubo2buf[idx].openFlag  = ginfo.openFlag;
     memset(hubo2buf[idx].NofVotePeople,0x00,sizeof(hubo2buf[0].NofVotePeople));
     sprintf(hubo2buf[idx].NofVotePeople,"%8d",VotePeople2[g_val-1][l_val-1]);
     
     kydc_ranking(&hubo2buf[idx],2);
     getvotedRate(hubo2buf[idx].votedRate,VotePeople2[g_val-1][l_val-1],hubo2buf[idx].nofVote);
     sub_val = sub_val + atoi(hubo2buf[idx].ignore);
     hubo2buf[idx].hap = sub_val;
     getopenRate(hubo2buf[idx].openRate,sub_val,hubo2buf[idx].nofVote);
}

void getvotedRate(char *buf,int totalvoted,char *voted)
{

     double tmp=0.0;
     if(atoi(voted) != 0) 
         tmp = ( (double)atoi(voted) / (double)totalvoted ) * 100.0;
     memset(buf,0x00,sizeof(buf));
     sprintf(buf,"%2.2f",tmp);
}

void getopenRate(char *buf,int totalvoted,char *voted)
{

     double tmp=0.0;

     if(totalvoted > 0)
         tmp = ( (double)totalvoted  / (double)atoi(voted)) * 100.0;
     memset(buf,0x00,sizeof(buf));
     sprintf(buf,"%2.2f",tmp);
}

