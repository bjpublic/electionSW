#include <stdio.h>
#include <unistd.h>
#include <memory.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>

#include "ginfo.h"
#include "local.h"

unsigned char *iptr, *loptr, obuf[4096];
ResultRecord *tmpresult;
VOTERECORD *tmpvote, *tvote;
int maxvote;

fillContent(infile, outfile, result)
char *infile, *outfile;
ResultRecord result;
{
	FILE *ofp;
	int fleng, ifd;
	char fname[50];

	memset(obuf, '\0', sizeof(obuf));
	ifd = open(infile, O_RDONLY);
	if(ifd < 0) {
		perror("input");
		exit(2);
	}
	fleng = getfilesize(ifd);
	if(fleng < 0) {
		perror("getfilesize");
		exit(3);
	}
	iptr = mmap((void *)0, fleng+1, PROT_READ, MAP_PRIVATE, ifd, 0);
	if(iptr < 0) {
		perror("mmap");
		exit(4);
	}
	sprintf(fname, "../data/%s.html", outfile);
	ofp = fopen(fname, "w");
	if(!ofp) {
		perror("output");
		exit(5);
	}
	tmpresult = (ResultRecord *)&result;
	tmpvote = result.voted;
	maxvote = 1;
	dataProc(ofp);
	munmap((void *)0, fleng+1);
	close(ifd);
	fclose(ofp);
}

dataProc(ofp)
FILE *ofp;
{
	int ret = 0;
	unsigned char *ptr, *optr;

	ptr = iptr;
	optr = obuf;
	for(; *ptr; ptr++) {
		if(*ptr == '\r')
			continue;
		if(*ptr == '<')
			ret = checkTag(&ptr, &optr);
		if(!ret)
			*optr++ = *ptr;
		ret = 0;
		if(*ptr == '\n') {
			*optr = '\0';
			fprintf(ofp, "%s", obuf);
			optr = obuf;
			memset(obuf, '\0', sizeof(obuf));
		}
	}
}

int loopend;

checkTag(ptr, optr)
unsigned char **ptr, **optr;
{
	if(*((*ptr)+1) != '%')
		return 0;
	*ptr += 2;
	if(!memcmp(*ptr, "TITLE", 5)) {
		(*ptr) += 6;
		if(tmpresult->l_val == 99)
			strcpy(*optr,
			 suncode[tmpresult->g_val-1][0].name);
		else
			strcpy(*optr,
			 suncode[tmpresult->g_val-1][tmpresult->l_val].name);
	} else if(!memcmp(*ptr, "RANK", 4)) {
		(*ptr) += 5;
		switch(tvote->status) {
		case '1': strcpy(*optr, "<img src=\"../icon/ani05_1.gif\" border=0>"); break;
		case '2': strcpy(*optr, "<img src=\"../icon/ani05.gif\" border=0>"); break;
		default : sprintf(*optr, "%2d", tvote->rank); break;
		}
	} else if(!memcmp(*ptr, "RIMG", 4)) {
		(*ptr) += 5;
		switch(tvote->status) {
		case '1': strcpy(*optr, "<img src=\"../icon/ani05_1.gif\" border=0>"); break;
		case '2': strcpy(*optr, "<img src=\"../icon/ani05.gif\" border=0>"); break;
		default : break;
		}
	} else if(!memcmp(*ptr, "NAME", 4)) {
		(*ptr) += 5;
		strcpy(*optr, tvote->name);
	} else if(!memcmp(*ptr, "PARTY", 5)) {
		(*ptr) += 6;
		strcpy(*optr, tvote->party_name);
	} else if(!memcmp(*ptr, "SHORTPARTY", 10)) {
		(*ptr) += 11;
		memcpy(*optr, tvote->party_name, 2);
		*((*optr)+2) = '\0';
	} else if(!memcmp(*ptr, "NOFVOTE", 7)) {
		(*ptr) += 8;
		strcpy(*optr, tvote->get_voted);
	} else if(!memcmp(*ptr, "ROFVOTE", 7)) {
		(*ptr) += 8;
		strcpy(*optr, tvote->gainRate);
	} else if(!memcmp(*ptr, "DOFVOTE", 7)) {
		(*ptr) += 8;
		strcpy(*optr, tvote->votedGap);
	} else if(!memcmp(*ptr, "LOOP", 4)) {
		(*ptr) += 5;
		loptr = *ptr;
		tvote = tmpvote;
		loopend = 0;
	} else if(!memcmp(*ptr, "NEXT", 4)) {
		(*ptr) += 5;
		maxvote++;
		if(maxvote > tmpresult->candidate)
			loopend = 1;
		else
			tvote++;
			
	} else if(!memcmp(*ptr, "ENDLOOP", 7)) {
		if(loopend)
			(*ptr) += 8;
		else
			*ptr = loptr;
	} else if(!memcmp(*ptr, "GU", 2)) {
		(*ptr) += 3;
		strcpy(*optr, docode[tmpresult->g_val - 1].name);
	} else if(!memcmp(*ptr, "CURDATE", 7)) {
		(*ptr) += 8;
		sprintf(*optr, "6월%s일 %s:%s", tmpresult->adv_day,
		                                tmpresult->adv_hour,
		                                tmpresult->adv_min);
	} else if(!memcmp(*ptr, "NOFYU", 5)) {
		(*ptr) += 6;
		strcpy(*optr, tmpresult->NofVotePeople);
	} else if(!memcmp(*ptr, "NOFTU", 5)) {
		(*ptr) += 6;
		strcpy(*optr, tmpresult->nofVote);
	} else if(!memcmp(*ptr, "ROFTU", 5)) {
		(*ptr) += 6;
		strcpy(*optr, tmpresult->votedRate);
	} else if(!memcmp(*ptr, "OOFTU", 5)) {
		(*ptr) += 6;
		strcpy(*optr, tmpresult->openRate);
	} else if(!memcmp(*ptr, "WGU", 3)) {
		(*ptr) += 4;
		strcpy(*optr, docode[tvote->guval - 1].name);
	}
	for(; **optr; (*optr)++)
		;
	return 1;
}

getfilesize(ifd)
int ifd;
{
	struct stat statbuf;

	if(fstat(ifd, &statbuf) < 0)
		return -1;
	return statbuf.st_size;
}
