#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

#include "ginfo.h"

extern ADVKYDC hubo1buf[MAX_HUBO1];
extern ADVKYDC hubo2buf[MAX_HUBO2];
extern HUBO hubo1[MAX_CITY][MAX_DATA];
extern HUBO hubo2[MAX_CITY][MAX_LOCAL][MAX_DATA];

void kydc_ranking(ADVKYDC *adv,int mode )
{
    OrderTmp g_order[MAX_DATA],g_tmp;
    int i,j;
    char voted[9];

    for(i=0;i< MAX_DATA;i++) {
       memcpy(voted,adv->voted[i].get_voted,8);
       voted[sizeof(voted)-1] = '\0';
       g_order[i].value = atoi(voted);
       g_order[i].loc = i;
       if(mode == 1)
           g_order[i].hubocode = atoi(hubo1[adv->g_val-1][i].hubocode); 
       else
           g_order[i].hubocode = atoi(hubo2[adv->g_val-1][adv->l_val-1][i].hubocode); 
    }
    for(i=0;i<MAX_DATA;i++) {
     for(j=i+1;j<MAX_DATA;j++) {
       if(g_order[i].value < g_order[j].value) {
          g_tmp.value = g_order[i].value;
          g_tmp.loc   = g_order[i].loc;
          g_order[i].value = g_order[j].value;
          g_order[i].loc = g_order[j].loc;
          g_order[j].value = g_tmp.value;
          g_order[j].loc   = g_tmp.loc;
       }
       else if((g_order[i].value == g_order[j].value) && (g_order[i].hubocode < g_order[j].hubocode)) {
          g_tmp.value = g_order[i].value;
          g_tmp.loc   = g_order[i].loc;
          g_order[i].value = g_order[j].value;
          g_order[i].loc = g_order[j].loc;
          g_order[j].value = g_tmp.value;
          g_order[j].loc   = g_tmp.loc;
       }
     }
    }
    for(i=0;i<MAX_DATA;i++) {
       adv->rank[i].loc  = g_order[i].loc;  /* 득표별 후보순서 */
       adv->rank[i].rank = i+1;                  /* 득표별 Ranking 부여 */
       if(i !=0) {
          if(g_order[i].value == g_order[i-1].value)   /* 동점자일 경우 */
               adv->rank[i].rank = adv->rank[i-1].rank;
       }
    }

}

void gcdc_ranking(ADVKYDC *adv)
{
    OrderTmp g_order[MAX_DATA],g_tmp;
    int i,j;
    char voted[9];

    for(i=0;i< MAX_DATA;i++) {
       memcpy(voted,adv->voted[i].get_voted,8);
       voted[sizeof(voted)-1] = '\0';
       g_order[i].value = atoi(voted);
       g_order[i].loc = i;
    }
    for(i=0;i<MAX_DATA;i++)
     for(j=i+1;j<MAX_DATA;j++) {
       if(g_order[i].value < g_order[j].value) {
          g_tmp.value = g_order[i].value;
          g_tmp.loc   = g_order[i].loc;
          g_order[i].value = g_order[j].value;
          g_order[i].loc = g_order[j].loc;
          g_order[j].value = g_tmp.value;
          g_order[j].loc   = g_tmp.loc;
       }
     }
    for(i=0;i<MAX_DATA;i++) {
       adv->rank[i].loc  = g_order[i].loc;  /* 득표별 후보순서 */
       adv->rank[i].rank = i+1;                  /* 득표별 Ranking 부여 */
       if(i !=0) {
          if(g_order[i].value == g_order[i-1].value)   /* 동점자일 경우 */
               adv->rank[i].rank = adv->rank[i-1].rank;
       }
    }

}
