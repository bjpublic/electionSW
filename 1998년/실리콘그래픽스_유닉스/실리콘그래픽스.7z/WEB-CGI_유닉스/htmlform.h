unsigned char *header="\
<html>\n\
<head><title>%s</title></head>\n\
<body bgcolor=#ffffff>\n\
<META HTTP-EQUIV=\"pragma\" CONTENT=no-cache>\n\
<META HTTP-EQUIV=\"Refresh\" CONTENT=60>\n\
<center>\n\
<table>\n\
<font size=7 color=blue>\n\
<tr><td><B>%s</B></td><td><B>( %s일 %s:%s 현재)</B></td></tr>\n\
</font>\n\
</table>\n\
\n\
<font size=+3>\n\
<table border=2>\n\
<tr bgcolor=lightblue><th width=60 nowrap>지역</th><th width=60 nowrap>1위후보자</th><th width=60 nowrap>득표수</th><th width=60 nowrap>2위후보자</th><th width=60 nowrap>득표수</th><th width=60 nowrap>3위후보자</th><th width=60 nowrap>득표수</th><th width=60 nowrap>4위후보자</th><th width=60 nowrap>득표수</th></tr>\n";

unsigned char *footer="\
</font>\n\
</table>\n\
</center>\n\
</body>\n\
</html>\n";

unsigned char *g_header="\
<html>\n\
<head><title>%s</title></head>\n\
<body bgcolor=#ffffff>\n\
<META HTTP-EQUIV=\"pragma\" CONTENT=no-cache>\n\
<META HTTP-EQUIV=\"Refresh\" CONTENT=60>\n\
<center>\n\
<table>\n\
<font size=7 color=blue>\n\
<tr><td><B>%s선거 개표현황</B></td><td><B>( %s일 %s:%s  현재)</B></td></tr>\n\
</font>\n\
</table>\n";

unsigned char *g_body1 = "\
<font size=+3>\n\
<table border=0>\n\
<tr bgcolor=lightblue><th width=150 nowrap>유권자수: %s </th><th width=150 nowrap>투표자수 : %s </th><th width=150 nowrap>투표율:%s %</th></tr></table>\n";

unsigned char *g_body2 = "\
<font size=+3>\n\
<table border=0>\n\
<tr bgcolor=lightblue><th width=300 nowrap>후보자별 득표현황</th><th width=150 nowrap>개표율:%s %</th></tr></table>\n";


unsigned char *g_body3 = "\
\n\
<font size=+3>\n\
<table border=2>\n\
<tr bgcolor=lightblue><th width=60 nowrap>순위</th><th width=60 nowrap>후보자</th><th width=100 nowrap>소속정당</th><th width=60 nowrap>득표수</th><th width=60 nowrap>득표율</th><th width=60 nowrap>득표차</th></tr>\n";

unsigned char *g_footer="\
</font>\n\
</table>\n\
</center>\n\
</body>\n\
</html>\n";

