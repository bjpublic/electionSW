#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

#include "ginfo.h"

void init_hubo(char *,int);
void init_VotePeople();
void kydc_proc();
void gcdc_proc();
void prt_hubo();
void prt_hubo1();
extern void kydc_convInfo( KYDCINFO );
extern void gcdc_convInfo( KYDCINFO ,int);
extern void make_total_html(char *);
extern void make_hubo1_html();
extern void make_hubo2_html();
extern void hubo_conv(HUBOLIST,int);
extern void make_result_record();

ADVKYDC hubo1buf[MAX_HUBO1];
ADVKYDC hubo2buf[MAX_HUBO2];
HUBO hubo1[MAX_CITY][MAX_DATA];
HUBO hubo2[MAX_CITY][MAX_LOCAL][MAX_DATA];
ResultRecord ResultBuf1[MAX_HUBO1];
ResultRecord ResultBuf2[MAX_HUBO2];
ResultRecord FirstBuf;
int  VotePeople1[MAX_CITY];
int  VotePeople2[MAX_CITY][MAX_LOCAL];

main()
{   
     int i,j;
     char dc_file[10];

     for(i=0;i<MAX_CITY;i++)
       for(j=0;j<MAX_DATA;j++)
            memset(hubo1[i][j].name,0x00,11);
       

     init_hubo("./data/hubo1.lst",1);    /* 광역단체장 후보자 저장 */
     init_hubo("./data/hubo2.lst",2);    /* 기초단체장 후보자 저장 */
     init_VotePeople();                  /* 각 도별,선거구별 유권자수 처리 */
     kydc_proc();                        /* 광역단체장 */
     gcdc_proc();                        /* 기초단체장 */
     /* prt_hubo1();*/
     make_result_record(); 
     /*
     make_total_html("광역 단체장 개표 종합");
     make_hubo1_html();
     make_hubo2_html();
     */
     for(i=0;i<MAX_HUBO1;i++) {
        sprintf(dc_file,"%s%s",ResultBuf1[i].g_code,"00");
        fillContent("dc.tmpl",dc_file,ResultBuf1[i]);
     }
     for(i=0;i<MAX_HUBO2;i++) {
        sprintf(dc_file,"%s%s",ResultBuf2[i].g_code,ResultBuf2[i].l_code);
        fillContent("dc.tmpl",dc_file,ResultBuf2[i]);
     }
     sprintf(dc_file,"wide");
     fillContent("wide.tmpl",dc_file,FirstBuf);
}

void init_hubo(char *filename,int mode)
{
     int  fd;
     HUBOLIST ghubo;
     char Databuf[sizeof(HUBOLIST)];

     fd = open(filename,O_RDONLY);
     if(fd < 0 ) {
         fprintf(stderr,"%s file open error \n",filename);
         exit(1);
     }

     memset(Databuf,0x00,sizeof(Databuf));
     while(read(fd,&ghubo,sizeof(HUBOLIST)) > 0) {
         hubo_conv(ghubo,mode);
         memset(Databuf,0x00,sizeof(Databuf));
     }
     close(fd);

}

void init_VotePeople()
{
     FILE  *fp;
     char Databuf[100];
     int g_val,l_val,g_total,l_total,tmp_total;
     char g_code[3],l_code[3],tmp[9];
     char g_tmp[3]="01";
     char l_tmp[3]="01";
     int i,j;

     fp = fopen("./data/g5.lst","r");
     if(fp == NULL ) {
         fprintf(stderr,"g5.lst file open error \n");
         exit(1);
     }
     g_total = 0;
     l_total = 0;

     memset(Databuf,0x00,100);
     while(fgets(Databuf,100,fp)){
         memcpy(g_code,Databuf,2);
         g_code[2] = '\0';
         memcpy(l_code,Databuf+2,2);
         l_code[2] = '\0';
         memcpy(tmp,Databuf+8,8);
         tmp[8] = '\0';
         g_val = atoi(g_code);
         l_val = atoi(l_code);
         tmp_total = atoi(tmp);
         if(!memcmp(l_tmp,l_code,2) && !memcmp(g_tmp,g_code,2))
            l_total = l_total + tmp_total;
         else {
           VotePeople2[atoi(g_tmp)-1][atoi(l_tmp)-1] = l_total; 
           l_total = tmp_total;
         }
         if(!memcmp(g_tmp,g_code,2))
            g_total = g_total + tmp_total; 
         else {
           VotePeople1[atoi(g_tmp)-1] = g_total; 
           g_total = tmp_total;
         }
           memcpy(g_tmp,g_code,2);
           g_tmp[2] = '\0';
           memcpy(l_tmp,l_code,2);
           l_tmp[2] = '\0';
         memset(Databuf,0x00,100);
     }
     VotePeople1[atoi(g_tmp)-1] = g_total; 
     VotePeople2[atoi(g_tmp)-1][atoi(l_tmp)-1] = l_total; 
     fclose(fp);

}


void kydc_proc()
{
     int fd;
     KYDCINFO ginfo;

     fd = open("./data/kydc.mbc",O_RDONLY);    /* 광역장 */
     if(fd < 0 ) {
         fprintf(stderr,"kydc.mbc file open error \n");
         exit(1);
     }

     while(1) {
         memset(&ginfo,0x00,sizeof(KYDCINFO));
         if(read(fd,&ginfo,sizeof(KYDCINFO)) < sizeof(KYDCINFO))
                  break;
         if(memcmp(ginfo.g_code,"99",2) && !memcmp(ginfo.l_code,"99",2))
               kydc_convInfo(ginfo);
     }
     close(fd);
     

}

void gcdc_proc()  /*기초장 */
{
     int fd,i=0,j=0;
     KYDCINFO ginfo;

     fd = open("./data/gcdc.mbc",O_RDONLY);  /*기초장 */
     if(fd < 0 ) {
         fprintf(stderr,"gcdc.mbc file open error \n");
         exit(1);
     }
     i=0;
     while(1) {
         memset(&ginfo,0x00,sizeof(KYDCINFO));
         if(read(fd,&ginfo,sizeof(KYDCINFO)) < sizeof(KYDCINFO))
                  break;
         if(memcmp(ginfo.g_code,"99",2) && memcmp(ginfo.l_code,"99",2)){
               gcdc_convInfo(ginfo,i);
               i++;
         }
     }
     close(fd);

}

void prt_hubo()
{
    int i,j,k;

    for(i=0;i<MAX_CITY;i++)
      for(j=0;j<MAX_DATA;j++) {
        printf("%d:%d %s:%s:%s:%s\n",i+1,j+1,hubo1[i][j].g_code,hubo1[i][j].l_code,hubo1[i][j].hubocode,hubo1[i][j].name);
      }

    for(i=0;i<MAX_CITY;i++)
      for(j=0;j<MAX_LOCAL;j++) 
        for(k=0;k<MAX_DATA;k++) {
        printf("%d:%d:%d %s:%s:%s:%s\n",i+1,j+1,k+1,hubo2[i][j][k].g_code,hubo2[i][j][k].l_code,hubo2[i][j][k].hubocode,hubo2[i][j][k].name);
      }

}
void prt_hubo1()
{
    int i,j,idx;

    for(i=0;i<MAX_HUBO2;i++){
      for(j=0;j<MAX_DATA;j++) {
        idx= hubo2buf[i].rank[j].loc;
        if(hubo2[hubo2buf[i].g_val-1][hubo2buf[i].l_val-1][idx].name[0] != '\0')
          printf("%s:%s:%d등:%s %s ,",hubo2buf[i].g_code,hubo2buf[i].l_code,hubo2buf[i].rank[j].rank,hubo2[hubo2buf[i].g_val-1][hubo2buf[i].l_val-1][idx].name,hubo2buf[i].voted[idx].get_voted);
      }
      printf("\n");
   }
     for(i=0;i<MAX_CITY;i++)
       printf("%2d : %8d\n",i+1,VotePeople1[i]);
     for(i=0;i<MAX_CITY;i++)
       for(j=0;j<MAX_LOCAL;j++)
         printf("%2d:%2d: %8d\n",i+1,j+1,VotePeople2[i][j]); 

}
