#include <stdio.h>
main()
{
printf("Content-Type: text/html\n\n");

printf("<html><body>");
printf("<form method=get>");
printf("<table border=1>");
printf("<p><p><p>");
printf("<body><p><h2>");
printf("<a href=http://server.co.kr/~test/server/kydc.cgi?name=kydc&value=1&name=count&value=16>������ü��</a>"); 
printf("<p>");

printf("<a href=http://server.co.kr/~test/server/gcdc.cgi>���ʴ�ü��</a>"); 
printf("<p>");
printf("<a href=http://server.co.kr/~test/server/kyyy.cgi>�����ǿ�</a>");
printf("<p>");
printf("<a href=http:/server.co.kr/~test/server/gcyy.cgi>�����ǿ�</a>");

printf("<p><p>");
printf("</body>");
printf("</html>");
}
