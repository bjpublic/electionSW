/*
================================================================================
	화일명 : vqmlib.c


	기 능 : VIPS's library



        Date : 96. 10. 15                 From : Tele service Team       Y.K.I
================================================================================
*/

#include	<stdio.h>
#include	<sys/types.h>
#include	<memory.h>
#include	<signal.h>
#include	<fcntl.h>
#include	<ctype.h>
#include	<time.h>
#include 	<sys/types.h>
#include 	<sys/ipc.h>
#include 	<sys/msg.h>
#include 	<sys/shm.h>
#include 	"/EDS/VIPS/VQM/include/VQMdef.h"
#include 	"/EDS/VIPS/VQM/include/VQMstc.h"
#include 	"/EDS/VIPS/VQM/include/VQMetrn.h"
#include 	<widec.h>
#include 	<wctype.h>
#include 	<locale.h>
#include 	<limits.h>

struct		VQM_TBL 	*SCT;

extern	int	errno;


Etrn_var_init()
{
	Uid 	= 0; 	Svid    = 0; 	Qry[0]  = '\0'; Dm    = 0;
	Time    = 0;   	Type 	= '\0'; Con 	= 0;   	Id[0] = '\0';
	Pwd[0]= '\0'; 	Dddphone[0] = '\0';Rw	= 0;  
	Ttp	= 0;	Vcaddr[0] = '\0';

	/* VPSM */
	PState = 0;

}


Sct_shm_init(level, uidno)
short	level, uidno;
{
	switch( level ) {
	case 1 :	/* ALL */
		bzero(&SCT->Sct[uidno], sizeof(SCT->Sct[uidno]) );
		break;

	case 2 :	/* VPSM */
		bzero(&SCT->Sct[uidno].p, sizeof(SCT->Sct[uidno].p) );
		break;
/*

	case 3 :	VTSM 
		bzero(&SCT->Sct[uidno].t, sizeof(SCT->Sct[uidno].t) );
		break;

	case 4 :	VESM 
		bzero(&SCT->Sct[uidno].e, sizeof(SCT->Sct[uidno].e) );
		break;

	case 5 :	VDSM 
		bzero(&SCT->Sct[uidno].d, sizeof(SCT->Sct[uidno].d) );
		break;
*/

	default :
		break;
	}

	return;
}


Vpsm_shm_read(uidno)
short	uidno;
{
	/* Gong_Tong */
	Uid 	= SCT->Sct[uidno].uid;
	Svid 	= SCT->Sct[uidno].svid;
	strcpy(Qry, SCT->Sct[uidno].query);
	Dm 	= SCT->Sct[uidno].dm;
	Time 	= SCT->Sct[uidno].time;
	Type 	= SCT->Sct[uidno].type;
	Con 	= SCT->Sct[uidno].con;
	strcpy(Id, SCT->Sct[uidno].id);
	strcpy(Pwd, SCT->Sct[uidno].pwd);
	strcpy(Dddphone, SCT->Sct[uidno].dddphone);
	Rw 	= SCT->Sct[uidno].rw;
	Ttp 	= SCT->Sct[uidno].ttp;
	strcpy(Vcaddr, SCT->Sct[uidno].vcaddr);

	/* VPSM */
	PState	= SCT->Sct[uidno].p.state;

	return;
}


Vtsm_shm_read(uidno)
short	uidno;
{
	/* Gong_Tong */
	Uid 	= SCT->Sct[uidno].uid;
	Svid 	= SCT->Sct[uidno].svid;
	strcpy(Qry, SCT->Sct[uidno].query);
	Dm 	= SCT->Sct[uidno].dm;
	Time 	= SCT->Sct[uidno].time;
	Type 	= SCT->Sct[uidno].type;
	Con 	= SCT->Sct[uidno].con;
	strcpy(Id, SCT->Sct[uidno].id);
	strcpy(Pwd, SCT->Sct[uidno].pwd);
	strcpy(Dddphone, SCT->Sct[uidno].dddphone);
	Rw 	= SCT->Sct[uidno].rw;
	Ttp 	= SCT->Sct[uidno].ttp;
	strcpy(Vcaddr, SCT->Sct[uidno].vcaddr);

	return;
}

Vesm_shm_read(uidno)
short	uidno;
{

	/* VESM */
}


Vpsm_shm_write(uidno)
short	uidno;
{
	SCT->Sct[uidno].uid	= Uid;
	SCT->Sct[uidno].svid 	= Svid;
	SCT->Sct[uidno].time 	= Time;
	SCT->Sct[uidno].dm 	= Dm;
	strcpy(SCT->Sct[uidno].vcaddr, Vcaddr);
	SCT->Sct[uidno].type = Type;
	strcpy(SCT->Sct[uidno].query, Qry);
	SCT->Sct[uidno].ttp 	= Ttp;
	SCT->Sct[uidno].con 	= Con;

/*
	strcpy(SCT->Sct[uidno].id, Id);
	strcpy(SCT->Sct[uidno].pwd, Pwd);
	strcpy(SCT->Sct[uidno].dddphone, Dddphone);
	SCT->Sct[uidno].rw 	= Rw;
	SCT->Sct[uidno].p.state 	= PState;
*/
	return;
}

Vtsm_shm_write(uidno)
short	uidno;
{
	/* VTSM Write */

	return;
}



send_errmsg_to_sosm(qid, ln, x_loc, y_loc, b_col, f_col, errmsg, quemsg)
int	qid, ln, x_loc, y_loc, b_col, f_col;
char	*errmsg;
struct	vqmmsg_t	*quemsg;
{
	struct	outmsg_t	vpso_q;

	Ttp = quemsg->ttp;
	vpso_q.cntltp= CU_DA_CU + (Ttp*1000);

	vpso_q.mtype = 1;
  	vpso_q.x25bd = quemsg->x25bd;

  	vpso_q.LUN = quemsg->vcno;
  	strcpy(vpso_q.device_name, quemsg->vcaddr);
	
	/*--- previous cursor location information --*/
	vpso_q.pre_cur[0] = E_X_CURLOC;
	vpso_q.pre_cur[1] = E_Y_CURLOC;
	vpso_q.pre_cur[2] = WHITE;
	vpso_q.pre_cur[3] = BLACK;

	/*--- after cursor location information --*/
	vpso_q.aft_cur[0] = x_loc;
	vpso_q.aft_cur[1] = y_loc;
	vpso_q.aft_cur[2] = b_col;
	vpso_q.aft_cur[3] = f_col;
	vpso_q.aft_cur[4] = ln;
	
  	vpso_q.BASE_screen[0] = NULL;
  	strcpy(vpso_q.text, errmsg);

	msgq_send(qid, &vpso_q, sizeof(vpso_q));

#ifdef	DISP
prt_sosm_msgq(&vpso_q);
#endif

	return;
} /*-- 	send_errmsg_to_sosm --*/


send_screen_to_sosm(qid,type,fnkey,x_loc,y_loc,b_col,f_col,ln,scrname,quemsg)
int	qid, type, fnkey, x_loc, y_loc, b_col, f_col, ln;
char	*scrname;
struct	vqmmsg_t	*quemsg;
{
	struct	outmsg_t	vpso_q;
	
	Ttp = quemsg->ttp;

	switch(fnkey) {
	case M_CONN :
	case F2HELP :
	case F3PREV :
	case F6MENU :
	case F8NEXT :
	case F10SEND :
	case FLOAD :
	 	vpso_q.cntltp = SC_CU + (Ttp*1000);
		break;

	case F4CANC :
	 	vpso_q.cntltp = CU + (Ttp*1000);
		break;

	case F9REPT :
		/*---	 Screen + Data 	---*/
		if( type == FIRST )
			vpso_q.cntltp= SC_SVB_CU + (Ttp*1000);
		else 	/* Screen */
			vpso_q.cntltp= SC_CU + (Ttp*1000);
		break;

	default :
		return;

	} /*-- fnkey --*/

	vpso_q.mtype = 1;
  	vpso_q.x25bd = quemsg->x25bd;
  	vpso_q.LUN = quemsg->vcno;
  	strcpy(vpso_q.device_name, quemsg->vcaddr);
	
	/*--- cursor location information --*/
	vpso_q.aft_cur[0] = x_loc;
	vpso_q.aft_cur[1] = y_loc;
	vpso_q.aft_cur[2] = b_col;
	vpso_q.aft_cur[3] = f_col;
	vpso_q.aft_cur[4] = ln;

	strcpy(vpso_q.BASE_screen, scrname);
  	vpso_q.text[0] = NULL;

	msgq_send(qid, &vpso_q, sizeof(vpso_q));

#ifdef	DISP
prt_sosm_msgq(&vpso_q);
#endif
	return;
} /*--  send_screen_to_sosm --*/


/*-- Telegram  화면 + data 출력 --*/
send_scr_data_to_sosm(qid, x_loc,y_loc,b_col,f_col,ln,scrname,text,quemsg)
int	qid, x_loc, y_loc, b_col, f_col, ln;
char	*scrname, *text;
struct	vqmmsg_t	*quemsg;
{
	char	date[20];
	struct	outmsg_t	vpso_q;
	
	Ttp = quemsg->ttp;

	/* screen+data(위치정보) 10000 -> let's vtx == 119 repr == 120 */
	vpso_q.cntltp= S_C_D_MANY + (Ttp*1000);	

	vpso_q.mtype = 1;
  	vpso_q.x25bd = quemsg->x25bd;
  	vpso_q.LUN = quemsg->vcno;
  	strcpy(vpso_q.device_name, quemsg->vcaddr);
	
	/*--- cursor location information --*/
	vpso_q.aft_cur[0] = x_loc;
	vpso_q.aft_cur[1] = y_loc;
	vpso_q.aft_cur[2] = b_col;
	vpso_q.aft_cur[3] = f_col;
	vpso_q.aft_cur[4] = ln;

	strcpy(vpso_q.BASE_screen, scrname);
	strcpy(vpso_q.text, text);

	msgq_send(qid, &vpso_q, sizeof(vpso_q));

#ifdef	DISP
prt_sosm_msgq(&vpso_q);
#endif
	return;
} 


/*---  Telegram READ에서 사용자 화일 읽어서 출력  --*/
send_hash_to_sosm(qid, type, x_loc, y_loc, b_col, f_col, scrname, text, quemsg)
int	qid, type, x_loc, y_loc, b_col, f_col;
char	*scrname, *text;
struct	vqmmsg_t	*quemsg;
{
	struct	outmsg_t	vpso_q;

	Ttp = quemsg->ttp;

	if( type == FIRST )
		vpso_q.cntltp= O_SC_CU_DA_CU + (Ttp*1000);   /* screen + data */
	else
		vpso_q.cntltp= O_CU_DA_CU + (Ttp*1000);	     /* data */

	vpso_q.mtype = 1;
  	vpso_q.x25bd = quemsg->x25bd;
  	vpso_q.LUN = quemsg->vcno;
  	strcpy(vpso_q.device_name, quemsg->vcaddr);
	
	/*--- previous cursor location information --*/
	vpso_q.pre_cur[0] = 5;		/* 5, 1에 뿌리자 */
	vpso_q.pre_cur[1] = T_Y_CURLOC;
	vpso_q.pre_cur[2] = WHITE;
	vpso_q.pre_cur[3] = BLACK;
	vpso_q.pre_cur[4] = 5;		/* 1, 1 삭제  */
	vpso_q.pre_cur[5] = 19;

	/*--- after cursor location information --*/
	vpso_q.aft_cur[0] = x_loc;
	vpso_q.aft_cur[1] = y_loc;
	vpso_q.aft_cur[2] = b_col;
	vpso_q.aft_cur[3] = f_col;
	vpso_q.aft_cur[4] = D_LN + 3;	/* 5자리 입력 */
	
  	strcpy(vpso_q.BASE_screen, scrname);
  	strcpy(vpso_q.text, text);

	msgq_send(qid, &vpso_q, sizeof(vpso_q));

#ifdef	DISP
prt_sosm_msgq(&vpso_q);
#endif
	return;

} /*-- 	send_text_to_sosm --*/

send_msg_to_sosm(qid, ln, d_x, d_y, x_loc, y_loc, b_col, f_col, errmsg, quemsg)
int	qid, ln, x_loc, y_loc, b_col, f_col;
char	*errmsg;
struct	vqmmsg_t	*quemsg;
{
	struct	outmsg_t	vpso_q;

	Ttp = quemsg->ttp;
	vpso_q.cntltp= CU_DA_CU + (Ttp*1000);

	vpso_q.mtype = 1;
  	vpso_q.x25bd = quemsg->x25bd;

  	vpso_q.LUN = quemsg->vcno;
  	strcpy(vpso_q.device_name, quemsg->vcaddr);
	
	/*--- previous cursor location information --*/
	vpso_q.pre_cur[0] = d_x;
	vpso_q.pre_cur[1] = d_y;
	vpso_q.pre_cur[2] = WHITE;
	vpso_q.pre_cur[3] = BLACK;

	/*--- after cursor location information --*/
	vpso_q.aft_cur[0] = x_loc;
	vpso_q.aft_cur[1] = y_loc;
	vpso_q.aft_cur[2] = b_col;
	vpso_q.aft_cur[3] = f_col;
	vpso_q.aft_cur[4] = ln;
	
  	vpso_q.BASE_screen[0] = NULL;
  	strcpy(vpso_q.text, errmsg);

	msgq_send(qid, &vpso_q, sizeof(vpso_q));

#ifdef	DISP
prt_sosm_msgq(&vpso_q);
#endif

	return;
} /*-- 	send_errmsg_to_sosm --*/


send_to_sksm(qid, fnkey, quemsg)
int	qid, fnkey;
struct	vqmmsg_t	*quemsg;
{
	struct sqmmsg_t	vpsk_t;

	vpsk_t.mtype = 1;
	vpsk_t.client_msqid = quemsg->client_msqid;
	vpsk_t.time = quemsg->time+1;
	vpsk_t.x25bd = quemsg->x25bd;
	vpsk_t.vcno = quemsg->vcno;
	vpsk_t.dm = fnkey;
	strcpy(vpsk_t.vcaddr, quemsg->vcaddr);
	vpsk_t.svid = 0;
	vpsk_t.ttp = quemsg->ttp;

	msgq_send(qid, &vpsk_t, sizeof(vpsk_t));
}

send_to_smsm(qid, quemsg)
int	qid;
struct	vqmmsg_t	*quemsg;
{
	struct sqmmsg_t	vpsm_t;

	vpsm_t.mtype = quemsg->mtype;
	vpsm_t.client_msqid = quemsg->client_msqid;
	vpsm_t.time = quemsg->time + 2;
	vpsm_t.x25bd = quemsg->x25bd;
	vpsm_t.vcno = quemsg->vcno;
	vpsm_t.dm = M_CONN;
	vpsm_t.query[0] = '\0';
	strcpy(vpsm_t.vcaddr, quemsg->vcaddr);
	vpsm_t.svid = quemsg->svid;
	vpsm_t.ttp = quemsg->ttp;

	msgq_send(qid, &vpsm_t, sizeof(vpsm_t));
}

send_to_vqm(qid, fnkey, quemsg)
int	qid, fnkey;
struct	vqmmsg_t	*quemsg;
{
	struct	vqmmsg_t	vpvq_t;
	
	quemsg->dm = fnkey;

	msgq_send(qid, quemsg, sizeof(vpvq_t));
	return;

}


long	getMSGQkey(keystr, keyno)
char	*keystr;
int	keyno;
{
	FILE	*fp, *fopen();
	char	tempbuf[100], keyname[20];
	int	cnt;
	long	key;

	if( (fp = fopen(KEYFILE, "r")) == 0 ) {
		fprintf(stderr, "ERROR> cannot open keyfile[%s] : %d\n"
			      , KEYFILE, errno);
		return((long)-1);
	}

	sprintf(keyname,"%s%d", keystr, keyno);

	while((cnt = fscanf(fp, "%s%ld", tempbuf, &key)) > 0) {
		if((cnt != 2) || (tempbuf[0] == '#')) continue;
		if(strcmp(keyname, tempbuf) == 0) {
			fclose(fp);
			return((long) key);
		}
	}
	fclose(fp);
	return((long )0);
}

int	open_msgq(key)
long	key;
{
	int	msgq_id;

   	if( (msgq_id = msgget(key, IPC_CREAT|0777)) == Error ) {
		fprintf(stderr, "can't msg_queue \n");
		return(Error);
	}
	
	return(msgq_id);
}

msgq_send(msg_qid, quemsg, sndmsgsize)
int	msg_qid;
char	*quemsg;
long	sndmsgsize;
{
	sndmsgsize -= sizeof(long);
	if( (msgsnd(msg_qid, quemsg, sndmsgsize, IPC_NOWAIT)) == -1 )
		fprintf(stderr, "msg_qid = %d  msgsnd error errno = %d \n"
				, msg_qid, errno);
	return;
} 

msgq_recv(msg_qid, quemsg, rcvmsgsize, wanttype)
int	msg_qid;
struct 	vqmmsg_t	*quemsg;
long	rcvmsgsize, wanttype;
{
	long	rcvln;

	rcvmsgsize -= sizeof(long);
	if( (rcvln = msgrcv(msg_qid, quemsg, rcvmsgsize, wanttype, 0)) == -1) {
		fprintf(stderr, "msgrcv failed \n");
		return(Error);
	}
	return(rcvln);

} /* msgq_recv --*/

int	gokey_map(keyword, key)
char	*keyword, *key;
{
	FILE	*fp, *fopen();
	char	record[100], *fd[100];

	if( (fp = fopen(DEFFILE, "r")) == NULL ) {
		fprintf(stderr, "%s file open error \n", DEFFILE);
		return(Error);
	}

	while( (fgets(record, sizeof(record), fp) != NULL) ) {
		if( record[0] == '#' )	continue;
		get_field(record, fd);
		if( strcmp(fd[0], keyword) == 0 ) {
			fclose(fp); strcpy(key, fd[1]);
			return(True);
		}
	}
	fclose(fp);
	return(False);

} /* gokey_map */

int	ddd_map(len, filename, query, icps_phone)
int	len;
char	*filename, *query, *icps_phone;
{
	FILE	*fp, *fopen();
	char	new_qry[20], phone1[10], phone2[10];
	char	record[100], *fd[100];

	if( (fp = fopen(filename, "r")) == NULL ) {
		fprintf(stderr, "%s file open error \n", filename);
		return(False);
	}

	sprintf(new_qry, "0%s", query);
	while( (fgets(record, sizeof(record), fp) != NULL) ) {
		if( record[0] == '#' )	continue;
		get_field(record, fd);
		if( strncmp(fd[0], new_qry, strlen(fd[0]) ) == 0 ) {
			fclose(fp); 
			strcpy(phone2, &new_qry[len-4]);
			new_qry[len-4] = '\0';
			strcpy(phone1, &new_qry[strlen(fd[0])]);
			sprintf(icps_phone, "%s-%s-%s", fd[0], phone1, phone2);
			return(True);
		}
	}
	fclose(fp);
	return(False);

} /* ddd_map */


get_field(buffer, fd)
char	*buffer;
char	*fd[50];
{
	char	*ptr, *strchr();
	int	i;

	fd[0]=buffer;
	for(i=1; ; i++) {
		fd[i] = strchr(fd[i-1],':');
		if(fd[i]==NULL) return(i-1);
		*(fd[i])=NULL;
		fd[i]+=1; 
	}
} /* get_field */


get_colon(buffer, fd)
char	*buffer;
char	*fd[50];
{
	char	*ptr, *strchr();
	int	i;

	fd[0]=buffer;
	for(i=1; ; i++) {
		fd[i] = strchr(fd[i-1], Colon);
		if(fd[i]==NULL) return(i-1);
		*(fd[i])=NULL;
		fd[i]+=1; 
	}
} /* get_colon */

get_subfd(fdstr, subfd)
char	*fdstr;
char	subfd[100][60];
{
	int	fdct=0, ln;
	char	*ptr1, *ptr2;

	if( *fdstr == NULL ) return(0);
	ptr1=fdstr;
	ptr2=fdstr;

	while(1) {
		if( *ptr2==',' || *ptr2 == NULL) {
			ln = ptr2-ptr1;
			memcpy(subfd[fdct], ptr1, ln);
			subfd[fdct][ln]=NULL;
			fdct++;
			ptr1=ptr2+1;
			if(*ptr2 == NULL ) return(fdct);
		}
		ptr2++;
	}
} /* get_subfd */

int	get_phonefd(phone, phonefd)
char	*phone;
char	phonefd[10][20];
{
	int	fdct=0, ln;
	char	*ptr1, *ptr2;

	if( *phone == NULL ) return(0);
	ptr1=phone;
	ptr2=phone;

	while(1) {
		if( *ptr2 == '-' || *ptr2 == NULL) {
			ln = ptr2-ptr1;
			memcpy(phonefd[fdct], ptr1, ln);
			phonefd[fdct][ln]=NULL;
			fdct++;
			ptr1=ptr2+1;
			if(*ptr2 == NULL ) return(fdct);
		}
		ptr2++;
	}
} /* get_phonefd */

errmsg_by_keyword(keyword, keylen, errmsg)
char	*keyword;
int	keylen;
char	*errmsg;
{
	FILE	*fp, *fopen();
	int	errlen;
	char	record[500];

	if( ( fp = fopen("ERRFILE", "r")) == NULL) {
		fprintf(stderr, "can't file \n");
		return(Error);
	}

	while( (fgets(record, sizeof(record), fp) != NULL) ) {
		if( record[0] == '#' || record[0] == ' ' )	continue;
		if( strncmp(record, keyword, keylen) == 0 ) {
			errlen = strlen(record) - 9;
			strncpy(errmsg, &record[7], errlen);
			errmsg[errlen] = '\0';
			fclose(fp);
			return(True);
		}
	}
	fclose(fp);
	return(False);

} /*-- errmsg_by_keyword --*/

prt_sct_shm(uidno)
short	uidno;
{
	fprintf(stderr, "-------------- SCT ------------- \n");
	fprintf(stderr, "Uid = %d ", SCT->Sct[uidno].uid);
	fprintf(stderr, "Svid = %d ", SCT->Sct[uidno].svid);
	fprintf(stderr, "Dm = %d ", SCT->Sct[uidno].dm);
	fprintf(stderr, "Time = %ld ", SCT->Sct[uidno].time);
	fprintf(stderr, "Type = %c ", SCT->Sct[uidno].type);
	fprintf(stderr, "Con = %d ", SCT->Sct[uidno].con);
	fprintf(stderr, "Id = %s ", SCT->Sct[uidno].id);
	fprintf(stderr, "Pwd = %s ", SCT->Sct[uidno].pwd);
	fprintf(stderr, "Dddphone = %s ", SCT->Sct[uidno].dddphone);
	fprintf(stderr, "Rw = %d ", SCT->Sct[uidno].rw);
	fprintf(stderr, "Ttp = %d ", SCT->Sct[uidno].ttp);
	fprintf(stderr, "Vcaddr = %s \n", SCT->Sct[uidno].vcaddr);

	return;
} /*-- prt_sct_shm --*/

prt_msg_queue(proc, quemsg)
char	*proc;
struct   vqmmsg_t	*quemsg;
{
	fprintf(stderr, " ------- [%s] Message Queue -----------\n", proc);
	fprintf(stderr, " time : %ld", quemsg->time);
	fprintf(stderr, " x25bd : %d", quemsg->x25bd);
	fprintf(stderr, " vcno : %d", quemsg->vcno);
	fprintf(stderr, " dm : %d \n", quemsg->dm);
	fprintf(stderr, " query : %s", quemsg->query);
	fprintf(stderr, " vcaddr : %s", quemsg->vcaddr);
	fprintf(stderr, " svid : %d \n", quemsg->svid);
	fprintf(stderr, " ttp : %d \n", quemsg->ttp);
}

prt_sosm_msgq(sosm)
struct   outmsg_t	*sosm;
{

	fprintf(stderr, " -----  SOSM_MSGQ ------------ \n");
	fprintf(stderr, "cntltp = %d ", sosm->cntltp);
  	fprintf(stderr, "LUN = %d ", sosm->LUN);
  	fprintf(stderr, "dname = %s \n", sosm->device_name);
	
	fprintf(stderr, "pre_x = %d ", sosm->pre_cur[0]);
	fprintf(stderr, "pre_y = %d ", sosm->pre_cur[1]);
	fprintf(stderr, "pre_b = %d ", sosm->pre_cur[2]);
	fprintf(stderr, "pre_f = %d \n", sosm->pre_cur[3]);

	fprintf(stderr, "aft_x = %d ", sosm->aft_cur[0]);
	fprintf(stderr, "aft_y = %d ", sosm->aft_cur[1]);
	fprintf(stderr, "aft_b = %d ", sosm->aft_cur[2]);
	fprintf(stderr, "aft_f = %d ", sosm->aft_cur[3]);
	fprintf(stderr, "aft_len = %d \n", sosm->aft_cur[4]);
	
  	fprintf(stderr, "screen = %s ", sosm->BASE_screen);
  	fprintf(stderr, "text = %s \n", sosm->text);

	return;

} /* prt_sosm_msgq */

/* year+month+day+hour */
get_current_time(date)
char	 *date;
{
	long	time(), nseconds;
	struct	tm *ptr, *localtime();
	
	nseconds = time(NULL);
	ptr = localtime(&nseconds);
	sprintf(date, "%02d%02d%02d", 
		      ptr->tm_year, ptr->tm_mon+1, ptr->tm_mday
/*
			, ptr->tm_hour
*/
	);
}

/*
 * From input 'filename'
 * make a directory name 'dir00/dir00' using hashing function
 */
hash_tele_dir(filename, hdir)
char	*filename, *hdir;
{
	char	d1[20];
	int	dirno1=0, dirno2=0;

	strncpy(d1, filename+5, 3);
	d1[3] = '\0';
	dirno1 = atoi(d1) * 46357 % 50;

	strncpy(d1, filename+9, 3);
	d1[3] = '\0';
	dirno2 = atoi(d1) * 46357 % 50;
	sprintf(hdir, "/TELE/dir%02d/dir%02d", dirno1,dirno2);
}

align_record(record,recln)
char	*record;
int	recln;
{
	char	*ptr, *strchr();

	ptr=strchr(record, '\n');
	if( ptr != NULL ) *ptr=NULL;
	size_align(record,recln-1);
}

size_align(string,size)
char	*string;
int	size;
{
	int	i, ln;

	ln=strlen(string);

	/* size==0  이면 입력 그냥 내보내기 */ 
	if(size==0) return(ln);

	/* size==ln  이면 입력 그냥 내보내기 */ 
	if( ln == size ) return(ln);

	/* 입력 string이 크면 짜르자 */ 
	if( ln > size ) {
		*(string+size)='\n';
		return(size);
	}
	/* 입력 string이 size보다 작은만큼 ' ' 문자 삽입 하자  */ 
	if( ln < size ) {
		for(i=ln; i<size; i++) *(string+i) = ' ';
		*(string+size)='\n';
		return(ln);
	}

} /* size_align */ 

is_numeric(str, size)
unsigned char	*str;
int		size;
{
	int	i;

	for(i=0; i<size; i++) 
		if( !isdigit(*(str+i)) ) return(False);
	return(True);

} /* is_numeric */


is_alphanum(str, size)
unsigned char	*str;
int		size;
{
	char 	*ptr;
	int 	a, b;
	setlocale(LC_CTYPE, "korean");

	/*-- 입력이 2이하면 에러 --*/
	if( size < 2 )	
		return(False);

	for(ptr = str;  *ptr != 0; ptr += b) {
		if ((b = mbtowc(&a, ptr, 5)) == -1) {
			return(0);
		} else if(iswprint(a)) {
/*
			putwchar(a);
			printf("\n%x, code = %d\n", a, b);
*/
		} else {
			return(False);
		}
	}

	return(True);
}


is_phone(phone)
char	*phone;
{
	char	*ptr, *strchr();

	if( (ptr=strchr(phone, '-')) == NULL ) 		return(False);
	if( strlen(phone) < 5 )				return(False);
	if( is_numeric(phone, ptr-phone) == False ) 	return(False);
	if( *(ptr+5) != NULL ) 				return(False);
	if( is_numeric(ptr+1, 4) == False ) 		return(False);

	return(True);
} /* is_phone */


/* ddd-국번-번호 check 	*/
int	is_dddphone(phone)
char	*phone;
{
	int	p_ln, ct, get_phonefd();
	char	sphone[50], pfd[10][20];

	strcpy(sphone, phone);
	ct = get_phonefd(sphone, pfd);

	switch(ct) {
	case 3 :	/* 0342-526-6547 */
		if( pfd[0][0] != '0' || atoi(pfd[0]) < 1 || atoi(pfd[0]) > 694 )
			return(False);

		p_ln = strlen(pfd[1]);
		if( p_ln < 2 || p_ln > 4 )			return(False);
		if( !is_numeric(pfd[1], p_ln) ) 		return(False);

		p_ln = strlen(pfd[2]);
		if( p_ln != 4 )					return(False);
		if( !is_numeric(pfd[2], p_ln) ) 		return(False);
		return(True);

	case 4 :	/* 0342-526-6547-name */
		/* current state */
		return(False);


		if( pfd[0][0] != '0' || atoi(pfd[0]) < 0 || atoi(pfd[0]) > 700 )
			return(False);

		p_ln = strlen(pfd[1]);
		if( p_ln < 2 || p_ln > 4 )			return(False);
		if( !is_numeric(pfd[1], p_ln) ) 		return(False);

		p_ln = strlen(pfd[2]);
		if( p_ln != 4 )					return(False);
		if( !is_numeric(pfd[2], p_ln) ) 		return(False);

		p_ln = strlen(pfd[3]);
		if( p_ln < 4 )					return(False);
		if( !is_alphanum(pfd[3], p_ln) )		return(False);

		/* dddphone_make */
/*
		sprintf(dddphone, "%s-%s-%s%c",pfd[0], pfd[1], pfd[2], 0x00);
		return(True);
*/

	default :
		return(False);
	} /* switch */
}


stoi(s, s_leng) 
char 	s[];
int 	s_leng;
{
	int 	i;
	char 	s_temp[10];

	s_temp[s_leng] = 0x00;
	strncpy(s_temp, s, s_leng);
	return(atoi(s_temp));
}

/*---	STAT DATA[SISDATA]  write  --*/
int	Wrt_Statfile(str)
char 	*str;
{
	FILE 	*sp;

	if( (sp = fopen(STATFILE, "a") ) == NULL) {
  		fprintf(stderr, "Can not open[%s] file\n"); 
		return(Error); 
	}

	fputs(str, sp);
	fclose(sp);
	return(True);
}
