/***************************************************************************
 MBC CODE split.c
***************************************************************************/

#include <stdio.h> 

 FILE *fp,*out; 
 int cnt; char bank[1024],temp[1024]; 
 int i,j,k,x,len; 
 char code[256],u_su[256],t_su[256],g_su[256];
 char giho[10][256],m_su[256],comp[6];
 int  ig_su,igiho[10],im_su;
 char *ptr;

 main(int argc, char *argv[])
{
 
 printf("Data Convert ..."); 
 fp = fopen("hancts.mbc","r");
 if (fp==NULL) exit(0); cnt=0;
 do {
     if (fgets(temp,1024,fp)==NULL) break;
     strcpy(bank,temp);
     strcpy(code,"data/");
     for (i=0; i<4; i++)
         code[i+5]=bank[i]; code[4+5]=0;
     out = fopen(code,"w");
     fprintf(out,bank);
     fclose(out);
     printf("\n %s",bank);
    } while(1);
 fclose(fp); 

 printf("\n");
}



