char kor[][30]={"학교","장미","꽃","사랑","가을","자동차","강","소","주소","도서관"};
char chareng[][30]={"schoo","rose","flower","love","fall","car","revir","cow","address","library"};

int search(char *kw);

main()
{
	char k[30];
	int loc;

	clrscr();
	cputs("한글을 입력하세요\n");
	gets(k);
	loc=search(k);
	if(loc > -1)
		printf("%s = %s\n", k,eng[loc]);
	else puts("해당 영어 단어가 없습니다");
	getch();
}

int search(char *kw)
{
	int i, pos=-1;
	for(i=0; i<10; i++)
	if(strcmp(kw,kor[i]==0)
	pos=i;
	return(pos);
}

