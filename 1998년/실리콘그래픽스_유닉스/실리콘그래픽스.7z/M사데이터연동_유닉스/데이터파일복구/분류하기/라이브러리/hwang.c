#include <stdio.h>
#include "item.h"

#define	REGION	"mbcregion.txt"
#define	DATA	"mbcdata.txt"
#define SZL_r	sizeof(line_r)
#define SZL_d	sizeof(line_d)

typedef struct {

	char	key[8] ;
	char	data[38] ;
}line_r ;

typedef struct {

	char	key[4] ;
	char	data[89] ;
}line_d ;

/** =========================================================
	search_item() 에서 사용할 테스팅 함수 
    
    항상 값은 0 아니면 1을 리턴해야 하고
    아규먼트로 키값 포인터(key)와 레코드 포인터(rec)를 받는다
============================================================**/

key_test_r(key,rec)
char	*key ;
line_r	*rec ;
{

	if( strncmp(key,rec->key, 8) == 0 )	return(1) ;
	else return(0) ;
}

key_test_d(key,rec)
char	*key ;
line_d	*rec ;
{

	if( strncmp(key,rec->key, 4) == 0 )	return(1) ;
	else return(0) ;
}


print_region(rec)
line_r	*rec ;
{
char	buf[200] ;
char	buf_data[200] ; /* BUGGY */
char	test_data[200] ; /* BUGGY */
char	new_buf[200] ;
char	test_buf[300] ;
char	imsi[20];
int	heap;

/*
	strncpy(buf_data,rec->key, 4) ;
	strncpy(&buf_data[4],rec->data, 89) ;
*/
	strcpy(buf_data,rec->data) ;
	heap =strlen(buf_data); 
	printf("size :%d, buf_data:%s",heap,buf_data) ;
/*
	sprintf(test_buf,"%.8s:%.18s:%.11s:",buf_data,&buf_data[8],&buf_data[16],&buf_data[27]);

	heap = strlen(test_buf);	
	printf("size >%d",heap);
	printf("test_buf>%s",test_buf);

/*
	test_buf[heap] = NULL;
	extract_field_from_record(test_buf,17,imsi);
	printf("imsi>%s",imsi);
	extract_field_from_record(test_buf,18,imsi);
	printf("imsi>%s",imsi);
	extract_field_from_record(test_buf,19,imsi);
	printf("imsi>%s",imsi);
*/

}


print_data(rec)
line_d	*rec ;
{
char	buf[200] ;
char	buf_data[200] ; /* BUGGY */
char	test_data[200] ; /* BUGGY */
char	new_buf[200] ;
char	test_buf[300] ;
char	imsi[20];
int	heap;

/*
	strcpy(test_data,"123456789012345678901234567890\n");

	strncpy(buf_data,rec->key, 4) ;
	strncpy(&buf_data[4],rec->data, 89) ;
*/
	strcpy(buf_data,rec->data) ;
	heap =strlen(buf_data); 
	printf("size :%d, buf_data:%s",heap,buf_data) ;

	sprintf(test_buf,"%.6s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.1s:",buf_data,&buf_data[6],&buf_data[14],&buf_data[15],&buf_data[23],&buf_data[24],&buf_data[32],&buf_data[33],&buf_data[41],&buf_data[42],&buf_data[50],&buf_data[51],&buf_data[59],&buf_data[60],&buf_data[68],&buf_data[69],&buf_data[77],&buf_data[78],&buf_data[86],&buf_data[87],&buf_data[88]);

	heap = strlen(test_buf);	
	printf("test_buf>%s",test_buf);

	test_buf[heap] = NULL;
	extract_field_from_record(test_buf,17,imsi);
	printf("imsi>%s",imsi);
	extract_field_from_record(test_buf,18,imsi);
	printf("imsi>%s",imsi);
	extract_field_from_record(test_buf,19,imsi);
	printf("imsi>%s",imsi);

}

main()
{

line_r	Line_r ;
line_d	Line_d ;
int	n=0 ;
char	buf[200] ;

char	buf_region[200] ; /* BUGGY */
char	test_region[200] ; /* BUGGY */
char	new_region[300] ;
char	region_buf[300] ;

char	test_data[200] ; /* BUGGY */
char	buf_data[200] ; /* BUGGY */
char	new_buf[300] ;
char	test_buf[400] ;
char	imsi[20];
int	heap;

	
	n = search_item(REGION,"01010001",&Line_r,SZL_r,key_test_r) ;

	strcpy(buf_region,Line_r.data) ;

	printf("buf_region>%s",buf_region) ;

	sprintf(new_region,"%.8s:%.18s:%.11s:",buf_region,&buf_region[8],&buf_region[26]);

	printf("region_region>%s",new_region);

	extract_field_from_record(new_region,1,imsi);
	printf("\nimsi>%s",imsi);


	printf("\n---------------------------------------\n");

	n = search_item(REGION,"01010004",&Line_r,SZL_r,key_test_r) ;

	strcpy(buf_region,Line_r.data) ;

	printf("buf_region>%s",buf_region) ;

	sprintf(new_region,"%.8s:%.18s:%.11s:",buf_region,&buf_region[8],&buf_region[26]);

	printf("region_region>%s",new_region);

	extract_field_from_record(new_region,1,imsi);
	printf("\nimsi>%s",imsi);

	/* key="0111" 로 레코드 찾아서 프린트 하기  */
	n = search_item(DATA,"0111",&Line_d,SZL_d,key_test_d) ;
	heap = sizeof(Line_d.data);
	strncpy(buf_data,Line_d.data,sizeof(Line_d.data)) ;
	
	heap = strlen(buf_data);
	printf(" \nbuf_data>%s",buf_data) ;

	sprintf(test_buf,"%.6s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.1s:",buf_data,&buf_data[6],&buf_data[14],&buf_data[15],&buf_data[23],&buf_data[24],&buf_data[32],&buf_data[33],&buf_data[41],&buf_data[42],&buf_data[50],&buf_data[51],&buf_data[59],&buf_data[60],&buf_data[68],&buf_data[69],&buf_data[77],&buf_data[78],&buf_data[86],&buf_data[87],&buf_data[88]);

	printf("\ntest_buf>%s",test_buf);

	extract_field_from_record(test_buf,0,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,17,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,18,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,19,imsi);
	printf("\nimsi>%s",imsi);

	printf("\n  ------------------------\n");


	/* key="0101" 로 레코드 찾아서 프린트 하기  */
	n = search_item(DATA,"0101",&Line_d,SZL_d,key_test_d) ;
	heap = sizeof(Line_d.data);
	strncpy(buf_data,Line_d.data,sizeof(Line_d.data)) ;

	printf(" \nbuf_data>%s",buf_data) ;

	sprintf(test_buf,"%.6s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.1s:",buf_data,&buf_data[6],&buf_data[14],&buf_data[15],&buf_data[23],&buf_data[24],&buf_data[32],&buf_data[33],&buf_data[41],&buf_data[42],&buf_data[50],&buf_data[51],&buf_data[59],&buf_data[60],&buf_data[68],&buf_data[69],&buf_data[77],&buf_data[78],&buf_data[86],&buf_data[87],&buf_data[88]);

	printf("\ntest_buf>%s",test_buf);

	extract_field_from_record(test_buf,0,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,1,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,2,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,3,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,4,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,5,imsi);
	printf("\nimsi>%s",imsi);
	extract_field_from_record(test_buf,6,imsi);
	printf("\nimsi>%s\n",imsi);


}

extract_field_from_record(buf,pos,field) 
char	*buf, *field;
int	pos;
{
	int	i;
	char	*token, *tmp_buf, *strchr();

	tmp_buf = buf;
	for(i=0; i<pos; i++) tmp_buf = strchr(tmp_buf,':') + 1;
	token = strchr(tmp_buf,':');
	while(tmp_buf != token)  *(field++) = *(tmp_buf++);
	*field = NULL;

} /* extract_field_from_record */


