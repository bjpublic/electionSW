#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#define	SZL sizeof(line)
#define	GCDC "HEHE"

typedef	struct{
	char key[4];
	char data[10];
}line;

key_test(key,rec)
char *key;
line *rec;
{
	if(strncmp(key,rec->key,4) == 0)  return(1);
  	else				  return(0);
}

print_line(rec)
line	*rec;
{

	char	buf[32];

	strncpy(buf,rec->key,4);
	strncpy(&buf[4],rec->data,10);
	buf[16]='\0';
	printf("%s",buf);
}

	

main()
{

	int i,n=0;
	line	Line;

	n= search_item(GCDC,"0101",&Line,SZL,key_test);
	print_line(&Line);
}
