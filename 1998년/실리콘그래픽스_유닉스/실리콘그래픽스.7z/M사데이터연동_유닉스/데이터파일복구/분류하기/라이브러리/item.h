extern int add_item();
extern int search_item();
extern int delete_item();
extern int fetch_item();
extern int fetch_items();
extern int change_item();
extern int num_items();
