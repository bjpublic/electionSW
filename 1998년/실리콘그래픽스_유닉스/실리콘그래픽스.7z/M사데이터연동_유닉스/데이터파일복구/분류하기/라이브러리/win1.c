#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "kyyy_def.h"

#ifndef NO_STDLIB_H
#else
char *getenv();
#endif

#define REGION "kyyy.lst"
#define DATA  "kyyy.mbc"
#define SZL_r sizeof(line_r)
#define SZL_d sizeof(line_d)

typedef struct{
	char key[8];
	char data[65];
}line_r;

typedef struct{
	char key[8];
	char data[86];
}line_d;

key_test_r(key,rec)
char *key;
line_r *rec;
{	
	if(strncmp(key, rec->key, 8) == 0) return(1);
	else return(0);
}

key_test_d(key,rec)
char *key;
line_d *rec;
{
	if(strncmp(key, rec->key,8) == 0) return(1);
	else return(0);
}
typedef struct{
	char name[128];
	char val[128];
}entry;
void getword(char *word, char *line, char stop);
char x2c(char *what);
void unescape_url(char *url);
void plustospace(char *str);
int data_display(char *id);

main(int argc, char *argv[])
{
	entry entries[100];
	register int x, m = 0;
	char *cl;
	line_r Line_r;
	line_d Line_d;
 	char buf[200];
	char buf_region[200];
	char test_region[200];
	char new_region[300];
	char region_buf[300];
	char buf_data[200];
	char test_data[200];
	char new_buf[200];
	char test_buf[400];
	char imsi_a[30];
	char imsi_b[20];
	char imsi_c[20];
	char imsi_d[20];
	char imsi_e[20];
	char imsi_f[20];
	char imsi_g[20];

	char point[24];
	
	char id[20], passwd[8];
	char rec_id[20], rec_passwd[8];
	char fd[10][20];
	char key_word[30][10];
	char tmp_count[5];
	int ct,i, n = 0;
	int heap,count,num;


	printf("Content-type:  text/html%c%c", 10,10);
	printf("<html><body>");
	cl = getenv("QUERY_STRING");
	if(cl == NULL) {
		printf("No query information to decode.\n");
		exit(1);
	}

	for(x=0; cl[0] != '\0'; x++) {
	m=x;
	getword(entries[x].val, cl, '&');
	plustospace(entries[x].val);
	unescape_url(entries[x].val);
	getword(entries[x].name, entries[x].val, '=');
	}

    strcpy(tmp_count,entries[1].val);
    num = atoi(tmp_count);
    strcpy(tmp_count,entries[3].val);
    count = atoi(tmp_count);

printf("<td>�������� �����ǿ�</td>");

for(i=0; i<count;i++)
{
// ���ű��̸� �ҷ��ͼ� �����ϴ� �κ�

	switch(num) {
	case 1 : 
		strcpy(point,region_seoul[i]);
		break;
	case 2 : 
		strcpy(point,region_pusan[i]);
		break;
	default :break;
      }
	n=search_item(REGION,point, &Line_r, SZL_r,key_test_r);
	strcpy(buf_region, Line_r.data);
	sprintf(new_region,"%.8s:%.23s:",buf_region, &buf_region[8]);
	extract_field_from_record(new_region,1,imsi_a);

//���� ����Ÿ �ҷ��ͼ� �����ִ� �κ�

   	n=search_item(DATA, data_seoul[i], &Line_d, SZL_d, key_test_d);
	strcpy(buf_data, Line_d.data);
	sprintf(test_buf,"%.6s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.8s:%.1s:%.1s:", buf_data,&buf_data[6],&buf_data[14],&buf_data[15],&buf_data[23],&buf_data[24],&buf_data[32],&buf_data[33],&buf_data[41],&buf_data[42],&buf_data[50],&buf_data[51],&buf_data[59],&buf_data[60],&buf_data[68],&buf_data[69], &buf_data[77],&buf_data[78],&buf_data[86],&buf_data[87],&buf_data[88]);
	extract_field_from_record(test_buf,5,imsi_b);
	extract_field_from_record(test_buf,7,imsi_c);
	extract_field_from_record(test_buf,9,imsi_d);
	extract_field_from_record(test_buf,10,imsi_e);
	extract_field_from_record(test_buf,14,imsi_f);
	extract_field_from_record(test_buf,15,imsi_g);
/*
printf("%s\n", imsi_b);
printf("%s\n", imsi_c);
printf("%s\n", imsi_d);
printf("%s\n", imsi_e);
printf("%s\n", imsi_f);
printf("%s\n", imsi_g);
*/
printf("<table border =1>");
printf("<tr>");
printf("<td width=70 rowspan=2>%s<h3></h3><p>&nbsp\n",imsi_a);
printf("&nbsp");
printf("</td>");
printf("<td width=68><p>&nbsp");
printf("�ĺ��̸�</td>");
printf("<td width=66><p>&nbsp");
printf("�ĺ�1</td>");
printf("<td width=70><p>&nbsp");
printf("&nbsp;�ĺ�2</td>");
printf("<td width=70><p>�ĺ�3</td>");
printf("<td width=70><p>�ĺ�4</td>");
printf("<td width=70><p>�ĺ�5</td>");
printf("<td width=70><p>�ĺ�6</td>");
printf("<td width=70><p>�ĺ�7</td>");
printf("<td width=70><p>�ĺ�8</td>");
printf("</tr><tr>");
printf("<td width=68 height=39><p>&nbsp\n");
printf("�� ǥ ��</td>");
printf("<td width=66 height=39>%s<p>&nbsp\n",imsi_b);
printf("</td>");
printf("<td width=70 height=39>%s<p>&nbsp\n",imsi_c);
printf("</td>");
printf("<td width=70 height=39>%s<p>&nbsp\n",imsi_d);
printf("</td>");
printf("<td width=70 height=39>%s<p>&nbsp\n",imsi_e);
printf("</td>");
printf("<td width=70 height=39>%s<p>&nbsp\n",imsi_f);
printf("</td>");
printf("<td width=70 height=39>%s<p>&nbsp\n",imsi_g);
printf("</td>");
printf("<td width=70 height=39><p>&nbsp\n");
printf("</td>");
printf("<td width=70 height=39><p>&nbsp\n");
printf("</td>");
printf("</tr></table>");
printf("<p>&nbsp");
printf("</p>");

}

}
extract_field_from_record(buf,pos,field)
char *buf,*field;
int pos;
{
	int i;
	char *token, *tmp_buf, *strchr();

	tmp_buf=buf;
	for(i=0; i<pos; i++) tmp_buf = strchr(tmp_buf, ':') +1;
	token=strchr(tmp_buf,':');
	while(tmp_buf != token) *(field++) = *(tmp_buf++);
	field=NULL;
}
