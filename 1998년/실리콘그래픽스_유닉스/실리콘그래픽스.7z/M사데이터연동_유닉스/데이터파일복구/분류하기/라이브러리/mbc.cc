/***************************************************************************
 MBC CODE c-mbc.c

 코드 시간 유권자수 투표자수 기호1 ,,,, 무효표수 예측판정 
 (4)  (6)     (8)      (8)     (8)        (8)      (5)

 코드 유권자수 투표자수 개표수 기호1 예측판정  
***************************************************************************/

#include <stdio.h> 

 FILE *fp,*out; 
 int cnt; char bank[400][1024],temp[1024]; 
 int i,j,k,x,len; 
 char code[256],u_su[256],t_su[256],g_su[256];
 char giho[10][256],m_su[256],comp[6];
 int  ig_su,igiho[10],im_su;
 char *ptr;

 main(int argc, char *argv[])
{
 
 printf("Data Convert ..."); 
 fp = fopen("hancts.mbc","r");
 if (fp==NULL) exit(0); cnt=0;
 do {
     if (fgets(temp,1024,fp)==NULL) break;
     strcpy(bank[cnt++],temp);
    } while(1);
 fclose(fp); 
 len=strlen(bank[k]);
 for (k=0; k<cnt; k++) 
     {
      for (i=0; i<4; i++) code[i]=bank[k][i]; code[4]=0;
      for (i=0; i<8; i++) u_su[i]=bank[k][i+8+2]; u_su[8]=0;
      for (i=0; i<8; i++) t_su[i]=bank[k][i+16+2]; t_su[8]=0;
      for (j=0; j<7; j++)
      for (i=0; i<8; i++) giho[j][i]=bank[k][i+24+2+j*8]; giho[j][8]=0;
      for (i=0; i<8; i++) m_su[i]=bank[k][i+24+2+j*8]; m_su[8]=0;
      
      /*for (i=0; i<6; i++) comp[i]=bank[k][i+24+2+(j+1)*8]; comp[8]=0;*/
      strcpy(comp,"00000");

      /* 개표수 = 후보별 득표수 + 무효표수*/      ig_su=0;
      for (i=0; i<7; i++)
          {
           igiho[i] = strtol(giho[i],&ptr,10); 
           ig_su += igiho[i];
          }
      ig_su = ig_su + strtol(m_su,&ptr,10);
      sprintf(g_su,"%8d",ig_su);
      sprintf(temp,"code/%s",code);

      //if (code[2]!='9' || code[3]!='9') continue;
      out=fopen(temp,"w");
      strcpy(giho[7],"        ");
      strcpy(giho[8],"        ");
      strcpy(giho[9],"        ");
      fprintf(fp,"%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s",code,u_su,t_su,g_su,giho[0],giho[1],giho[2],giho[3],giho[4],giho[5],giho[6],giho[7],giho[8],giho[9],comp);
      fclose(out);
      printf("\n<br>%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s@%s",code,u_su,t_su,g_su,giho[0],giho[1],giho[2],giho[3],giho[4],giho[5],giho[6],giho[7],giho[8],giho[9],comp);
     } 
 printf("\n");
}

