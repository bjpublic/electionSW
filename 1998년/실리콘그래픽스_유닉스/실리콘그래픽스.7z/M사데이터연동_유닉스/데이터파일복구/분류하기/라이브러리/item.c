#include<stdio.h>
#include<sys/file.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<unistd.h>
#include<time.h>
#include<fcntl.h>
#ifdef BSD
#define  P(fd)        flock(fd,LOCK_EX)
#define V(fd)          flock(fd,LOCK_UN)
#else
#define P(fd)    lockf(fd,F_LOCK,0)
#define V(fd)    lockf(fd,F_ULOCK,0)
#endif


int search_item(db_file,key,record,rsz,test)
char *db_file,*key, *record;
int rsz;
int (*test)();
{
int fd;
int num,i;
	num=num_items(db_file,rsz);
	if(num == 0) {
	fprintf(stderr,"search_item:empty file\n");
	return(-1);
	}
	if((fd = open(db_file,O_RDONLY)) < 0) {
	fprintf(stderr,"search_item:can't open file\n");
	close(fd);
	return(-1);
}

lseek(fd,0,SEEK_SET);
for(i=0; i<num; i++) {
	if(read(fd,record,rsz)<0) {
	fprintf(stderr,"search_item : read error\n");
	close(fd);
	return(-1);
	}
	
	if((*test)(key,record)) break;
	}
if(i < num) {
	close(fd);
	return(i);
}
else
{
	close(fd);
	return(-1);
}
}
int num_items(db_file,rsz)
char *db_file;
int  rsz;
{
struct stat stb;
	if(stat(db_file, &stb) <0) {
	fprintf(stderr,"num_items : failed in stst\n");
	return(0);
	}
	else return((int)stb.st_size/rsz);
}
