#include<stdio.h>


main()
{

printf("Content-Type:  text/html\n\n");

printf("<html>");
printf("<head>");
printf("<p><font size=5>&lt;기초단체장&gt;</font>&nbsp;<font size=3>지역을 클릭해주세요</font></p>");
printf("<p>&nbsp");
printf("<form method=get>");
printf("<table border=1>");
printf("<tr>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gd_seoul.cgi?name=seoul&value=1&name=count&value=25>서울</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gd_pusan.cgi?name=pusan&value=2&name=count&value=9>부산</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gcdc.cgi>대구</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gcdc.cgi>인천</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gcdc.cgi>광주</a></b></font></td>");
printf("</tr><tr>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gcdc.cgi>대전</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gcdc.cgi>울산</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gcdc.cgi>경기도</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gcdc.cgi>강원도</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gcdc.cgi>충청남도</a></b></font></td>");
printf("</tr><tr>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gcdc.cgi>충청북도</a></b></font></td>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gcdc.cgi>전라남도</a></b></font></td>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gcdc.cgi>전라북도</a></b></font></td>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gcdc.cgi>경상남도</a></b></font></td>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gcdc.cgi>경상북도</a></b></font></td>");
printf("</tr><tr>");
printf("<td height=31 colspan=2><p align=center>&nbsp");
printf("</td>");
printf("<td width=141 height=31><p align=center><font size=4><b><a href=gcdc.cgi>제주도</a></b></font></td>");
printf("<td height=31 colspan=2><p align=center>&nbsp");
printf("</td>");
printf("</tr></table>");
printf("<p>&nbsp");
printf("</form>");
printf("</p>");
printf("</body>");
printf("</html>");
}
