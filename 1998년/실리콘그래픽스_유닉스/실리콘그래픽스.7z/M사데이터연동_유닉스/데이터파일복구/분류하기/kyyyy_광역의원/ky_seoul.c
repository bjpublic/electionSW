#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>


main()
{

	FILE *fn;
	int i;
	char su[256]; char code[5];
	printf("Content-type: text/html\n\n");
	printf("<html><body><center>");
	printf("<td>서울지역 광역의원</td></center>");

	fn=fopen("gcdc.mbc", "rt");
	fgets(su,256,fn);
	for(i=0;i<47;i++)
	{
        printf("<p>&nbsp;");
        printf("<table border = 1>");
      printf("<tr>");
      printf("<td width=70 rowspan=2>%s<p>&nbsp\n");
      printf("&nbsp");
      printf("</td>");
      printf("<td width=68><p>&nbsp");
      printf("후보이름</td>");
      printf("<td width=66><p>&nbsp");
      printf("후보1</td>");
      printf("<td width=70><p>&nbsp");
      printf("&nbsp;후보2</td>");
      printf("<td width=70><p>후보3</td>");
      printf("<td width=70><p>후보4</td>");
      printf("<td width=70><p>후보5</td>");
      printf("<td width=70><p>후보6</td>");
      printf("<td width=70><p>후보7</td>");
      printf("<td width=70><p>후보8</td>");
      printf("</tr><tr>");
      printf("<td width=68 height=39><p>&nbsp\n");
      printf("득 표 수</td><pre>");
      printf("<td width=66 height=39><p>&nbsp\n");
      printf("</td>");
      printf("<td width=70 height=39><p>&nbsp\n");
      printf("</td>");
      printf("<td width=70 height=39><p>&nbsp\n");
      printf("</td>");
      printf("<td width=70 height=39><p>&nbsp\n");
      printf("</td>");
      printf("<td width=70 height=39><p>&nbsp\n");
      printf("</td>");
      printf("<td width=70 height=39><p>&nbsp\n");
      printf("</td>");
      printf("<td width=70 height=39><p>&nbsp\n");
      printf("</td>");
      printf("<td width=70 height=39><p>&nbsp\n");
      printf("</td>");
      printf("</tr></table>");
      printf("<p>&nbsp");
      printf("</p>");
	
     //   code[0]=su[0]; code[1]=su[1]; code[2]=su[2]; code[3]=su[3]; code[4]=0;
	fn=fopen("gcdc.mbc", "rt");
	fgets(su,256,fn);
	
     // if (strncmp(su,"01",2)!=0) break;
	printf("%s", su);
	}
	fclose(fn);
	printf("</body></html>");
}
