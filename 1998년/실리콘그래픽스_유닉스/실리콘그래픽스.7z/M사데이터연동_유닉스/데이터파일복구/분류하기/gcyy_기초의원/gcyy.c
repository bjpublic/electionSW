#include<stdio.h>


main()
{

printf("Content-Type:  text/html\n\n");

printf("<html>");
printf("<head>");
printf("<p><font size=5>&lt;�����ǿ�&gt;</font>&nbsp;<font size=3>������ Ŭ�����ּ���</font></p>");
printf("<p>&nbsp");
printf("<table border>");
printf("<tr>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gu_seoul.cgi>����</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_pusan.cgi>�λ�</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_deagu.cgi>�뱸</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_inchun.cgi>��õ</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_kwang.cgi>����</a></b></font></td>");
printf("</tr><tr>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_deajun.cgi>����</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_ulsan.cgi>���</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_kyunggi.cgi>��⵵</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_kwangwon.cgi>������</a></b></font></td>");
printf("<td width=141 height=30><p align=center><font size=4><b><a href=gi_chungnam.cgi>��û����</a></b></font></td>");
printf("</tr><tr>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gi_chungk.cgi>��û�ϵ�</a></b></font></td>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gi_junnam.cgi>���󳲵�</a></b></font></td>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gi_junbuk.cgi>����ϵ�</a></b></font></td>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gi_kyungnam.cgi>��󳲵�</a></b></font></td>");
printf("<td width=141 height=32><p align=center><font size=4><b><a href=gi_kyungbuk.cgi>���ϵ�</a></b></font></td>");
printf("</tr><tr>");
printf("<td height=31 colspan=2><p align=center>&nbsp");
printf("</td>");
printf("<td width=141 height=31><p align=center><font size=4><b><a href=gi_jeaju.cgi>���ֵ�</a></b></font></td>");
printf("<td height=31 colspan=2><p align=center>&nbsp");
printf("</td>");
printf("</tr></table>");
printf("<p>&nbsp");
printf("</p>");
printf("</body>");
printf("</html>");
}
