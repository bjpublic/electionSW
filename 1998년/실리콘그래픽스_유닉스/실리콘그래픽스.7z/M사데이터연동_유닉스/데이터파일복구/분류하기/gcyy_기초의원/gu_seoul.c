#include<stdio.h>

main()
{

printf("Content-Type:  text/html\n\n");
printf("<html>");
printf("<head>");

printf("<p><font size=3>&lt서울지역 기초의원&gt;</font>&nbsp;</font></p>"); 
printf("<table border=1>");
printf("<tr>");
printf("<td width=141 height=26><p><a href=gs_jonglo.cgi?name=seoul&value=1&name=count&value=19><종로구</a></td>");
printf("<td width=141 height=26><p>중구</td>");
printf("<td width=141 height=26><p>용산구</td>");
printf("<td width=141 height=26><p>성동구</td>");
printf("<td width=141 height=26><p>광진구</td>");
printf("</tr><tr>");
printf("<td width=141 height=27><p>동대문구</td>");
printf("<td width=141 height=27><p>중랑구</td>");
printf("<td width=141 height=27><p>성북구</td>");
printf("<td width=141 height=27><p>강북구</td>");
printf("<td width=141 height=27><p>도봉구</td>");
printf("</tr><tr>");
printf("<td width=141 height=27><p>노원구</td>");
printf("<td width=141 height=27><p>은평구</td>");
printf("<td width=141 height=27><p>서대문구</td>");
printf("<td width=141 height=27><p>마포구</td>");
printf("<td width=141 height=27><p>양천구</td>");
printf("</tr><tr>");
printf("<td width=141 height=27><p>강서구</td>");
printf("<td width=141 height=27><p>구로구</td>");
printf("<td width=141 height=27><p>금천구</td>");
printf("<td width=141 height=27><p>영등포구</td>");
printf("<td width=141 height=27><p>동작구</td>");
printf("</tr><tr>");
printf("<td width=141 height=28><p>관악구</td>");
printf("<td width=141 height=28><p>서초구</td>");
printf("<td width=141 height=28><p>강남구</td>");
printf("<td width=141 height=28><p>송파구</td>");
printf("<td width=141 height=28><p>강동구</td>");
printf("</tr></table>");
printf("<p>&nbsp;</p>");
printf("</body>");
printf("</html>");
}
