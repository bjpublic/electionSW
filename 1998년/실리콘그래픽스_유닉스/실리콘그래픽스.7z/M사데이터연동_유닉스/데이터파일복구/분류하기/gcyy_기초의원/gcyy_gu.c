#include<stdio.h>

main()
{

printf("Content-Type:  text/html\n\n");
printf("<html>");
printf("<head>");
printf("<p>&lt");
printf("구역을 클릭해주세요&gt");
printf("<a href=gc_seoul.cgi>종로구 </a>");
printf("</p>");
printf("<p>&nbsp");
printf("<table border=1>");
printf("<tr>");
printf("<td width=708><p>종로구 중구.......</td>");
printf("</tr></table>");
printf("<p>&nbsp");
printf("</p>");
printf("</body>");
printf("</html>");

}
