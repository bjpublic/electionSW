#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>



void displayForm(char cyty[100],int dat1,int dat2,int dat3,int dat4,int dat5,int dat6,int dat7,int dat8);

void displayForm(char cyty[100],int dat1,int dat2,int dat3,int dat4,int dat5,int dat6,int dat7,int dat8)
{
printf("<p>&nbsp;");
printf("<table border = 1>");
printf("<tr>");
printf("<td width=70 rowspan=2>%s<p>&nbsp\n", cyty);
printf("&nbsp");
printf("</td>");
printf("<td width=68><p>&nbsp");
printf("후보이름</td>");
printf("<td width=66><p>&nbsp");
printf("후보1</td>");
printf("<td width=70><p>&nbsp");
printf("&nbsp;후보2</td>");
printf("<td width=70><p>후보3</td>");
printf("<td width=70><p>후보4</td>");
printf("<td width=70><p>후보5</td>");
printf("<td width=70><p>후보6</td>");
printf("<td width=70><p>후보7</td>");
printf("<td width=70><p>후보8</td>");
printf("</tr><tr>");
printf("<td width=68 height=39><p>&nbsp\n");
printf("득 표 수</td><pre>");
printf("<td width=66 height=39>%-d<p>&nbsp\n", dat1);
printf("</td>");
printf("<td width=70 height=39>%-d<p>&nbsp\n", dat2);
printf("</td>");
printf("<td width=70 height=39>%d<p>&nbsp\n", dat3);
printf("</td>");
printf("<td width=70 height=39>%-8d<p>&nbsp\n", dat4);
printf("</td>");
printf("<td width=70 height=39>%-8d<p>&nbsp\n", dat5);
printf("</td>");
printf("<td width=70 height=39>%-8d<p>&nbsp\n", dat6);
printf("</td>");
printf("<td width=70 height=39>%-8d<p>&nbsp\n", dat7);
printf("</td>");
printf("<td width=70 height=39>%-8d<p>&nbsp\n", dat8);
printf("</td>");
printf("</tr></table>");
printf("<p>&nbsp");
printf("</p>");
}

 main()
{
	int fn, n;

	char buf1[150];

        char su[15][20]; char *temp; char temp_str[100];
        int i,j,k;
	
        printf("Content-type: text/html\n\n");
        printf("<html><body>");

	fn = open("data/0199", O_RDONLY);

	n=read(fn, buf1, 150);
        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
           } 

displayForm("seoul1",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
        close(fn);

	fn = open("data/0299", O_RDONLY);
	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul2",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));

	close(fn);
	fn = open("data/0399", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul3",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));

	close(fn);

	fn = open("data/0499", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul4",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/0599", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul5",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/0699", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul6",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/0799", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul7",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/0899", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul8",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/0999", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul9",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/1099", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul10",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("code/1199", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul11",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/1299", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul12",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/1399", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul13",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/1499", O_RDONLY);

	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul14",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/1599", O_RDONLY);
	n=read(fn, buf1, 150);

        j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i];
            }

displayForm("seoul15",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);
	fn = open("data/1699", O_RDONLY);
	n = read(fn, buf1, 150);
	j=0; k=0;
        for (i=0; i<strlen(buf1); i++)
            {
             if (buf1[i]=='@') {su[k][j]=0; j=0; k++;}
           else
             su[k][j++] = buf1[i]; 
            }
        
displayForm("seoul16",atoi(su[7]),atoi(su[8]),atoi(su[9]),atoi(su[10]),atoi(su[11]),atoi(su[12]),atoi(su[13]),atoi(su[14]));
	close(fn);

}
