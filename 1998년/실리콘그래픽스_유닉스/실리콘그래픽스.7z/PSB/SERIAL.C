/********************************************************************/
/*																	*/
/*		serial.c : ��Ű� ���õ� �ϵ���� ���� ����� ����ִ� ���� */ 
/*																	*/
/*																	*/
/*																	*/
/* 		 Copyright (c) 1996 by PSB Corp.    					*/
/********************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <time.h>

#define DFLT_SPEED 			B9600   /* communication speed */
#define	TTY_LINE			"ttyd1" /* communication file */

extern int fd;                      /* ars_main.c Defined         */

void ExitSignal(int sig)	
{
	fprintf(stderr, "Exiting on signal %d\n", sig);
	exit(1);
}

void TtyIoctl(int cmd, struct termio *termio)
{
	if (ioctl(fd, cmd, termio) < 0) {
		exit(1);
	}
}

void OpenSerialLine(void)
{
/*
	(void)signal(SIGINT,  ExitSignal);
	(void)signal(SIGQUIT, SIG_IGN);
	(void)signal(SIGHUP,  SIG_IGN);
	(void)signal(SIGTERM, SIG_IGN);
	(void)setpgrp();
*/

	(void)signal(SIGINT,  SIG_IGN);
	(void)signal(SIGQUIT, SIG_IGN);
	(void)signal(SIGHUP,  ExitSignal);
	(void)signal(SIGTERM, ExitSignal);
	(void)setpgrp();

	if (chdir("/dev") < 0) {
		exit(1);
	}

   if ((fd = open(TTY_LINE, O_RDWR)) < 0) {
		exit(1);
	}
fprintf(stderr, "Serial Port Opened\n");
}

void ConnectSerialLine(void)
{
	struct   termio termio;		

    TtyIoctl(TCGETA, &termio);

	termio.c_iflag = ICRNL;
	termio.c_oflag = 0;
	termio.c_cflag = DFLT_SPEED | CS8 | CREAD | HUPCL;
	termio.c_lflag = 0;
	termio.c_line = LDISC0;
	termio.c_cc[VMIN] = 1;
	termio.c_cc[VTIME] = 0;

    TtyIoctl(TCSETAF, &termio);

    TtyIoctl(TCSETAW, &termio);

fprintf(stderr, "Serial Port Connected\n");
}

 