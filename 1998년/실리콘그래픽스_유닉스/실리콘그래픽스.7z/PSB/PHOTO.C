/********************************************************************/
/*																	*/
/*		photo.c : �������� �⺻�Լ����� ����ִ� ����(�׸���,�����)*/ 
/*																	*/
/*																	*/
/*																	*/
/* 		Copyright (c) 1996 by PSB Corp.    				*/
/********************************************************************/

#include <Xm/Xm.h>
#include <gl/glws.h>
#include <stdio.h>
#include <stdlib.h>

#include "videolib.h"
#include "typedef.h"
#include "readtga.h"
#include "scrinfo.h"
#include "photo.h"


static int		nCurPhotoNum = 0;
static int		nCurPhotoMode;

static PHOTOINFO Photo[3];
static unsigned long Bkbuf[SCREEN_WID * SCREEN_HGT];
static unsigned long OrgBkbuf[SCREEN_WID * SCREEN_HGT];

void	DrawMovingPhoto(int x, int y, int wid, int hgt, unsigned long * PhotoBuf, int direction, int ratio, long rtime)
{
    int     i, j, k;

/*
	if (wid * hgt == 0 || (x + wid) * hgt > SCREEN_WID * SCREEN_HGT / 2) {
		printf("illegal Photo Size\n");
		return;
	}
*/

	switch(direction) {
	case RIGHT:  /* ���������� �����̴� ���� */
		GetImage(0, y, x + wid, hgt, OrgBkbuf);
		for (i = 0; i < (x + wid) * hgt; i++) {
			OrgBkbuf[i] |= 0xff000000;
			Bkbuf[i] = OrgBkbuf[i];
			Photo[nCurPhotoNum].OrgBkbuf[i] = OrgBkbuf[i];
		}

		for (i = 0; i < x ; i += ratio) {
			if (i > x - (ratio + 1))
				i = x;
			for (j = 0; j < hgt; j++) {
				for (k = 0; k < wid; k++) 
					Bkbuf[i + j * (x + wid) + k] = PhotoBuf[j * wid + k];
			}
			PutImage(0, y, x + wid, hgt, Bkbuf);
			DelayLoop(rtime);
			/* �ٽ� ������ �̹����� �����Ѵ�. */
			for (j = 0; j < hgt; j++) {
				for (k = 0; k < wid; k++)
					Bkbuf[i + j * (x + wid) + k] = OrgBkbuf[i + j * (x + wid) + k];
			}
		}
		break;

	case LEFT:
		GetImage(x, y, SCREEN_WID - x, hgt, OrgBkbuf);
		for (i = 0; i < (SCREEN_WID - x) * hgt; i++) {
			OrgBkbuf[i] |= 0xff000000;
			Bkbuf[i] = OrgBkbuf[i];
			Photo[nCurPhotoNum].OrgBkbuf[i] = OrgBkbuf[i];
		}

		for (i = SCREEN_WID - wid; i > x ; i -= ratio) {
			if (i < x + (ratio + 1))
				i = x;
			for (j = 0; j < hgt; j++) {
				for (k = 0; k < wid; k++)
					Bkbuf[i - x + j * (SCREEN_WID - x) + k] = PhotoBuf[j * wid + k];
			}
            PutImage(x, y, SCREEN_WID - x, hgt, Bkbuf);

			DelayLoop(rtime);
			for (j = 0; j < hgt; j++) {
				for (k = 0; k < wid; k++)
					Bkbuf[i - x + j * (SCREEN_WID - x) + k] = OrgBkbuf[i - x + j * (SCREEN_WID - x) + k];
			}
		}
		break;

	case UPWARD:
	case DOWNWARD:
		GetImage(x, y, wid, hgt , Photo[nCurPhotoNum].OrgBkbuf);
		for (i = 0; i < wid*hgt; i++)      /* set alpha to 255 */
			Photo[nCurPhotoNum].OrgBkbuf[i] |= 0xff000000;

		for (i = 4; i < hgt; i += ratio){
			if (direction == DOWNWARD) {
				PutImage(x, y, wid, i, PhotoBuf + (wid * hgt) - (wid * i));
			}
			else {
				PutImage(x, y + hgt - i, wid, i, PhotoBuf);
			}
			DelayLoop(rtime);
		}
		PutImage(x, y, wid, hgt, PhotoBuf);
		break;
	}
	Photo[nCurPhotoNum].x = x;
	Photo[nCurPhotoNum].y = y;
	Photo[nCurPhotoNum].Wid = wid;
	Photo[nCurPhotoNum].Hgt = hgt;
	nCurPhotoNum++;
}

void    _ErasePhoto(PHOTOINFO * p, int direction, int ratio)
{
	static DWORD Bkbuf[360 * 360], Photobuf[360 * 360];
	int i, j, k ;

	GetImage(p->x, p->y, p->Wid, p->Hgt, Photobuf);
	for (i = 0; i < p->Wid * p->Hgt; i++)
		Photobuf[i] |= 0xff000000;

	switch(direction) {
	case UPWARD:
	case DOWNWARD:
		for (i = p->Hgt; i > 0; i -= ratio){
			for (j = 0; j < p->Wid * p->Hgt; j++)
				Bkbuf[j] = p->OrgBkbuf[j];

		   	for (j = 0; j < i; j++) {
		        for (k = 0; k < p->Wid; k++) {
					if (direction == UPWARD)
						Bkbuf[j * p->Wid + k] = Photobuf[(p->Hgt - i) * p->Wid + j * p->Wid + k];
					else
						Bkbuf[(p->Hgt - i) * p->Wid + j * p->Wid + k] = Photobuf[j * p->Wid + k];
				}
			}
			PutImage(p->x, p->y, p->Wid, p->Hgt, Bkbuf);
			DelayLoop(50);
		}
		PutImage(p->x, p->y, p->Wid, p->Hgt, p->OrgBkbuf);
		break;

	case LEFT:
		for (i = p->x; i > 0 ; i -= ratio) {
			for (j = 0; j < (p->x + p->Wid) * p->Hgt; j++)
				Bkbuf[j] = p->OrgBkbuf[j];

            for (j = 0; j < p->Hgt; j++) {
				for (k = 0; k < p->Wid; k++) {
					Bkbuf[i + j * (p->x + p->Wid) + k] = Photobuf[j * p->Wid + k];
				}
			}
			PutImage(0, p->y, p->x + p->Wid, p->Hgt, Bkbuf);
			DelayLoop(50);
		}
		PutImage(0, p->y, p->x + p->Wid, p->Hgt, p->OrgBkbuf);
		break;

	case RIGHT:
		for (i = p->x; i < SCREEN_WID - p->Wid ; i += ratio) {
			for (j = 0; j < (SCREEN_WID - p->x) * p->Hgt; j++)
				Bkbuf[j] = p->OrgBkbuf[j];

			for (j = 0; j < p->Hgt; j++) {
				for (k = 0; k < p->Wid; k++) {
					Bkbuf[i - p->x + j * (SCREEN_WID - p->x) + k] = Photobuf[j * p->Wid + k];
				}
			}
			PutImage(p->x, p->y, SCREEN_WID - p->x, p->Hgt, Bkbuf);
			DelayLoop(50);
		}
		PutImage(p->x, p->y, SCREEN_WID - p->x, p->Hgt, p->OrgBkbuf);
		break;
	}
}

void	ErasePhoto()
{
	int i;

	if (nCurPhotoNum == 0)
		return;

	switch(nCurPhotoMode) {
	case V_MIDDLE:
        for (i = 0; i < nCurPhotoNum; i++) {
            if (Photo[i].y < SCREEN_HGT/2)
                _ErasePhoto(&Photo[i], UPWARD, 16);
            else
                _ErasePhoto(&Photo[i], DOWNWARD, 16);
        }
		break;

	case H_MIDDLE:
	case H_LARGE:
        for (i = 0; i < nCurPhotoNum; i++) {
            if (Photo[i].x < SCREEN_CENTER_X)   /* Left-Part Photo */
                _ErasePhoto(&Photo[i], LEFT, 24);
            else
                _ErasePhoto(&Photo[i], RIGHT, 24);
        }
		break;

	case O_LARGE: /* Single Mode, �缱Ȯ�� etc */
        _ErasePhoto(&Photo[0], DOWNWARD, 16);
		break;

	case V_SMALL:
		for (i = 0; i < nCurPhotoNum; i++)
            _ErasePhoto(&Photo[i], DOWNWARD, 8);
		break;

	case H_SMALL:
		for (i = 0; i < nCurPhotoNum; i++)
            _ErasePhoto(&Photo[i], LEFT, 12);
		break;

	default :
		fprintf(stderr, "Can't Erase Photo : Invalid Photo Mode\n");
		return;
	}
	nCurPhotoNum = 0;
}

void	SetPhotoMode(int n)
{
	nCurPhotoMode = n;
}

 