
/********************************************************************/
/*                                                                  */
/*        ars_main.c : �ݿ����� �ϴ��ڸ� Program Main Module        */
/*                                                                  */
/*                                                                  */
/*                 Copyright (c) 1996 by PSB Corp.                  */
/********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Frame.h>
#include <X11/X.h>
#include <X11/cursorfont.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <assert.h>
#include <gl/gl.h>

#include "videolib.h"
#include "typedef.h"
#include "scrinfo.h"
#include "path.h"
#include "ref.h"


                                /* Global Widget                    */
Widget 	Form,                   /* Form                             */
        ScreenFrame,
        OkButton;               /* Start Button                     */

IMAGETMP BkPanel[2];
IMAGEBUF BarImageBuf[3] = { 
         { "h_bbar.tga" }, { "h_rbar.tga" }, { "v_bar1.tga" }
};
IMAGEBUF BandSpotImage[7] = { 
         { "J_BkBand.tga" }, { "N_BkBand.tga" },
         { "band1.tga"    }, { "band2.tga"    },
         { "band3.tga"    }, { "band4.tga"    },
         { "band5.tga"    } 
};
IMAGEBUF CommonBkImageBuf[BACK_IMAGE_NUM] = { 
         { "Jback.tga"    }, { "v_rarrow.tga" },
         { "v_barrow.tga" }, { "Jmenu1.tga"   },
         { "Jmenu2.tga"   }, { "Jmenu3.tga"   },
         { "Jmenu4.tga"   }, { "Jmenu5.tga"   },
         { "p_arrow1.tga" }, { "p_arrow2.tga" },
         { "p_arrow3.tga" }, { "p_arrow4.tga" },
         { "off_bar.tga"  }, { "off_title.tga" }
};

DWORD    H_BarImage[H_BAR_NUM][BAR_HGT];

int           fd;                      /* dev/ttyd1 File Description*/
int           RunningBatchMode;        /* Running Mode(Serial,Batch)*/
char          log_file[80];            /* Log File Name             */
int           TermWidth[5];

unsigned long GET_IMGBuf[300 * LS_PANEL_H];

static void DrawBoundary(int screen);
static void DrawRectangle(Widget w, int x1, int y1, int x2, int y2, 
                          int width, int color, int bFillMode);
/********************************************************************/
/* Function Name : main(int argc, char **argv)                      */
/* Description   : Main Module                                      */
/********************************************************************/
void main(int argc,  char **argv)
{
    int          i;
    XtAppContext app;
    Widget       top;
    Arg          args[5];
    Cardinal     n;
    FILE         * fp;

    if (getgdesc(GD_BITS_NORM_DBL_RED) == 0) {
        fprintf(stderr, "Double buffered RGB not available on this machine\ni");
        exit(1);
    }

    if (argc != 3 || (*argv[1] != 'b' && *argv[1] != 's')) {
        fprintf(stderr, "\n");
        fprintf(stderr, "    Usage : ars mode File Name\n");
        fprintf(stderr, "     mode : s (Serial Mode)\n");
        fprintf(stderr, "     mode : b (Batch Mode)\n");
        fprintf(stderr, "File Name : Log File Name, Data File Name\n");
        exit(0);
    }

    strcpy(log_file, argv[2]);
    if(*argv[1] == 'b') {
        if ((fp = fopen(log_file, "rt")) == NULL) {
            fprintf(stderr, "Can't open %s.\n", log_file);
            exit(0);
        }
        fclose(fp);
        RunningBatchMode = 1;
    }
    else {
        RunningBatchMode = 0;
    }

    fprintf(stderr, "STOCK TGA Image File Readding...\n");

    ReadBackGroundImages();
    InitFontMachinery(FONT_PATH);

                                /* "ARSSTART"�� Resource File       */
    top=XtAppInitialize(&app,"ARSSTART",NULL,0,&argc, argv, NULL, NULL, 0);

    n=0;
    XtSetArg(args[n],XmNtitle,"STOCK PROGRAM"); n++;
    XtSetValues(top, args, n);

                                /* form �ʱ�ȭ, no rubberband       */
    n=0;
    XtSetArg(args[n],XmNwidth,1280); n++;
    XtSetArg(args[n],XmNheight,1024); n++;
    XtSetArg(args[n],XmNrubberPositioning,False); n++;
    Form = XmCreateForm(top,"Form",args,n);
    XtManageChild(Form);
    XtAddEventHandler(Form, ExposureMask, FALSE, FormEventHandlerExposed, NULL);

                                /* ǥ�� ȭ�� �ʱ�ȭ                 */
    InitScreen(Form);
    XtRealizeWidget(top);
    InitGlWindow(ScreenFrame);
    CreateGlWindow(DRAWING_WINDOW_X1, DRAWING_WINDOW_Y1, SCREEN_WID, SCREEN_HGT);
    CreateGlWindow(DRAWING_WINDOW_X2, DRAWING_WINDOW_Y2, SCREEN_WID, SCREEN_HGT);

    XtAppMainLoop(app);         /* main loop (event���)            */
}

/********************************************************************/
/* Function Name : InitScreen(Widget form)                          */
/* Description   : ǥ�� ȭ�� �ʱ�ȭ                                 */
/********************************************************************/
void InitScreen(Widget form)
{
    Arg        args[5];
    Cardinal   n=0;

    n=0;
    XtSetArg(args[n],XmNwidth,2 * LEFTX1 + SCREEN_WID); n++;
    XtSetArg(args[n],XmNheight,2 * SCREEN_HGT + 11); n++;
    XtSetArg(args[n],XmNx,0); n++;
    XtSetArg(args[n],XmNy,0); n++;
    ScreenFrame = XmCreateFrame(form,"sframe",args,n);
    XtManageChild(ScreenFrame);

    InitWorkButtons(form);      /* ��Ÿ �۾� ��ư �ʱ�ȭ            */
}

/********************************************************************/
/* Function Name : InitWorkButtons(Widget form)                     */
/* Description   : ��Ÿ �۾� ��ư �ʱ�ȭ                            */
/********************************************************************/
void InitWorkButtons(Widget form)
{

    OkButton = PutButtonWithCallBack(form, "view", -1, -1, -1, -1,
            "S\nT\nA\nR\nT", 24, 0, ViewButtonCallback, NULL);
    XtAddEventHandler(OkButton, KeyPressMask, FALSE, EventHandlerKeyPressed, NULL);
}

/********************************************************************/
/* Function Name : PutButtonWithCallBack(                           */
/*                   Widget form,char *resName,int width,           */
/*                   int height,int xx,int yy,char *str,int size,   */
/*                   int font,XtPointer CallBack,int index)         */
/* Description   : ��ư ���� Routine                                */
/*                 Widget,Resource���� �̸�,��ư�� ��,����,xy��ġ,  */
/*                 ��ư�� Caption(�ѱ� ȥ�밡��),                   */
/*                 Text�� Fontũ�� (16|24), Text�� Font����         */
/*                 (0=����, 1=����, ũ�Ⱑ 24�� ���� ��� ����)   */
/*                 Button�� ������ ���� Callback�Լ�                */
/*                 Call back�� Index(������ NULL,�������� Array��   */
/*                 ����Ҷ��� 0~n������ ��ư ����                   */
/********************************************************************/
Widget PutButtonWithCallBack(Widget form, char *resName,int width,
                             int height, int xx, int yy, char *str,
                             int size, int font, XtPointer CallBack,
                             int index)
{
    Widget          pushb;
    XmString        xmstr;
    Arg             args[5];
    Cardinal        n;

                    /* -1�̸� resource�� ��ϵ� ������ Xm�� Set�� ��*/
    n=0;

    if (width != -1) { 
        XtSetArg(args[n],XmNwidth,width); n++;
    }

    if (height != -1) {
        XtSetArg(args[n],XmNheight,height); n++;
    }

    if (xx != -1) {
        XtSetArg(args[n],XmNx,xx); n++;
    }

    if (yy != -1) {
        XtSetArg(args[n],XmNy,yy); n++;
    }

    if (*str) {
        xmstr =  TransXmString(str,size,font);
        XtSetArg(args[n], XmNlabelString, xmstr); n++;
    }

    XtSetArg(args[n], XmNrecomputeSize, False); n++;
                                 /* Button ����                     */
    pushb = XmCreatePushButton(form,resName,args,n);

    if (*str)
        XmStringFree(xmstr); /* TransXmString ȣ���ϸ� �ݵ�� Free! */

    XtManageChild(pushb);

    if (CallBack)                /* NULL�� �ƴϸ� index�� �Բ� ��� */
        XtAddCallback(pushb, XmNactivateCallback, CallBack, (XtPointer)index);
	
    return pushb;                /* ������� Button Widget�� Return */
}

/********************************************************************/
/* Function Name : TransXmString(char *str, int size, int font)     */
/* Description   : �ѱ�/���� ȥ�� String�� XmString���� Conversion  */
/*                   size = 16 or 24                                */
/*                   font = 0 for ����, 1 ����                      */
/********************************************************************/
XmString TransXmString(char *str, int size, int font)
{
    static char FontName[3][2][5]={
        "e16", "hg16",              /* 16 ���� ���ý�               */
        "e16", "hm16",              /* 16 ���� ���ý�               */
        "e24", "h24",               /* 24 ���ý�                    */
    };
    XmString xmstr1, xmstr2, xmstrOutput;
    char *eFont, *hFont;
    char buf[256];

    if (size==24) {                 /* 24 Font                      */
        eFont = FontName[2][0]; 
        hFont = FontName[2][1];
    }
    else {                          /* size=16���� ����             */
        if (font==1) {              /* ����                         */
            eFont = FontName[1][0];
            hFont = FontName[1][1];
        }
        else {                      /* �������� ����                */
            eFont = FontName[0][0];
            hFont = FontName[0][1];
        }
    }

                                    /* XmString NULL��              */
    xmstrOutput = XmStringCreate(NULL, eFont);
    if (str==NULL)
        return xmstrOutput;         /* ��ȯ,Caller���� Free�ؾ� ��  */

    while(*str) {
        if (*str & 0x80) {          /* ������ ���ö� ���� Scan      */
            char *p=buf;
            while(*str) {
                if ((*str & 0x80)==0) break;
                *p++ = (*str++) & 0x7f;     /* �ѱ� Code�� MSB Cut  */
                *p++ = *str++ & 0x7f;       /* "                    */
            }
            *p = 0;             /* buf�� ������ �ѱ۷θ� �� String  */
                                /* �ѱ� Font�� XmString ����        */
            xmstr2 = XmStringCreateLtoR(buf, hFont);
        }
        else {
                                /* �ѱ��� ���ö� ���� Scan          */
            char *p=buf;
            while(*str) {
                if (*str & 0x80) break;
                *p++ = *str++;
            }
            *p = 0;            /* buf�� ������ �������θ� �� String */

                                /* ���� Font�� XmString ����        */
            xmstr2 = XmStringCreateLtoR(buf, eFont);
        }

                                /* XmString Cat                     */
        xmstr1 = XmStringConcat(xmstrOutput, xmstr2);

                                /* �ӽ� XmString Free               */
        XmStringFree(xmstrOutput);
        XmStringFree(xmstr2);

                                /* set new output string            */
        xmstrOutput = xmstr1;
    }
	
    return xmstrOutput;         /* ��ȯ, Caller���� Free�ؾ� ��     */
}

/********************************************************************/
/* Function Name : ViewButtonCallback(Widget w,                     */
/*                     XtPointer client_data, XtPointer call_data)  */
/* Description   : CallBack Function                                */
/********************************************************************/
void ViewButtonCallback(Widget w, XtPointer client_data, XtPointer call_data)
{

    if(RunningBatchMode == 0) { /* Serial Mode Running              */
        SerialDataView();
    }
    else {
        BatchDataView();
    }
}

/********************************************************************/
/* Description   : Serial Port Control ���� Define                  */
/********************************************************************/
int nCurCommandMode;
#define PREVIEW_MODE 0
#define ONAIR_MODE   1

#define BUFLEN 4096

char RcvBuf[4096];
char CmdStr[4096];


/********************************************************************/
/* Function Name : SerialDataView(void)                             */
/* Description   : CallBack Function (Serial Data Display)          */
/********************************************************************/
void SerialDataView(void)
{
    int  i;
    int  len;
    FILE *fp;
    int  reclen=0;
    int  cmdlen=0;
    char recbuf[BUFLEN];
    char cmdbuf[BUFLEN];
    char saveLogfile[80];

    OpenSerialLine();
    ConnectSerialLine();
    memset(saveLogfile, 0x00, sizeof(saveLogfile));
    sprintf(saveLogfile, "%s/%s", BASE_PATH, log_file);
    fprintf(stderr, "Receive Start");
    while(1) {                  /* Data Receive                     */
        memset(recbuf, 0x00, BUFLEN);
        len = read(fd, recbuf, BUFLEN);
        if (len < 1) {
            fprintf(stderr,"Receive Error\n");
            continue;
        }
        recbuf[len] = '\0';

        for (i = 0; i < len; i++) {
            cmdbuf[cmdlen++] = recbuf[i];
            if (cmdlen > BUFLEN) assert(0);

            if (recbuf[i] == '#') {
                cmdbuf[cmdlen]=0;
                fp = fopen(saveLogfile, "a+");
                if (fp != NULL) {
                    fprintf(fp, "%s\n", cmdbuf);
                    fclose(fp);
                }
                ProcessCommandString(cmdbuf);
                cmdlen =0;
            }
        }
    }
}

/********************************************************************/
/* Function Name : BatchDataView(void)                              */
/* Description   : CallBack Function (Log File Data Display)        */
/********************************************************************/
void BatchDataView(void)
{
    FILE  *fp;
    int   i, len;
    int   cmdlen;
    char  cmdbuf[BUFLEN];
    char  recbuf[BUFLEN];

    fp = fopen(log_file, "rt");
    if (fp == NULL) {
        fprintf(stderr, "can't open %s\n", log_file);
        exit(1);
    }

    while(1) {                  /* Data Receive                     */
        if(fgets(recbuf, BUFLEN, fp) == NULL) {
            fprintf(stderr, "End of File\n");
            exit(1);
        }

        len=strlen(recbuf);
        cmdlen = 0;
        for (i = 0; i < len; i++) {
            if(i < len -1 && recbuf[i] == 0x0d && recbuf[i+1] == 0x0a)
            {
                continue;
            }

            cmdbuf[cmdlen++] = recbuf[i];
            if (cmdlen > BUFLEN) assert(0);

            if (recbuf[i]=='#') {
                cmdbuf[cmdlen]=0;
                ProcessCommandString(cmdbuf);
                cmdlen =0;
             }
        }
    }
}

/********************************************************************/
/* Function Name : ProcessCommandString(char *cmdstr)               */
/* Description   : ���ŵ� ����Ÿ�� �� �޴��� �°� ��ȯ              */
/********************************************************************/
void ProcessCommandString(char *cmdstr)
{
 
    if (*cmdstr != '*') {
        while (*cmdstr != '\0' && *cmdstr != '*') {
            cmdstr++;
        }
    }

                                /* Receved Data Display             */
    CommandParsing(cmdstr);
}

/********************************************************************/
/* Description   : ���� Ű���� Define                               */
/********************************************************************/
#define ENTER        98
#define NENTER      129
#define END         109
#define MINUS       140
#define PLUS        132
#define CONTROL      25
#define RCONTROL     96
#define ALT          33

/********************************************************************/
/* Function Name : EventHandlerKeyPressed(                          */
/*                               Widget w,XtPointer client_data,    */
/*                               XEvent *event, Boolean *flag)      */
/* Description   : KeyPressed ó��                                  */
/********************************************************************/
void EventHandlerKeyPressed(Widget w, XtPointer client_data,
                            XEvent *event, Boolean *flag)
{
    XKeyEvent *ke = (XKeyEvent *)event;
    static int prevKeyCode=0;

    switch(ke->keycode) {
        case ENTER:
        case NENTER:
                                    /* ȭ���� �����Ѵ�.             */
                DumpScreen();
                break;

        case END :                  /* END key twice -> end         */
                if (prevKeyCode==END)
                    exit(0);
                    break;

        default :
                fprintf(stderr, "<%d>\n", ke->keycode);
    }
    prevKeyCode = ke->keycode;
}

/********************************************************************/
/* Function Name : FormEventHandlerExposed(Widget w,                */
/*                           XtPointer client_data,                 */
/*                           XEvent *event, Boolean *flag)          */
/* Description   :                                                  */
/********************************************************************/
void FormEventHandlerExposed(Widget w, XtPointer client_data,
                             XEvent *event, Boolean *flag)
{
    static int bInitOnce=0;
    int        BackImgNo;

    BackImgNo = 0;
    if (bInitOnce==0) {
        ClearScreen(0);
        ClearScreen(1);
        DrawBoundary(0);
                                /* ������������ �ʱ�ȭ,             */
                                /* ������������,������ Ȯ��         */
        InitVideoOutput();
                                /* ����������������� ��µ�        */
                                /* Output Window�� ��ġ�� �����Ѵ�  */
        ChangeVideoOutputPosition(OUTPUT_WINDOW_X2, OUTPUT_WINDOW_Y2);

        Winset(PAGE_PREVIEW);
        PutImage(0, 0, CommonBkImageBuf[BackImgNo].wid,
                       CommonBkImageBuf[BackImgNo].hgt,
                       CommonBkImageBuf[BackImgNo].bufptr);
        Winset(PAGE_ONAIR);
        PutImage(0, 0, CommonBkImageBuf[BackImgNo].wid,
                       CommonBkImageBuf[BackImgNo].hgt,
                       CommonBkImageBuf[BackImgNo].bufptr);

                                /* ���÷��� ������ �󿡼� Ŀ����  */
        ChangeCursor();         /* �̹����� ��������� �ۼ��� �Լ�  */
        bInitOnce=1;
    }
}

/********************************************************************/
/* Function Name : DrawBoundary(int screen)                         */
/* Description   : ��۵Ǵ� ȭ���� ������ ��踦 �ش�               */
/********************************************************************/
static void DrawBoundary(int screen)
{
    if (screen==0) {
        DrawRectangle(Form, LEFTX1-1, DRAWING_WINDOW_Y1-1,LEFTX1+SCREEN_WID+2,
                            DRAWING_WINDOW_Y1 + SCREEN_HGT + 2, 2, C_RED, 0);
        DrawRectangle(Form, LEFTX2-1, DRAWING_WINDOW_Y2-1,LEFTX2+SCREEN_WID+2,
                            DRAWING_WINDOW_Y2 + SCREEN_HGT+2, 2, C_GREEN, 0);

        DrawRectangle(Form, LEFTX1-BOUNDARY_W, DRAWING_WINDOW_Y1-2,LEFTX1-1,
                            DRAWING_WINDOW_Y1 + SCREEN_HGT+3, 0, C_RED, 1);
        DrawRectangle(Form, LEFTX2-BOUNDARY_W, DRAWING_WINDOW_Y2-2,LEFTX2-1,
                            DRAWING_WINDOW_Y2 + SCREEN_HGT+3, 0, C_GREEN, 1);

        DrawRectangle(Form, LEFTX1 + SCREEN_WID + 2, DRAWING_WINDOW_Y1 - 2,
                            LEFTX1 + SCREEN_WID + BOUNDARY_W,
                            DRAWING_WINDOW_Y1+SCREEN_HGT + 3, 0, C_RED, 1);
        DrawRectangle(Form, LEFTX2 + SCREEN_WID + 2, DRAWING_WINDOW_Y2 - 2,
                            LEFTX2 + SCREEN_WID + BOUNDARY_W,
                            DRAWING_WINDOW_Y2 + SCREEN_HGT + 3,0, C_GREEN, 1);
    }
    else {
        DrawRectangle(Form, LEFTX1-1, DRAWING_WINDOW_Y1-1,LEFTX1+SCREEN_WID+2,
                            DRAWING_WINDOW_Y1 + SCREEN_HGT + 2,2, C_GREEN, 0);
        DrawRectangle(Form, LEFTX2-1, DRAWING_WINDOW_Y2-1,LEFTX2+SCREEN_WID+2,
                            DRAWING_WINDOW_Y2 + SCREEN_HGT + 2, 2, C_RED, 0);

        DrawRectangle(Form, LEFTX2-BOUNDARY_W, DRAWING_WINDOW_Y1 - 2,LEFTX2-1,
                            DRAWING_WINDOW_Y1 + SCREEN_HGT + 3,0, C_GREEN, 1);
        DrawRectangle(Form, LEFTX2 - BOUNDARY_W, DRAWING_WINDOW_Y2-2,LEFTX2-1, 
                            DRAWING_WINDOW_Y2 + SCREEN_HGT + 3, 0, C_RED, 1);

        DrawRectangle(Form, LEFTX1 + SCREEN_WID + 2, DRAWING_WINDOW_Y1 - 2,
                            LEFTX1 + SCREEN_WID + BOUNDARY_W,
                            DRAWING_WINDOW_Y1+SCREEN_HGT + 3, 0, C_GREEN, 1);
        DrawRectangle(Form, LEFTX2 + SCREEN_WID + 2, DRAWING_WINDOW_Y2 - 2,
                            LEFTX2 + SCREEN_WID + BOUNDARY_W, 
                            DRAWING_WINDOW_Y2 + SCREEN_HGT + 3, 0, C_RED, 1);
    }
}

/********************************************************************/
/* Function Name : DrawRectangle(Widget w, int x1, int y1, int x2,  */
/*                               int y2, int width, int color,      */
/*                               int bFillMode)                     */
/* Description   : Rectangle�� �׸���                               */
/********************************************************************/
static void DrawRectangle(Widget w, int x1, int y1, int x2, int y2, int width,
                   int color, int bFillMode)
{
    XGCValues gcv;
    GC	      gc;

    w = ScreenFrame;
    gcv.line_width = width;
    gcv.foreground = color;
    gc = XCreateGC(XtDisplay(w), DefaultRootWindow(XtDisplay(w)),
                                 GCLineWidth | GCForeground, &gcv);
    if (bFillMode==0)
        XDrawRectangle(XtDisplay(w), XtWindow(w),gc, x1, y1, x2-x1, y2-y1);
    else
        XFillRectangle(XtDisplay(w), XtWindow(w),gc, x1, y1, x2-x1, y2-y1);
    XFreeGC(XtDisplay(w),gc);
}

/********************************************************************/
/* Function Name : ChangeCursor(void)                               */
/* Description   : ���÷��� ������ �󿡼�                         */
/*                   Ŀ���� �̹����� ��������� �ۼ��� �Լ�         */
/********************************************************************/
void ChangeCursor(void)
{
    unsigned char  lnblogo_bits[] = {0xff};
    unsigned long  bgpix;
    unsigned long  fgpix;
    Display        *p_disp = XtDisplay(ScreenFrame);
    Window root_win = RootWindow(p_disp, DefaultScreen(p_disp));
    Pixmap pmap;
    XColor color;
    Colormap def_cmap = DefaultColormap(p_disp,DefaultScreen(p_disp));
    Cursor cursor;

    bgpix = WhitePixel(p_disp, DefaultScreen(p_disp));
    fgpix = BlackPixel(p_disp, DefaultScreen(p_disp));
                                /* depth must be 1!                 */
    pmap = XCreatePixmapFromBitmapData(p_disp, root_win,lnblogo_bits,
                                       1, 1, fgpix, bgpix, 1);

    XParseColor(p_disp, def_cmap, "green", &color);
    XAllocColor(p_disp, def_cmap, &color);

    cursor = XCreatePixmapCursor(p_disp, pmap, pmap, &color, &color, 0, 0);
    XDefineCursor(p_disp, XtWindow(ScreenFrame), cursor);
}

 