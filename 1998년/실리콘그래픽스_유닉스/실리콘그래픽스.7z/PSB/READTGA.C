/********************************************************************/
/*																	*/
/*		readtga.c : TGA Format File	Handling Module			   		*/ 
/*  		       													*/
/*																	*/
/*																	*/
/* 		 Copyright (c) 1996 by PSB Corp.    					*/
/********************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>

#include <stdio.h>
#include <stdlib.h>

#include "videolib.h"
#include "typedef.h"
#include "scrinfo.h"
#include "ref.h"
#include "readtga.h"


#define	IMAGE_PATH "."

static unsigned long	TGAImageBuf[720*486];

typedef struct _TGA_HDR {
	unsigned char IDLength;
	unsigned char ColorMapType;
	unsigned char ImageType;
	unsigned short CMapStart;
	unsigned short CMapLength;
	unsigned char CMapDepth;
	unsigned short XOffset;
	unsigned short YOffset;
	unsigned short Width;
	unsigned short Height;
	unsigned char PixelDepth;
	unsigned char ImageDescriptor;
} TGA_HDR;


static unsigned char GetByte(FILE *fp)
{
	return fgetc(fp);
}

static unsigned short GetWordBE(FILE *fp)
{
	return ((unsigned char)fgetc(fp) << 8) | fgetc(fp);
}

static unsigned long GetLongBE(FILE *fp)
{
	return ((unsigned char)fgetc(fp) << 24) |
		   ((unsigned char)fgetc(fp) << 16) |
		   ((unsigned char)fgetc(fp) << 8) |
		   (unsigned char)fgetc(fp) ;
}

static unsigned short GetWordLE(FILE *fp)
{
	return fgetc(fp) | ((unsigned char)fgetc(fp) << 8);
}

static unsigned long GetLongLE(FILE *fp)
{
	return (unsigned char)fgetc(fp) |
		   ((unsigned char)fgetc(fp) << 8) |
		   ((unsigned char)fgetc(fp) << 16) |
		   ((unsigned char)fgetc(fp) << 24);
}

int	ReadTGAImage(char *szFileName, unsigned long *pBuf, int *pWid, int *pHgt)
{
	FILE	*fp;
	char	name[128];
	TGA_HDR	hdr;
	unsigned long *p, *q;
	int		i, j;
	unsigned char	r,g,b,a;

	if (strchr(szFileName, '/'))
		strcpy(name, szFileName);
	else
		sprintf(name, "%s/%s", IMAGE_PATH, szFileName);

	fp = fopen(name, "r");
	if (fp == NULL) {
		int i;
		fprintf(stderr,"Can't open %s\n", name);
		*pWid = 10;
		*pHgt = 10;
		for (i = 0; i < 100; i++)
			pBuf[i] = 0xffffffff;
		
		return;
	}


	hdr.IDLength     = GetByte(fp);
	hdr.ColorMapType = GetByte(fp);
	hdr.ImageType    = GetByte(fp);
	hdr.CMapStart    = GetWordLE(fp);
	hdr.CMapLength   = GetWordLE(fp);
	hdr.CMapDepth    = GetByte(fp);
	hdr.XOffset      = GetWordLE(fp);
	hdr.YOffset      = GetWordLE(fp);
	hdr.Width        = GetWordLE(fp);
	hdr.Height       = GetWordLE(fp);
	hdr.PixelDepth   = GetByte(fp);
	hdr.ImageDescriptor = GetByte(fp);

	if (hdr.ImageType != 2 || (hdr.PixelDepth != 24 && hdr.PixelDepth != 32)) {
		fprintf(stderr,"%s : imagetype=%d, pixeldepth=%d: this program can handle only un-compressed, truecolor (24,32bits) TGA files\n", szFileName, hdr.ImageType, hdr.PixelDepth);
		exit(1);
	}
	if (hdr.Width > 720 || hdr.Height > 486) {
		fprintf(stderr,"too big image\n");
		exit(1);
	}

	if (hdr.IDLength != 0) {		/* skip id */
		fseek(fp, hdr.IDLength, SEEK_CUR);
	}

	if (hdr.ColorMapType != 0) {		/* skip palette */
		int	ColorMapSize;
		ColorMapSize = (hdr.CMapDepth + 7) / 8 * hdr.CMapLength;
		fseek(fp, ColorMapSize, SEEK_CUR);
	}
	p = pBuf + hdr.Width * (hdr.Height -1);
	a = 0xff;
	for (i = 0; i < hdr.Height; i++) {
		q = p;
		for (j = 0; j < hdr.Width; j++) {
			b = fgetc (fp);
			g = fgetc(fp);
			r = fgetc(fp);
			if (hdr.PixelDepth == 32)
				a = fgetc(fp);
			*q++ = (a << 24) | (b << 16) | (g << 8) | r;
		}
		p -= hdr.Width;
	}
	fclose(fp);

	*pWid = hdr.Width;
	*pHgt = hdr.Height;
}

int	ReadAllocTGAImage(IMAGEBUF *buf)
{
	FILE	*fp;
	char	name[128];
	TGA_HDR	hdr;
	unsigned long *p, *q;
	int		i, j;

	sprintf(name, "%s/%s", IMAGE_PATH, buf->filename);
	fp = fopen(name, "r");
	if (fp == NULL) {
		int i;
		fprintf(stderr,"Can;t open %s\n", buf->filename);
		buf->wid = 10;
		buf->hgt = 10;
		buf->bufptr = calloc(4,100);
		for (i = 0; i < 100; i++)
			buf->bufptr[i] = 0xffffffff;
		return;
		/*exit(1);
		*/
	}

	hdr.IDLength     = GetByte(fp);
	hdr.ColorMapType = GetByte(fp);
	hdr.ImageType    = GetByte(fp);
	hdr.CMapStart    = GetWordLE(fp);
	hdr.CMapLength   = GetWordLE(fp);
	hdr.CMapDepth    = GetByte(fp);
	hdr.XOffset      = GetWordLE(fp);
	hdr.YOffset      = GetWordLE(fp);
	hdr.Width        = GetWordLE(fp);
	hdr.Height       = GetWordLE(fp);
	hdr.PixelDepth   = GetByte(fp);
	hdr.ImageDescriptor = GetByte(fp);
	fclose(fp);

	buf->wid = hdr.Width;
	buf->hgt = hdr.Height;
	buf->bufptr = calloc(4, hdr.Width * hdr.Height);
	if (buf->bufptr == NULL) {
		fprintf(stderr, "can't alloc buffer for image in ReadAllocTGAImage: %s (%dx%d)\n", buf->filename, buf->wid, buf->hgt);
		exit(1);
	}
	return ReadTGAImage(buf->filename, buf->bufptr, &buf->wid, &buf->hgt);
}

void	GetTGAImageSize(char *filename, int *width, int *height)
{
	char name[128];
	FILE	*fp;
	TGA_HDR	hdr;

	sprintf(name, "%s/%s", IMAGE_PATH, filename);
	fp = fopen(name, "r");
	if (fp == NULL) {
		printf("Can;t open %s\n", name);
		exit(1);
	}

	hdr.IDLength     = GetByte(fp);
	hdr.ColorMapType = GetByte(fp);
	hdr.ImageType    = GetByte(fp);
	hdr.CMapStart    = GetWordLE(fp);
	hdr.CMapLength   = GetWordLE(fp);
	hdr.CMapDepth    = GetByte(fp);
	hdr.XOffset      = GetWordLE(fp);
	hdr.YOffset      = GetWordLE(fp);
	hdr.Width        = GetWordLE(fp);
	hdr.Height       = GetWordLE(fp);
	hdr.PixelDepth   = GetByte(fp);
	hdr.ImageDescriptor = GetByte(fp);
	fclose(fp);

	*width = hdr.Width;
	*height =hdr.Height;
}


void DumpScreen()
{
	int i;
	static int nFileNo=0;
	FILE *fi;
	char buf[100];
	unsigned char tgahdr[18] = { 0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0x20,0 };
	unsigned long *ptr;

	tgahdr[12] = (SCREEN_WID%256);
	tgahdr[13] = (SCREEN_WID/256);
	tgahdr[14] = (SCREEN_HGT%256);
	tgahdr[15] = (SCREEN_HGT/256);

	Winset(0);
	GetImage(0, 0, SCREEN_WID, SCREEN_HGT, TGAImageBuf);
	for (i = 0 ; i < (SCREEN_WID *SCREEN_HGT); i++)
		TGAImageBuf[i] = (TGAImageBuf[i] << 8) | 0xff;

    sprintf(buf,"s%.3d.tga",nFileNo);
	if ((fi = fopen(buf,"w"))!=NULL) {
		fwrite(tgahdr,18,1,fi);
		ptr = TGAImageBuf + (SCREEN_HGT-1) * SCREEN_WID;
		for (i=0; i<SCREEN_HGT; i++) {
			fwrite(ptr,SCREEN_WID,4,fi);
			ptr -= SCREEN_WID;
		}
		fclose(fi);
		nFileNo++;
		fprintf(stderr,"\nSave Screen as %s\n",buf);
	}
}

 