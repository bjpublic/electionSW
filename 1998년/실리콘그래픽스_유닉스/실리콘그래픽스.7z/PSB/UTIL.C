/********************************************************************/
/*																	*/
/*		util.c : ȭ���ۼ��� ���� ���̴� �Լ����� ����ִ� ����   	*/ 
/*																	*/
/*																	*/
/*																	*/
/* 		 Copyright (c) 1996 by PSB Corp.    				*/
/********************************************************************/

#include <Xm/Xm.h>
#include <gl/glws.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <time.h>

#include "scrinfo.h"
#include "typedef.h"
#include "ref.h"
#include "readtga.h"


void	DrawThinLine(int x1, int y1, int x2, int y2, unsigned long color)
{
	long    v[2];

	cpack(0xff000000 | color);
	bgnline();
	v[0] = x1;
	v[1] = SCREEN_HGT-y1;
	v2i(v);
	v[0] = x2;
	v[1] = SCREEN_HGT-y2;
	v2i(v);
	endline();
}

char * FormatNumber(long val)
{
	char	buf[100];
	static char buf2[100];
	int		len, n, i, j;

	sprintf(buf, "%d", val);
	len = strlen(buf);
	n = 3 - (len % 3);
	for (i = j = 0; i < len; i++) {
		buf2[j++] = buf[i];
		if ((++n % 3) == 0 && i != len-1)
			buf2[j++] = ',';
	}
	buf2[j] = '\0';
	return buf2;
}

char * FormatPercent(float val)
{
	static char	buf[100];

	sprintf(buf, "%2.0f%%", val);
	return buf;
}

int DelayLoop(int n)
{
	long j, tot;
	long nDelayDivisor;

	nDelayDivisor = 1L;
	tot = 0;
	for (j = 0; j < n*800/nDelayDivisor; j++)
		tot += j;
	return tot;
}

int GetMinValue(int *dArray, int element_num)
{
    int i, min;

    min = abs(dArray[0]);
    for(i = 1; i < element_num; i++)
    {
        if(min > dArray[i])
            min = dArray[i];
    }
    return min;
}

int GetMaxValue(int *dArray, int element_num)
{
    int i, max;

    max = abs(dArray[0]);
    for(i = 1; i < element_num; i++)
    {
        if(max < dArray[i])
            max = dArray[i];
    }
    return max;
}

void GetMinDoubleValue(double *dArray, int element_num, double *ret_val)
{
    int i;
    double min, tmin;

    if(dArray[0] < 0.00) min = dArray[0] * (-1.0);
    else                 min = dArray[0];
    for(i = 1; i < element_num; i++)
    {
        if(dArray[i] < 0.00) tmin = dArray[i] * (-1.0);
        else                 tmin = dArray[i];
        if(min > tmin) min = tmin;
    }
    *ret_val = min;
}

void GetMaxDoubleValue(double *dArray, int element_num, double *ret_val)
{
    int i;
    double max, tmax;

    if(dArray[0] < 0.00) max = dArray[0] * (-1.0);
    else                 max = dArray[0];
    for(i = 1; i < element_num; i++)
    {
        if(dArray[i] < 0.00) tmax = dArray[i] * (-1.0);
        else                 tmax = dArray[i];
        if(max < tmax) max = tmax;
    }
    *ret_val = max;
}

void GetTrimStr(char *s, char *buf, int n)
{
	int		i;

	strncpy(buf, s, n);
	buf[n-1] = '\0';
	for (i = n - 2; i >= 0; i--) {
		if (buf[i] == ' ') buf[i] = '\0';
		else break;
	}
}
 