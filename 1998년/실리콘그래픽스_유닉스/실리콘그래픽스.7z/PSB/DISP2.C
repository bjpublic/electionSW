/********************************************************************/
/*                                                                  */
/*            data_dsp.c : �ݿ����� �ϴ��ڸ� Data Display Module    */
/*                                                                  */
/*                                                                  */
/*                     Copyright (c) 1996 by PSB Corp.              */
/********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Frame.h>
#include <X11/X.h>
#include <X11/cursorfont.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>

#include "videolib.h"
#include "typedef.h"
#include "scrinfo.h"
#include "ref.h"

extern IMAGEBUF      CommonBkImageBuf[BACK_IMAGE_NUM];
extern IMAGEBUF      BarImageBuf[];
extern IMAGEBUF      BandSpotImage[];
extern IMAGETMP      BkPanel[2];
extern DWORD         H_BarImage[H_BAR_NUM][BAR_HGT];

/********************************************************************/
/* Function Name : ReadBackGroundImages(void)                       */
/* Description   : TGAImage File Read�� ���� Memory Allocation      */
/********************************************************************/
void ReadBackGroundImages(void)
{
    int    i;
    int    j;

    for (i = 0; i < BACK_IMAGE_NUM; i++) {
        ReadAllocTGAImage(&CommonBkImageBuf[i]);
    }

    for (i = 0; i < 3; i++) {
        ReadAllocTGAImage(&BarImageBuf[i]);
    }

    for (i = 0; i < 7; i++) {
        ReadAllocTGAImage(&BandSpotImage[i]);
    }

    for(j = 0; j < 3; j++) {
        for(i=0; i < BarImageBuf[0].hgt - 1; i++) {
            H_BarImage[j][i] = *(BarImageBuf[j].bufptr + 5 +
                        BarImageBuf[j].wid * (i + 1));
        }
    }
}

/********************************************************************/
/* Function Name : BackPanelGetImage(int x, int y,                  */
/*                                   int wid, int hgt, int num)     */
/* Description   : Back Image Get                                   */
/********************************************************************/
void BackPanelGetImage(int x, int y, int wid, int hgt, int num)
{
    int i;

    BkPanel[num].x = x;
    BkPanel[num].y = y;
    BkPanel[num].Wid = wid;
    BkPanel[num].Hgt = hgt;

    GetImage(BkPanel[num].x,BkPanel[num].y,BkPanel[num].Wid,BkPanel[num].Hgt,BkPanel[num].OrgBkBuf);
    for (i=0; i < BkPanel[num].Wid * BkPanel[num].Hgt; i++)
        BkPanel[num].OrgBkBuf[i] |= 0xff000000;
}

/********************************************************************/
/* Function Name : BackPanelGetImage(int num)                       */
/* Description   : Back Image Put                                   */
/********************************************************************/
void BackPanelPutImage(int num)
{
    PutImage(BkPanel[num].x,BkPanel[num].y,BkPanel[num].Wid,BkPanel[num].Hgt,BkPanel[num].OrgBkBuf);
}

void SlowDisplay(int x, int y, int wid, int hgt, int direction, int ratio, long rTime)
{
    int i;

    switch(direction) {
    case LEFT:
        for(i = wid-ratio; i > 0; i-= ratio) {
           Winset(PAGE_PREVIEW);
           BackPanelGetImage(x+i, y, ratio, hgt, 0);
           Winset(PAGE_ONAIR);
           BackPanelPutImage(0);
           DelayLoop(rTime);
        }
        break;
    case RIGHT:
        for(i = 0; i < wid; i+= ratio) {
           Winset(PAGE_PREVIEW);
           BackPanelGetImage(x+i, y, ratio, hgt, 0);
           Winset(PAGE_ONAIR);
           BackPanelPutImage(0);
           DelayLoop(rTime);
        }
        break;
    default:
        break;
    }
}

void ScrollDisplay(int x, int y, int wid, int hgt, int direction, int ratio, long rTime)
{
    int i, xx;

    switch(direction) {
    case LEFT:
        for(i = 1; i < wid; i+= ratio) {
           Winset(PAGE_PREVIEW);
           BackPanelGetImage(x, y, i, hgt, 0);
           Winset(PAGE_ONAIR);
           BkPanel[0].x = x + wid - i;
           BkPanel[0].y = y;
           BackPanelPutImage(0);
           DelayLoop(rTime);
        }
        break;
    case RIGHT:
        for(i = 0; i < wid; i+= ratio) {
           Winset(PAGE_PREVIEW);
           BackPanelGetImage(x+i, y, ratio, hgt, 0);
           Winset(PAGE_ONAIR);
           BackPanelPutImage(0);
           DelayLoop(rTime);
        }
        break;
    default:
        break;
    }
}
 