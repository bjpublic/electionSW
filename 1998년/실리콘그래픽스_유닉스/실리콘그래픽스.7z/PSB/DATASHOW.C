/*******************************************************************/
/*                                                                  		*/
/*        data_dsp.c : �ݿ����� �ϴ��ڸ� Data Display Module    */
/*                                                                  		*/
/*                                                                  		*/
/*                     Copyright (c) 1996 by PSB Corp.              	*/
/******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Frame.h>
#include <X11/X.h>
#include <X11/cursorfont.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>


#include "videolib.h"
#include "typedef.h"
#include "scrinfo.h"
#include "path.h"
#include "photo.h"
#include "ref.h"
#include "datastru.h"

extern IMAGETMP      BkPanel[];
extern IMAGEBUF      BarImageBuf[];
extern IMAGEBUF      BandSpotImage[];
extern IMAGEBUF      CommonBkImageBuf[];
extern DWORD         H_BarImage[H_BAR_NUM][BAR_HGT];
extern unsigned long GET_IMGBuf[300 * LS_PANEL_H];

static int  CommandSearch(char *cmdStr, char *destStr);
static void DataErrorDisplay(int nScreen_id, char *cmdStr);
static void StartTypeDisplay(int ImgNo, char *cmdStr);
static void MainATypeDisplay(int ImgNo, char *cmdStr);
static void MainB1TypeDisplay(int ImgNo, char *cmdStr);
static void MainB2TypeDisplay(int ImgNo, char *cmdStr);
static void MainDTypeDisplay(int ImgNo, char *cmdStr);
static void MainETypeDisplay(int ImgNo, char *cmdStr);
static void MainFTypeDisplay(int ImgNo, char *cmdStr);
static void BandSpotATypeDisplay(int ImgNo, char *cmdStr);
static void BandSpotBTypeDisplay(int ImgNo, char *cmdStr);
static void BandSpotCTypeDisplay(int ImgNo, char *cmdStr);
static void BandSpotDTypeDisplay(int ImgNo, char *cmdStr);

static void DataADisplay(int ImgNo);
static void DataBDisplay(int ImgNo);
static void DataDDisplay(int ImgNo, int count);
static void DataEDisplay(int ImgNo, int count);
static void DataFDisplay(int ImgNo, int count, char *JungNum, int Eflag);

static DWORD TGABuf[SCREEN_WID*SCREEN_HGT];
static DWORD BandSpotBuf[5][SCREEN_WID*100];

int          dArray[50];
int          iArray[50];
int          dArrayCount;
int          iArrayCount;

STOCK_MENU_A StockMenuA;
STOCK_MENU_B StockMenuB[15];
STOCK_MENU_D StockMenuD;
STOCK_MENU_E StockMenuE[5];
STOCK_MENU_F StockMenuF[6];

/********************************************************************/
/* Function Name : CommandParsing(char *cmdStr)                  */
/* Description   : ���ŵ� Data File�� �ڷ� ������ Set�� ��          */
/*                 ȭ�鿡 Data�� ǥ���Ѵ�                       	  */
/********************************************************************/
void CommandParsing(char *cmdStr)
{

    SetDrawStringMode(ARISING_STRING_MODE);
    switch(cmdStr[1]) {
    case 'S':                   /* ��¥ǥ�ø� ���Ͽ�                */
        StartTypeDisplay(3, &cmdStr[3]);
        break;
    case 'A':                   /* ������ ����                      */
        MainATypeDisplay(3, &cmdStr[3]);
        break;
    case 'B':                   /* �ְ����� (�����ְ�����)          */
        MainB1TypeDisplay(4, &cmdStr[3]);
        break;
    case 'C':                   /* �ְ����� (�ŷ���)                */
        MainB2TypeDisplay(4, &cmdStr[3]);
        break;
    case 'D':                   /* ������ ���                      */
        MainDTypeDisplay(5, &cmdStr[3]);
        break;
    case 'E':                   /* ��������                       */
        MainETypeDisplay(6, &cmdStr[3]);
        break;
    case 'F':                   /* ���� ����,���,�ŷ���          */
        MainFTypeDisplay(7, &cmdStr[3]);
        break;
    case 'G':                   /* BAND SPOT                        */
        BandSpotATypeDisplay(0, &cmdStr[3]);
/*
        BandSpotATypeDisplay(0, &cmdStr[3]);
        BandSpotBTypeDisplay(0, &cmdStr[3]);
*/
/*
        BandSpotCTypeDisplay(0, &cmdStr[3]);
        BandSpotDTypeDisplay(0, &cmdStr[3]);
*/
        break;
    default:
        break;
    }
}

/********************************************************************/
/* Function Name : CommandSearch(char *cmdStr)                      */
/* Description   : ���ŵ� Data File���� Command�� ã�Ƽ�            */
/*                 Return�Ѵ�                                       */
/********************************************************************/
static int CommandSearch(char *cmdStr, char *destStr)
{
    int  i;
    int  j;
    int  len;
    char DataTmpBuf[1000];

    j = 0;
    len = strlen(cmdStr);
    memset(DataTmpBuf, 0x00, sizeof(DataTmpBuf));
    for(i = 0; i < len; i++)
    {
        if(cmdStr[i] == '*' || cmdStr[i] == '#') {
            DataTmpBuf[j] = 0x00;
            j++;
            break;
        }
        DataTmpBuf[j] = *(cmdStr + i);
        j++;
    }
    if(strlen(DataTmpBuf) > 0) { 
        strcpy(destStr, DataTmpBuf);
        return j;
    } 
    else {
        return 0;
    }
}
/********************************************************************/
/* Function Name : DataErrorDisplay(int nScreen_id,char *cmdStr)    */
/* Description   : ���ŵ� Data���� Error�߻��� ȭ�鿡 Display�Ѵ�   */
/********************************************************************/
static void DataErrorDisplay(int nScreen_id, char *cmdStr)
{
    Winset(nScreen_id);
    DrawStringCenterJustified(SCREEN_WID / 2, 100, cmdStr);
}

static void StartTypeDisplay(int ImgNo, char *cmdStr)
{
    int  ret;
    char tmpbuf[20];
    char DateBuf[20];

    memset(DateBuf, 0x00, sizeof(DateBuf));
    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    ret = CommandSearch(cmdStr, tmpbuf);
    memcpy(&DateBuf[0], &tmpbuf[0], 4);
    memcpy(&DateBuf[4], "�� ", 3);
    memcpy(&DateBuf[7], &tmpbuf[4], 2);
    memcpy(&DateBuf[9], "�� ", 3);
    memcpy(&DateBuf[12], &tmpbuf[6], 2);
    memcpy(&DateBuf[14], "�� ", 3);

    Winset(PAGE_ONAIR);
    SetFontMode(FONTMODE_DEFAULT);
    SetFontColor(RGB(254,246,150));
    SetHanFont(HAN_ROUNDHEAD, 48, 48);
    SetEngFont(ENG_HEADLINE, 48, 48);
    DrawStringCenterJustified(SCREEN_CENTER_X, SCREEN_CENTER_Y, DateBuf);
    sleep(3);
}

static void MainATypeDisplay(int ImgNo, char *cmdStr)
{
    int  ret;
    int  pos = 0;
    int  count = 0;
    char tmpbuf[100];

    memset(&StockMenuA, 0x00, sizeof(&StockMenuA));
    while(1) {
        memset(tmpbuf, 0x00, sizeof(tmpbuf));
        ret = CommandSearch(&cmdStr[pos], tmpbuf);
        if(ret == 0) break;

        switch(count % 4) {
        case 0:
            StockMenuA.JonghapJisu = atof(tmpbuf);
            break;
        case 1:
            StockMenuA.GeoreoRang = atol(tmpbuf);
            break;
        case 2:
            StockMenuA.GeoreoDaegum = atol(tmpbuf);
            break;
        case 3:
            StockMenuA.Dungrac = atof(tmpbuf);
            break;
        }
        count++;
        pos += ret;
    }
    DataADisplay(ImgNo);
}

static void MainB1TypeDisplay(int ImgNo, char *cmdStr)
{
    int  ret;
    int  pos = 0;
    char tmpbuf[100];

    dArrayCount = 0;
    memset(StockMenuB, 0x00, sizeof(StockMenuB));
    memset(dArray, 0x00, sizeof(dArray));
    while(1) {
        memset(tmpbuf, 0x00, sizeof(tmpbuf));
        ret = CommandSearch(&cmdStr[pos], tmpbuf);
        if(ret == 0) break;
        if(atoi(tmpbuf) < 1) break;

        StockMenuB[dArrayCount].JonghapJisu = atoi(tmpbuf);
        dArray[dArrayCount++] = StockMenuB[dArrayCount].JonghapJisu;
        pos += ret;
    }
    if(dArrayCount == iArrayCount)
        DataBDisplay(ImgNo);
}

static void MainB2TypeDisplay(int ImgNo, char *cmdStr)
{
    int  ret;
    int  pos = 0;
    char tmpbuf[100];

    iArrayCount = 0;
    memset(iArray, 0x00, sizeof(iArray));
    while(1) {
        memset(tmpbuf, 0x00, sizeof(tmpbuf));
        ret = CommandSearch(&cmdStr[pos], tmpbuf);
        if(ret == 0) break;
        if(atoi(tmpbuf) < 1) break;

        iArray[iArrayCount++] = atoi(tmpbuf);
        pos += ret;
    }
    if(dArrayCount == iArrayCount)
        DataBDisplay(ImgNo);
}

static void MainDTypeDisplay(int ImgNo, char *cmdStr)
{
int i;
    int  ret;
    int  pos = 0;
    int  count = 0;
    char tmpbuf[100];

    memset(&StockMenuD, 0x00, sizeof(&StockMenuD));
    while(1) {
        switch(count % 2) {
        case 0:
            ret = CommandSearch(&cmdStr[pos], StockMenuD.BupjongName[count/2]);
            break;
        case 1:
            memset(tmpbuf, 0x00, sizeof(tmpbuf));
            ret = CommandSearch(&cmdStr[pos], tmpbuf);
            StockMenuD.Persent[count/2] = atof(tmpbuf);
            break;
        }
        if(ret == 0) break;
        count++;
        pos += ret;
    }
    DataDDisplay(ImgNo, count / 2);
}

static void MainETypeDisplay(int ImgNo, char *cmdStr)
{
    int  ret;
    int  pos = 0;
    int  count = 0;
    char tmpbuf[100];

    memset(StockMenuE, 0x00, sizeof(StockMenuE));
    while(1) {
        if(!(count % 2)) {
            ret = CommandSearch(&cmdStr[pos], StockMenuE[count / 2].Name);
        }
        else {
            memset(tmpbuf, 0x00, sizeof(tmpbuf));
            ret = CommandSearch(&cmdStr[pos], tmpbuf);
            StockMenuE[count/2].Value = atoi(tmpbuf);
        }
        if(ret == 0) break;
        count++;
        pos += ret;
    }
    DataEDisplay(ImgNo, count / 2);
}

static void MainFTypeDisplay(int ImgNo, char *cmdStr)
{
    int  ret, endflag;
    int  pos = 0;
    int  count = 0;
    char tmpbuf[100];
    char JongNumStr[20];

    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    ret = CommandSearch(&cmdStr[pos], tmpbuf);
    pos += ret;
    endflag = atoi(tmpbuf);

    memset(StockMenuF, 0x00, sizeof(StockMenuF));
    memset(JongNumStr, 0x00, sizeof(JongNumStr));
    ret = CommandSearch(&cmdStr[pos], JongNumStr);
    pos += ret;
    while(1) {
        switch(count % 5) {
        case 0:
            ret = CommandSearch(&cmdStr[pos], StockMenuF[count/5].JongName);
            break;
        case 1:
            memset(tmpbuf, 0x00, sizeof(tmpbuf));
            ret = CommandSearch(&cmdStr[pos], tmpbuf);
            StockMenuF[count/5].JongGa = atol(tmpbuf);
            break;
        case 2:
            memset(tmpbuf, 0x00, sizeof(tmpbuf));
            ret = CommandSearch(&cmdStr[pos], tmpbuf);
            StockMenuF[count/5].Flag = atoi(tmpbuf);
            break;
        case 3:
            memset(tmpbuf, 0x00, sizeof(tmpbuf));
            ret = CommandSearch(&cmdStr[pos], tmpbuf);
            StockMenuF[count/5].Dungrac = atoi(tmpbuf);
            break;
        case 4:
            memset(tmpbuf, 0x00, sizeof(tmpbuf));
            ret = CommandSearch(&cmdStr[pos], tmpbuf);
            StockMenuF[count/5].GeoreoRang = atol(tmpbuf);
            break;
        default:
            ret = 0;
            break;
        }
        if(ret == 0) break;
        count++;
        pos += ret;
    }
    DataFDisplay(ImgNo, count / 5, &JongNumStr[0], endflag);
}

static void DataADisplay(int ImgNo)
{
    int  x, y, no, len;
    char tmpbuf[50];

    y = 50;
    SetFontMode(FONTMODE_DEFAULT);
    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    Winset(PAGE_PREVIEW);
    PutImage(0,0,CommonBkImageBuf[ImgNo].wid,
                 CommonBkImageBuf[ImgNo].hgt, CommonBkImageBuf[ImgNo].bufptr);
    DrawStringCenterJustified(SCREEN_CENTER_X, y, "������ ����");
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);

    x = 220;
    SetHanFont(HAN_ROUNDHEAD, 36, 48);
    SetEngFont(ENG_HEADLINE, 36, 48);
    y = 168;
    SetFontColor(RGB(209,243,255));
    if(StockMenuA.JonghapJisu < 1000.00)
        DrawString(x-2, y, "�����ְ�����");
    else
        DrawString(x-2, y, "�����ְ�");
    y = 258;
    SetFontColor(COLOR_WHITE);
    DrawString(x, y, "�� �� ��");
    y = 345;
    DrawString(x, y, "�ŷ����");

    x = 573;
    SetFontColor(RGB(254,246,150));
    SetHanFont(HAN_ROUNDHEAD, 36, 48);
    SetEngFont(ENG_HEADLINE, 36, 48);
/*
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
*/
    y = 168;
    sprintf(tmpbuf, "%7.2f", StockMenuA.JonghapJisu);
    DrawStringRightJustified(x+10, y, tmpbuf);
    y = 258;
    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    memcpy(tmpbuf, FormatNumber(StockMenuA.GeoreoRang), sizeof(tmpbuf));
    DrawStringRightJustified(x-80, y, tmpbuf);
    SetFontColor(COLOR_WHITE);
    DrawStringRightJustified(x, y, "����");
    y = 345;
    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    memcpy(tmpbuf, FormatNumber(StockMenuA.GeoreoDaegum), sizeof(tmpbuf));
    SetFontColor(RGB(254,246,150));
    DrawStringRightJustified(x-80, y, tmpbuf);
    SetFontColor(COLOR_WHITE);
    DrawStringRightJustified(x, y, "���");

    if(StockMenuA.Dungrac == 0.0) {
        SetFontColor(COLOR_WHITE);
        DrawStringCenterJustified(130, 220, "�� ��");
        SetFontColor(RGB(254,246,150));
        SetHanFont(HAN_ROUNDHEAD, 30, 40);
        SetEngFont(ENG_HEADLINE, 30, 40);
        DrawStringCenterJustified(130, 285, "0.00");
        sleep(20);
        return;
    }
    SetFontColor(RGB(254,246,150));
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    SetPhotoMode(V_SMALL);
    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    if(StockMenuA.Dungrac > 0.0) {
        no = 1;
        DrawMovingPhoto(82,190,CommonBkImageBuf[no].wid,
                        CommonBkImageBuf[no].hgt, CommonBkImageBuf[no].bufptr, UPWARD, 1, 100L);
    }
    else {
        no = 2;
        DrawMovingPhoto(82,190,CommonBkImageBuf[no].wid,
                        CommonBkImageBuf[no].hgt, CommonBkImageBuf[no].bufptr, DOWNWARD, 1, 100L);
    }
    sprintf(tmpbuf, "%6.2f", StockMenuA.Dungrac);
    DrawStringCenterJustified(120, 310, tmpbuf);
    sleep(20);
}

static void DataBDisplay(int ImgNo)
{
    char   buf[10];
    int    i, j, k, yPos, xPos, time;
    int    x1, y1, x2, y2;
    int    min_x, min_y;
    int    min, max, term;
    double num_dot;

    if(dArrayCount < 1) {
        dArrayCount  = 0;
        iArrayCount  = 0;
        return;
    }

    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    Winset(PAGE_PREVIEW);
    PutImage(0,0,CommonBkImageBuf[ImgNo].wid,
                 CommonBkImageBuf[ImgNo].hgt, CommonBkImageBuf[ImgNo].bufptr);
    DrawStringCenterJustified(SCREEN_CENTER_X, 50, "������ �ְ�����");
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);

sleep(3);

/* Draw */
                                /* �ְ����� (�����ְ�����)          */
    xPos = 130;
    yPos = SCREEN_CENTER_Y + 20;
    SetFontColor(RGB(254,246,150));
    SetHanFont(HAN_ROUNDHEAD, 24, 24);
    SetEngFont(ENG_HEADLINE, 24, 24);
    DrawStringRightJustified(SCREEN_WID-70, 125, "�����ְ�����");

                                /* �ְ����� (�ŷ���)                */
    xPos = 130;
    yPos = SCREEN_HGT - 70;
    DrawStringRightJustified(SCREEN_WID-70, 277, "�ŷ��� (����: ����)");
    DrawStringRightJustified(SCREEN_WID-63, yPos + 5, "��");

                                /* �ְ����� (�����ְ�����)          */
    SetFontColor(COLOR_WHITE);
    xPos = 140;
    yPos = SCREEN_CENTER_Y + 20;
/*
    min = GetMinValue(dArray, dArrayCount);
    max = GetMaxValue(dArray, dArrayCount);
    min = (int)(min / 10) * 10;
    max = (int)((max + 5) / 10) * 10;
    term = (max - min) / 2;
    num_dot = (double)(70.0 / (double)(max - min));
*/
min = 620;
max = 700;
term = 40;
num_dot = (12.0 / (double)term) * 3.0;

    min_x = xPos - 15;
    min_y = yPos - 45;

    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 24, 24);
    SetEngFont(ENG_HEADLINE, 24, 24);
    for(i = 2; i >= 0; i--) {
        memset(buf, 0x00, sizeof(buf));
        sprintf(buf, "%d", min + (term * i));
        x1 = min_x;
        y1 = min_y - (int)((term * i) * num_dot);

        DrawStringRightJustified(x1, y1, buf);
        x1 += 13;
        y1 += 12;
        for(j = 0; j < 3; j++) {
            DrawThinLine(x1,y1+j-1,x1+3,y1+j-1,RGB(0,48,131));
        }
    }
    min_y = y1;

    x1 = xPos + 30;
    y1 = min_y - (int)((double)(dArray[0] - min) * num_dot);
    for(i = 1; i < dArrayCount; i++) {
        x2 = x1 + 37;
        y2 = min_y - (int)((double)(dArray[i] - min) * num_dot);
        for(j = 0; j < 5; j++) {
            DrawThinLine(x1,y1+j-2,x2,y2+j-2,RGB(181,32,55));
        }
        for(j = 5; j < 7; j++) {
            DrawThinLine(x1,y1+(j-2),x2,y2+(j-2),RGB(0,0,0));
        }
        x1 = x2;
        y1 = y2;
        DelayLoop(1000);
    }

                                /* �ְ����� (�ŷ���)                */
    xPos = 140;
    yPos = SCREEN_HGT - 70;
    min = GetMinValue(iArray, iArrayCount);
    max = GetMaxValue(iArray, iArrayCount);
    min = (int)(min / 100) * 100;
    max = (int)((max + 50) / 100) * 100;
    term = (max - min) / 3;
    num_dot = (double)(84.0 / (double)(max - min));
    min_x = xPos - 15;
    min_y = yPos - 35;

    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 24, 24);
    SetEngFont(ENG_HEADLINE, 24, 24);
    for(i = 3; i >= 0; i--) {
        x1 = min_x;
        y1 = min_y - (28 * i);
        memset(buf, 0x00, sizeof(buf));
        sprintf(buf, "%d", min + (term * i));
        DrawStringRightJustified(x1, y1, buf);
        x1 += 13;
        y1 += 12;
        for(j = 0; j < 3; j++) {
            DrawThinLine(x1,y1+j-1,x1+3,y1+j-1,RGB(0,48,131));
        }
    }
    min_y = y1;

    SetHanFont(HAN_ROUNDHEAD, 24, 24);
    SetEngFont(ENG_HEADLINE, 24, 24);
    time = 10;
    yPos = SCREEN_HGT - 70;
    x2 = xPos + 20;
    for(i = 0; i < iArrayCount; i++) {
        y2 = min_y - (int)((double)(iArray[i] - min) * num_dot);
        if(!(i % 2)) {
            memset(buf, 0x00, sizeof(buf));
            sprintf(buf, "%d", time);
            DrawStringCenterJustified(x2+10, yPos + 7, buf);
            if(time == 12) time = 2;
            else           time++;
        }
        k = yPos - 10 - y2;
        for(j = 0; j < k; j++) {
            PutImage(x2, yPos - 14 - j, BarImageBuf[2].wid, 1,
                                 BarImageBuf[2].bufptr);
            DelayLoop(50);
        }
        x2 = x2 + 37;
    }
    dArrayCount  = 0;
    iArrayCount  = 0;
    sleep(2);
}

static void DataDDisplay(int ImgNo, int count)
{
    char   tmpbuf[100];
    int    i, j, x, y;
    int    end, xPos; 
    double dmin, dmax;
    double num_dot;

    if(count < 2) return;

    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    Winset(PAGE_PREVIEW);
    PutImage(0,0,CommonBkImageBuf[ImgNo].wid,
                 CommonBkImageBuf[ImgNo].hgt, CommonBkImageBuf[ImgNo].bufptr);
    DrawStringCenterJustified(SCREEN_CENTER_X, 50, "������ ���");
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);

    xPos = SCREEN_CENTER_X + 70;
    GetMinDoubleValue(&StockMenuD.Persent, count, &dmin);
    GetMaxDoubleValue(&StockMenuD.Persent, count, &dmax);
    num_dot = (70.0 / dmax);

    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 30);
    SetEngFont(ENG_HEADLINE, 30, 30);
    for(i = 0; i < count; i++) {
        y = 150 + (i * 45);
        DrawStringCenterJustified(SCREEN_CENTER_X, y, StockMenuD.BupjongName[i]);
    }

    SetFontColor(RGB(254,246,150));
    SetHanFont(HAN_ROUNDHEAD, 24, 30);
    SetEngFont(ENG_HEADLINE, 24, 30);
    for(i = 0; i < count; i++) {
        y = 150 + (i * 45);
        end = (int)(abs(StockMenuD.Persent[i] * num_dot));
        memset(tmpbuf, 0x00, sizeof(tmpbuf));
        sprintf(tmpbuf, "%7.2f%%", StockMenuD.Persent[i]);
        if(StockMenuD.Persent[i] >= 0.00) {
            x = xPos;
            for(j = 0; j < end; j++) {
                PutImage(x, y, 1, BAR_HGT, &H_BarImage[1][0]);
                DelayLoop(50);
                x++;
            }
            DrawString(x - 20, y+2, tmpbuf);
        }
        else {
            x = SCREEN_CENTER_X - 70;
            for(j = 0; j < end; j++) {
                PutImage(x, y, 1, BAR_HGT, &H_BarImage[0][0]);
                DelayLoop(50);
                x--;
            }
            DrawStringRightJustified(x - 5, y+2, tmpbuf);
        }
    }
    sleep(2);
}

static void DataEDisplay(int ImgNo, int count)
{
    int  i, x, y;
    char tmpbuf[20];

    y = 50;
    SetFontMode(FONTMODE_DEFAULT);
    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    Winset(PAGE_PREVIEW);
    PutImage(0,0,CommonBkImageBuf[ImgNo].wid,
                 CommonBkImageBuf[ImgNo].hgt, CommonBkImageBuf[ImgNo].bufptr);
    DrawStringCenterJustified(SCREEN_CENTER_X, y, "��� �����");
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);

    for(i = 0; i < count; i++) {
        SetEngFont(ENG_HEADLINE, 36, 48);
        SetHanFont(HAN_ROUNDHEAD, 36, 48);
        y = 160 + (i/2) * 100;
        if(!(i%2)) x = 118; 
        else       x = 390; 
        switch((int)(i/2)) {
            case 0:
                SetFontColor(RGB(209,243,255));
                break;
            case 1:
                SetFontColor(RGB(177,253,206));
                break;
            case 2:
                SetFontColor(COLOR_WHITE);
                break;
        }

        DrawStringCenterJustified(x, y, StockMenuE[i].Name);
        SetFontColor(RGB(254,246,150));
        DrawStringRightJustified(x + 185, y, FormatNumber(StockMenuE[i].Value));
/*
        SetHanFont(HAN_ROUNDHEAD, 30, 40);
        SetEngFont(ENG_HEADLINE, 30, 40);
        memset(tmpbuf, 0x00, sizeof(tmpbuf));
        sprintf(tmpbuf, "%d", StockMenuE[i].Value);
        DrawStringRightJustified(x + 148, y+4, tmpbuf);

        SetFontColor(COLOR_WHITE);
        SetEngFont(ENG_HEADLINE, 36, 48);
        SetHanFont(HAN_ROUNDHEAD, 36, 48);
        DrawStringRightJustified(x + 185, y, "��");
*/
    }
    sleep(2);
}

static void DataFDisplay(int ImgNo, int count, char *JungNum, int Eflag)
{
    int  i, x, y;
    char tmpbuf[20];
/*
    static int   FtypeStart = 0;

    if(FtypeStart == 0) {
*/
        SetDrawStringMode(LANDING_STRING_MODE);
        SetFontMode(FONTMODE_DEFAULT);
        SetFontColor(COLOR_WHITE);
        SetHanFont(HAN_ROUNDHEAD, 30, 40);
        SetEngFont(ENG_HEADLINE, 30, 40);
        Winset(PAGE_PREVIEW);
        PutImage(0,0,CommonBkImageBuf[ImgNo].wid,
                 CommonBkImageBuf[ImgNo].hgt, CommonBkImageBuf[ImgNo].bufptr);
        SetFontColor(RGB(209,243,255));
        SetHanFont(HAN_ROUNDHEAD, 24, 30);
        SetEngFont(ENG_HEADLINE, 24, 30);
        y = 62;
        x = 118;
        DrawStringCenterJustified(x, y, JungNum);
        x = 251;
        DrawStringCenterJustified(x, y, "�� ��");
        x = 390;
        DrawStringCenterJustified(x, y, "�� ��");
        x = 528;
        DrawStringCenterJustified(x, y, "�ŷ���");
        GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
        Winset(PAGE_ONAIR);
        DesolveScreen(0, TGABuf);
/*
        FtypeStart = 1;
    }
    else {
        SetFontColor(RGB(209,243,255));
        SetHanFont(HAN_ROUNDHEAD, 24, 30);
        SetEngFont(ENG_HEADLINE, 24, 30);
        Winset(PAGE_ONAIR);
        DesolveScreen(0, TGABuf);
        y = 62;
        x = 118;
        DrawStringCenterJustified(x, y, JungNum);
    }
*/

    for(i = 0; i < count; i++) {
        y = 113 + i * 54;
        x = 118;
        SetFontColor(RGB(254,246,150));
        DrawStringCenterJustified(x, y, StockMenuF[i].JongName);
        x = 311;
        SetFontColor(COLOR_WHITE);
        DrawStringRightJustified(x, y, FormatNumber(StockMenuF[i].JongGa));
        x = 327;
        switch(StockMenuF[i].Flag) { 
        case 1:
                PutImage(x,y,CommonBkImageBuf[8].wid,
                         CommonBkImageBuf[8].hgt,
                         CommonBkImageBuf[8].bufptr);
                break;
        case 2:
                PutImage(x,y,CommonBkImageBuf[9].wid,
                         CommonBkImageBuf[9].hgt,
                         CommonBkImageBuf[9].bufptr);
                break;
        case 3:
                PutImage(x+3,y,CommonBkImageBuf[10].wid,
                         CommonBkImageBuf[10].hgt,
                         CommonBkImageBuf[10].bufptr);
                break;
        case 4:
                PutImage(x+3,y,CommonBkImageBuf[11].wid,
                         CommonBkImageBuf[11].hgt,
                         CommonBkImageBuf[11].bufptr);
                break;
        default:
                break;
        }

        x = 450;
        DrawStringRightJustified(x, y, FormatNumber(StockMenuF[i].Dungrac));
        x = 582;
        if(StockMenuF[i].GeoreoRang > 999999L) {
            SetHanFont(HAN_ROUNDHEAD, 20, 30);
            SetEngFont(ENG_HEADLINE, 20, 30);
            DrawStringRightJustified(x, y, FormatNumber(StockMenuF[i].GeoreoRang));
            SetHanFont(HAN_ROUNDHEAD, 24, 30);
            SetEngFont(ENG_HEADLINE, 24, 30);
        }
        else {
            DrawStringRightJustified(x, y, FormatNumber(StockMenuF[i].GeoreoRang));
        }
    }
    if(!Eflag) {
        for(i = 0; i < 3; i++) {
            PutImage(50,315,CommonBkImageBuf[BACK_IMAGE_NUM-2].wid,
                 CommonBkImageBuf[BACK_IMAGE_NUM-2].hgt,
                 CommonBkImageBuf[BACK_IMAGE_NUM-2].bufptr);

            DelayLoop(15000L);
            PutImage(130,330,CommonBkImageBuf[BACK_IMAGE_NUM-1].wid,
                 CommonBkImageBuf[BACK_IMAGE_NUM-1].hgt,
                 CommonBkImageBuf[BACK_IMAGE_NUM-1].bufptr);

            DelayLoop(15000L);
        }
        sleep(5);
    }
    else {
        DelayLoop(100000L);
    }
}

static void BandSpotATypeDisplay(int ImgNo, char *cmdStr)
{
    int  i, ret;
    int  pos, count, BandIndex;
    char tmpbuf[10][50];

    pos = count = 0;
    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    while(1) {
        ret = CommandSearch(&cmdStr[pos], &tmpbuf[count][0]);
        if(!ret) break;
        count ++;
        pos += ret;
    }

    SetDrawStringMode(DOWN_STRING_MODE);
    SetFontMode(FONTMODE_DEFAULT);
    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 30);
    SetEngFont(ENG_HEADLINE, 30, 30);
    Winset(PAGE_PREVIEW);
    PutImage(0,0,BandSpotImage[ImgNo].wid,
                 BandSpotImage[ImgNo].hgt, BandSpotImage[ImgNo].bufptr);

    BandIndex = 2;
    for(i = 0; i < count; i++) {
        PutImage(90,120 + i * 80, BandSpotImage[BandIndex+4].wid,
                 BandSpotImage[BandIndex+4].hgt,
                 BandSpotImage[BandIndex+4].bufptr);
    }
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);

    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    Winset(PAGE_PREVIEW);
    for(i = 1; i < count; i++) {
        SetFontColor(RGB(156,156,180));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
    }
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);
    sleep(3);

    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    for(i = 0; i < count; i++) {
        for(ret = 0; ret < 6; ret++) {
            for(pos = 0; pos < 5; pos++) {
                PutImage(90,120 + i * 80,BandSpotImage[BandIndex+pos].wid,
                         BandSpotImage[BandIndex+pos].hgt,
                         BandSpotImage[BandIndex+pos].bufptr);
                DelayLoop(400);
            }
        }
        SetFontColor(COLOR_YELLOW);
        SetFontColor(RGB(254,246,150));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
        sleep(30);
        Winset(PAGE_PREVIEW);
        SetFontColor(RGB(156,156,180));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
        GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
        Winset(PAGE_ONAIR);
        DesolveScreen(0, TGABuf);
    }
}

static void BandSpotBTypeDisplay(int ImgNo, char *cmdStr)
{
    int  i, ret;
    int  pos, count, BandIndex;
    char tmpbuf[10][50];

    pos = count = 0;
    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    while(1) {
        ret = CommandSearch(&cmdStr[pos], &tmpbuf[count][0]);
        if(!ret) break;
        count ++;
        pos += ret;
    }

    SetDrawStringMode(DOWN_STRING_MODE);
    SetFontMode(FONTMODE_DEFAULT);
    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 30);
    SetEngFont(ENG_HEADLINE, 30, 30);
    Winset(PAGE_PREVIEW);
    PutImage(0,0,BandSpotImage[ImgNo].wid,
                 BandSpotImage[ImgNo].hgt, BandSpotImage[ImgNo].bufptr);

    BandIndex = 2;
    for(i = 0; i < count; i++) {
        PutImage(90,120 + i * 80, BandSpotImage[BandIndex+4].wid,
                 BandSpotImage[BandIndex+4].hgt,
                 BandSpotImage[BandIndex+4].bufptr);
    }
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);

    sleep(3);
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    for(i = 0; i < count; i++) {
        for(ret = 0; ret < 6; ret++) {
            for(pos = 0; pos < 5; pos++) {
                PutImage(90,120 + i * 80,BandSpotImage[BandIndex+pos].wid,
                         BandSpotImage[BandIndex+pos].hgt,
                         BandSpotImage[BandIndex+pos].bufptr);
                DelayLoop(400);
            }
        }
        SetFontColor(COLOR_YELLOW);
        SetFontColor(RGB(254,246,150));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
        sleep(30);
        Winset(PAGE_PREVIEW);
        SetFontColor(RGB(156,156,180));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
        GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
        Winset(PAGE_ONAIR);
        DesolveScreen(0, TGABuf);
    }
}

static void BandSpotCTypeDisplay(int ImgNo, char *cmdStr)
{
    int  i, ret;
    int  pos, count, BandIndex;
    char tmpbuf[10][50];

    pos = count = 0;
    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    while(1) {
        ret = CommandSearch(&cmdStr[pos], &tmpbuf[count][0]);
        if(!ret) break;
        count ++;
        pos += ret;
    }

    SetDrawStringMode(DOWN_STRING_MODE);
    SetFontMode(FONTMODE_DEFAULT);
    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 30);
    SetEngFont(ENG_HEADLINE, 30, 30);
    Winset(PAGE_PREVIEW);
    PutImage(0,0,BandSpotImage[ImgNo].wid,
                 BandSpotImage[ImgNo].hgt, BandSpotImage[ImgNo].bufptr);

    BandIndex = 2;
    for(i = 0; i < count; i++) {
        PutImage(90,120 + i * 80, BandSpotImage[BandIndex+4].wid,
                 BandSpotImage[BandIndex+4].hgt,
                 BandSpotImage[BandIndex+4].bufptr);
    }
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);

    sleep(3);
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    for(i = 0; i < count; i++) {
        Winset(PAGE_PREVIEW);
        SetFontColor(COLOR_YELLOW);
        SetFontColor(RGB(254,246,150));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
        SlowDisplay(90, 120+i*80,BandSpotImage[BandIndex].wid,BandSpotImage[BandIndex].hgt, RIGHT, 3, 100L);

        sleep(30);

        Winset(PAGE_PREVIEW);
        SetFontColor(RGB(156,156,180));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
        SlowDisplay(90, 120+i*80,BandSpotImage[BandIndex].wid,BandSpotImage[BandIndex].hgt, LEFT, 3, 100L);

    }
}

static void BandSpotDTypeDisplay(int ImgNo, char *cmdStr)
{
    int  i, ret;
    int  pos, count, BandIndex;
    char tmpbuf[10][50];

    pos = count = 0;
    memset(tmpbuf, 0x00, sizeof(tmpbuf));
    while(1) {
        ret = CommandSearch(&cmdStr[pos], &tmpbuf[count][0]);
        if(!ret) break;
        count ++;
        pos += ret;
    }

    SetDrawStringMode(DOWN_STRING_MODE);
    SetFontMode(FONTMODE_DEFAULT);
    SetFontColor(COLOR_WHITE);
    SetHanFont(HAN_ROUNDHEAD, 30, 30);
    SetEngFont(ENG_HEADLINE, 30, 30);
    Winset(PAGE_PREVIEW);
    PutImage(0,0,BandSpotImage[ImgNo].wid,
                 BandSpotImage[ImgNo].hgt, BandSpotImage[ImgNo].bufptr);

    BandIndex = 2;
    for(i = 0; i < count; i++) {
        PutImage(90,120 + i * 80, BandSpotImage[BandIndex+4].wid,
                 BandSpotImage[BandIndex+4].hgt,
                 BandSpotImage[BandIndex+4].bufptr);
    }
    GetImage(0,0,SCREEN_WID,SCREEN_HGT,TGABuf);
    Winset(PAGE_ONAIR);
    DesolveScreen(0, TGABuf);

    sleep(3);
    SetHanFont(HAN_ROUNDHEAD, 30, 40);
    SetEngFont(ENG_HEADLINE, 30, 40);
    for(i = 0; i < count; i++) {
        Winset(PAGE_PREVIEW);
        SetFontColor(COLOR_YELLOW);
        SetFontColor(RGB(254,246,150));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
        ScrollDisplay(90, 120+i*80,BandSpotImage[BandIndex].wid,BandSpotImage[BandIndex].hgt, LEFT, 3, 100L);

        sleep(30);

        Winset(PAGE_PREVIEW);
        SetFontColor(RGB(156,156,180));
        DrawStringCenterJustified(SCREEN_CENTER_X, 130+i*80, &tmpbuf[i][0]);
        SlowDisplay(90, 120+i*80,BandSpotImage[BandIndex].wid,BandSpotImage[BandIndex].hgt, RIGHT, 3, 100L);
    }
}
 