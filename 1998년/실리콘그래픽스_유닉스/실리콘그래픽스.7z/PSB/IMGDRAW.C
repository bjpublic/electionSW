/********************************************************************/
/*                                                                  */
/*          imgdraw.c : ȭ�������� �⺻�Լ����� ���ִ� ����       */ 
/*                                                                  */
/*                                                                  */
/*                  Copyright (c) 1996 by PSB Corp.                            */
/********************************************************************/

#include <Xm/Xm.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "videolib.h"
#include "typedef.h"
#include "readtga.h"
#include "ref.h"
#include "scrinfo.h"

/***********************************************************************/
/* �⺻ ȭ�� ó�� ���� �Լ��� (�����(����), ���׸���, ���� �ޱ�)    */
/***********************************************************************/

#define DESOLVE_LEVEL 10
#define	BAND_HGT      50
#define	BAND_SPACE     4

        /* ȭ��� �̹����� ������ ��Ÿ���� �Լ� */
void DesolveScreen(int mode, unsigned long *pBuf)
{
    int i, j, k, h, alpha;
    static unsigned char AlphaTable[DESOLVE_LEVEL] = {
                         16, 32, 48, 64, 80, 96, 128, 160, 192, 255 };
    unsigned long *p;

    switch (mode) {
    case 0:
        for (i = 1; i <= DESOLVE_LEVEL; i+=2) {
            alpha = (AlphaTable[i] << 24) & 0xff000000;
            p = pBuf;
            for (j = 0; j < SCREEN_WID*SCREEN_HGT; j++, p++) {
                *p = (*p & 0x00ffffff) | alpha;
            }
            PutImage(0,0,SCREEN_WID,SCREEN_HGT,pBuf);
        }
        break;

            /* ȭ���� ������κ��� �ϴ����� ���ݾ� ǥ���� ������. */
    case 1:
        for (i = 0; i < SCREEN_HGT; i += BAND_SPACE) {
            p = &pBuf[i*SCREEN_WID];
            for (j = 0; j < BAND_HGT; j++) {
                if (i + j >= SCREEN_HGT)
                    break;
                if (j < BAND_SPACE)
                    alpha = 0xff000000;
                else {
                    k = 255 - (j * 256 / BAND_HGT);
                    alpha = (k << 24) & 0xff000000;
                }
                for (k = 0; k < SCREEN_WID; k++, p++)
                    *p = (*p & 0x00ffffff) | alpha;
            }
            if (i > SCREEN_HGT - BAND_HGT)
                h = SCREEN_HGT - i;
            else
                h = BAND_HGT;
            PutImage(0, i, SCREEN_WID, h, &pBuf[i*SCREEN_WID]);
        }
        break;
    }
}


 